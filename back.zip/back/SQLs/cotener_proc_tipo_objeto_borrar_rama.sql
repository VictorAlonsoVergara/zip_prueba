create or replace procedure borrar_rama_tipo_objeto (id IN INTEGER , borrados INOUT INTEGER[])
LANGUAGE plpgsql
AS $$
DECLARE
	array_len INTEGER;
	padre_rec record;
	index INTEGER := 1;
	array_padres INTEGER[];
	array_hijos INTEGER[];
BEGIN
	FOR padre_rec IN (select * from "MAT_TIPO_OBJ" where tobj_padre_id = id) LOOP
		SELECT array_append(array_padres,padre_rec.tobj_padre_id) INTO array_padres;
		SELECT array_append(array_hijos,padre_rec.tobj_id) INTO array_hijos;
	END LOOP;
	IF array_length(array_padres,1) > 0 THEN
		array_len := array_upper(array_padres,1);
		WHILE index <= array_len LOOP
			FOR padre_rec IN (select * from "MAT_TIPO_OBJ" where tobj_padre_id = array_hijos[index]) LOOP
				SELECT array_append(array_padres,padre_rec.tobj_padre_id) INTO array_padres;
				SELECT array_append(array_hijos,padre_rec.tobj_id) INTO array_hijos;
				array_len := array_upper(array_padres,1);
			END LOOP;
			index := index + 1;
		END LOOP;

		SELECT array_prepend(id,array_hijos) INTO array_hijos;
		borrados := array_hijos;
		index := array_len+1;
		WHILE index > 0 LOOP
			DELETE FROM "MAT_TIPO_OBJ" WHERE tobj_id = array_hijos[index];
			index := index - 1;
		END LOOP;
	ELSE
		borrados := ARRAY [id];
		DELETE FROM "MAT_TIPO_OBJ" WHERE tobj_id = id;
	END IF;
END $$;