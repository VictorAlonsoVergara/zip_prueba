create or replace view view_crons_consultas_objetos as
select cron.cron_id,cons.con_trama_pregunta,
		prot.prot_abreviacion,obj.obj_id,obj.obj_ip_address,obj.obj_usuario,obj.obj_password
from "MAE_CRON" as cron 
join "MAE_CONSULTAS" as cons on cons.cron_id = cron.cron_id
join "MAE_OBJETOS" as obj on obj.tobj_id = cons.tobj_id and obj.prot_id = cons.prot_id and obj.mod_id = cons.mod_id
join "TAB_PROTOCOLO" as prot on prot.prot_id = cons.prot_id
where cron.cron_estado = 'A' and obj.obj_estado = 'A'
order by cron.cron_id,cons.con_id,obj.obj_id;