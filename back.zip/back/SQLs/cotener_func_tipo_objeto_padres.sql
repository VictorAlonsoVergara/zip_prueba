create or replace function buscar_padres_tipo_objeto (id INTEGER)
	RETURNS TABLE (
		id_nodo INTEGER,
		id_padre INTEGER
)
AS $$
DECLARE
	salir INTEGER := 1;
	padre INTEGER;
	hijo INTEGER;
BEGIN
	salir := 1;
	hijo := id;
	WHILE salir > 0 LOOP
		padre := (select tobj_padre_id from "MAT_TIPO_OBJ" where tobj_id = hijo limit 1);
		id_nodo := hijo;
		id_padre := padre;
		IF id_padre IS NULL THEN
			salir := 0;
		END IF;
		hijo := padre;
		RETURN NEXT;
	END LOOP;
END $$
LANGUAGE plpgsql;