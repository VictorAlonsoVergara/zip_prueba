--UPDATE "TAB_MENU" SET menu_ord = 1  where menu_name = 'Tipo Usuario';
--UPDATE "TAB_MENU" SET menu_ord = 2  where menu_name = 'Usuarios';
--UPDATE "TAB_MENU" SET menu_ord = 3  where menu_name = 'Usuarios Menu';
--UPDATE "TAB_MENU" SET menu_ord = 4  where menu_name = 'Usuario Acceso Arboles';
--UPDATE "TAB_MENU" SET menu_ord = 5  where menu_name = 'Usuario Alertas';
--UPDATE "TAB_MENU" SET menu_ord = 6  where menu_name = 'Usuario Acceso Reportes';
--UPDATE "TAB_MENU" SET menu_ord = 7  where menu_name = 'Tipo Objeto';
--UPDATE "TAB_MENU" SET menu_ord = 8  where menu_name = 'Marcas';
--UPDATE "TAB_MENU" SET menu_ord = 9  where menu_name = 'Modelos';
--UPDATE "TAB_MENU" SET menu_ord = 10 where menu_name = 'Protocolos';
--UPDATE "TAB_MENU" SET menu_ord = 11 where menu_name = 'Objetos';
--UPDATE "TAB_MENU" SET menu_ord = 12 where menu_name = 'Consultas';
--UPDATE "TAB_MENU" SET menu_ord = 13 where menu_name = 'Idiomas';
--UPDATE "TAB_MENU" SET menu_ord = 14 where menu_name = 'Areas';
--UPDATE "TAB_MENU" SET menu_ord = 15 where menu_name = 'Arboles Fisicos';
--UPDATE "TAB_MENU" SET menu_ord = 16 where menu_name = 'Arboles Logicos';
--UPDATE "TAB_MENU" SET menu_ord = 17 where menu_name = 'Cron';
--UPDATE "TAB_MENU" SET menu_ord = 18 where menu_name = 'Objetos Fisicos';
--UPDATE "TAB_MENU" SET menu_ord = 19 where menu_name = 'Objetos Logicos';
--UPDATE "TAB_MENU" SET menu_ord = 20 where menu_name = 'Reportes';
--UPDATE "TAB_MENU" SET menu_ord = 21 where menu_name = 'Acciones';
--UPDATE "TAB_MENU" SET menu_ord = 22 where menu_name = 'Menu';
--UPDATE "TAB_MENU" SET menu_ord = 23 where menu_name = 'Acciones usuario';
--UPDATE "TAB_MENU" SET menu_ord = 24 where menu_name = 'Ejecuciones';
INSERT INTO "TAB_MENU" (menu_desc,menu_name,menu_ord) VALUES
('Permiso para tipo de usuario','Tipo Usuario',1),
('Permiso para crons','Cron',17),
('Permiso para Tipo de objetos','Tipo Objeto',7),
('Permiso para ejecuciones','Ejecuciones',24),
('Permiso para consultas','Consultas',12),
('Permiso para reportes','Reportes',20),
('Permiso para objetos','Objetos',11),
('Permiso para accesos a reportes','Usuario Acceso Reportes',6),
('Permiso para alertas de usuario','Usuario Alertas',5),
('Permiso para acceso de arboles','Usuario Acceso Arboles',4),
('Permiso para arboles fisicos','Arboles Fisicos',15),
('Permiso para arboles logicos','Arboles Logicos',16),
('Permiso para objetos fisicos','Objetos Fisicos',18),
('Permiso para objetos logicos','Objetos Logicos',19),
('Permiso para marcas','Marcas',8),
('Permiso para area','Areas',14),
('Permiso para idiomas','Idiomas',13),
('Permios para modelos','Modelos',9),
('Permiso para menu de usuarios','Usuarios Menu',3),
('Permiso para menus','Menu',22),
('Permiso para protocolos','Protocolos',10),
('Permiso para acciones','Acciones',21),
('Permiso para acciones de usuarios','Acciones usuario', 23),
('Permiso para usuarios','Usuarios',2)