create or replace procedure borrar_rama_arbol_logico (id IN INTEGER , borrados INOUT INTEGER[])
LANGUAGE plpgsql
AS $$
DECLARE
	array_len INTEGER;
	padre_rec record;
	index INTEGER := 1;
	array_padres INTEGER[];
	array_hijos INTEGER[];
BEGIN
	FOR padre_rec IN (select * from "ARB_LOGICO" where log_id_padre = id) LOOP
		SELECT array_append(array_padres,padre_rec.log_id_padre) INTO array_padres;
		SELECT array_append(array_hijos,padre_rec.log_id) INTO array_hijos;
	END LOOP;
	IF array_length(array_padres,1) > 0 THEN
		array_len := array_upper(array_padres,1);
		WHILE index <= array_len LOOP
			FOR padre_rec IN (select * from "ARB_LOGICO" where log_id_padre = array_hijos[index]) LOOP
				SELECT array_append(array_padres,padre_rec.log_id_padre) INTO array_padres;
				SELECT array_append(array_hijos,padre_rec.log_id) INTO array_hijos;
				array_len := array_upper(array_padres,1);
			END LOOP;
			index := index + 1;
		END LOOP;

		SELECT array_prepend(id,array_hijos) INTO array_hijos;
		borrados := array_hijos;
		index := array_len+1;
		WHILE index > 0 LOOP
			DELETE FROM "ARB_LOGICO" WHERE log_id = array_hijos[index];
			index := index - 1;
		END LOOP;
	ELSE
		borrados := ARRAY [id];
		DELETE FROM "ARB_LOGICO" WHERE log_id = id;
	END IF;
END $$;