create or replace function buscar_padres_arbol_fisico (id INTEGER)
	RETURNS TABLE (
		id_nodo INTEGER,
		id_padre INTEGER
)
AS $$
DECLARE
	salir INTEGER := 1;
	padre INTEGER;
	hijo INTEGER;
BEGIN
	salir := 1;
	hijo := id;
	WHILE salir > 0 LOOP
		padre := (select fis_id_padre from "ARB_FISICO" where fis_id = hijo limit 1);
		id_nodo := hijo;
		id_padre := padre;
		IF id_padre IS NULL THEN
			salir := 0;
		END IF;
		hijo := padre;
		RETURN NEXT;
	END LOOP;
END $$
LANGUAGE plpgsql;
