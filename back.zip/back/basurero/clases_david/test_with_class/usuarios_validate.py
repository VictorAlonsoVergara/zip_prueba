from validations import validate_char
from validations import validate_int
from validations import validate_string
from validations import validate_varchar


def validate_usuarios(
    usu_id, usu_nombre, tusu_id, usu_estado, usu_correo, usu_usuario, usu_password
):

    # tusu_id es un serial y no será validado aun
    v_usu_id = True  # serial
    v_usu_nombre = validate_varchar(usu_nombre, 300)  # varchar(300)
    v_tusu_id = validate_int(tusu_id)  # integer
    v_usu_estado = validate_char(usu_estado)  # char(1)
    v_usu_correo = validate_varchar(usu_correo, 100)  # varchar(100)
    v_usu_usuario = validate_varchar(usu_usuario, 50)  # varchar(50)
    v_usu_password = validate_varchar(usu_password, 2048)  # varchar(2048)

    # print the mistakes
    show_mistakes(
        v_usu_id,
        v_usu_nombre,
        v_tusu_id,
        v_usu_estado,
        v_usu_correo,
        v_usu_usuario,
        v_usu_password,
    )

    if (
        v_usu_id
        and v_usu_nombre
        and v_tusu_id
        and v_usu_estado
        and v_usu_correo
        and v_usu_usuario
        and v_usu_password
    ):
        return True

    else:
        return False


# this function prints the mistakes done by the user
def show_mistakes(
    v_usu_id,
    v_usu_nombre,
    v_tusu_id,
    v_usu_estado,
    v_usu_correo,
    v_usu_usuario,
    v_usu_password,
):

    if v_usu_id == False:
        print("con_id debe ser de tipo serial")
    if v_usu_nombre == False:
        print("usu_nombre debe ser de tipo varchar(200) ")
    if v_tusu_id == False:
        print("tusu_id debe ser de tipo smallint")
    if v_usu_estado == False:
        print("usu_estado debe ser de tipo serial")
    if v_usu_correo == False:
        print("usu_correo debe ser de tipo varchar(200) ")
    if v_usu_usuario == False:
        print("usu_usuario debe ser de tipo smallint")
    if v_usu_password == False:
        print("usu_password debe ser de tipo varchar(2048)")


if __name__ == "__main__":

    usu_id = 1  # serial
    usu_nombre = "varchar"  # varchar(300)
    tusu_id = 10  # integer
    usu_estado = "a"  # char(1)
    usu_correo = "asdada@cadsa.com"  # varchar(100)
    usu_usuario = "apesol"  # varchar(50)
    usu_password = "apesol "  # varchar(2048)

    usuariosIsValidated = validate_usuarios(
        usu_id, usu_nombre, tusu_id, usu_estado, usu_correo, usu_usuario, usu_password
    )

    if usuariosIsValidated:
        print(" Fue validado")

    else:
        print("NO fue validado")
