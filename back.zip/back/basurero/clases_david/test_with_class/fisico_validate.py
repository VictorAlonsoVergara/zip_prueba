from validations import validate_char
from validations import validate_int
from validations import validate_string
from validations import validate_varchar


def logico_validate(id_obj_hijo, id_obj_padre):

    # tusu_id es un serial y no será validado aun
    v_id_obj_hijo = validate_int(id_obj_hijo)  # integer
    v_id_obj_padre = validate_int(id_obj_padre)  # integer

    # print the mistakes
    show_mistakes(v_id_obj_hijo, v_id_obj_padre)

    if v_id_obj_hijo and v_id_obj_padre:
        return True

    else:
        return False


# this function prints the mistakes done by the user
def show_mistakes(v_id_obj_hijo, v_id_obj_padre):

    if v_id_obj_hijo == False:
        print("id_obj_hijo debe ser de tipo integer")
    if v_id_obj_padre == False:
        print("id_obj_hijo debe ser de tipo integer ")


if __name__ == "__main__":

    id_obj_hijo = 12  # integer
    id_obj_padre = 12  # integer

    logicoIsValidated = logico_validate(id_obj_hijo, id_obj_padre)

    if logicoIsValidated:
        print(" Fue validado")

    else:
        print("NO fue validado")
