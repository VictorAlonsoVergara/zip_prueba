from validations import validate_char
from validations import validate_int
from validations import validate_string
from validations import validate_varchar


def validate_tipo_obj(tobj_id, tobj_desc, tobj_estado, tobj_consulta, tobj_ldesc):

    # con_id es un serial y no será validado aun

    v_id = True
    v_desc = validate_varchar(tobj_desc, 200)  # varchar(200)
    v_estado = validate_char(tobj_estado)  # char(1)
    v_consulta = validate_char(tobj_consulta)  # char(1)
    v_ldesc = True  # text

    # print the mistakes
    show_mistakes(v_id, v_desc, v_estado, v_consulta, v_ldesc)

    if v_desc and v_estado and v_consulta and v_ldesc:
        return True

    else:
        return False


# this function prints the mistakes done by the user
def show_mistakes(v_id, v_desc, v_estado, v_consulta, v_ldesc):

    if v_id == False:
        print("tobj_id debe ser de tipo serial")

    if v_desc == False:
        print("tobj_desc debe ser de tipo varchar(200) ")
    if v_estado == False:
        print("tobj_estado debe ser de tipo char(1)")
    if v_consulta == False:
        print("tobj_consulta debe ser de tipo char(1)")
    if v_ldesc == False:
        print("tobj_ldesc debe ser de tipo text")


if __name__ == "__main__":

    tobj_id = 1
    tobj_desc = "varchar100"
    tobj_estado = "ea"
    tobj_consulta = "c"
    tobj_ldesc = "text"

    tipo_objIsValidated = validate_tipo_obj(
        tobj_id, tobj_desc, tobj_estado, tobj_consulta, tobj_ldesc
    )

    if tipo_objIsValidated:
        print(" Fue validado")

    else:
        print("NO fue validado")
