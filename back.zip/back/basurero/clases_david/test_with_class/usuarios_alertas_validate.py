from validations import validate_char
from validations import validate_int
from validations import validate_string
from validations import validate_varchar


def usuarios_alertas_validate(ind_id, usu_id):

    # tusu_id es un serial y no será validado aun
    v_ind_id = validate_int(ind_id)  # integer
    v_usu_id = validate_int(usu_id)  # integer

    # print the mistakes
    show_mistakes(v_ind_id, v_usu_id)

    if v_ind_id and v_usu_id:
        return True

    else:
        return False


# this function prints the mistakes done by the user
def show_mistakes(v_ind_id, v_usu_id):

    if v_ind_id == False:
        print("ind_id debe ser de tipo serial")
    if v_usu_id == False:
        print("usu_id debe ser de tipo varchar(200) ")


if __name__ == "__main__":

    ind_id = 1  # integer
    usu_id = 1  # integer

    usuarios_alertasIsValidated = usuarios_alertas_validate(ind_id, usu_id)

    if usuarios_alertasIsValidated:
        print(" Fue validado")

    else:
        print("NO fue validado")
