from validations import validate_char
from validations import validate_int
from validations import validate_string
from validations import validate_varchar


def acceso_indicadores_validate(uind_id, ind_id, usu_id):

    # tusu_id es un serial y no será validado aun
    v_uind_id = True  # serial
    v_ind_id = validate_int(ind_id)  # integer
    v_usu_id = validate_int(ind_id)  # integer

    # print the mistakes
    show_mistakes(v_uind_id, v_ind_id, v_usu_id)

    if v_uind_id and v_ind_id and v_usu_id:
        return True

    else:
        return False


# this function prints the mistakes done by the user
def show_mistakes(v_uind_id, v_ind_id, v_usu_id):

    if v_uind_id == False:
        print("uind_id debe ser de tipo serial")
    if v_ind_id == False:
        print("ind_id debe ser de tipo integer ")
    if v_usu_id == False:
        print("usu_id debe ser de tipo integer ")


if __name__ == "__main__":

    uind_id = 1  # serial
    ind_id = 1  # integer
    usu_id = 1  # integer

    acceso_indicadoresIsValidated = acceso_indicadores_validate(uind_id, ind_id, usu_id)

    if acceso_indicadoresIsValidated:
        print(" Fue validado")

    else:
        print("NO fue validado")
