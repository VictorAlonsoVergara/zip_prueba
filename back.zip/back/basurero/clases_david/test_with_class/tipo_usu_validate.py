from validations import validate_char
from validations import validate_int
from validations import validate_string
from validations import validate_varchar


def validate_consultas(tusu_id, tusu_desc, tusu_estado):

    # tusu_id es un serial y no será validado aun
    v_id = True
    v_desc = validate_varchar(tusu_desc, 200)  # varchar(200)
    v_estado = validate_int(tusu_estado)  # smallint

    # print the mistakes
    show_mistakes(v_id, v_desc, v_estado)

    if v_desc and v_estado:
        return True

    else:
        return False


# this function prints the mistakes done by the user
def show_mistakes(v_id, v_desc, v_estado):

    if v_id == False:
        print("con_id debe ser de tipo serial")

    if v_desc == False:
        print("con_desc debe ser de tipo varchar(200) ")
    if v_estado == False:
        print("con_estado debe ser de tipo smallint")


if __name__ == "__main__":

    tusu_id = 1
    tusu_desc = "varchar"
    tusu_estado = 12

    tipo_usuIsValidated = validate_consultas(tusu_id, tusu_desc, tusu_estado)

    if tipo_usuIsValidated:
        print(" Fue validado")

    else:
        print("NO fue validado")
