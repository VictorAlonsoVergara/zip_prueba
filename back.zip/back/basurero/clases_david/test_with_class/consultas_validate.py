from validations import validate_char
from validations import validate_int
from validations import validate_string
from validations import validate_varchar


def validate_consultas(con_id, con_desc, con_estado, con_protoclo, con_trama_pregunta):

    # con_id es un serial y no será validado aun
    v_id = True
    v_desc = validate_varchar(con_desc, 100)  # varchar 100
    v_estado = validate_char(con_estado)  # char 1
    v_protocolo = validate_char(con_protoclo)  # char 1
    v_trama = validate_varchar(con_trama_pregunta, 500)  # varchar 500

    # print the mistakes
    show_mistakes(v_id, v_desc, v_estado, v_protocolo, v_trama)

    if v_desc and v_estado and v_protocolo and v_trama:
        return True

    else:
        return False


# this function prints the mistakes done by the user
def show_mistakes(v_id, v_desc, v_estado, v_protocolo, v_trama):

    if v_id == False:
        print("con_id debe ser de tipo serial")

    if v_desc == False:
        print("con_desc debe ser de tipo varchar(500) ")
    if v_estado == False:
        print("con_estado debe ser de tipo char(1)")
    if v_protocolo == False:
        print("con_protocolo debe ser de tipo char(1)")
    if v_trama == False:
        print("con_trama_pregunta debe ser de tipo varchar(500)")


if __name__ == "__main__":

    con_id = 1
    con_desc = "varchar"
    con_estado = "e"
    con_protoclo = "p"
    con_trama_pregunta = "varchar"

    consultasIsValidated = validate_consultas(
        con_id, con_desc, con_estado, con_protoclo, con_trama_pregunta
    )

    if consultasIsValidated:
        print(" Fue validado")

    else:
        print("NO fue validado")
