from validations import validate_char
from validations import validate_int
from validations import validate_string
from validations import validate_varchar


def validate_objetos(obj_id, obj_desc, tobj_id, obj_estado, obj_ldesc):

    # tusu_id es un serial y no será validado aun
    v_obj_id = True  # serial
    v_obj_desc = validate_varchar(obj_desc, 200)  # varchar(200)
    v_tobj_id = validate_int(tobj_id)  # integer
    v_obj_estado = validate_char(obj_estado)  # char(1)
    v_obj_ldesc = True  # text

    # print the mistakes
    show_mistakes(v_obj_id, v_obj_desc, v_tobj_id, v_obj_estado, v_obj_ldesc)

    if v_obj_id and v_obj_desc and v_tobj_id and v_obj_estado and v_obj_ldesc:
        return True

    else:
        return False


# this function prints the mistakes done by the user
def show_mistakes(v_obj_id, v_obj_desc, v_tobj_id, v_obj_estado, v_obj_ldesc):

    if v_obj_id == False:
        print("obj_id debe ser de tipo serial")
    if v_obj_desc == False:
        print("obj_desc debe ser de tipo varchar(200) ")
    if v_tobj_id == False:
        print("tobj_id debe ser de tipo integer     ")
    if v_obj_estado == False:
        print("obj_estado debe ser de tipo char(1)")
    if v_obj_ldesc == False:
        print("obj_ldesc debe ser de tipo text ")


if __name__ == "__main__":

    obj_id = True  # serial
    obj_desc = "varchar"  # varchar(200)
    tobj_id = 12  # integer
    obj_estado = "e"  # char(1)
    obj_ldesc = True  # text

    usuariosIsValidated = validate_objetos(
        obj_id, obj_desc, tobj_id, obj_estado, obj_ldesc
    )

    if usuariosIsValidated:
        print(" Fue validado")

    else:
        print("NO fue validado")
