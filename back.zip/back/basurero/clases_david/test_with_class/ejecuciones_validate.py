from validations import validate_char
from validations import validate_int
from validations import validate_string
from validations import validate_varchar


def ejecuciones_validate(
    eje_id,
    eje_fecha,
    cron_id,
    eje_fecha_ini,
    eje_fecha_fin,
    eje_log,
    eje_fecha_transferencia,
    eje_fecha_parseo,
):

    # tusu_id es un serial y no será validado aun
    v_eje_id = True  # serial
    v_eje_fecha = validate_varchar(eje_fecha, 8)  # char(8)
    v_cron_id = validate_int(cron_id)  # integer
    v_eje_fecha_ini = True  # time
    v_eje_fecha_fin = True  # time
    v_eje_log = validate_varchar(eje_log, 50)  # varchar(50)
    v_eje_fecha_transferencia = True  # time
    v_eje_fecha_parseo = True  # time

    # print the mistakes
    show_mistakes(
        v_eje_id,
        v_eje_fecha,
        v_cron_id,
        v_eje_fecha_ini,
        v_eje_fecha_fin,
        v_eje_log,
        v_eje_fecha_transferencia,
        v_eje_fecha_parseo,
    )

    if (
        v_eje_id
        and v_eje_fecha
        and v_cron_id
        and v_eje_fecha_ini
        and v_eje_fecha_fin
        and v_eje_log
        and v_eje_fecha_transferencia
        and v_eje_fecha_parseo
    ):
        return True

    else:
        return False


# this function prints the mistakes done by the user
def show_mistakes(
    v_eje_id,
    v_eje_fecha,
    v_cron_id,
    v_eje_fecha_ini,
    v_eje_fecha_fin,
    v_eje_log,
    v_eje_fecha_transferencia,
    v_eje_fecha_parseo,
):

    if v_eje_id == False:
        print("eje_id debe ser de tipo serial")
    if v_eje_fecha == False:
        print("eje_fecha debe ser de tipo char(8) ")
    if v_cron_id == False:
        print("cron_id debe ser de tipo integer")
    if v_eje_fecha_ini == False:
        print("eje_fecha_ini debe ser de tipo time ")
    if v_eje_fecha_fin == False:
        print("eje_fecha_fin debe ser de tipo time")
    if v_eje_log == False:
        print("eje_log debe ser de tipo varchar(50) ")
    if v_eje_fecha_transferencia == False:
        print("eje_fecha_transferencia debe ser de tipo integer")
    if v_eje_fecha_parseo == False:
        print("eje_fecha_parseo debe ser de tipo integer ")


if __name__ == "__main__":

    eje_id = 1  # serial
    eje_fecha = "varchar"  # char(8)
    cron_id = 10  # integer
    eje_fecha_ini = "prueba"  # time
    eje_fecha_fin = "prueba"  # time
    eje_log = "varchar"  # varchar(50)
    eje_fecha_transferencia = "prueba"  # time
    eje_fecha_parseo = "prueba "  # time

    ejecucionesIsValidated = ejecuciones_validate(
        eje_id,
        eje_fecha,
        cron_id,
        eje_fecha_ini,
        eje_fecha_fin,
        eje_log,
        eje_fecha_transferencia,
        eje_fecha_parseo,
    )

    if ejecucionesIsValidated:
        print(" Fue validado")

    else:
        print("NO fue validado")
