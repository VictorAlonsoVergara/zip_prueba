from validations import validate_char
from validations import validate_int
from validations import validate_string
from validations import validate_varchar


def validate_cron(cron_id, tobj_id, cron_tipo, cron_periodo, cron_estado):

    # tusu_id es un serial y no será validado aun
    v_cron_id = True  # serial
    v_tobj_id = validate_int(tobj_id)  # integer
    v_cron_tipo = validate_char(cron_tipo)  # char(1)
    v_cron_periodo = validate_varchar(cron_periodo, 20)  # varchar(20)
    v_cron_estado = validate_char(cron_estado)  # char(1)

    # print the mistakes
    show_mistakes(v_cron_id, v_tobj_id, v_cron_tipo, v_cron_periodo, v_cron_estado)

    if v_cron_id and v_tobj_id and v_cron_tipo and v_cron_periodo and v_cron_estado:
        return True

    else:
        return False


# this function prints the mistakes done by the user
def show_mistakes(v_cron_id, v_tobj_id, v_cron_tipo, v_cron_periodo, v_cron_estado):

    if v_cron_id == False:
        print("cron_id debe ser de tipo serial")
    if v_tobj_id == False:
        print("tobj_id debe ser de tipo varchar(200) ")
    if v_cron_tipo == False:
        print("cron_tipo debe ser de tipo smallint")
    if v_cron_periodo == False:
        print("cron_periodo debe ser de tipo serial")
    if v_cron_estado == False:
        print("cron_estado debe ser de tipo varchar(200) ")


if __name__ == "__main__":

    cron_id = True  # serial
    tobj_id = 12  # integer
    cron_tipo = "t"  # char(1)
    cron_periodo = "varchar"  # varchar(20)
    cron_estado = "e"  # char(1)

    cronIsValidated = validate_cron(
        cron_id, tobj_id, cron_tipo, cron_periodo, cron_estado
    )

    if cronIsValidated:
        print(" Fue validado")

    else:
        print("NO fue validado")
