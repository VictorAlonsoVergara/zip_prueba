from validations import validate_char
from validations import validate_int
from validations import validate_string
from validations import validate_varchar


def indicadores_validate(
    ind_id,
    ind_desc,
    ind_estado,
    ind_ldesc,
    ind_alerta,
    cron_id,
    ind_trap,
    ind_trap_definicion,
):

    # tusu_id es un serial y no será validado aun
    v_ind_id = True  # serial
    v_ind_desc = validate_varchar(ind_desc, 200)  # varchar(200)
    v_ind_estado = validate_int(ind_estado)  # smallint
    v_ind_ldesc = validate_int(ind_ldesc)  # smallint
    v_ind_alerta = validate_char(ind_alerta)  # char(1)
    v_cron_id = validate_int(cron_id)  # integer
    v_ind_trap = validate_char(ind_trap)  # char(1)
    v_ind_trap_definicion = True  # text

    # print the mistakes
    show_mistakes(
        v_ind_id,
        v_ind_desc,
        v_ind_estado,
        v_ind_ldesc,
        v_ind_alerta,
        v_cron_id,
        v_ind_trap,
        v_ind_trap_definicion,
    )

    if (
        v_ind_id
        and v_ind_desc
        and v_ind_estado
        and v_ind_ldesc
        and v_ind_alerta
        and v_cron_id
        and v_ind_trap
        and v_ind_trap_definicion
    ):
        return True

    else:
        return False


# this function prints the mistakes done by the user
def show_mistakes(
    v_ind_id,
    v_ind_desc,
    v_ind_estado,
    v_ind_ldesc,
    v_ind_alerta,
    v_cron_id,
    v_ind_trap,
    v_ind_trap_definicion,
):

    if v_ind_id == False:
        print("ind_id debe ser de tipo serial")
    if v_ind_desc == False:
        print("ind_desc debe ser de tipo varchar(200) ")
    if v_ind_estado == False:
        print("ind_estado debe ser de tipo smallint")
    if v_ind_ldesc == False:
        print("ind_ldesc debe ser de tipo smallint ")
    if v_ind_alerta == False:
        print("ind_alerta debe ser de tipo char(1)")
    if v_cron_id == False:
        print("cron_id debe ser de tipo integer ")
    if v_ind_trap == False:
        print("ind_trap debe ser de tipo char(1)")
    if v_ind_trap_definicion == False:
        print("ind_trap_definicion debe ser de tipo text ")


if __name__ == "__main__":

    ind_id = 1  # serial
    ind_desc = "varchar"  # varchar(200)
    ind_estado = 1  # smallint
    ind_ldesc = 1  # smallint
    ind_alerta = "a"  # char(1)
    cron_id = 1  # integer
    ind_trap = "t"  # char(1)
    ind_trap_definicion = "text"  # text

    indicadoresIsValidated = indicadores_validate(
        ind_id,
        ind_desc,
        ind_estado,
        ind_ldesc,
        ind_alerta,
        cron_id,
        ind_trap,
        ind_trap_definicion,
    )

    if indicadoresIsValidated:
        print(" Fue validado")

    else:
        print("NO fue validado")
