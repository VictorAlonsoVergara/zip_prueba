from validations import validate_char
from validations import validate_int
from validations import validate_string
from validations import validate_varchar


def validate_usu_accesos_arboles(uarb_id, uind_id, uarb_tipo, uarb_hijo):

    # tusu_id es un serial y no será validado aun

    v_uarb_id = True  # serial
    v_uind_id = validate_int(uind_id)  # integer
    v_uarb_tipo = validate_char(uarb_tipo)  # char(1)
    v_uarb_hijo = validate_int(uarb_hijo)  # integer

    # print the mistakes
    show_mistakes(v_uarb_id, v_uind_id, v_uarb_tipo, v_uarb_hijo)

    if v_uarb_id and v_uind_id and v_uarb_tipo and v_uarb_hijo:
        return True
    else:
        return False


# this function prints the mistakes done by the user
def show_mistakes(v_uarb_id, v_uind_id, v_uarb_tipo, v_uarb_hijo):

    if v_uarb_id == False:
        print("uarb_id debe ser de tipo serial")
    if v_uind_id == False:
        print("uind_id debe ser de tipo integer ")
    if v_uarb_tipo == False:
        print("uarb_tipo debe ser de tipo char(1)")
    if v_uarb_hijo == False:
        print("uarb_hijo debe ser de tipo integer")


if __name__ == "__main__":

    uarb_id = 1  # serial
    uind_id = 1  # integer
    uarb_tipo = "t"  # char(1)
    uarb_hijo = 1  # integer

    accesos_arbolesIsValidated = validate_usu_accesos_arboles(
        uarb_id, uind_id, uarb_tipo, uarb_hijo
    )

    if accesos_arbolesIsValidated:
        print(" Fue validado")

    else:
        print("NO fue validado")
