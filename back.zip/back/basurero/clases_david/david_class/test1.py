#from MAT_TIPO_OBJ import MAT_TIPO_OBJ
from MAE_OBJETOS import MAE_OBJETOS


if __name__ == "__main__":


    #VALIDACION MAT_TIPO_OBJ
    # tobj_desc = "descripcion"  # input ('Ingrese descripcion: ')
    # tobj_estado = "e"  # input ('Ingrese estado: ')
    # tobj_consulta = "c"  # input('Ingrese consulta: ')
    # tobj_ldesc = "ldesc"  # str( input('Ingrese ldesc: '))
    # string = '{},{},{},{},'.format(tobj_desc,tobj_estado,tobj_consulta,tobj_ldesc)
    #tipo_obj = MAT_TIPO_OBJ(tobj_desc, tobj_estado, tobj_consulta, tobj_ldesc, 202)
    #tipo_obj.guardar_dato()
    #tipo_obj.buscar_dato()
    #tipo_obj.actualizar_dato('desc2','e','C','descrp2')
    # tipo_obj.borrar_tipo_obj()


    obj_desc = "descripcion" # input ('Ingrese descripcion: ')
    tobj_id = 200
    obj_estado = "F"  # input ('Ingrese estado: ')
    obj_ldesc = "ldescrip"  # str( input('Ingrese ldesc: '))
  
    #VALIDACION MAE_OBJETOS
    objetos = MAE_OBJETOS(obj_desc, tobj_id, obj_estado, obj_ldesc,5)
    #objetos.guardar_objeto()
    objetos.buscar_dato()
    #objetos.modificar_objeto(obj_desc, tobj_id, obj_estado, obj_ldesc)
    #objetos.borrar_objeto()


    
    print("program has ended !")
    pass
