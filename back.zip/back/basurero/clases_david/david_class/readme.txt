 
 En el archivo MAT_TIPO_OBJ :

cambios:    
    se agregó el tobj_id para probar los métodos de las librerias


Observacion:

Se debe borrar la linea 25 y modificar la linea 33 ;además de modificar la linea 9 y poner = None
borrar el print de la linea 52


