import psycopg2
import sys
import generico
from MAE_OBJETOS_CONSULTAS import MAE_OBJETOS_CONSULTAS
import logging
import datetime
import os


class MAE_CONSULTAS:
    def __init__(
        self,
        obj_id,
        con_id,
        objc_estado,
        objc_protocolo,
        objc_trama
    ):    
  	self.con_id = con_id #serial
	self.con_desc = con_desc #varchar(100)
	self.con_estado = con_estado #char(1)
	self.con_protocolo = con_protocolo #char(1)
	self.con_trama_pregunta = con_trama_pregunta #varchar(500)


    #    nombre_log = 'Log_programa_'+generico.diahora()+'.log'
    #    logging.basicConfig(filename=nombre_log,level=logging.DEBUG)

    def guardar_dato(self):

        try:
            con = generico.entraBD()
            cur = con.cursor()
            tup = (
                self.con_desc,
                self.con_estado,
                self.con_protocolo,
                self.con_trama_pregunta,
            )

            cur.execute(
                'INSERT INTO "MAE_CONSULTAS" (con_desc,con_estado,con_protocolo,con_trama_pregunta) VALUES (%s,%s,%s,%s)',
                tup,
            )
            con.commit()
            cur.execute(
                'SELECT * FROM "MAE_CONSULTAS" WHERE con_desc =\''
                + self.con_desc
                + "' AND con_estado ='"
                + self.con_estado
                + "' AND con_protocolo='"
                + self.con_protocolo
                + "' AND con_trama_pregunta='"
                + self.con_trama_pregunta
                + "' "
            )
            version = cur.fetchall()
            self.con_id = version[len(version) - 1][0]
            dato = "ok"
            logging.info(
                str(datetime.datetime.today())
                + "se guardo un dato en tabla MAE_CONSULTAS"
            )
        except psycopg2.DatabaseError as e:
            dato = "error"
            print(f"Error {e}")
            logging.error(
                str(datetime.datetime.today())
                + "sucedio un error guardando en la tabla MAE_CONSULTAS"
            )
        except:
            dato = "error"
            logging.error(
                str(datetime.datetime.today())
                + "sucedio un error guardando en la tabla MAE_CONSULTAS"
            )
        finally:
            if con:
                con.close()
            return dato

    def buscar_dato(self):
        try:
            con = generico.entraBD()
            cur = con.cursor()
            cur.execute(
                'SELECT * FROM "MAE_CONSULTAS" WHERE con_id =' + str(self.con_id)
            )
            version = cur.fetchall()

            self.con_desc = version[0][1]  # varchar(100)
            self.con_estado = version[0][2]  # char(1)
            self.con_protocolo = version[0][3]  # char(1)
            self.con_trama_pregunta = version[0][4]  # varchar(500)
            dato = "ok"
        except psycopg2.DatabaseError as e:
            dato = "error"
            print(f"Error {e}")
        except:
            dato = "error"
        finally:
            if con:
                con.close()
            return dato

    @staticmethod
    def consultar_lista():
        try:
            con = generico.entraBD()
            cur = con.cursor()
            cur.execute('SELECT * FROM "MAE_CONSULTAS"')
            version = cur.fetchall()
            lista = {}
            num = 0
            for con in version:
                data = {}
                data["con_id"] = con[0]
                data["con_desc"] = con[1]
                data["con_estado"] = con[4]
                data["con_protocolo"] = con[5]
                data["con_trama_pregunta"] = con[3]
                                
                lista[num] = data
                num = num + 1
        except psycopg2.DatabaseError as e:
            lista = {}
            lista["Error"] = "1"
            print(f"Error {e}")
        except Exception as e:
            lista = {}
            lista["Error"] = "2"
            print(e)
        finally:
            if con:
                con.close()
            return lista

    def modificar_usuario(self):
        try:
            con = generico.entraBD()
            cur = con.cursor()
            my_sql = (
                'UPDATE "MAE_CONSULTAS" SET con_desc = \''
                + self.con_desc
                + "' , con_estado = '"
                + self.con_estado
                + "' , con_protocolo= '"
                + self.con_protocolo
                + "' , con_trama_pregunta='"
                + self.con_trama_pregunta
                + " WHERE con_id = "
                + str(self.con_id)
                + " "
            )
            cur.execute(my_sql)
            con.commit()
        except psycopg2.DatabaseError as e:
            lista = {}
            lista["result"] = "failed"
            lista["error"] = "Sucedio un error"
            lista["error_cod"] = 412
            lista["val_errors"] = str(e)

        except Exception as e:
            lista = {}
            lista["result"] = "failed"
            lista["error"] = "Sucedio un error"
            lista["error_cod"] = 412
            lista["val_errors"] = str(e)
        else:
            lista = {}
            lista["result"] = "ok"
        finally:
            if con:
                con.close()
            return lista

    def borrar_usuario(self):
        try:
            con = generico.entraBD()
            cur = con.cursor()
            my_sql = 'DELETE FROM "MAE_CONSULTAS" WHERE con_id=' + str(self.con_id)
            cur.execute(my_sql)
            con.commit()
        except psycopg2.DatabaseError as e:
            lista = {}
            lista["result"] = "failed"
            lista["error"] = "Sucedio un error"
            lista["error_cod"] = 505
            lista["val_errors"] = str(e)

        except Exception as e:
            lista = {}
            lista["result"] = "failed"
            lista["error"] = "Sucedio un error"
            lista["error_cod"] = 505
            lista["val_errors"] = str(e)
        else:
            lista = {}
            lista["result"] = "ok"
        finally:
            if con:
                con.close()
            return lista

    def consultar(self):
        print("consulta")
