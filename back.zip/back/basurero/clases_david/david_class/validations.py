def validate_string(data):
    words = str(data)
    try:
        number = int(words)
        # print('Solo esta permitido cadenas y usted ha ingresado un numero')
        return [False, "ha ingresado un numero"]
    except ValueError:
        pass

    lenght = len(data)
    for i in range(lenght):
        try:
            character = int(words[i])
            # print('Todos los caracteres de la data deben ser letras y no numeros')
            return [False, "se encontro un numero como caracter"]
        except ValueError:
            # print('todo ok con el caracter ')
            continue

    return [True, "ok"]


def validate_varchar(data, maximum_length):
    words = str(data)
    try:
        number = int(words)
        # print('Solo esta permitido cadenas y usted ha ingresado un numero')
        return [False, "ha ingresado un numero"]
    except ValueError:
        pass

    lenght = len(data)
    if lenght > maximum_length:
        # print('La longitud de la entrada no debe ser mayor a {}'.format(maximum_length))
        return [False, "Sobrepaso longitud maxima de " + str(maximum_length)]

    return [True, "ok"]


def validate_int(data):
    try:
        number = int(data)
        return [True, "ok"]
    except ValueError:
        return [False, "ValueError en el int"]


def validate_char(data):
    words = str(data)
    try:
        number = int(words)
        # print('Solo esta permitido cadenas y usted ha ingresado un numero')
        return [False, "Ha ingresado un numero"]
    except ValueError:
        pass
        # print('La entrada {} no se pudo convertir a int'.format(words))

    # largo del input
    lenght = len(data)
    if lenght > 1:
        # print('La longitud de la entrada no debe ser mayor a {}'.format(1))
        return [False, "Sobrepaso la longitud de 1"]

    return [True, "ok"]
