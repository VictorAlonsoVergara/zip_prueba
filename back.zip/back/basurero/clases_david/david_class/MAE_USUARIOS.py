import psycopg2
import sys
import generico
from MAE_TIPO_USU import MAE_TIPO_USU
import logging
import datetime
import os


class MAE_USUARIOS:
    def __init__(
        self,
        usu_nombre,
        tusu_id,
        usu_estado,
        usu_correo,
        usu_usuario,
        usu_password,
        usu_id=0,
    ):

        self.usu_id = usu_id  # serial
        self.usu_nombre = usu_nombre  # varchar(300)
        self.tusu_id = tusu_id  # integer
        self.usu_estado = usu_estado  # char(1)
        self.usu_correo = usu_correo  # varchar(100)
        self.usu_usuario = usu_usuario  # varchar(50)
        self.usu_password = usu_password  # varchar(2048)
        self.mae_tipo_usu = MAE_TIPO_USU(" ", " ", tusu_id)
        self.mae_tipo_usu.buscar_dato()

    #    nombre_log = 'Log_programa_'+generico.diahora()+'.log'
    #    logging.basicConfig(filename=nombre_log,level=logging.DEBUG)

    def guardar_dato(self):
        try:
            con = generico.entraBD()
            cur = con.cursor()
            tup = (
                self.usu_nombre,
                self.tusu_id,
                self.usu_estado,
                self.usu_correo,
                self.usu_usuario,
            )

            cur.execute(
                'INSERT INTO "MAE_USUARIOS" (usu_nombre,tusu_id,usu_estado,usu_correo,usu_usuario) VALUES (%s,%s,%s,%s,%s)',
                tup,
            )
            con.commit()
            cur.execute(
                'SELECT * FROM "MAE_USUARIOS" WHERE usu_nombre =\''
                + self.usu_nombre
                + "' AND tusu_id ="
                + str(self.tusu_id)
                + " AND usu_estado='"
                + self.usu_estado
                + "' AND usu_correo='"
                + self.usu_correo
                + "' AND usu_usuario='"
                + self.usu_usuario
                + "' "
            )
            version = cur.fetchall()

            self.usu_id = version[len(version) - 1][0]
            dato = ["ok", " "]

        #     logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla MAE_USUARIOS')
        except psycopg2.DatabaseError as e:
            dato = ["error", str(e)]
            print(f"Error {e}")
            print(exc_type, fname, exc_tb.tb_lineno)
        #     logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_USUARIOS')
        except Exception as e:
            dato = ["error", str(e)]
            print(exc_type, fname, exc_tb.tb_lineno)
        #     logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_USUARIOS')
        finally:
            if con:
                con.close()
            return dato

    def buscar_dato(self):
        try:
            con = generico.entraBD()
            cur = con.cursor()
            cur.execute(
                'SELECT * FROM "MAE_USUARIOS" WHERE usu_id =' + str(self.usu_id)
            )
            version = cur.fetchall()

            self.usu_nombre = version[0][1]  # varchar(300)
            self.tusu_id = version[0][2]  # integer
            self.usu_estado = version[0][3]  # char(1)
            self.usu_correo = version[0][4]  # varchar(100)
            self.usu_usuario = version[0][5]  # varchar(50)
            self.mae_tipo_usu = MAE_TIPO_USU(" ", " ", self.tusu_id)
            self.mae_tipo_usu.buscar_dato()
            self.usu_password = " "  # version[0][6] #varchar(2048)
            dato = ["ok", " "]
        except psycopg2.DatabaseError as e:
            dato = ["error", str(e)]
            print(f"Error {e}")
        except Exception as e:
            dato = ["error", str(e)]
        finally:
            if con:
                con.close()
            return dato

    @staticmethod
    def consultar_lista():
        try:
            con = generico.entraBD()
            cur = con.cursor()
            cur.execute('SELECT * FROM "MAE_USUARIOS"')
            version = cur.fetchall()
            lista = {}
            num = 0
            for usu in version:
                data = {}
                data["usu_id"] = usu[0]
                data["usu_nombre"] = usu[1]
                data["usu_correo"] = usu[4]
                data["usu_usario"] = usu[5]
                data["usu_estado"] = usu[3]
                data["usu_estado_desc"] = "Descripcion"
                data["tusu_id"] = usu[2]
                obj2 = MAE_TIPO_USU(" ", " ", int(usu[2]))
                obj2.buscar_dato()
                data["tusu_desc"] = obj2.tusu_desc
                lista[num] = data
                num = num + 1
        except psycopg2.DatabaseError as e:
            lista = {}
            lista["Error"] = "1"
            print(f"Error {e}")
        except Exception as e:
            lista = {}
            lista["Error"] = "2"
            print(e)
        finally:
            if con:
                con.close()
            return lista

    def modificar_usuario(self):
        try:
            con = generico.entraBD()
            cur = con.cursor()
            my_sql = (
                'UPDATE "MAE_USUARIOS" SET usu_nombre = \''
                + self.usu_nombre
                + "' , usu_correo = '"
                + self.usu_correo
                + "' , usu_usuario= '"
                + self.usu_usuario
                + "' , usu_estado='"
                + self.usu_estado
                + "' , tusu_id="
                + str(self.tusu_id)
                + " WHERE usu_id = "
                + str(self.usu_id)
                + " "
            )
            cur.execute(my_sql)
            con.commit()
        except psycopg2.DatabaseError as e:
            lista = {}
            lista["result"] = "failed"
            lista["error"] = "Sucedio un error"
            lista["error_cod"] = 412
            lista["val_errors"] = str(e)

        except Exception as e:
            lista = {}
            lista["result"] = "failed"
            lista["error"] = "Sucedio un error"
            lista["error_cod"] = 412
            lista["val_errors"] = str(e)
        else:
            lista = {}
            lista["result"] = "ok"
        finally:
            if con:
                con.close()
            return lista

    def borrar_usuario(self):
        try:
            con = generico.entraBD()
            cur = con.cursor()
            my_sql = 'DELETE FROM "MAE_USUARIOS" WHERE usu_id=' + str(self.usu_id)
            cur.execute(my_sql)
            con.commit()
        except psycopg2.DatabaseError as e:
            lista = {}
            lista["result"] = "failed"
            lista["error"] = "Sucedio un error"
            lista["error_cod"] = 505
            lista["val_errors"] = str(e)

        except Exception as e:
            lista = {}
            lista["result"] = "failed"
            lista["error"] = "Sucedio un error"
            lista["error_cod"] = 505
            lista["val_errors"] = str(e)
        else:
            lista = {}
            lista["result"] = "ok"
        finally:
            if con:
                con.close()
            return lista

    def consultar(self):
        print("consulta")
