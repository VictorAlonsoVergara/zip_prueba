import MAE_CONSULTAS


def run():

    con_desc = input("Escriba el con_desc (varchar)")
    con_estado = input("Escriba con_estado (char)")
    con_protocolo = input("Escriba con_protocolo (char)")
    con_trama_pregunta = input("Escriba con_trama_pregunta (varchar)")

    objConsultas = MAE_CONSULTAS.MAE_CONSULTAS(
        con_desc, con_estado, con_protocolo, con_trama_pregunta
    )

    print("se creo la clase")


if __name__ == "__main__":

    run()
