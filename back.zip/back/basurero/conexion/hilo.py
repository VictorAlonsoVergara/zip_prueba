
import threading
import time
import datetime
import logging
import random
from dispositivo import dispositivo

nombre_log = "traza_hilos2.log"

logging.basicConfig(filename=nombre_log)#,level=logging.INFO)
logging.warning('^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^INICIO DE LOS HILOS :'+str(datetime.datetime.today())+'^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^')

class MyThread (threading.Thread):

	def __init__(self,number):

		self.number = number
		self.hostname = ''
		self.password = ''
		self.username = ''
		self.port = ''
		self.community = ''
		self.conexion = ''
		self.comando = ''
		self.lock = threading.RLock()
		self.estado = 'ocupado'
		self.obj = ''
		super(MyThread, self).__init__()

	def salir(self):  # you can use a proper setter if you want
		with self.lock:
			self.estado = 'salir'

	def cambio_parametros(self,hostname,password,username,port,community,conexion,comando):  # you can use a proper setter if you want
		with self.lock:
			self.hostname = hostname
			self.password = password
			self.username = username
			self.port = port
			self.community = community
			self.conexion = conexion
			self.comando = comando
			self.estado = 'disponible'


	def run(self):
		while True:
			with self.lock:
				if(self.estado == 'salir'):
					break

				if(self.estado=='disponible'):
					self.estado='ocupado'
					self.obj = dispositivo(self.hostname,self.password,self.username,self.port,self.community,self.conexion)
					dato=self.obj.metodo(self.comando)
					#if (dato == ['error']):
					logging.warning('hilo numero '+str(self.number)+' : '+str(dato)+' '+str(datetime.datetime.today())) 

					print('acabo de correr: '+str(self.number)+ ' ' + str(datetime.datetime.today()))
					#print('///////////'+str(datetime.datetime.today())+'/////////////')
					self.estado='acabo'
			#time.sleep(0.1)  # let it breathe




