import mysql.connector
import datetime
import logging
import sys
import os
import paramiko
import time
class objSsh:
	#dia_hora = datetime.datetime.utcnow() + datetime.timedelta(hours=configuracionParametros.desfazeUTC())

	def __init__(self,hostname,password,username,port):

		self.hostname = hostname
		self.password = password
		self.username = username
		self.port = port

	def buscar(self,command):
		try:
			lista = []
			client = paramiko.SSHClient()
			client.set_missing_host_key_policy(paramiko.AutoAddPolicy()) #
			client.load_system_host_keys()
			client.set_missing_host_key_policy(paramiko.WarningPolicy)
			client.connect(hostname=self.hostname, port=self.port, username=self.username, password=self.password,timeout=5)

			for orden in command:
				stdin, stdout, stderr = client.exec_command(orden)
				respuesta = stdout.read()
				lista.append(respuesta)
			
			
		except:
		    lista =  ["error"]
		finally:
			client.close()
			return lista		