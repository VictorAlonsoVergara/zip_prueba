import json
import requests
import mysql.connector
import datetime
import logging
import sys
import os
from objSsh import objSsh
from objTelnet import objTelnet
from objSnmp import objSnmp

class dispositivo:

	def __init__(self,hostname,password,username,port,community,conexion):

		self.hostname = hostname
		self.password = password
		self.username = username
		self.port = port
		self.community = community
		self.tipoConex = conexion

		if(self.tipoConex == 'ssh' or self.tipoConex == 'SSH' ):
			self.obj = objSsh(self.hostname,self.password,self.username,self.port)
		elif(self.tipoConex == 'telnet' or self.tipoConex == 'TELNET' ):
			self.obj = objTelnet(self.hostname,self.password,self.username,self.port)
		elif(self.tipoConex == 'snmp' or self.tipoConex == 'SNMP' ):
			self.obj = objSnmp(self.hostname,self.community)
		else:
			self.obj = ''
			print('error')

	#def __del__(self):
	#	print("deleted")

	@staticmethod
	def listaVacia(str_lista):
		if not str_lista:
			str_result = "vacio"
		else:
			str_result = "no vacio"
		return str_result

	def metodo(self,command):
		try:		
			dato = self.obj.buscar(command)
		except:
			dato = 'Error'
		finally:
			return dato



	#def metodo2(self):

	#def metodo3(self):	
	'''
	def entraBD(self):
		BD = configuracionParametros.datosBD()
		try:
			mydb = mysql.connector.connect(
			host=BD[0],
			user=BD[1],
			passwd=BD[2],
			database=BD[3],
			)
			return mydb
		except Exception as e:
			logging.error(str(datetime.datetime.utcnow() + datetime.timedelta(hours=configuracionParametros.desfazeUTC())) + " Error en ticket en linea :     " + str(sys.exc_info()[2].tb_lineno)  + "     " + str(e.args),exc_info=True)
		except :
			logging.error(str(datetime.datetime.utcnow() + datetime.timedelta(hours=configuracionParametros.desfazeUTC())) + " Error en ticket en linea :     " + str(sys.exc_info()[2].tb_lineno)  + "      Error mayor",exc_info=True)
	'''
