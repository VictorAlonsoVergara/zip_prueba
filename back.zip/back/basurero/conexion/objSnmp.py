import mysql.connector
import datetime
import logging
import sys
import os
from easysnmp import Session

class objSnmp:
	

	def __init__(self,hostname,community):

		self.hostname = hostname
		self.community = community

	def buscar(self,command):
		try:
			lista = []
			session = Session(hostname=self.hostname,community=self.community, version=1)
			for orden in command :
				description = session.get(orden)
				lista.append(description)
		except:
			lista = "Error"
		finally:
			return lista