import datetime

print('********************************2')

tiempo_inic1 = datetime.timedelta(hours=12,minutes=39,seconds=7,microseconds=497766)
tiempo_inic2 = datetime.timedelta(hours=12,minutes=39,seconds=10,microseconds=560545)

tiempo_fin1 = datetime.timedelta(hours=12,minutes=39,seconds=7,microseconds=618605)
tiempo_fin2 = datetime.timedelta(hours=12,minutes=39,seconds=10,microseconds=671021)

print(tiempo_fin1-tiempo_inic1)
print(tiempo_fin2-tiempo_inic2)

print('********************************3')

tiempo_inic1 = datetime.timedelta(hours=12,minutes=54,seconds=33,microseconds=586404)
tiempo_fin1 = datetime.timedelta(hours=12,minutes=54,seconds=33,microseconds=677755)

print(tiempo_fin1-tiempo_inic1)


print('********************************4')

tiempo_inic1 = datetime.timedelta(hours=12,minutes=56,seconds=48,microseconds=271048)
tiempo_fin1 = datetime.timedelta(hours=12,minutes=56,seconds=49,microseconds=98521)

print(tiempo_fin1-tiempo_inic1)


print('********************************5')

tiempo_inic1 = datetime.timedelta(hours=14,minutes=14,seconds=48,microseconds=607748)
tiempo_fin1 = datetime.timedelta(hours=14,minutes=14,seconds=51,microseconds=744194)

print(tiempo_fin1-tiempo_inic1)


print('********************************6')

tiempo_inic1 = datetime.timedelta(hours=14,minutes=22,seconds=1,microseconds=90096)
tiempo_fin1 = datetime.timedelta(hours=14,minutes=22,seconds=23,microseconds=128816)

print(tiempo_fin1-tiempo_inic1)


print('********************************7')

tiempo_inic1 = datetime.timedelta(hours=14,minutes=25,seconds=59,microseconds=267842)
tiempo_fin1 = datetime.timedelta(hours=14,minutes=26,seconds=2,microseconds=295129)

print(tiempo_fin1-tiempo_inic1)