import mysql.connector
import datetime
import logging
import sys
import os
import telnetlib

class objTelnet:
	#dia_hora = datetime.datetime.utcnow() + datetime.timedelta(hours=configuracionParametros.desfazeUTC())

	def __init__(self,hostname,password,username,port):

		self.hostname = hostname
		self.password = password
		self.username = username
		self.port = port

	def buscar(self,command):

		tn = telnetlib.Telnet(self.hostname,self.port)

		tn.read_until(b'login: ')
		tn.write(self.username + "\n")
		if password:
		   tn.read_until(b'Password: ')
		   tn.write(self.password + "\n")

		tn.write(command+"\n")
		tn.write("exit\n")
		dato = tn.read_all()