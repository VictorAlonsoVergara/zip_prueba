
import time
import datetime
from hilo import MyThread
import CaptaDatos
import math

maximohilos= 20

hostname = '192.168.1.50'
password = 'apesol'
community = 'apesol'
command = 'pwd && ps'
comandoSnmp = 'iso.3.6.1.2.1.1.1.0'
username = 'ernesto'
port = 22
tipo_conexion = 'snmp'
comando = ['iso.3.6.1.2.1.1.1.0','iso.3.6.1.2.1.1.9.1.3.1','iso.3.6.1.2.1.1.9.1.3.6','iso.3.6.1.2.1.2.2.1.2.3','iso.3.6.1.2.1.25.2.3.1.3.1']
#comando = ['iso.3.6.1.2.1.1.1.0']

threads = list()
inicio2 = time.perf_counter()
inicio3 = time.process_time()
ips = CaptaDatos.separador_datos('ONT')
numero = math.ceil(len(ips)/maximohilos)
print('NUMERO DIVIDIDO ES: '+str(len(ips))+'/'+str(maximohilos)+'='+str(numero))                      

for i in range(maximohilos):
	try:
		ips[i]
		t = MyThread(i)
		threads.append(t)
		t.cambio_parametros(ips[i],password,username,port,community,tipo_conexion,comando)
		t.start()		
	except:
		pass
	finally:
		pass

print('TERMINO EL INICIO')
#print(threads)
	
actual = 1
while (actual != numero):
	print('NUMERO ACTUAL DEL WHILE '+str(actual))
	for nu in range(maximohilos):
		try:
			nume = actual*maximohilos
			ct = ips[nu+nume]  #saco la siguiente ip

		except:
			print('ERRO EN : '+str(nu+nume))
			pass
		else:
			parame = [0,'no encontro']
			for vari in range(len(threads)):
				if (threads[vari].estado=='acabo'):
					parame = [vari,'encontro']
					te = threads[vari]
					te.cambio_parametros(ips[nu+nume],password,username,port,community,tipo_conexion,comando)					
					break

			#print('*****************PARAME: '+ str(parame))
			#if (parame[1] == 'encontro'):
			#	te = threads[parame[0]]
			#	te.cambio_parametros(ips[nu+nume],password,username,port,community,tipo_conexion,comando)
			#else:
			if(parame[1]=='no encontro'):
				aumento=len(threads)
				t = MyThread(aumento)
				threads.append(t)
				t.cambio_parametros(ips[nu+nume],password,username,port,community,tipo_conexion,comando)
				t.start()


	if (len(threads)>maximohilos):
		print(threads)
		largoThreads = len(threads)
		for i in range(largoThreads-maximohilos):
			print('PRINTEO de I , maximohilos y Len '+str(i)+' '+str(maximohilos)+' '+str(len(threads)))

			if(threads[largoThreads-(1+i)].estado=='acabo'):
				print(threads[largoThreads-(1+i)])
				threads[largoThreads-(1+i)].salir()
				del threads[largoThreads-(1+i)]

	actual = actual + 1

print('INICIO DEL FIN')
print(threads)
while(1):
	flag = 'si'
	for temp in threads:
		if (temp.estado != 'acabo'):
			flag = 'no'
	if (flag == 'si'):
		break
print('ACABO TODO')
fin2 = time.perf_counter()
fin3 = time.process_time()
print('_FIN_DE_TIEMPO_')

print('EL PROGRAMA DURO2: '+str(fin2 - inicio2))
print(fin2)
print(inicio2)

print('EL PROGRAMA DURO3: '+str(fin3 - inicio3))
print(fin3)
print(inicio3)



