import os 
import time
import threading

def programa1():
	os.system('python3 programa1.py')

def programa2():
	os.system('python3 prueba.py')

while(1):
	x = input('escribe algo: ')
	t = threading.Thread(target=programa1, args=())
	t2 = threading.Thread(target=programa2, args=())
	t.start()
	t2.start()
	time.sleep(1)