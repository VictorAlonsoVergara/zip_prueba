import datetime
import CaptaDatos
import math
import threading
import time
import datetime
import logging
import random
from dispositivo import dispositivo

ips2 = CaptaDatos.separador_datos2('ONT')

nombre_log = "traza_hilos2.log"

logging.basicConfig(filename=nombre_log)#,level=logging.INFO)
logging.warning('^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^INICIO DE LOS HILOS :'+str(datetime.datetime.today())+'^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^')

class MyThread (threading.Thread):
	global ips2
	def __init__(self,number):

		self.number = number
		self.hostname = ''
		self.password = 'apesol'
		self.username = 'ernesto'
		self.port = 22
		self.community = 'apesol'
		self.conexion = 'snmp'
		self.comando = ['iso.3.6.1.2.1.1.1.0','iso.3.6.1.2.1.1.9.1.3.1','iso.3.6.1.2.1.1.9.1.3.6','iso.3.6.1.2.1.2.2.1.2.3','iso.3.6.1.2.1.25.2.3.1.3.1']
		self.lock = threading.RLock()
		self.estado = 'disponible'
		self.obj = ''
		super(MyThread, self).__init__()

	def salir(self):  # you can use a proper setter if you want
		with self.lock:
			self.estado = 'salir'

	def cambio_parametros(self,hostname,password,username,port,community,conexion,comando):  # you can use a proper setter if you want
		with self.lock:
			self.hostname = hostname
			self.password = password
			self.username = username
			self.port = port
			self.community = community
			self.conexion = conexion
			self.comando = comando
			self.estado = 'disponible'


	def run(self):
		while True:
			with self.lock:
				if(self.estado == 'salir'):
					break

				if(self.estado=='disponible'):
					self.estado='ocupado'
					tempo = ''
					for codi in ips2:
						if (codi[1]==''):
							codi[1] = 'ocupado'
							self.hostname = codi[0]							
							self.obj = dispositivo(self.hostname,self.password,self.username,self.port,self.community,self.conexion)
							dato=self.obj.metodo(self.comando)
							#if (dato == ['error']):
							logging.warning('hilo numero '+str(self.number)+' : '+str(dato)+' '+str(datetime.datetime.today())) 

							print('acabo de correr: '+str(self.number)+ ' ' + str(datetime.datetime.today()))
							#print('///////////'+str(datetime.datetime.today())+'/////////////')
							self.estado='acabo'


			#time.sleep(0.1)  # let it breathe



maximohilos= 20

hostname = '192.168.1.50'
password = 'apesol'
community = 'apesol'
command = 'pwd && ps'
comandoSnmp = 'iso.3.6.1.2.1.1.1.0'
username = 'ernesto'
port = 22
tipo_conexion = 'snmp'
comando = ['iso.3.6.1.2.1.1.1.0','iso.3.6.1.2.1.1.9.1.3.1','iso.3.6.1.2.1.1.9.1.3.6','iso.3.6.1.2.1.2.2.1.2.3','iso.3.6.1.2.1.25.2.3.1.3.1']
#comando = ['iso.3.6.1.2.1.1.1.0']

threads = list()
inicio2 = time.perf_counter()
inicio3 = time.process_time()
ips = CaptaDatos.separador_datos('ONT')
#print(ips2)
#print(ips)
numero = math.ceil(len(ips)/maximohilos)
print('NUMERO DIVIDIDO ES: '+str(len(ips))+'/'+str(maximohilos)+'='+str(numero))                      

for i in range(maximohilos):
	try:
		ips[i]
		t = MyThread(i)
		threads.append(t)
		#t.cambio_parametros(ips[i],password,username,port,community,tipo_conexion,comando)
		t.start()		
	except:
		pass
	finally:
		pass

print('TERMINO EL INICIO')
#print(threads)
'''
actual = 1
while (actual != numero):
	print('NUMERO ACTUAL DEL WHILE '+str(actual))
	for nu in range(maximohilos):
		try:
			nume = actual*maximohilos
			ct = ips[nu+nume]  #saco la siguiente ip

		except:
			print('ERRO EN : '+str(nu+nume))
			pass
		else:
			parame = [0,'no encontro']
			for vari in range(len(threads)):
				if (threads[vari].estado=='acabo'):
					parame = [vari,'encontro']
					te = threads[vari]
					te.cambio_parametros(ips[nu+nume],password,username,port,community,tipo_conexion,comando)					
					break

			#print('*****************PARAME: '+ str(parame))
			#if (parame[1] == 'encontro'):
			#	te = threads[parame[0]]
			#	te.cambio_parametros(ips[nu+nume],password,username,port,community,tipo_conexion,comando)
			#else:
			if(parame[1]=='no encontro'):
				aumento=len(threads)
				t = MyThread(aumento)
				threads.append(t)
				t.cambio_parametros(ips[nu+nume],password,username,port,community,tipo_conexion,comando)
				t.start()


	if (len(threads)>maximohilos):
		print(threads)
		largoThreads = len(threads)
		for i in range(largoThreads-maximohilos):
			print('PRINTEO de I , maximohilos y Len '+str(i)+' '+str(maximohilos)+' '+str(len(threads)))

			if(threads[largoThreads-(1+i)].estado=='acabo'):
				print(threads[largoThreads-(1+i)])
				threads[largoThreads-(1+i)].salir()
				del threads[largoThreads-(1+i)]

	actual = actual + 1
'''
print('INICIO DEL FIN')
#print(threads)
while(1):
	flag = 'si'
	for temp in threads:
		if (temp.estado != 'acabo'):
			flag = 'no'
	if (flag == 'si'):
		break
print('ACABO TODO')
fin2 = time.perf_counter()
fin3 = time.process_time()
print('_FIN_DE_TIEMPO_')

print('EL PROGRAMA DURO2: '+str(fin2 - inicio2))
print(fin2)
print(inicio2)

print('EL PROGRAMA DURO3: '+str(fin3 - inicio3))
print(fin3)
print(inicio3)



