
import threading
import time

def worker(num):
    """thread worker function"""
    print('Worker: %s' % num) 

threads = []
for i in range(10):
	time.sleep(0.5)
	t = threading.Thread(target=worker, args=(i,))
	threads.append(t)
	t.start()
