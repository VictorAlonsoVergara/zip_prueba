
import pandas as pd
from xlrd import open_workbook
from xlutils.copy import copy

def datos():
	try :
		data = pd.read_excel('datos2.xls') 
		df = pd.DataFrame(data, columns= ['Ips','CLASE']) 
		lista = []
		lista.append('ok')
		lista.append(df[0:])
	except :
		lista = ['no','']
	finally:
		return lista

def actualizacion_OLT(archivoRecep,archivoEnvi):
	#try :
	data = pd.read_excel(archivoEnvi)
	df = pd.DataFrame(data, columns= ['Direccion IP','MAC CM (ONT SerialNumber)'])
	lista = []
	lista.append('ok')
	lista.append(df[0:])
	print(archivoEnvi)
	print(len(lista[1]))
	print(lista)
	print('-------------------------------------')
	data2 = pd.read_excel(archivoRecep)
	df2 = pd.DataFrame(data2, columns= ['Ips','CLASE','MAC'])
	lista2 = []
	lista2.append('ok')
	lista2.append(df2[0:])
	print(archivoRecep)
	print(len(lista2[1]))
	print(lista2)
	print('-------------------------------------')

	numero = len(lista2[1])
	rb = open_workbook(archivoRecep)
	wb = copy(rb)
	s = wb.get_sheet(0)
	#for i in range(numero) :
	#	s.write(i+1,0,'j')
	#	s.write(i+1,1,'j')
	#	s.write(i+1,2,'j')
	#wb.save(archivoRecep)

	numero2 = len(lista[1])
	rb = open_workbook(archivoRecep)
	wb = copy(rb)
	s = wb.get_sheet(0)
	for i in range(numero2) :
		s.write(i+numero+1,0,lista[1].iloc[i]['Direccion IP'])
		s.write(i+numero+1,1,lista[1].iloc[i]['MAC CM (ONT SerialNumber)'])
		s.write(i+numero+1,2,'OLT')
	wb.save(archivoRecep)


def actualizacion_ONT(archivoRecep,archivoEnvi):
	#try :
	data = pd.read_excel(archivoEnvi)
	df = pd.DataFrame(data, columns= ['Direccion IP','MAC CM (ONT SerialNumber)'])
	lista = []
	lista.append('ok')
	lista.append(df[0:])
	print(archivoEnvi)
	print(len(lista[1]))
	print(lista)
	print('-------------------------------------')
	data2 = pd.read_excel(archivoRecep)
	df2 = pd.DataFrame(data2, columns= ['Ips','CLASE','MAC'])
	lista2 = []
	lista2.append('ok')
	lista2.append(df2[0:])
	print(archivoRecep)
	print(len(lista2[1]))
	print(lista2)
	print('-------------------------------------')

	numero = len(lista2[1])
	rb = open_workbook(archivoRecep)
	wb = copy(rb)
	s = wb.get_sheet(0)
	for i in range(numero) :
		s.write(i+1,0,'')
		s.write(i+1,1,'')
		s.write(i+1,2,'')
	wb.save(archivoRecep)

	numero2 = len(lista[1])
	rb = open_workbook(archivoRecep)
	wb = copy(rb)
	s = wb.get_sheet(0)
	for i in range(numero2) :
		s.write(i+1,0,lista[1].iloc[i]['Direccion IP'])
		s.write(i+1,1,lista[1].iloc[i]['MAC CM (ONT SerialNumber)'])
		s.write(i+1,2,'ONT')
	wb.save(archivoRecep)


def devuelve_posicion(nombre,string,columna):
	try:
		temp = datos(nombre,columna)
		numero = len(temp[1])
		grupo = []
		for i in range(numero) :
			if (temp[1].iloc[i][columna]==string):
				grupo.append(i+1)
	except:
		print('error3')
	finally:
		return grupo	

def separador_datos(string):
	try:
		#print('separador_datos')
		temp = datos()
		#print(temp)
		numero = len(temp[1])
		#print(numero)
		#print(string)
		grupo = []
		for i in range(numero) :
			#print('conteo: '+str(i))
			#print(temp[1].iloc[i]['CLASE'])
			if (temp[1].iloc[i]['CLASE']==string):
				#print('entro al if')
				grupo.append(temp[1].iloc[i]['Ips'])
	except:
		print('error1')
	finally:
		return grupo

def separador_datos2(string):
	try:
		#print('separador_datos')
		temp = datos()
		#print(temp)
		numero = len(temp[1])
		#print(numero)
		#print(string)
		grupo = []
		for i in range(numero) :
			#print('conteo: '+str(i))
			#print(temp[1].iloc[i]['CLASE'])
			if (temp[1].iloc[i]['CLASE']==string):
				#print('entro al if')
				grupo.append([temp[1].iloc[i]['Ips'],''])
	except:
		print('error1')
	finally:
		return grupo		

def editar(filename,columna,fila,dato):
	if ("codigos IP" == columna ):
		colum = 0
	elif("clases" == columna):
		colum = 1
	elif("cluster/nodo" == columna):
		colum = 2
	elif("direccion" == columna):
		colum = 3
	elif("distrito" == columna):
		colum = 4
	elif("ciudad" == columna):
		colum = 5
	elif("lat" == columna):
		colum = 6
	elif("long" == columna):
		colum = 7
	elif("anillo" == columna):
		colum = 8
	elif("ESTADO" == columna):
		colum = 9		
	else:
		colum = 12
	rb = open_workbook(filename)
	wb = copy(rb)
	s = wb.get_sheet(0)
	s.write(fila,colum,dato) #(numero_fila,numero_columna,contenido en la celda)
	wb.save(filename)

'''
try:

	filename = 'datos2.xls'

	header = ("codigos IP", "clases", "cluster/nodo","direccion","distrito","ciudad","lat","long","anillo","ESTADO")
	nombre = 'datos2.xls'
	columna = ['codigos IP','clases','cluster/nodo','ESTADO']
	temp=separador_datos(nombre,columna,'OLT')
	temp2 = devuelve_posicion(nombre,'192.70.0.322','codigos IP')
	try:
		temp2[0]
		editar(filename,'codigos IP',temp2[0],'192.70.0.21')
	except:
		print('error4')
except:
	print('error2')
finally:
	print('')'''
#while(1):
#try:
#actualizacion_ONT('datos2.xls','ONTs.xls')
#actualizacion_OLT('datos2.xls','OLTs.xls')
#print(separador_datos('OLT'))
#except:
#	print('error')


