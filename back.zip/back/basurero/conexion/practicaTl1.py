
'''
import pandas as pd

data = pd.read_excel (r'C:/Users/Ron/Desktop/Product List.xlsx') 
df = pd.DataFrame(data, columns= ['Product'])
print (df)'''

# ip de esta computadora 127.0.1.1
'''
import socket    
hostname = socket.gethostname()    
IPAddr = socket.gethostbyname(hostname)    
print("Your Computer Name is:" + hostname)    
print("Your Computer IP Address is:" + IPAddr) '''


from scapy.all import *

ans,unans = arping("127.0.1.0/24", verbose=0)
for s,r in ans:
    print("{} {}".format(r[Ether].src,s[ARP].pdst))



