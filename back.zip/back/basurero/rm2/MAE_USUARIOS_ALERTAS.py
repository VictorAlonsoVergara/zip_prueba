import psycopg2
import sys
import generico
from MAE_USUARIOS import MAE_USUARIOS
from MAE_INDICADORES import MAE_INDICADORES
import logging
import datetime

class MAE_USUARIOS_ALERTAS :

	def __init__(self,ind_id,usu_id):
	
		self.ind_id = ind_id #integer
		self.usu_id = usu_id #integer
		self.mae_usuarios = MAE_USUARIOS('','','','','','',usu_id)
		self.mae_indicadores = MAE_INDICADORES('','','',ind_id)
		self.mae_usuarios.buscar_dato()
		self.mae_indicadores.buscar_dato()
		nombre_log = 'Log_programa_'+generico.diahora()+'.log'
		logging.basicConfig(filename=nombre_log,level=logging.DEBUG)		
		
	def guardar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			tup = (self.ind_id,self.usu_id)
		   
			cur.execute('INSERT INTO "MAE_USUARIOS_ALERTAS" (ind_id,usu_id) VALUES (%s,%s)',tup)
			con.commit()
			dato = 'ok'
			logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla MAE_USUARIOS_ALERTAS')
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_USUARIOS_ALERTAS')
		except :
			dato = 'error'
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_USUARIOS_ALERTAS')
		finally:
			if con:
				con.close()
			return dato


	def consultar(self):
		print('consulta')