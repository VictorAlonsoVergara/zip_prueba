class consultas :

	def __init__(self, con_id):
		self.con_id = con_id
		self.con_desc = [con_id]
		self.con_estado = [con_id]
		self.con_protoclo = [con_id]
		self.con_trama_pregunta = [con_id]
		


	def funcion(self):  # you can use a proper setter if you want
		print('prueba')

	def consultar(self):
		print('consulta')