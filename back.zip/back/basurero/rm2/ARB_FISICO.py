import psycopg2
import sys
import generico
from MAE_OBJETOS import MAE_OBJETOS
import logging
import datetime

class ARB_FISICO :

	def __init__(self,id_obj_hijo,id_obj_padre):
	
		self.id_obj_hijo = id_obj_hijo #integer
		self.id_obj_padre = id_obj_padre #integer
		self.mae_objeto_hijo = MAE_OBJETOS('','','','',id_obj_hijo)
		self.mae_objeto_padre = MAE_OBJETOS('','','','',id_obj_padre)
		self.mae_objeto_hijo.buscar_dato()
		self.mae_objeto_padre.buscar_dato()
		nombre_log = 'Log_programa_'+generico.diahora()+'.log'
		logging.basicConfig(filename=nombre_log,level=logging.DEBUG)			

	def guardar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			tup = (self.id_obj_hijo,self.id_obj_padre)

			cur.execute('INSERT INTO "ARB_FISICO" (id_obj_hijo,id_obj_padre) VALUES (%s,%s)',tup)
			con.commit()
			dato = 'ok'
			logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla ARB_FISICO')
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla ARB_FISICO')
		except :
			dato = 'error'
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla ARB_FISICO')
		finally:
			if con:
				con.close()
			return dato

	def buscar_dato_hijo(self,codigo):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "ARB_FISICO" WHERE id_obj_padre ='+ str(self.codigo))
			version = cur.fetchall()

			self.id_obj_hijo = version[0][0] #integer
		except psycopg2.DatabaseError as e:
			print(f'Error {e}')
		finally:
			if con:
				con.close()
			return self.id_obj_hijo

	def buscar_dato_padre(self,codigo):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "ARB_FISICO" WHERE id_obj_hijo ='+ str(self.codigo))
			version = cur.fetchall()

			self.id_obj_padre = version[0][1] #integer
		except psycopg2.DatabaseError as e:
			print(f'Error {e}')
		finally:
			if con:
				con.close()
			return self.id_obj_padre		    

	def consultar(self):
		print('consulta')