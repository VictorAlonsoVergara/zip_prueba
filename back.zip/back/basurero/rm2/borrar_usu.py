import sys
sys.path.insert(0, '/home/sistema/clases')

import json
from MAE_USUARIOS import MAE_USUARIOS

def application(environ,start_response):
        status = '200 OK'
        bdata = environ['PATH_INFO']
        cdata = environ['QUERY_STRING']
        obj = MAE_USUARIOS(' ',1,' ',' ',' ',' ',int(bdata.split('/')[1]))
        resp = obj.borrar_usuario()
        preoutput = json.dumps(resp)
        output = bytes(preoutput, 'utf-8')
        response_headers =[('Content-type','application/json')]
        start_response(status,response_headers)
        return [output]
#http://81.17.56.130:33380/usuarios/crear?usu_nombre=Danillo soca&usu_correo=danillo@email.com&usu_usuario=Danil&usu_password=1234abc&usu_estado=A&usu_estado_desc=Activo&tusu_id=1


############################################################3
#CREATE TABLE account_role
#(
#  user_id integer NOT NULL,
#  role_id integer NOT NULL,
#  grant_date timestamp without time zone,
#  PRIMARY KEY (user_id, role_id),
#  CONSTRAINT account_role_role_id_fkey FOREIGN KEY (role_id)
#      REFERENCES role (role_id) MATCH SIMPLE
#      ON UPDATE NO ACTION ON DELETE NO ACTION,
#  CONSTRAINT account_role_user_id_fkey FOREIGN KEY (user_id)
#      REFERENCES account (user_id) MATCH SIMPLE
#      ON UPDATE NO ACTION ON DELETE NO ACTION
#);

#CREATE TABLE role(
#   role_id serial PRIMARY KEY,
#   role_name VARCHAR (255) UNIQUE NOT NULL
#);

#ALTER TABLE "MAE_USUARIOS" ADD usu_estado_desc varchar(200);

