from cgi import parse_qs,escape
from MAE_OBJETOS_CONSULTAS import MAE_OBJETOS_CONSULTAS

def application(environ,start_response):
	ldata = int(environ.get('CONTENT_LENGTH',0))
	bdata = environ['wsgi.input'].read(ldata)
	logging.info(bdata)

	data = parse_qs(bdata)
	logging.info(data)

	d_obj_id = data.get(b'obj_id')
	d_con_id = data.get(b'con_id')
	d_objc_estado = data.get(b'objc_estado')
	d_objc_protocolo = data.get(b'objc_protocolo')
	d_objc_trama = data.get(b'objc_trama')

	obj = MAE_OBJETOS_CONSULTAS(d_obj_id[0].decode(),d_con_id[0].decode(),d_objc_estado[0].decode(),d_objc_protocolo[0].decode(),d_objc_trama[0].decode())
	obj.guardar_dato()

	status='200 OK'
	output='ID de objeto :' + d_obj_id[0].decode() + "</br>" + "Id de consulta:" + d_con_id[0].decode() + "</br>" + "Estado de objeto de consulta:" + d_objc_estado[0].decode() + "</br>" + "Protocolo de objeto consulta:" + d_objc_protocolo[0].decode() + "</br>" + "Trama de objeto consulta:" +  d_objc_trama.decode()
	output = output.encode()

	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]
	start_response(status,response_headers)
	return [output]
