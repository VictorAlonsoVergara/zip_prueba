from cgi import parse_qs,escape
from ARB_LOGICO import ARB_LOGICO

def application(environ,start_response):
	ldata = int(environ.get('CONTENT_LENGTH',0))
	bdata = environ['wsgi.input'].read(ldata)
	logging.info(bdata)

	data = parse_qs(bdata)
	logging.info(data)

	d_id_obj_hijo = data.get(b'id_obj_hijo')
	d_id_obj_padre = data.get(b'id_obj_padre')
	obj = ARB_LOGICO(d_id_obj_hijo[0].decode(),d_id_obj_padre[0].decode())
	obj.guardar_dato()

	status='200 OK'
	output='ID del hijo :' + d_id_obj_hijo[0].decode() + "</br>" + "Id del padre:" + d_id_obj_padre[0].decode() 
	output = output.encode()

	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]
	start_response(status,response_headers)
	return [output]
