import sys
sys.path.insert(0, '/home/sistema/clases')

import json
from MAE_USUARIOS import MAE_USUARIOS

def application(environ,start_response):
  status = '200 OK'
  bdata = environ['PATH_INFO']
  cdata = environ['QUERY_STRING'] #usare esto
  datos_recev=cdata.split('&')
  diccionario = {}
  for dat in datos_recev:
  	duo = dat.split('=')
  	diccionario[duo[0]]=duo[1]

  obj = MAE_USUARIOS(diccionario['usu_nombre']replace("%20", " "),int(diccionario['tusu_id']),diccionario['usu_estado'],diccionario['usu_correo'],diccionario['usu_usuario'],diccionario['usu_password'])
  resp = obj.guardar_dato()
  linea = {}
  if (resp[0] == 'ok'):
    linea['result'] = "ok" 
    linea['usu_id'] = obj.usu_id
  else:
    linea['result'] = "failed"
    linea['error'] = "Sucedio un error"
    linea['error_cod'] = 412
    linea['val_errors'] = resp[1]

  preoutput = json.dumps(linea)
  output = bytes(preoutput, 'utf-8')
  response_headers =[('Content-type','application/json')]
  start_response(status,response_headers)
  return [output]


#  usu_nombre=Manuel Laura&usu_correo=manuel@email.com&usu_usuario=manuel&usu_password=1234abc&usu_estado=A&usu_estado_desc=Activo&tusu_id=1

