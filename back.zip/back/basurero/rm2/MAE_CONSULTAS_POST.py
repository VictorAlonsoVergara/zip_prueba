

def application(environ,start_response):   #<-- esta función es la que buscará el Apache para empezar la respuesta al navegador
	status='200 OK'   #<-- código de respuesta, 200 es "página existe"
	output=b'<form method="POST" action="graba_MAE_CONSULTAS_POST/">Maestro Consultas</br></br>descripcion de consulta:<input name="con_desc" type="text"></br></br>estado de consulta:<input type="text" name="con_estado"></br></br>protocolo de consulta:<input type="text" name="con_protocolo"></br></br>trama pregunta de consulta:<input type="text" name="con_trama_pregunta"></br></br><input type="submit"></form>'
	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]   
	start_response(status,response_headers) 
	return [output]    #<-- se envía la data al navegador