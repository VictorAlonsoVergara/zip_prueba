from cgi import parse_qs,escape
from TAB_EJECUCIONES import TAB_EJECUCIONES

def application(environ,start_response):
	ldata = int(environ.get('CONTENT_LENGTH',0))
	bdata = environ['wsgi.input'].read(ldata)
	logging.info(bdata)

	data = parse_qs(bdata)
	logging.info(data)

	d_eje_fecha = data.get(b'eje_fecha')
	d_cron_id = data.get(b'cron_id')
	d_eje_fecha_ini = data.get(b'eje_fecha_ini')
	d_eje_fecha_fin = data.get(b'eje_fecha_fin')
	d_eje_log = data.get(b'eje_log')
	d_eje_fecha_transferencia = data.get(b'eje_fecha_transferencia')
	d_eje_fecha_parseo = data.get(b'eje_fecha_parseo')

	obj = TAB_EJECUCIONES(d_eje_fecha[0].decode(),d_cron_id[0].decode(),d_eje_fecha_ini[0].decode(),d_eje_fecha_fin[0].decode(),d_eje_log[0].decode(),d_eje_fecha_transferencia[0].decode(),d_eje_fecha_parseo[0].decode())
	obj.guardar_dato()

	status='200 OK'
	output='Fecha de ejecucion :' + d_eje_fecha[0].decode() + "</br>" + "Id del cron:" + d_cron_id[0].decode() + "</br>" + "Fecha de inicio de ejecucion:" + d_eje_fecha_ini[0].decode() + "</br>" + "Fecha de fin de ejecucion:" + d_eje_fecha_fin[0].decode() + "</br>" + "Ejecucion de log" + d_eje_log[0].decode() + "</br>" + "Fecha de ejecucion de transferencia:" + d_eje_fecha_transferencia[0].decode() + "</br>" + "Fecha de ejecucion de parseo:" + d_eje_fecha_parseo[0].decode()
	output = output.encode()

	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]
	start_response(status,response_headers)
	return [output]
