import sys
sys.path.insert(0, '/home/sistema/clases')

import json
from MAE_USUARIOS import MAE_USUARIOS

def application(environ,start_response):
        status = '200 OK'
        bdata = environ['PATH_INFO']
        cdata = environ['QUERY_STRING']
        obj = MAE_USUARIOS('a',1,'b','c','d','e',int(bdata.split('/')[1]))
        obj.buscar_dato()
        data = {}
        data['usu_id']=int(bdata.split('/')[1])
        data['usu_nombre']= obj.usu_nombre
        data['usu_correo']= obj.usu_correo
        data['usu_usario']= obj.usu_usuario
        data['usu_estado']= obj.usu_estado
        data['usu_estado_desc'] = 'Descripcion'
        data['tusu_id']= obj.tusu_id
        data['tusu_desc']=obj.mae_tipo_usu.tusu_desc
        preoutput = json.dumps(data)
        output = bytes(preoutput, 'utf-8')
        response_headers =[('Content-type','application/json')]
        start_response(status,response_headers)
        return [output]
