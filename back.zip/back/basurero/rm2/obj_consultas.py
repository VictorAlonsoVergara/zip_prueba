import consultas

class obj_consultas :

	def __init__(self, obj_id):
		self.obj_id = obj_id
		self.con_id = consultas(obj_id)
		self.objc_estado = [obj_id]
		self.objc_protocolo = [obj_id]
		self.objc_trama = [obj_id]


	def funcion(self):  # you can use a proper setter if you want
		print('prueba')

	def consultar(self):
		print('consulta')