from PRUEBA3 import PRUEBA3

dato = PRUEBA3('xd','fd')