from cgi import parse_qs,escape
from MAE_INDICADORES import MAE_INDICADORES

def application(environ,start_response):
	ldata = int(environ.get('CONTENT_LENGTH',0))
	bdata = environ['wsgi.input'].read(ldata)
	logging.info(bdata)

	data = parse_qs(bdata)
	logging.info(data)

	d_ind_desc = data.get(b'ind_desc')
	d_ind_estado = data.get(b'ind_estado')
	d_ind_ldesc = data.get(b'ind_ldesc')
	d_ind_alerta = data.get(b'ind_alerta')
	d_cron_id = data.get(b'cron_id')
	d_ind_trap = data.get(b'ind_trap')
	d_ind_trap_definicion = data.get(b'ind_trap_definicion')

	obj = MAE_INDICADORES(d_ind_desc[0].decode(),d_ind_estado[0].decode(),d_ind_ldesc[0].decode(),d_ind_alerta[0].decode(),d_cron_id[0].decode(),d_ind_trap[0].decode(),d_ind_trap_definicion[0].decode())
	obj.guardar_dato()

	status='200 OK'
	output='Descripcion de indicador :' + d_ind_desc[0].decode() + "</br>" + "Estado de indicador:" + d_ind_estado[0].decode() + "</br>" + "Ldescripcion de indicador:" + d_ind_ldesc[0].decode() + "</br>" + "Alerta del indicador:" + d_ind_alerta[0].decode() + "</br>" + "Id del cron" + d_cron_id[0].decode() + "</br>" + "Trap del indicador:" + d_ind_trap[0].decode() + "</br>" + "Definicion del trap del indicador:" + d_ind_trap_definicion[0].decode()
	output = output.encode()

	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]
	start_response(status,response_headers)
	return [output]
