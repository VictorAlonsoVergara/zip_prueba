import sys
sys.path.insert(0, '/home/sistema/clases')

import json
from MAE_USUARIOS import MAE_USUARIOS

def application(environ,start_response):

  status = '200 OK'
  bdata = environ['PATH_INFO']
  cdata = environ['QUERY_STRING'] #usare esto
  datos_recev=cdata.split('&')
  diccionario = {}
  for dat in datos_recev:
  	duo = dat.split('=')
  	diccionario[duo[0]]=duo[1]

  obj = MAE_USUARIOS(diccionario['usu_nombre'].replace("%20", " "),int(diccionario['tusu_id']),diccionario['usu_estado'],diccionario['usu_correo'],diccionario['usu_usuario'],diccionario['usu_password'],int(diccionario['usu_id']))
  resp = obj.modificar_usuario()

  preoutput = json.dumps(resp)
  output = bytes(preoutput, 'utf-8')
  response_headers =[('Content-type','application/json')]
  start_response(status,response_headers)
  return [output]

#http://81.17.56.130:33380/usuarios/modificar?usu_nombre=Danillo%20soca&usu_correo=danillo@email.com&usu_usuario=Danil&usu_password=1234abc&usu_estado=A&usu_estado_desc=Activo&tusu_id=1&usu_id=11