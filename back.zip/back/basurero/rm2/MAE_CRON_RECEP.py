from cgi import parse_qs,escape
from MAE_CRON import MAE_CRON

def application(environ,start_response):
	ldata = int(environ.get('CONTENT_LENGTH',0))
	bdata = environ['wsgi.input'].read(ldata)
	logging.info(bdata)

	data = parse_qs(bdata)
	logging.info(data)

	d_tobj_id = data.get(b'tobj_id')
	d_cron_tipo = data.get(b'cron_tipo')
	d_cron_periodo = data.get(b'cron_periodo')
	d_cron_estado = data.get(b'cron_estado')

	obj = MAE_CRON(d_tobj_id[0].decode(),d_cron_tipo[0].decode(),d_cron_periodo[0].decode(),d_cron_estado[0].decode())
	obj.guardar_dato()

	status='200 OK'
	output='ID de tipo de objeto :' + d_tobj_id[0].decode() + "</br>" + "Tipo de cron:" + d_cron_tipo[0].decode() + "</br>" + "Periodo de cron:" + d_cron_periodo[0].decode() + "</br>" + "Estado de cron:" + d_cron_estado[0].decode() 
	output = output.encode()

	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]
	start_response(status,response_headers)
	return [output]
