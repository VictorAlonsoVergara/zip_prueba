from cgi import parse_qs,escape
from MAE_USUARIOS_ALERTAS import MAE_USUARIOS_ALERTAS

def application(environ,start_response):
	ldata = int(environ.get('CONTENT_LENGTH',0))
	bdata = environ['wsgi.input'].read(ldata)
	logging.info(bdata)

	data = parse_qs(bdata)
	logging.info(data)

	d_ind_id = data.get(b'ind_id')
	d_usu_id = data.get(b'usu_id')

	obj = MAE_INDICADORES(d_ind_id[0].decode(),d_usu_id[0].decode())
	obj.guardar_dato()

	status='200 OK'
	output='ID del indicador :' + d_ind_id[0].decode() + "</br>" + "Estado de indicador:" + d_usu_id[0].decode() 
	output = output.encode()

	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]
	start_response(status,response_headers)
	return [output]
