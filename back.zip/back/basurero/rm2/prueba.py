import logging

logname="/var/log/app/traza.log"
logging.basicConfig(filename=logname, level=logging.DEBUG)
logging.info("ENTRO")
