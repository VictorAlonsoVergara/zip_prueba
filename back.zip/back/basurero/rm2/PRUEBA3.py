

class PRUEBA3 :

	def __init__(self, msg1, msg2):
	
		self.msg1 = msg1
		self.msg2 = msg2
		print('init 1')	

	def __init__(self, msg1):
	
		self.msg1 = msg1
		print('init 2')	
		