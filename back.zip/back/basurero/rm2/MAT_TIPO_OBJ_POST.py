
def application(environ,start_response):   #<-- esta función es la que buscará el Apache para empezar la respuesta al navegador
	status='200 OK'   #<-- código de respuesta, 200 es "página existe"
	output=b'<form method="POST" action="graba_MAT_TIPO_OBJ_POST/">Tipo Objetos</br></br>descripcion de tipo de objeto:<input name="tobj_desc" type="text"></br></br>Estado de tipo de objeto:<input type="text" name="tobj_estado"></br></br>Consulta tipo de objeto:<input type="text" name="tobj_consulta"></br></br>Ldescripcion de tipo objeto:<input type="text" name="tobj_ldesc"></br></br><input type="submit"></form>'
	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]   
	start_response(status,response_headers) 
	return [output]    #<-- se envía la data al navegador