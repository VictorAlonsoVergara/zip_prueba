

def application(environ,start_response):   #<-- esta función es la que buscará el Apache para empezar la respuesta al navegador											
	status='200 OK'   #<-- código de respuesta, 200 es "página existe"
	output=b'<form method="POST" action="graba_MAE_OBJETOS_CONSULTAS_POST/">Maestro de objetos consultas</br></br>ID de objeto:<input name="obj_id" type="text"></br></br>Id de la consultas:<input type="text" name="con_id"></br></br>Estado de objeto consulta:<input type="text" name="objc_estado"></br></br>Protocolo de objeto consulta:<input type="text" name="objc_protocolo"></br></br>Trama de objeto consulta:<input type="text" name="objc_trama"></br></br><input type="submit"></form>'
	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]   
	start_response(status,response_headers) 
	return [output]    #<-- se envía la data al navegador