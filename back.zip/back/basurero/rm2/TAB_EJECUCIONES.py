import psycopg2
import sys
import generico
from MAE_CRON import MAE_CRON
import logging
import datetime

class TAB_EJECUCIONES :

	def __init__(self,eje_fecha,cron_id,eje_fecha_ini,eje_fecha_fin,eje_log,eje_fecha_transferencia,eje_fecha_parseo,eje_id=None):
	
		self.eje_id = eje_id #serial
		self.eje_fecha = eje_fecha #datetime timestamp with time zone
		self.cron_id = cron_id #integer
		self.eje_fecha_ini = eje_fecha_ini #datetime timestamp with time zone
		self.eje_fecha_fin = eje_fecha_fin #datetime timestamp with time zone
		self.eje_log = eje_log # varchar(50)
		self.eje_fecha_transferencia = eje_fecha_transferencia #datetime timestamp with time zone
		self.eje_fecha_parseo = eje_fecha_parseo #datetime timestamp with time zone
		self.mae_cron = MAE_CRON('','','','',cron_id)
		self.mae_cron.buscar_dato()
		nombre_log = 'Log_programa_'+generico.diahora()+'.log'
		logging.basicConfig(filename=nombre_log,level=logging.DEBUG)


	def guardar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			tup = (self.eje_fecha,self.cron_id,self.eje_fecha_ini,self.eje_fecha_fin,self.eje_log,self.eje_fecha_transferencia,self.eje_fecha_parseo)

			cur.execute('INSERT INTO "TAB_EJECUCIONES" (eje_fecha,cron_id,eje_fecha_ini,eje_fecha_fin,eje_log,eje_fecha_transferencia,eje_fecha_parseo) VALUES (%s,%s,%s,%s,%s,%s,%s)',tup)
			con.commit()
			cur.execute('SELECT * FROM "TAB_EJECUCIONES" WHERE eje_fecha =\''+ str(self.eje_fecha)+'\' AND cron_id ='+ str(self.cron_id)+' AND eje_fecha_ini = \''+str(self.eje_fecha_ini)+'\' AND eje_fecha_fin = \''+str(self.eje_fecha_fin)+'\' AND eje_log = \''+self.eje_log+'\' AND eje_fecha_transferencia = \''+str(self.eje_fecha_transferencia)+'\' AND eje_fecha_parseo = \''+str(self.eje_fecha_parseo)+'\' ')
			version = cur.fetchall()
			self.eje_id = version[len(version)-1][0]
			dato = 'ok'
			logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla TAB_EJECUCIONES')
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla TAB_EJECUCIONES')
		except :
			dato = 'error'
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla TAB_EJECUCIONES')
		finally:
			if con:
				con.close()
			return dato

	def buscar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "TAB_EJECUCIONES" WHERE eje_id ='+ str(self.eje_id))
			version = cur.fetchall()

			self.eje_fecha = version[0][1] #datetime timestamp with time zone
			self.cron_id = version[0][2] #integer
			self.eje_fecha_ini = version[0][3] #datetime timestamp with time zone
			self.eje_fecha_fin = version[0][4] #datetime timestamp with time zone
			self.eje_log = version[0][5] # varchar(50)
			self.eje_fecha_transferencia = version[0][6] #datetime timestamp with time zone
			self.eje_fecha_parseo = version[0][7] #datetime timestamp with time zone
			dato = 'ok'
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
		except :
			dato = 'error'
		finally:
			if con:
				con.close()
			return dato

	def consultar(self):
		print('consulta')