

def application(environ,start_response):   #<-- esta función es la que buscará el Apache para empezar la respuesta al navegador											
	status='200 OK'   #<-- código de respuesta, 200 es "página existe"
	output=b'<form method="POST" action="graba_MAE_USUARIOS_POST/">Usuario</br></br>Nombre de usuario:<input name="usu_nombre" type="text"></br></br>Tipo de usuario id:<input type="text" name="tusu_id"></br></br>Estado de usuario:<input type="text" name="usu_estado"></br></br>Correo de usuario:<input type="text" name="usu_correo"></br></br>Nombre de usuario a utilizar:<input type="text" name="usu_usuario"></br></br>Contrasena de usuario:<input type="text" name="usu_password"></br></br><input type="submit"></form>'
	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]   
	start_response(status,response_headers) 
	return [output]    #<-- se envía la data al navegador