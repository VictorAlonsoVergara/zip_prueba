

def application(environ,start_response):   #<-- esta función es la que buscará el Apache para empezar la respuesta al navegador											
	status='200 OK'   #<-- código de respuesta, 200 es "página existe"
	output=b'<form method="POST" action="graba_ARB_LOGICO_POST/">Arbol logico</br></br>ID del hijo:<input name="id_obj_hijo" type="text"></br></br>ID del padre:<input type="text" name="id_obj_padre"></br></br><input type="submit"></form>'
	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]   
	start_response(status,response_headers) 
	return [output]    #<-- se envía la data al navegador