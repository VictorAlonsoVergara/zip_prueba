from cgi import parse_qs,escape
from MAT_TIPO_OBJ import MAT_TIPO_OBJ

def application(environ,start_response):
	ldata = int(environ.get('CONTENT_LENGTH',0))
	bdata = environ['wsgi.input'].read(ldata)
	logging.info(bdata)

	data = parse_qs(bdata)
	logging.info(data)

	d_tobj_desc = data.get(b'tobj_desc')
	d_tobj_estado = data.get(b'tobj_estado')
	d_tobj_consulta = data.get(b'tobj_consulta')
	d_tobj_ldesc = data.get(b'tobj_ldesc')

	obj = MAT_TIPO_OBJ(d_tobj_desc[0].decode(),d_tobj_estado[0].decode(),d_tobj_consulta[0].decode(),d_tobj_ldesc[0].decode())
	obj.guardar_dato()
	status='200 OK'
	output='Descripcion de tipo objeto:' + d_tobj_desc[0].decode() + "</br>" + "Estado de tipo de objeto:" + d_tobj_estado[0].decode()+ "</br>" + "Consulta tipo de objeto:" + d_tobj_consulta[0].decode() + "</br>" + "Ldescripcion de tipo de objeto:" + d_tobj_ldesc[0].decode()
	output = output.encode()

	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]
	start_response(status,response_headers)
	return [output]
