

def application(environ,start_response):   #<-- esta función es la que buscará el Apache para empezar la respuesta al navegador											
	status='200 OK'   #<-- código de respuesta, 200 es "página existe"
	output=b'<form method="POST" action="graba_TAB_EJECUCIONES_POST/">Tabla de ejecuciones</br></br>Fecha de ejecucion:<input name="eje_fecha" type="text"></br></br>ID del cron:<input type="text" name="cron_id"></br></br>Fecha de inicio de ejecucion:<input type="text" name="eje_fecha_ini"></br></br>Fecha de fin de ejecucion:<input type="text" name="eje_fecha_fin"></br></br>Log de ejecucion:<input type="text" name="eje_log"></br></br>Fecha de ejecucion de transferencia:<input type="text" name="eje_fecha_transferencia"></br></br>Fecha de ejecucion de parseo:<input type="text" name="eje_fecha_parseo"></br></br><input type="submit"></form>'
	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]   
	start_response(status,response_headers) 
	return [output]    #<-- se envía la data al navegador