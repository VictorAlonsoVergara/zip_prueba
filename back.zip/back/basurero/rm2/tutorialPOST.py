'''
import psycopg2
#try:

connection = psycopg2.connect(user = "sistema",password = "sistemacotener2019",host = "81.17.56.130",port = "33332",dbname = "cotener")
cursor = connection.cursor()
print(connection.get_dsn_parameters(),"\n")

cursor.execute("SELECT version();")
record = cursor.fetchone()
print("you are connected to - ",record,"\n")

#except (Exception, psycopg2.Error) as error:
#	print("Error while connecting to PostgreSQL",error)
#finally:
if(connection):
	cursor.close()
	connection.close()
	print("PostgreSQL connection is closed")'''
'''
import psycopg2
import sys

con = None

try:

    con = psycopg2.connect(database='cotener',user='cotener',password='cotener')

    cur = con.cursor()
    tup = [('descripcionTusu2',7),('descrip',9)]
   # cur.executemany('INSERT INTO "MAE_OBJETOS" (obj_desc,tobj_id,obj_estado,obj_l$
    cur.executemany('INSERT INTO "MAE_TIPO_USU" (tusu_desc,tusu_estado) VALUES (%s,%s)',tup)
    con.commit()
    cur.execute('SELECT * FROM "MAE_TIPO_USU"')
    version = cur.fetchall()
    print(version)

except psycopg2.DatabaseError as e:

    print(f'Error {e}')
    sys.exit(1)

finally:

    if con:
        con.close()
'''

'''
 Schema |            Name             | Type  |  Owner   
--------+-----------------------------+-------+----------
 public | ARB_FISICO                  | table | postgres
 public | ARB_LOGICO                  | table | postgres
 public | MAE_CONSULTAS               | table | postgres
 public | MAE_CRON                    | table | postgres
 public | MAE_INDICADORES             | table | postgres
 public | MAE_OBJETOS                 | table | postgres
 public | MAE_OBJETOS_CONSULTAS       | table | postgres
 public | MAE_TIPO_USU                | table | postgres
 public | MAE_USUARIOS                | table | postgres
 public | MAE_USU_ACCESOS_ARBOLES     | table | postgres
 public | MAE_USU_ACCESOS_INDICADORES | table | postgres
 public | MAT_TIPO_OBJ                | table | postgres
 public | TAB_EJECUCIONES             | table | postgres
**********************************************

                   Table "public.MAE_OBJETOS_CONSULTAS"
     Column     |          Type          | Collation | Nullable | Default 
----------------+------------------------+-----------+----------+---------
 obj_id         | integer                |           | not null | 
 con_id         | integer                |           | not null | 
 objc_estado    | character(1)           |           |          | 
 objc_protocolo | character(1)           |           |          | 
 objc_trama     | character varying(500) |           |          | 
Indexes:
    "MAE_OBJETOS_CONSULTAS_pk" PRIMARY KEY, btree (obj_id, con_id)
Foreign-key constraints:
    "FK_MAE_OBJETOS_CONSULTA1" FOREIGN KEY (obj_id) REFERENCES "MAE_OBJETOS"(obj_id) MATCH FULL
    "FK_MAE_OBJETOS_CONSULTA2" FOREIGN KEY (con_id) REFERENCES "MAE_CONSULTAS"(con_id) MATCH FULL



 '''
resp = ['error','error por algo']
linea = {}
if (resp[0] == 'ok'):
	linea['result'] = "ok" 
	linea['usu_id'] = 12
else:
	linea['result'] = "failed"
	linea['error'] = "Sucedio un error"
	linea['error_cod'] = 412
	linea['val_errors'] = resp[1]

print(linea)