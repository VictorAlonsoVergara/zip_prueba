import sys
sys.path.insert(0, '/home/sistema/clases')

import json
from MAE_USUARIOS import MAE_USUARIOS

def application(environ,start_response):
  status = '200 OK'
  bdata = environ['PATH_INFO']
  cdata = environ['QUERY_STRING']
  diccionario = MAE_USUARIOS.consultar_lista()
  preoutput = json.dumps(diccionario)
  output = bytes(preoutput, 'utf-8')
  response_headers =[('Content-type','application/json')]
  start_response(status,response_headers)
  return [output]
