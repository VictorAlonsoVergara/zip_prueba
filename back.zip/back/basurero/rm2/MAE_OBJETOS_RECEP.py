from cgi import parse_qs,escape
from MAE_OBJETOS import MAE_OBJETOS

def application(environ,start_response):
	ldata = int(environ.get('CONTENT_LENGTH',0))
	bdata = environ['wsgi.input'].read(ldata)
	logging.info(bdata)

	data = parse_qs(bdata)
	logging.info(data)

	d_obj_desc = data.get(b'obj_desc')
	d_tobj_id = data.get(b'tobj_id')
	d_obj_estado = data.get(b'obj_estado')
	d_obj_ldesc = data.get(b'obj_ldesc')

	obj = MAE_OBJETOS(d_obj_desc[0].decode(),d_tobj_id[0].decode(),d_obj_estado[0].decode(),d_obj_ldesc[0].decode())
	obj.guardar_dato()

	status='200 OK'
	output='Descripcion de objeto :' + d_obj_desc[0].decode() + "</br>" + "Descripcion de id tipo de objetivo:" + d_tobj_id[0].decode() + "</br>" + "Estado de objeto:" + d_obj_estado[0].decode() + "</br>" + "Ldescripcion de objeto:" + d_obj_ldesc[0].decode() 
	output = output.encode()

	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]
	start_response(status,response_headers)
	return [output]
