from cgi import parse_qs,escape
from MAE_TIPO_USU import MAE_TIPO_USU

def application(environ,start_response):
	ldata = int(environ.get('CONTENT_LENGTH',0))
	bdata = environ['wsgi.input'].read(ldata)
	logging.info(bdata)

	data = parse_qs(bdata)
	logging.info(data)

	d_tusu_desc = data.get(b'tusu_desc')
	d_tusu_estado = data.get(b'tusu_estado')

	obj = MAE_TIPO_USU_RECEP(d_tusu_desc[0].decode(),d_tusu_estado[0].decode())
	obj.guardar_dato()

	status='200 OK'
	output='Descripcion de tipo de usuario :' + d_tusu_desc[0].decode() + "</br>" + "Estado de tipo de usuario:" + d_tusu_estado[0].decode()
	output = output.encode()

	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]
	start_response(status,response_headers)
	return [output]
