from cgi import parse_qs,escape
from MAE_USUARIOS import MAE_USUARIOS

def application(environ,start_response):
	ldata = int(environ.get('CONTENT_LENGTH',0))
	bdata = environ['wsgi.input'].read(ldata)
	logging.info(bdata)

	data = parse_qs(bdata)
	logging.info(data)

	d_usu_nombre = data.get(b'usu_nombre')
	d_tusu_id = data.get(b'tusu_id')
	d_usu_estado = data.get(b'usu_estado')
	d_usu_correo = data.get(b'usu_correo')
	d_usu_usuario = data.get(b'usu_usuario')
	d_usu_password = data.get(b'usu_password')	

	obj = MAE_USUARIOS(d_usu_nombre[0].decode(),d_tusu_id[0].decode(),d_usu_estado[0].decode(),d_usu_correo[0].decode(),d_usu_usuario[0].decode(),d_usu_password[0].decode())
	obj.guardar_dato()

	status='200 OK'
	output='Nombre de usuario :' + d_tusu_desc[0].decode() + "</br>" + "Tipo de usuario id:" + d_tusu_id[0].decode() + "</br>" + "Estado de usuario:" + d_usu_estado[0].decode() + "</br>" + "Correo de usuario:" + d_usu_correo[0].decode() + "</br>" + "Nombre de usuario a utilizar:" + d_usu_usuario[0].decode() + "</br>" + "Contrasena de usuario:" + d_usu_password[0].decode()
	output = output.encode()

	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]
	start_response(status,response_headers)
	return [output]
