

def application(environ,start_response):   #<-- esta función es la que buscará el Apache para empezar la respuesta al navegador											
	status='200 OK'   #<-- código de respuesta, 200 es "página existe"
	output=b'<form method="POST" action="graba_MAE_INDICADORES_POST/">Maestro de indicadores</br></br>Descripcion de indicador:<input name="ind_desc" type="text"></br></br>Estado de indicador:<input type="text" name="ind_estado"></br></br>Ldescripcion de indicador:<input type="text" name="ind_ldesc"></br></br>Alerta de indicador:<input type="text" name="ind_alerta"></br></br>ID de cron:<input type="text" name="cron_id"></br></br>Trap del indicador:<input type="text" name="ind_trap"></br></br>Definicion del trap del indicador:<input type="text" name="ind_trap_definicion"></br></br><input type="submit"></form>'
	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]   
	start_response(status,response_headers) 
	return [output]    #<-- se envía la data al navegador