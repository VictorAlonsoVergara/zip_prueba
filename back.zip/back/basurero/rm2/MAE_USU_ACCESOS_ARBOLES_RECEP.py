from cgi import parse_qs,escape
from MAE_USU_ACCESOS_ARBOLES import MAE_USU_ACCESOS_ARBOLES

def application(environ,start_response):
	ldata = int(environ.get('CONTENT_LENGTH',0))
	bdata = environ['wsgi.input'].read(ldata)
	logging.info(bdata)

	data = parse_qs(bdata)
	logging.info(data)

	d_uind_id = data.get(b'uind_id')
	d_uarb_tipo = data.get(b'uarb_tipo')
	d_uarb_hijo = data.get(b'uarb_hijo')

	obj = MAE_USU_ACCESOS_ARBOLES(d_uind_id[0].decode(),d_uarb_tipo[0].decode(),d_uarb_hijo[0].decode())
	obj.guardar_dato()

	status='200 OK'
	output='ID de usuario accesos arboles :' + d_uind_id[0].decode() + "</br>" + "Tipo de usuario accesos arboles:" + d_uarb_tipo[0].decode() + "</br>" + "Hijo de usuario accesos arboles:" + d_uarb_hijo[0].decode() 
	output = output.encode()

	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]
	start_response(status,response_headers)
	return [output]
