

def application(environ,start_response):   #<-- esta función es la que buscará el Apache para empezar la respuesta al navegador											
	status='200 OK'   #<-- código de respuesta, 200 es "página existe"
	output=b'<form method="POST" action="graba_MAE_USU_ACCESOS_INDICADORES_POST/">Maestro de indicadores de usuarios de usuarios</br></br>ID del indicador:<input name="ind_id" type="text"></br></br>ID del usuario:<input type="text" name="usu_id"></br></br><input type="submit"></form>'
	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]   
	start_response(status,response_headers) 
	return [output]    #<-- se envía la data al navegador