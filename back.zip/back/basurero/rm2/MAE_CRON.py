import psycopg2
import sys
import generico
from MAT_TIPO_OBJ import MAT_TIPO_OBJ
import logging
import datetime

class MAE_CRON :

	def __init__(self,tobj_id,cron_tipo,cron_periodo,cron_estado,cron_id=None):
	
		self.cron_id = cron_id #serial
		self.tobj_id = tobj_id #integer
		self.cron_tipo = cron_tipo #char(1)
		self.cron_periodo = cron_periodo #varchar(20)
		self.cron_estado = cron_estado #char(1)
		self.mat_tipo_obj = MAT_TIPO_OBJ('','','','',tobj_id)
		self.mat_tipo_obj.buscar_dato()
		nombre_log = 'Log_programa_'+generico.diahora()+'.log'
		logging.basicConfig(filename=nombre_log,level=logging.DEBUG)		

	def guardar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			tup = (self.tobj_id,self.cron_tipo,self.cron_periodo,self.cron_estado)

			cur.execute('INSERT INTO "MAE_CRON" (tobj_id,cron_tipo,cron_periodo,cron_estado) VALUES (%s,%s,%s,%s)',tup)
			con.commit()
			cur.execute('SELECT * FROM "MAE_CRON" WHERE tobj_id ='+ str(self.tobj_id)+' AND cron_tipo =\''+ self.cron_tipo+'\' AND cron_periodo=\''+self.cron_periodo+'\' AND cron_estado=\''+self.cron_estado+'\' ')
			version = cur.fetchall()
			self.cron_id = version[len(version)-1][0]
			dato = 'ok'
			logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla MAE_CRON')
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_CRON')
		except :
			dato = 'error'
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_CRON')
		finally:
			if con:
				con.close()
			return dato

	def buscar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "MAE_CRON" WHERE cron_id ='+ str(self.cron_id))
			version = cur.fetchall()

			self.tobj_id = version[0][1] #integer
			self.cron_tipo = version[0][1] #char(1)
			self.cron_periodo = version[0][1] #varchar(20)
			self.cron_estado = version[0][1] #char(1)
			dato = 'ok'
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
		except :
			dato = 'error'
		finally:
			if con:
				con.close()
			return dato

	def consultar(self):
		print('consulta')