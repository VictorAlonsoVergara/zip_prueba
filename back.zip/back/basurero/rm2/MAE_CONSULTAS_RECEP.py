import logging
from cgi import parse_qs,escape
from MAE_CONSULTAS import MAE_CONSULTAS

def application(environ,start_response):
	ldata = int(environ.get('CONTENT_LENGTH',0))
	bdata = environ['wsgi.input'].read(ldata)
	logging.info(bdata)

	data = parse_qs(bdata)
	logging.info(data)

	d_con_desc = data.get(b'con_desc')
	d_con_estado = data.get(b'con_estado')
	d_con_protocolo = data.get(b'con_protocolo')
	d_con_trama_pregunta = data.get(b'con_trama_pregunta')
	
	obj = MAE_CONSULTAS(d_con_desc[0].decode(),d_con_estado[0].decode(),d_con_protocolo[0].decode(),d_con_trama_pregunta[0].decode())
	obj.guardar_dato()
	status='200 OK'
	output='Descripcion de consulta:' + d_con_desc[0].decode() + "</br>" + "Estado de consulta:" + d_con_estado[0].decode()+ "</br>" + "Protocolo de consulta:" + d_con_protocolo[0].decode() + "</br>" + "Trama pregunta de consulta:" + d_con_trama_pregunta[0].decode()
	output = output.encode()

	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))] 
	start_response(status,response_headers)
	return [output]
