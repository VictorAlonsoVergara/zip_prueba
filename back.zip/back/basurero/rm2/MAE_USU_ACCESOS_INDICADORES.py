import psycopg2
import sys
import generico
from MAE_USUARIOS import MAE_USUARIOS
from MAE_INDICADORES import MAE_INDICADORES
import logging
import datetime

class MAE_USU_ACCESOS_INDICADORES :

	def __init__(self,ind_id,usu_id,uind_id=None):
	
		self.uind_id = uind_id #serial
		self.ind_id = ind_id #integer
		self.usu_id = usu_id #integer
		self.mae_usuarios = MAE_USUARIOS('','','','','','',usu_id)
		self.mae_indicadores = MAE_INDICADORES('','','',ind_id)
		self.mae_usuarios.buscar_dato()
		self.mae_indicadores.buscar_dato()
		nombre_log = 'Log_programa_'+generico.diahora()+'.log'
		logging.basicConfig(filename=nombre_log,level=logging.DEBUG)
		
	def guardar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			tup = (self.ind_id,self.usu_id)

			cur.execute('INSERT INTO "MAE_USU_ACCESOS_INDICADORES" (ind_id,usu_id) VALUES (%s,%s)',tup)
			con.commit()
			cur.execute('SELECT * FROM "MAE_USU_ACCESOS_INDICADORES" WHERE ind_id ='+ str(self.ind_id)+' AND usu_id ='+ str(self.usu_id))
			version = cur.fetchall()
			self.uind_id = version[len(version)-1][0]
			dato = 'ok'
			logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla MAE_USU_ACCESOS_INDICADORES')
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_USU_ACCESOS_INDICADORES')
		except :
			dato = 'error'
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_USU_ACCESOS_INDICADORES')
		finally:
			if con:
				con.close()
			return dato

	def buscar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "MAE_USU_ACCESOS_INDICADORES" WHERE uind_id ='+ str(self.uind_id))
			version = cur.fetchall()

			self.ind_id = version[0][1] #integer
			self.usu_id = version[0][2] #integer
			dato = 'ok'
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
		except :
			dato = 'error'
		finally:
			if con:
				con.close()
			return dato

	def consultar(self):
		print('consulta')