import arb_logico
import arb_fisico
import consultas
import tipo_obj


class objetos :

	def __init__(self, obj_id, obj_desc, tobj_id, obj_estado, obj_ldesc):
		self.obj_id = obj_id
		self.arb_logico = arb_logico(obj_id) #
		self.arb_fisico = arb_fisico(obj_id) #
		self.consultas = consultas(obj_id) #
		self.tipo_obj = tipo_obj(tobj_id) #
		self.obj_desc = obj_desc
		self.tobj_id = tobj_id
		self.obj_estado = obj_estado
		self.obj_ldesc = obj_ldesc


	def funcion(self):  # you can use a proper setter if you want
		print('prueba')

	def consultar(self):
		print('consulta')


