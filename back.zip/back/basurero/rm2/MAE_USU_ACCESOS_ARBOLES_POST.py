

def application(environ,start_response):   #<-- esta función es la que buscará el Apache para empezar la respuesta al navegador											
	status='200 OK'   #<-- código de respuesta, 200 es "página existe"
	output=b'<form method="POST" action="graba_MAE_USU_ACCESOS_ARBOLES_POST/">Maestro de acceso a arboles de usuarios</br></br>ID de usuario acceso indicadores:<input name="uind_id" type="text"></br></br>Tipo de usuario acceso arboles:<input type="text" name="uarb_tipo"></br></br>Hijo de usuario acceso arboles:<input type="text" name="uarb_hijo"></br></br><input type="submit"></form>'
	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]   
	start_response(status,response_headers) 
	return [output]    #<-- se envía la data al navegador