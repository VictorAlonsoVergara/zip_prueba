

def application(environ,start_response):   #<-- esta función es la que buscará el Apache para empezar la respuesta al navegador											
	status='200 OK'   #<-- código de respuesta, 200 es "página existe"
	output=b'<form method="POST" action="graba_MAE_OBJETOS_POST/">Maestro de objetos</br></br>Descripcion de objetos:<input name="obj_desc" type="text"></br></br>Id de tipo de objeto:<input type="text" name="tobj_id"></br></br>Estado del objeto:<input type="text" name="obj_estado"></br></br>Ldescripcion de objeto:<input type="text" name="obj_ldesc"></br></br><input type="submit"></form>'
	response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]   
	start_response(status,response_headers) 
	return [output]    #<-- se envía la data al navegador