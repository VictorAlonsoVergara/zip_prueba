import psycopg2
import sys
import generico
from MAE_CRON import MAE_CRON
import logging
import datetime

class MAE_INDICADORES :

	def __init__(self,ind_desc,ind_estado,ind_ldesc,ind_alerta, cron_id, ind_trap, ind_trap_definicion,ind_id=None):
	
		self.ind_id = ind_id #serial
		self.ind_desc = ind_desc #varchar(200)
		self.ind_estado = ind_estado #smallint
		self.ind_ldesc = ind_ldesc #smallint
		self.ind_alerta = ind_alerta #char(1)
		self.cron_id = cron_id #integer
		self.ind_trap = ind_trap #char(1)
		self.ind_trap_definicion = ind_trap_definicion #text
		self.mae_cron = MAE_CRON('','','','',cron_id)
		self.mae_cron.buscar_dato()
		nombre_log = 'Log_programa_'+generico.diahora()+'.log'
		logging.basicConfig(filename=nombre_log,level=logging.DEBUG)		

	def guardar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			tup = (self.ind_desc,self.ind_estado,self.ind_ldesc,self.ind_alerta,self.cron_id,self.ind_trap,self.ind_trap_definicion)
		   
			cur.execute('INSERT INTO "MAE_INDICADORES" (ind_desc,ind_estado,ind_ldesc,ind_alerta,cron_id,ind_trap,ind_trap_definicion) VALUES (%s,%s,%s,%s,%s,%s,%s)',tup)
			con.commit()
			cur.execute('SELECT * FROM "MAE_INDICADORES" WHERE ind_desc =\''+ self.ind_desc+'\' AND ind_estado ='+ str(self.ind_estado)+' AND ind_ldesc='+str(self.ind_ldesc)+' AND ind_alerta =\''+ str(self.ind_alerta)+'\' AND cron_id='+ str(self.cron_id))
			version = cur.fetchall()
			self.ind_id = version[len(version)-1][0]
			dato = 'ok'
			logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla MAE_INDICADORES')
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_INDICADORES')
		except:
			dato = 'error'
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_INDICADORES')
		finally:
			if con:
				con.close()
			return dato

	def buscar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "MAE_INDICADORES" WHERE ind_id ='+ str(self.ind_id))
			version = cur.fetchall()

			self.ind_desc = version[0][1] #varchar(200)
			self.ind_estado = version[0][2] #smallint
			self.ind_ldesc = version[0][3] #smallint
			self.ind_alerta = version[0][4] #char(1)
			self.cron_id = version[0][5] #integer
			self.ind_trap = version[0][6] #char(1)
			self.ind_trap_definicion = version[0][7] #text			
			dato = 'ok'
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
		except :
			dato = 'error'		
		finally:
			if con:
				con.close()
			return dato


	def consultar(self):
		print('consulta')