import psycopg2
import sys
import generico
import logging
import datetime

class MAE_TIPO_USU :

	def __init__(self,tusu_desc,tusu_estado,tusu_id=None):
	
		self.tusu_id = tusu_id #serial
		self.tusu_desc = tusu_desc #varchar(200)
		self.tusu_estado = tusu_estado #smallint
		nombre_log = 'Log_programa_'+generico.diahora()+'.log'
		logging.basicConfig(filename=nombre_log,level=logging.DEBUG)		
		
	def guardar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			tup = (self.tusu_desc,self.tusu_estado)

			cur.execute('INSERT INTO "MAE_TIPO_USU" (tusu_desc,tusu_estado) VALUES (%s,%s)',tup)
			con.commit()
			cur.execute('SELECT * FROM "MAE_TIPO_USU" WHERE tusu_desc =\''+ self.tusu_desc+'\' AND tusu_estado ='+ str(self.tusu_estado))
			version = cur.fetchall()
			self.tusu_id = version[len(version)-1][0]
			dato = 'ok'
			logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla MAE_TIPO_USU')
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_TIPO_USU')
		except :
			dato = 'error'
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_TIPO_USU')
		finally:
			if con:
				con.close()
			return dato

	def buscar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()

			cur.execute('SELECT * FROM "MAE_TIPO_USU" WHERE tusu_id ='+ str(self.tusu_id))
			version = cur.fetchall()

			self.tusu_desc = version[0][1] #varchar(200)
			self.tusu_estado = version[0][2] #smallint
			dato = 'ok'
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
		except :
			dato = 'error'
		finally:
			if con:
				con.close()
			return dato

	def consultar(self):
		print('consulta')

	def verificarDatos(self):

		try:
			len(self.tusu_desc)#varchar(200)
          	int(self.tusu_estado)#smallint
          	
          	dato='datos correctos'
         	return dato

      	except:
           	dato='error'
         	return dato