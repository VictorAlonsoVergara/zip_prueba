import generico 
import psycopg2

def foreign_Mae_Obj(tobj_id):

	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT * FROM "MAT_TIPO_OBJ" WHERE tobj_id ='+ str(tobj_id))
		version = cur.fetchall()

		a=len(version)

		if a!=0:
			dato = True #'ok'
		else: # sí existe un dato con el codigo tobj_id en la tabla MAT_TIPO_OBJ

			dato = False  #'ok'
	except psycopg2.DatabaseError as e:
		dato = False #'error' # Error de pgsql
		print(f'Error {e}')

	except :
		dato = False #'error'

	finally:
		if con:
			con.close()
		return dato