import generico
import psycopg2


def foreign_Acc_Arb(uind_id):

	# Verifiación de llave foranea

	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT * FROM "MAE_USU_ACCESOS_INDICADORES" WHERE uind_id ='+ str(uind_id))
		version = cur.fetchall()

		a=len(version)

		if a!=0:
			dato=True  # ok
		else:  

			dato = False #Error
	except psycopg2.DatabaseError as e:
		dato = False #Error
		print(f'Error {e}')
	except :
		dato = False #Error
	
	finally:
		if con:
			con.close()
		return dato # cordinar 


