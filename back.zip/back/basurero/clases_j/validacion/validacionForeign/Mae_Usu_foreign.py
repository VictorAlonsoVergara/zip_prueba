import generico 
import psycopg2

def foreign_Mae_Usu (tusu_id):
 
	try:
		con = generico.entraBD()
		cur = con.cursor()

		cur.execute('SELECT * FROM "MAE_TIPO_USU" WHERE tusu_id ='+ str(tusu_id))
		version = cur.fetchall()

		a=len(version)

		if a!=0:# sí existe un dato con el codigo tusu_id 
			dato = True #'ok'
		else: 
			dato = False #'error'

		
	except psycopg2.DatabaseError as e:
		dato = False #'error'
		print(f'Error {e}')
	except :
		dato = False #'error'
	finally:
		if con:
			con.close()
		return dato