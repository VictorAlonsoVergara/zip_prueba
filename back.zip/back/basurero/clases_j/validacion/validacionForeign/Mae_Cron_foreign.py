import generico 
import psycopg2

def foreign_Mae_Cron(tobj_id):          

	try:
		con = generico.entraBD()
		cur = con.cursor()

		cur.execute('SELECT * FROM "MAT_TIPO_OBJ" WHERE tobj_id ='+ str(tobj_id))
		version = cur.fetchall()

		a=len(version)

		if (a!=0): # sí existe un dato con el codigo tusu_id en la tabla MAE_TIPO_USU 
			dato = True #'ok'
		else: 
			dato = False #'error'

	
	except psycopg2.DatabaseError as e:
		dato = False #'error'
		print(f'Error {e}')
	except :
		dato = False #'error'
	finally:
		if con:
			con.close()
		return dato