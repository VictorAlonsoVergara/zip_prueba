import generico 
import psycopg2

def foreign_Mae_Obj_Con(obj_id,con_id):

	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT * FROM "MAE_OBJETOS" WHERE obj_id ='+ str(self.obj_id))
		version1 = cur.fetchall()
		a=len(version1)
			
		cur.execute('SELECT * FROM "MAE_CONSULTAS" WHERE con_id ='+ str(self.con_id))
		version2 = cur.fetchall()
		b= len(version2)
			
		if (a!=0 and b!=0):

			dato = True #'ok'
		else:
			dato = False #'error'
	except psycopg2.DatabaseError as e:
		dato = False #'error'
		print(f'Error {e}')
	except :
		dato = False #'error'
	finally:
		if con:
			con.close()
		return dato

