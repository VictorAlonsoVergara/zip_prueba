import generico 
import psycopg2

def foreign_Arb_Log(id_obj_hijo,id_obj_padre):

	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT * FROM "MAE_OBJETOS" WHERE obj_id ='+ str(id_obj_hijo))
		version1 = cur.fetchall()

		a=len(version1)

		if (id_obj_padre!=None):
			cur.execute('SELECT * FROM "MAE_OBJETOS" WHERE obj_id ='+ str(id_obj_padre))
			version2 = cur.fetchall()
			b= len(version2)
			
		else:
			b=1
			
		if (a!=0 and b!=0):

			dato = True #'ok'
		else:
			dato = False #'error'

	except psycopg2.DatabaseError as e:
		dato = False #'error'
		print(f'Error {e}')
	except :
		dato = False #'error'
	finally:
		if con:
			con.close()
		return dato