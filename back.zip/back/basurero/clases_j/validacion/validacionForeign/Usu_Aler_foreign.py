import generico 
import psycopg2

def foreign_Usu_Aler(usu_id,ind_id):

	# Verifiación de llave foranea

	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT * FROM "MAE_USUARIOS" WHERE usu_id ='+ str(usu_id))
		version1 = cur.fetchall()

		a=len(version1)

		cur.execute('SELECT * FROM "MAE_INDICADORES" WHERE ind_id ='+ str(ind_id))
		version2 = cur.fetchall()
		b= len(version2)
			
		if (a!=0 and b!=0):

			dato = True #'ok'
		else:
			dato = False #'error'

	except psycopg2.DatabaseError as e:
		dato = False #'error'
		print(f'Error {e}')
	except :
		dato = False #'error'
	
	finally:
		if con:
			con.close()
		return dato
