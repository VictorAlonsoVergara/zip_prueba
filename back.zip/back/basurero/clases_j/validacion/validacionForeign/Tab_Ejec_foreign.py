import generico 
import psycopg2


def foreign_Tab_Ejec(cron_id):

	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT * FROM "MAE_CRON" WHERE cron_id ='+ str(cron_id))
		version1 = cur.fetchall()

		a=len(version1)
			
		if (a!=0):

			dato = True #'ok'
		else:
			dato = False #'error'

	except psycopg2.DatabaseError as e:
		dato = False #'error'
		print(f'Error {e}')

	except :
		dato = False #'error'

	finally:
		if con:
			con.close()
		return dato