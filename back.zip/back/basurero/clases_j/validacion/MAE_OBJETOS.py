import psycopg2
import sys
import generico
from MAT_TIPO_OBJ import MAT_TIPO_OBJ
import logging
import datetime

class MAE_OBJETOS :

	def __init__(self,obj_desc,tobj_id,obj_estado,obj_ldesc,obj_id=None):
	
		self.obj_id = obj_id #serial
		self.obj_desc = obj_desc #varchar(200)
		self.tobj_id = tobj_id #integer
		self.obj_estado = obj_estado #char(1)
		self.obj_ldesc = obj_ldesc #text
		self.mat_tipo_obj = MAT_TIPO_OBJ('','','','',tobj_id)
		self,mat_tipo_obj.buscar_dato()
		nombre_log = 'Log_programa_'+generico.diahora()+'.log'
		logging.basicConfig(filename=nombre_log,level=logging.DEBUG)		

	def guardar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			tup = (self.obj_desc,self.tobj_id,self.obj_estado,self.obj_ldesc)

			cur.execute('INSERT INTO "MAE_OBJETOS" (obj_desc,tobj_id,obj_estado,obj_ldesc) VALUES (%s,%s,%s,%s)',tup)
			con.commit()
			cur.execute('SELECT * FROM "MAE_OBJETOS" WHERE obj_desc =\''+ self.obj_desc+'\' AND tobj_id ='+ str(self.tobj_id)+' AND obj_estado=\''+self.obj_estado+'\' AND obj_ldesc=\''+self.obj_ldesc+'\' ')
			version = cur.fetchall()
			self.obj_id = version[len(version)-1][0]
			dato = 'ok'
			logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla MAE_OBJETOS')
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_OBJETOS')
		except :
			dato = 'error'
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_OBJETOS')
		finally:
			if con:
				con.close()
			return dato

	def buscar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "MAE_OBJETOS" WHERE obj_id ='+ str(self.obj_id))
			version = cur.fetchall()

			self.obj_desc = version[0][1] #varchar(200)
			self.tobj_id = version[0][2] #integer
			self.obj_estado = version[0][3] #char(1)
			self.obj_ldesc = version[0][4] #text
			dato = 'ok'
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
		except :
			dato = 'error'
		finally:
			if con:
				con.close()
			return dato

	def consultar(self):
		print('consulta')

	def verificarDatos(self):

		try:
			a=en(self.obj_desc)#varchar(200)
			int(self.tobj_id)#integer
          	b=len(self.obj_estado)#char(1)
          	len(self.obj_ldesc)#text
          
          	if (a<200 and b==1):
          		dato='datos correctos'
          	else:
          		dato ='error'
         	return dato

      	except:
           	dato='error'
         	return dato

    def verificarForeign(self):

    	try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "MAT_TIPO_OBJ" WHERE tobj_id ='+ str(self.tobj_id))
			version = cur.fetchall()

			a=len(version)

			if a==0:
				dato='error'
			else: # sí existe un dato con el codigo tobj_id 

				dato = 'ok'
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
		except :
			dato = 'error'
		finally:
			if con:
				con.close()
			return dato