#import validations
#import generico 

#from validations import validate_char
#from validations import validate_int
#from validations import validate_string
#from validations import validate_varchar
#from validations import validate_date_time



# MAE_CRON 

def verificarForeign(tusu_id):          

	try:
		con = generico.entraBD()
		cur = con.cursor()

		cur.execute('SELECT * FROM "MAE_TIPO_USU" WHERE tusu_id ='+ str(tusu_id))
		version = cur.fetchall()

		a=len(version)

		if (a!=0): # sí existe un dato con el codigo tusu_id en la tabla MAE_TIPO_USU 
			dato='ok'
		else: 
			dato = 'error'

	
	except psycopg2.DatabaseError as e:
		dato = 'error'
		print(f'Error {e}')
	except :
		 dato = 'error'
	finally:
		if con:
			con.close()
		return dato

# MAE_OBJETOS 
def verificarForeign(tobj_id):

	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT * FROM "MAT_TIPO_OBJ" WHERE tobj_id ='+ str(tobj_id))
		version = cur.fetchall()

		a=len(version)

		if a==0:
			dato='error'
		else: # sí existe un dato con el codigo tobj_id en la tabla MAT_TIPO_OBJ

			dato = 'ok'
	except psycopg2.DatabaseError as e:
		dato = 'error'
		print(f'Error {e}')
	except :
		dato = 'error'
	finally:
		if con:
			con.close()
		return dato

#MAE_USUARIOS 

def Veri_MAE_USUARIOS (tusu_id):

	try:
		con = generico.entraBD()
		cur = con.cursor()

		cur.execute('SELECT * FROM "MAE_TIPO_USU" WHERE tusu_id ='+ str(tusu_id))
		version = cur.fetchall()

		a=len(version)

		if a!=0:# sí existe un dato con el codigo tusu_id 
			dato='ok'
		else: 
			dato = 'error'

		
	except psycopg2.DatabaseError as e:
		dato = 'error'
		print(f'Error {e}')
	except :
		dato = 'error'
	finally:
		if con:
			con.close()
		return dato

# TABLA ARB_LOGICO

def Validate_ARB_LOGICO(id_obj_hijo,id_obj_padre):

	val1=validate_int(id_obj_hijo)
	val2=validate_int(id_obj_padre)

	if (val1 and val2):
		print('validación correcta')

	if (val1 ==False):
		print('id_obj_hijo no es del tipo int. Error')

	if (val2 ==False):
		print('id_obj_padre no es del tipo int.Error')
	
	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT * FROM "MAE_OBJETOS" WHERE obj_id ='+ str(id_obj_hijo))
		version1 = cur.fetchall()

		a=len(version1)

		if (id_obj_padre!=None):
			cur.execute('SELECT * FROM "MAE_OBJETOS" WHERE obj_id ='+ str(id_obj_padre))
			version2 = cur.fetchall()
			b= len(version2)
		else:
			b=1
			
		if (a!=0 and b!=0):

			dato = 'ok'
		else:
			dato='error'

	except psycopg2.DatabaseError as e:
		dato = 'error'
		print(f'Error {e}')
	except :
		dato = 'error'
	finally:
		if con:
			con.close()
		return dato


# TABLA ARB_FISICO 

def Veri_ARB_FISICO(id_obj_hijo,id_obj_padre):

	val1=validate_int(id_obj_hijo)
	val2=validate_int(id_obj_padre)

	if (val1 and val2):
		print('validación correcta')

	if (val1 ==False):
		print('id_obj_hijo no es del tipo int. Error')

	if (val2 ==False):
		print('id_obj_padre no es del tipo int.Error')
	
	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT * FROM "MAE_OBJETOS" WHERE obj_id ='+ str(id_obj_hijo))
		version1 = cur.fetchall()

		a=len(version1)

		if (id_obj_padre!=None):
			cur.execute('SELECT * FROM "MAE_OBJETOS" WHERE obj_id ='+ str(id_obj_padre))
			version2 = cur.fetchall()
			b= len(version2)
		else:
			b=1
			
		if (a!=0 and b!=0):

			dato = 'ok'
		else:
			dato='error'

	except psycopg2.DatabaseError as e:
		dato = 'error'
		print(f'Error {e}')
	except :
		dato = 'error'
	finally:
		if con:
			con.close()
		return dato

#TABLA MAE_INDICADORES   

def Veri_MAE_INDICADORES(ind_desc,ind_estado,ind_ldesc,ind_alerta, cron_id, ind_trap, ind_trap_definicion):


	val1=validate_varchar(ind_desc,200)
	val2=validate_varchar(ind_estado,200)
	val3=validate_int(ind_ldesc)
	val4=validate_char(ind_alerta)
	val5=validate_int(cron_id)
	val6=validate_char(ind_trap)
	val7=validate_string(ind_trap_definicion)

	if (val1 and val2 and val3 and val4 and val5 and val6 and val7):
		pritn('Validación correcta')

	if (val1==False):
		print('ind_estado no es del tipo varchar[200]. Error')

	if (val2==False):
		print('ind_estado no es del tipo varchar[200]. Error')

	if (val3==False):
		print('ind_ldesc no es del tipo int. Error')

	if (val4==False):
		print('ind_alerta no es del tipo char[1]. Error')

	if (val5==False):
		print('cron_id no es del tipo int. Error')

	if (val6==False):
		print('ind_trap no es del tipo char[1]. Error')

	if (val7==False):
		print('ind_trap_definicion no es del tipo string. Error')


	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT * FROM "MAE_CRON" WHERE cron_id ='+ str(cron_id))
		version = cur.fetchall()

		a=len(version1)

		if (a!=0):

			dato = 'ok'
		else:
			dato='error'

	except psycopg2.DatabaseError as e:
		dato = 'error'
		print(f'Error {e}')
	except :
		dato = 'error'
	finally:
		if con:
			con.close()
		return dato

# TABLA MAE_OBJETOS_CONSULTAS

def Veri_MAE_OBJETOS_CONSULTAS(obj_id,con_id,objc_estado,objc_protocolo,objc_trama):

	val1=validate_int(obj_id)
	val2=validate_int(con_id)
	val3=validate_char(objc_estado)
	val4=validate_char(objc_protocolo)
	val5=validate_varchar(objc_trama,500)

	if (val1 and val2 and val3 and val4 and val5):
		pritn('Validación correcta')

	if (val1==False):
		print('obj_id no es del tipo int. Error')

	if (val2==False):
		print('con_id no es del tipo int. Error')

	if (val3==False):
		print('objc_estado no es del tipo char[1]. Error')

	if (val4==False):
		print('objc_protocolo no es del tipo char[1]. Error')

	if (val5==False):
		print('objc_trama no es del tipo varchar[500]. Error')


	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT * FROM "MAE_OBJETOS" WHERE obj_id ='+ str(self.obj_id))
		version1 = cur.fetchall()
		a=len(version1)
			
		cur.execute('SELECT * FROM "MAE_CONSULTAS" WHERE con_id ='+ str(self.con_id))
		version2 = cur.fetchall()
		b= len(version2)
			
		if (a!=0 and b!=0):

			dato = 'ok'
		else:
			dato='error'
	except psycopg2.DatabaseError as e:
		dato = 'error'
		print(f'Error {e}')
	except :
		dato = 'error'
	finally:
		if con:
			con.close()
		return dato

# TABLA TAB_EJECUCIONES
def Veri_TAB_EJECUCIONES(eje_fecha,cron_id,eje_fecha_ini,eje_fecha_fin,eje_log,eje_fecha_transferencia,eje_fecha_parseo):

	val1=validate_date_time(eje_fecha)
	val2=validate_int(cron_id)
	val3=validate_date_time(eje_fecha_ini)
	val4=validate_date_time(eje_fecha_fin)
	val5=validate_varchar(eje_log,50)
	val6=validate_date_time(eje_fecha_transferencia)
	val7=validate_date_time(eje_fecha_parseo)


	if (val1 and val2 and val3 and val4 and val5 and val6 and val7):
		print('Validación correcta')
	
	if (val1==False):
		print('eje_fecha no es del tipo date_time. Error')

	if (val2==False):
			print('cron_id no es del tipo int. Error')

	if (val3==False):
		print('eje_fecha_ini no es del tipo date_time. Error')

	if (val4==False):
		print('eje_fecha_fin no es del tipo date_time. Error')

	if (val5==False):
		print('eje_log no es del tipo varchar[50]. Error')

	if (val6==False):
		print('eje_fecha_transferencia no es del tipo date_time. Error')

	if (val7==False):
		print('eje_fecha_parseo no es del tipo date_time. Error')



	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT * FROM "MAE_CRON" WHERE cron_id ='+ str(cron_id))
		version1 = cur.fetchall()

		a=len(version1)
			
		if (a!=0):

			dato = 'ok'
		else:
			dato='error'

	except psycopg2.DatabaseError as e:
		dato = 'error'
		print(f'Error {e}')

	except :
		dato = 'error'

	finally:
		if con:
			con.close()
		return dato

# TABLA MAE_USU_ACCESOS_INDICADORES 

def Veri_MAE_USU_ACCESOS_INDICADORES(usu_id,ind_id):

	val1=validate_int(ind_id)
	val2=validate_int(usu_id)

	if (val1 and val2):
		print('Validación correcta')

	if (val1== False):
		print ('ind_id no es del tipo int. Error')

	if (val2== False):
		print ('usu_id no es del tipo int. Error')


	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT * FROM "MAE_USUARIOS" WHERE usu_id ='+ str(usu_id))
		version1 = cur.fetchall()

		a=len(version1)

		cur.execute('SELECT * FROM "MAE_INDICADORES" WHERE ind_id ='+ str(ind_id))
		version2 = cur.fetchall()
		b= len(version2)
			
		if (a!=0 and b!=0):

			dato = 'ok'
		else:
			dato='error'

	except psycopg2.DatabaseError as e:
		dato = 'error'
		print(f'Error {e}')
	except :
		dato = 'error'
	finally:
		if con:
			con.close()
		return dato

# TABLA MAE_USUARIOS_ALERTAS

def Ver_MAE_USUARIOS_ALERTAS(usu_id,ind_id):

	val1=validate_int(ind_id)
	val2=validate_int(usu_id)

	if (val1 and val2):
		print('Validación correcta')

	if (val1==False):
		print ('ind_id no es del tipo int. Error')

	if (val2==False):
		print ('usu_id no es del tipo int. Error')
	

	# Verifiación de llave foranea

	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT * FROM "MAE_USUARIOS" WHERE usu_id ='+ str(usu_id))
		version1 = cur.fetchall()

		a=len(version1)

		cur.execute('SELECT * FROM "MAE_INDICADORES" WHERE ind_id ='+ str(ind_id))
		version2 = cur.fetchall()
		b= len(version2)
			
		if (a!=0 and b!=0):

			dato = 'ok'
		else:
			dato='error'

	except psycopg2.DatabaseError as e:
		dato = 'error'
		print(f'Error {e}')
	except :
		dato = 'error'
	
	finally:
		if con:
			con.close()
		return dato

# MAE_USU_aCCESO_ARBOLES

# Verificacion de datos

def Ver_MAE_USU_ACCESO_ARBOLES(uind_id, uarb_tipo,uarb_hijo):

	val1=validate_int(ind_id)
	val2=validate_char(uarb_tipo)
	val3=validate_int(uarb_hijo)

	if (val1 and val2 and val3):
		print('Validación correcta')
	
	if (val1==False):
		print('ind_id no es del tipo int. Error')

	if (val2==False):
		print('uarb_tipo no es del tipo char[1]. Error')
		
	if (val3==False):
		print('uarb_hijo no es del tipo int. Error') # Revisar


	# Verifiación de llave foranea

	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT * FROM "MAE_USU_ACCESOS_INDICADORES" WHERE uind_id ='+ str(uind_id))
		version = cur.fetchall()

		a=len(version)

		if a!=0:
			dato='ok'
		else:  

			dato = 'error'
	except psycopg2.DatabaseError as e:
		dato = 'error'
		print(f'Error {e}')
	except :
		dato = 'error'
	
	finally:
		if con:
			con.close()
		return dato # cordinar 