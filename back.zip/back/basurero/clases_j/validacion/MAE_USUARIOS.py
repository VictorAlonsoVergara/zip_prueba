import psycopg2
import sys
import generico
from MAE_TIPO_USU import MAE_TIPO_USU
import logging
import datetime

class MAE_USUARIOS :

	def __init__(self,usu_nombre,tusu_id,usu_estado,usu_correo,usu_usuario,usu_password,usu_id=None):
	
		self.usu_id = usu_id #serial
		self.usu_nombre = usu_nombre #varchar(300)
		self.tusu_id = tusu_id #integer
		self.usu_estado = usu_estado #char(1)
		self.usu_correo = usu_correo #varchar(100)
		self.usu_usuario = usu_usuario #varchar(50)
		self.usu_password = usu_password #varchar(2048)
		self.mae_tipo_usu = MAE_TIPO_USU('','',tusu_id)
		self.mae_tipo_usu.buscar_dato()
		nombre_log = 'Log_programa_'+generico.diahora()+'.log'
		logging.basicConfig(filename=nombre_log,level=logging.DEBUG)		

	def guardar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			tup = (self.usu_nombre,self.tusu_id,self.usu_estado,self.usu_correo,self.usu_usuario)

			cur.execute('INSERT INTO "MAE_USUARIOS" (usu_nombre,tusu_id,usu_estado,usu_correo,usu_usuario) VALUES (%s,%s,%s,%s,%s)',tup)
			con.commit()
			cur.execute('SELECT * FROM "MAE_USUARIOS" WHERE usu_nombre =\''+ self.usu_nombre+'\' AND tusu_id ='+ str(self.tusu_id)+' AND usu_estado=\''+self.usu_estado+'\' AND usu_correo=\''+self.usu_correo+'\' AND usu_usuario=\''+self.usu_usuario+'\' ')
			version = cur.fetchall()
			self.usu_id = version[len(version)-1][0]
			dato = 'ok'
			logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla MAE_USUARIOS')
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_USUARIOS')
		except :
			dato = 'error'
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_USUARIOS')
		finally:
			if con:
				con.close()
			return dato

	def buscar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "MAE_USUARIOS" WHERE usu_id ='+ str(self.usu_id))
			version = cur.fetchall()

			self.usu_nombre = version[0][1] #varchar(300)
			self.tusu_id = version[0][2] #integer
			self.usu_estado = version[0][3] #char(1)
			self.usu_correo = version[0][4] #varchar(100)
			self.usu_usuario = version[0][5] #varchar(50)
			self.usu_password = version[0][6] #varchar(2048)
			dato = 'ok'
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
		except :
			dato = 'error'
		finally:
			if con:
				con.close()
			return dato

	def consultar(self):
		print('consulta')


	def verificarDatos(self):

		try:
			len(self.usu_nombre)#varchar(300)
			int(self.tusu_id)#integer
          	a=len(self.usu_estado)#char(1)
          	len(self.usu_correo)#varchar(100)
          	b=len(self.usu_usuario)#varchar(50)
          	len(self.usu_password)#varchar(2048)
          
          	if (a==1 and b<50):
          		dato='datos correctos'
          	else:
          		dato ='error'
         	
         	return dato

      	except:
           	dato='error'
         	return dato

    def verificarForeign(self):

    	try:
			con = generico.entraBD()
			cur = con.cursor()

			cur.execute('SELECT * FROM "MAE_TIPO_USU" WHERE tusu_id ='+ str(self.tusu_id))
			version = cur.fetchall()

			a=len(version)

			if a!=0:# sí existe un dato con el codigo tusu_id 
				dato='ok'
			else: 
				dato = 'error'

		
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
		except :
			dato = 'error'
		finally:
			if con:
				con.close()
			return dato