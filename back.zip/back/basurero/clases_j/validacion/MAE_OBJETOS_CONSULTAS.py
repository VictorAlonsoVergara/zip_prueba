import psycopg2
import sys
import generico
from MAE_CONSULTAS import MAE_CONSULTAS
from MAE_OBJETOS import MAE_OBJETOS
import logging
import datetime

class MAE_OBJETOS_CONSULTAS :

	def __init__(self,obj_id,con_id,objc_estado,objc_protocolo,objc_trama):
	
		self.obj_id = obj_id #integer
		self.con_id = con_id #integer
		self.objc_estado = objc_estado #char(1)
		self.objc_protocolo = objc_protocolo #char(1)
		self.objc_trama = objc_trama #varchar(500)
		self.mae_consultas = MAE_CONSULTAS('','','','',con_id)
		self.mae_consultas.buscar_dato()
		self.mae_objetos = MAE_OBJETOS('','','','',obj_id)
		self.mae_objetos.buscar_dato()
		nombre_log = 'Log_programa_'+generico.diahora()+'.log'
		logging.basicConfig(filename=nombre_log,level=logging.DEBUG)		
		
	def guardar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			tup = (self.obj_id,self.con_id,self.objc_estado,self.objc_protocolo,self.objc_trama)

			cur.execute('INSERT INTO "MAE_OBJETOS_CONSULTAS" (obj_id,con_id,objc_estado,objc_protocolo,objc_trama) VALUES (%s,%s,%s,%s,%s)',tup)
			con.commit()
			dato = 'ok'
			logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla MAE_OBJETOS_CONSULTAS')
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_OBJETOS_CONSULTAS')
		except :
			dato = 'error'
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_OBJETOS_CONSULTAS')
		finally:
			if con:
				con.close()
			return dato


	def consultar(self):
		print('consulta')

	def verificarDatos(self):

		try:
			int(self.obj_id)#integer
			int(self.con_id)#integer
			a=len(self.objc_estado)#char(1)
			b=len(self.objc_protocolo)#char(1)
			len(self.objc_trama)#varchar(500)

			if (a==1 and b==1):
          		dato='datos correctos'
          	else:
          		dato ='error'
         				          	
      	except:

           	dato='error'
        finally:
        	return dato

    def verificarForeign(self):
    	try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "MAE_OBJETOS" WHERE obj_id ='+ str(self.obj_id))
			version1 = cur.fetchall()
			a=len(version1)
			
			cur.execute('SELECT * FROM "MAE_CONSULTAS" WHERE con_id ='+ str(self.con_id))
			version2 = cur.fetchall()
			b= len(version2)
			
			if (a!=0 and b!=0):

				dato = 'ok'
			else:
				dato='error'
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
		except :
			dato = 'error'
		finally:
			if con:
				con.close()
			return dato