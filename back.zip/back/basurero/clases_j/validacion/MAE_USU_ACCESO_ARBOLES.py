import psycopg2
import sys
import generico
from MAE_USU_ACCESOS_INDICADORES import MAE_USU_ACCESOS_INDICADORES
import logging
import datetime

class MAE_USU_ACCESO_ARBOLES :

	def __init__(self, uind_id, uarb_tipo,uarb_hijo,uarb_id=None):
	
		self.uarb_id = uarb_id #serial
		self.uind_id = uind_id #integer
		self.uarb_tipo = uarb_tipo #char(1)
		self.uarb_hijo = uarb_hijo #integer
		self.mae_usu_accesos_indicadores = MAE_USU_ACCESOS_INDICADORES('','',uind_id)
		self.mae_usu_accesos_indicadores.buscar_dato()
		nombre_log = 'Log_programa_'+generico.diahora()+'.log'
		logging.basicConfig(filename=nombre_log,level=logging.DEBUG)
		
	def guardar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			tup = (self.uind_id,self.uarb_tipo,self.uarb_hijo)
		   
			cur.execute('INSERT INTO "MAE_USU_ACCESO_ARBOLES" (uind_id,uarb_tipo,uarb_hijo) VALUES (%s,%s,%s)',tup)
			con.commit()
			cur.execute('SELECT * FROM "MAE_USU_ACCESO_ARBOLES" WHERE uind_id ='+ str(self.uind_id)+' AND uarb_tipo =\''+ self.uarb_tipo+'\' AND uarb_hijo='+str(uarb_hijo))
			version = cur.fetchall()
			self.uarb_id = version[len(version)-1][0]
			dato = 'ok'
			logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla MAE_USU_ACCESO_ARBOLES')
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_USU_ACCESO_ARBOLES')
		except :
			dato = 'error'
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_USU_ACCESO_ARBOLES')
		finally:
			if con:
				con.close()
			return dato

	def buscar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "MAE_USU_ACCESO_ARBOLES" WHERE uarb_id ='+ str(self.uarb_id))
			version = cur.fetchall()

			self.uind_id = version[0][1] #integer
			self.uarb_tipo = version[0][2] #char(1)
			self.uarb_hijo = version[0][3] #integer
			dato = 'ok'
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
		except :
			dato = 'error'
		finally:
			if con:
				con.close()
			return dato

	def consultar(self):
		print('consulta')

	def verificarDatos(self):
		
		try:
			int(self.uind_id)#integer
			a=len(self.uarb_tipo) #char(1)
          	int(self.uarb_hijo)#integer
          	
          	if (a==1):

          		dato='datos correctos'
         	else:
         		dato='error'
         	return dato

      	except:
           	dato='error'
         	return dato

    def verificarForeign(self):

    	try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "MAE_USU_ACCESOS_INDICADORES" WHERE uind_id ='+ str(self.uind_id))
			version = cur.fetchall()

			a=len(version)

			if a!=0:
				dato='ok'
			else: # sí existe un dato con el codigo tobj_id 

				dato = 'error'
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
		except :
			dato = 'error'
		finally:
			if con:
				con.close()
			return dato