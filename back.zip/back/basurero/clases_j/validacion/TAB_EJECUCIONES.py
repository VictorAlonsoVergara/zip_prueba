import psycopg2
import sys
import generico
from MAE_CRON import MAE_CRON
import logging
import datetime

class TAB_EJECUCIONES :

	def __init__(self,eje_fecha,cron_id,eje_fecha_ini,eje_fecha_fin,eje_log,eje_fecha_transferencia,eje_fecha_parseo,eje_id=None):
	
		self.eje_id = eje_id #serial
		self.eje_fecha = eje_fecha #datetime timestamp with time zone
		self.cron_id = cron_id #integer
		self.eje_fecha_ini = eje_fecha_ini #datetime timestamp with time zone
		self.eje_fecha_fin = eje_fecha_fin #datetime timestamp with time zone
		self.eje_log = eje_log # varchar(50)
		self.eje_fecha_transferencia = eje_fecha_transferencia #datetime timestamp with time zone
		self.eje_fecha_parseo = eje_fecha_parseo #datetime timestamp with time zone
		self.mae_cron = MAE_CRON('','','','',cron_id)
		self.mae_cron.buscar_dato()
		nombre_log = 'Log_programa_'+generico.diahora()+'.log'
		logging.basicConfig(filename=nombre_log,level=logging.DEBUG)

		
	def guardar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			tup = (self.eje_fecha,self.cron_id)

			cur.execute('INSERT INTO "TAB_EJECUCIONES" (eje_fecha,cron_id) VALUES (%s,%s)',tup)
			con.commit()
			cur.execute('SELECT * FROM "TAB_EJECUCIONES" WHERE eje_fecha =\''+ str(self.eje_fecha)+'\' AND cron_id ='+ str(self.cron_id)+' AND eje_fecha_ini = \''+self.eje_fecha_ini+'\' AND eje_fecha_fin = \''+self.eje_fecha_fin+'\' ')
			version = cur.fetchall()
			self.eje_id = version[len(version)-1][0]
			dato = 'ok'
			logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla TAB_EJECUCIONES')
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla TAB_EJECUCIONES')
		except :
			dato = 'error'
			logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla TAB_EJECUCIONES')
		finally:
			if con:
				con.close()
			return dato

	def buscar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "TAB_EJECUCIONES" WHERE eje_id ='+ str(self.eje_id))
			version = cur.fetchall()

			self.eje_fecha = version[0][1] #datetime timestamp with time zone
			self.cron_id = version[0][2] #integer
			self.eje_fecha_ini = version[0][3] #datetime timestamp with time zone
			self.eje_fecha_fin = version[0][4] #datetime timestamp with time zone
			self.eje_log = version[0][5] # varchar(50)
			self.eje_fecha_transferencia = version[0][6] #datetime timestamp with time zone
			self.eje_fecha_parseo = version[0][7] #datetime timestamp with time zone
			dato = 'ok'
		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
		except :
			dato = 'error'
		finally:
			if con:
				con.close()
			return dato

	def consultar(self):
		print('consulta')

	def verificarDatos(self):

	
		try:
			int(self.cron_id)#integer
          	a=len(self.eje_log)#varchar(50)
          	b=self.eje_fecha[4]+self.eje_fecha[7]+self.eje_fecha[13]+self.eje_fecha[16]
          	c=self.eje_fecha[19] # + o - segun utc 
          	d=self.eje_fecha_ini[4]+self.eje_fecha_ini[7]+self.eje_fecha_ini[13]+self.eje_fecha_ini[16]
          	e=self.eje_fecha_ini[19] # + o - segun utc 
          	f=self.eje_fecha_fin[4]+self.eje_fecha_fin[7]+self.eje_fecha_fin[13]+self.eje_fecha_fin[16]
          	g=self.eje_fecha_fin[19] # + o - segun utc 
          	h=self.eje_fecha_transferencia[4]+self.eje_fecha_transferencia[7]+self.eje_fecha_transferencia[13]+self.eje_fecha_transferencia[16]
          	i=self.eje_fecha_transferencia[19] # + o - segun utc 
          	j=self.eje_fecha_parseo[4]+self.eje_fecha_parseo[7]+self.eje_fecha_parseo[13]+self.eje_fecha_parseo[16]
          	k=self.eje_fecha_parseo[19] # + o - segun utc 
          	
          	formato='--::'
          	utc=(c=='+'or c=='-') and (e=='+'or e=='-') and (g=='+'or g=='-') and (i=='+'or i=='-') and (k=='+'or k=='-')
          	fecha=(b==formato) and (d==formato) and (f==formato) and (h==formato) and (j==formato)

          	if (a<51 and utc and fecha):
          		dato='datos correctos'
          	else:
          		dato ='error'
         	return dato

      	except:
           	dato='error'
         	return dato

	def verificarForeign(self):

    	try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "MAE_CRON" WHERE cron_id ='+ str(self.cron_id))
			version1 = cur.fetchall()

			a=len(version1)
			
			if (a!=0):

				dato = 'ok'
			else:
				dato='error'

		except psycopg2.DatabaseError as e:
			dato = 'error'
			print(f'Error {e}')
		except :
			dato = 'error'
		finally:
			if con:
				con.close()
			return dato