import sys
sys.path.insert(0,'/var/python')
sys.path.insert(1,'/home/ernesto/login')


from clsSession import Session
import logging
from cgi import parse_qs,escape

sys.path.insert(2, '/home/sistema/jassir/clases')

import json
from TAB_EJECUCIONES import TAB_EJECUCIONES
import validations

def application(environ,start_response):
	status = '200 OK'
	s = Session()
	cookie = environ.get('HTTP_COOKIE',0)
	tk = s.getCookie(cookie,'token')
	
	if s.valToken(tk):	

		status = '200 OK'
		bdata = environ['PATH_INFO']
		lendata = int(environ.get('CONTENT_LENGTH',0))
		bydata = environ['wsgi.input'].read(lendata) 	
		respuest = validations.validate_int(bdata.split('/')[1])
		if(respuest[0] == True):
			obj = TAB_EJECUCIONES(1,' ',' ',' ',' ',' ',int(bdata.split('/')[1]))
			dato = obj.buscar_dato()
			
			if(dato[0] == 'ok'):
				data = {}
				data['eje_id']=int(bdata.split('/')[1])
				data['eje_fecha']= str(obj.eje_fecha)
				data['eje_fecha_ini']= str(obj.eje_fecha_ini)
				data['eje_fecha_fin']= str(obj.eje_fecha_fin)
				data['eje_log']= str(obj.eje_log)
				data['eje_fecha_transferencia']= str(obj.eje_fecha_transferencia)
				data['eje_fecha_parseo']= str(obj.eje_fecha_parseo)
				data['cron_id'] = obj.cron_id
				data['cron_tipo']= obj.mae_cron.cron_tipo
				data['cron_periodo']= obj.mae_cron.cron_periodo
				data['cron_estado']= obj.mae_cron.cron_estado
				data['tobj_id']= obj.mae_cron.tobj_id
				data['tobj_desc']= obj.mae_cron.mat_tipo_obj.tobj_desc
				data['tobj_estado']= obj.mae_cron.mat_tipo_obj.tobj_estado
				data['tobj_consulta']= obj.mae_cron.mat_tipo_obj.tobj_consulta
				data['tobj_ldesc']= obj.mae_cron.mat_tipo_obj.tobj_ldesc
				
				
			else:
				data = {}
				data['result'] = "failed"
				data['error'] = "Sucedio un error"
				data['error_cod'] = 412
				data['val_errors'] = dato[1]
		else:
			data = {}
			data['result'] = "failed"
			data['error'] = "Sucedio un error"
			data['error_cod'] = 412
			data['val_errors'] = respuest[1]
	else:
		data = {}
		data['result'] = "failed"
		data['error'] = "Token no validado"
		data['error_cod'] = 412
		data['val_errors'] = ""

	preoutput = json.dumps(data)
	output = bytes(preoutput, 'utf-8')
	headers =[('Access-Control-Allow-Origin','*')]
	start_response(status,headers)
	return [output]
