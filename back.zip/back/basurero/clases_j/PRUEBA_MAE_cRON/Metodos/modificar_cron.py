import sys
sys.path.insert(0,'/var/python')
sys.path.insert(1,'/home/ernesto/login')

from clsSession import Session
import logging
from cgi import parse_qs,escape

sys.path.insert(0, '/home/sistema/jassir/clases')

import json
from MAE_CRON import MAE_CRON
import validations

def application(environ,start_response):

	status = '200 OK'
	s = Session()
	cookie = environ.get('HTTP_COOKIE',0)
	tk = s.getCookie(cookie,'token')

	if s.valToken(tk):
		#cdata = environ['QUERY_STRING'] #usare esto
		lendata = int(environ.get('CONTENT_LENGTH',0))
		bydata = environ['wsgi.input'].read(lendata) 
		jsdata = json.loads(bydata.decode("utf-8"))	
		#datos_recev=cdata.split('&')
		try:
			#diccionario = {}
			extra = {}
			#for dat in datos_recev:
			#	duo = dat.split('=')
			#	diccionario[duo[0]]=duo[1] 
			respu1 = validations.validate_int(jsdata['tobj_id'])
			respu2 = validations.validate_char(jsdata['cron_tipo'])
			respu3 = validations.validate_varchar(jsdata['cron_periodo'],20)
			respu4 = validations.validate_char(jsdata['cron_estado'])
			respu5 = validations.validate_int(jsdata['cron_id'])
			
			if(respu1[0]==True):
				respu6 = validations.foreign_Mae_Cron(int(jsdata['tobj_id']))
			else :
				respu6 = [False,'No se tiene un tobj_id correcto']

			if(respu5[0]==True):
				respu7 = validations.id_Mae_Cron(jsdata['cron_id']) 
			else :
				respu7 = [False,'No se tiene un cron_id correcto']

			
			list_respu = [respu1,respu2,respu3,respu4,respu5,respu6,respu7]
			nombres = [ 'tobj_id','cron_tipo','cron_periodo','cron_estado','cron_id','tobj_desc','cron_id']       

			if (respu1[0] and respu2[0] and respu3[0] and respu4[0] and respu5[0] and respu6[0] and respu7[0]):
				obj = MAE_CRON(int(jsdata['tobj_id']),jsdata['cron_tipo'],jsdata['cron_periodo'],jsdata['cron_estado'],int(jsdata['cron_id']))
				resp = obj.modificar()
			else :
				resp = ['error','']
				num = 0 
				
				for respu in list_respu:
					if(respu[0]==False):
						#resp[1] = resp[1]+'-'+nombres[num]+': '+respu[1]+' \n' 
						extra[nombres[num]] = respu[1]
					num = num + 1


		except Exception as e :
			resp = ['error',str(e)]
		linea = {}

		if (resp[0] == 'ok'):
			linea['result'] = "ok" 
		else:
			linea['result'] = "failed"
			linea['error'] = "Sucedio un error"
			linea['error_cod'] = 412
			if (bool(extra)):
				linea['val_errors'] = extra
			else:
				linea['val_errors'] = resp[1]
	else:
		linea = {}
		linea['result'] = "failed"
		linea['error'] = "Token no valido"
		linea['error_cod'] = 412

	preoutput = json.dumps(linea)
	output = bytes(preoutput, 'utf-8')
	headers =[('Access-Control-Allow-Origin','*')]
	start_response(status,headers)
	return [output]


