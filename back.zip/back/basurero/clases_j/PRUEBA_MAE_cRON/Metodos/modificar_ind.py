import sys
sys.path.insert(0,'/var/python')
sys.path.insert(1,'/home/ernesto/login')

from clsSession import Session
import logging
from cgi import parse_qs,escape

sys.path.insert(0, '/home/sistema/jassir/clases')

import json
from MAE_INDICADORES import MAE_INDICADORES
import validations

def application(environ,start_response):

	status = '200 OK'	
	s = Session()
	cookie = environ.get('HTTP_COOKIE',0)
	tk = s.getCookie(cookie,'token')

	if s.valToken(tk):

		status = '200 OK'
		lendata = int(environ.get('CONTENT_LENGTH',0))
		bydata = environ['wsgi.input'].read(lendata) 
		jsdata = json.loads(bydata.decode("utf-8"))		
		
		try:
			
			extra = {}
			respu1 = validations.validate_varchar(jsdata['ind_desc'],200)
			respu2 = validations.validate_int(jsdata['ind_estado'])
			respu3 = validations.validate_int(jsdata['ind_ldesc'])
			respu4 = validations.validate_char(jsdata['ind_alerta'])
			respu5 = validations.validate_int(jsdata['cron_id'])
			respu6 = validations.validate_char(jsdata['ind_trap'])
			respu7 = validations.validate_string(jsdata['ind_trap_definicion'])
			respu8 = validations.validate_int(jsdata['ind_id'])
			if(respu5[0]==True):
				respu9 = validations.id_Mae_Cron(int(jsdata['cron_id']))
			else :
				respu9 = [False,'No se tiene un cron_id correcto']

			if(respu8[0]==True):
				respu10 = validations.id_Mae_Ind(int(jsdata['ind_id']))
			else :
				respu10 = [False,'No se tiene ind_id correcto']	

			list_respu = [respu1,respu2,respu3,respu4,respu5,respu6,respu7,respu8,respu9,respu10]
			nombres = ['ind_desc','ind_estado','ind_ldesc','ind_alerta','cron_id','ind_trap','ind_trap_definicion','ind_id','cron_id','ind_id']	

			if (respu1[0] and respu2[0] and respu3[0] and respu4[0] and respu5[0] and respu6[0] and respu7[0] and respu8[0] and respu9[0] and respu10[0]):	
				obj = MAE_INDICADORES(jsdata['ind_desc'],int(jsdata['ind_estado']),int(jsdata['ind_ldesc']),jsdata['ind_alerta'],int(jsdata['cron_id']),jsdata['ind_trap'], jsdata['ind_trap_definicion'], int(jsdata['ind_id']))
				resp = obj.modificar_indicador()
			else :
				resp = ['error','']
				num = 0

				for respu in list_respu:
					if(respu[0]==False):
						#resp[1] = resp[1]+'-'+respu[1]+'\n'
						extra[nombres[num]] = respu[1]
					num = num + 1

		except Exception as e :
			resp = ['error',str(e)]
		linea = {}

		if (resp[0] == 'ok'):
			linea['result'] = "ok" 
		else:
			linea['result'] = "failed"
			linea['error'] = "Sucedio un error"
			linea['error_cod'] = 412
			if (bool(extra)):
				linea['val_errors'] = extra
			else:
				linea['val_errors'] = resp[1]

	else:
		linea = {}
		linea['result'] = "failed"
		linea['error'] = "Token no valido"
		linea['error_cod'] = 412

	preoutput = json.dumps(linea)
	output = bytes(preoutput, 'utf-8')
	headers =[('Access-Control-Allow-Origin','*')]
	start_response(status,headers)
	return [output]


