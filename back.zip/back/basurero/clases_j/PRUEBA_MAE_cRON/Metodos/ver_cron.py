import sys
sys.path.insert(0,'/var/python')
sys.path.insert(1,'/home/ernesto/login')

from clsSession import Session
import logging
from cgi import parse_qs,escape

sys.path.insert(2, '/home/sistema/jassir/clases')

import json
from MAE_CRON import MAE_CRON
import validations

def application(environ,start_response):

	s = Session()
	cookie = environ.get('HTTP_COOKIE',0)
	tk = s.getCookie(cookie,'token')

	if len(tk) < 1:
		data = {}
		data['result'] = "failed"
		data['error'] = "No existe token"
		data['error_cod'] = 412
		data['val_errors'] = ""
		
	else:
	
		if s.valToken(tk):
			bdata = environ['PATH_INFO']
			respuest = validations.validate_int(bdata.split('/')[1])
			if(respuest[0] == True):
				obj = MAE_CRON('1',' ',' ',' ',int(bdata.split('/')[1]))
				dato = obj.buscar_dato()
				if(dato[0] == 'ok'):
					data = {}
					data['cron_id']=int(bdata.split('/')[1])
					data['cron_tipo']= obj.cron_tipo
					data['cron_periodo']= obj.cron_periodo
					data['cron_estado']= obj.cron_estado
					data['tobj_id']= obj.tobj_id
					data['tobj_desc']=obj.mat_tipo_obj.tobj_desc
					data['tobj_estado']=obj.mat_tipo_obj.tobj_estado
					data['tobj_consulta']=obj.mat_tipo_obj.tobj_consulta
					data['tobj_ldesc']=obj.mat_tipo_obj.tobj_ldesc
				else:
					data = {}
					data['result'] = "failed"
					data['error'] = "Sucedio un error"
					data['error_cod'] = 412
					data['val_errors'] = dato[1]
			else:
				data = {}
				data['result'] = "failed"
				data['error'] = "Sucedio un error"
				data['error_cod'] = 412
				data['val_errors'] = respuest[1]
		else:
			data = {}
			data['result'] = "failed"
			data['error'] = "Token no validado"
			data['error_cod'] = 412
			data['val_errors'] = ""
			
	status = '200 OK'
	preoutput = json.dumps(data)
	output = bytes(preoutput, 'utf-8')
	headers =[('Access-Control-Allow-Origin','application/json')]
	start_response(status,headers)
	return [output]
