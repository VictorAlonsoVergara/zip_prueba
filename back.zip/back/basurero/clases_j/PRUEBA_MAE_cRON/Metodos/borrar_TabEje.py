import sys
sys.path.insert(0,'/var/python')
sys.path.insert(1,'/home/ernesto/login')

from clsSession import Session
import logging
from cgi import parse_qs,escape

sys.path.insert(2, '/home/sistema/jassir/clases')
import json
from TAB_EJECUCIONES import TAB_EJECUCIONES
import validations

def application(environ,start_response):
	
	status = '200 OK'
	s = Session()
	cookie = environ.get('HTTP_COOKIE',0)
	tk = s.getCookie(cookie,'token')
	if s.valToken(tk):
		bdata = environ['PATH_INFO']
		respuest = validations.validate_int(bdata.split('/')[1])
		if(respuest[0] == True):
			respu = validations.id_Tab_Eje(bdata.split('/')[1])

			if (respu[0]):
				obj = TAB_EJECUCIONES(1,' ',' ',' ',' ',' ',int(bdata.split('/')[1]))
				resp = obj.borrar()
			else:
				resp = {}
				resp['result'] = "failed"
				resp['error'] = "Sucedio un error"
				resp['error_cod'] = 412
				resp['val_errors'] = respu[1]
		else:
			resp = {}
			resp['result'] = "failed"
			resp['error'] = "Sucedio un error"
			resp['error_cod'] = 412
			resp['val_errors'] = respuest[1]
	else:
		resp = {}
		resp['result'] = "failed"
		resp['error'] = "Token no validado"
		resp['error_cod'] = 412
		resp['val_errors'] = ""

	preoutput = json.dumps(resp)
	output = bytes(preoutput, 'utf-8')
	headers =[('Access-Control-Allow-Origin','application/json')]
	start_response(status,headers)
	return [output]

