import sys
sys.path.insert(0,'/var/python')
sys.path.insert(1,'/home/ernesto/login')

from clsSession import Session
import logging
from cgi import parse_qs,escape

sys.path.insert(0, '/home/sistema/jassir/clases')

import json
from MAE_CRON import MAE_CRON

def application(environ,start_response):
	status = '200 OK'
	
	s = Session()
	cookie = environ.get('HTTP_COOKIE',0)
	tk = s.getCookie(cookie,'token')

	if s.valToken(tk):
		diccionario = MAE_CRON.consultar_lista()
	else:
		diccionario = {}
		diccionario['Error'] ='Token no validado'
		
	preoutput = json.dumps(diccionario)
	output = bytes(preoutput, 'utf-8')
	headers =[('Access-Control-Allow-Origin','application/json')]

	start_response(status,headers)
	return [output]

