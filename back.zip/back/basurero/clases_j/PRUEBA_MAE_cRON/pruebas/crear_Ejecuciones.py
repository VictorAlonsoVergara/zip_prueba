import requests
url = 'http://81.17.56.130:33380/ejecuciones/crear'

payload = {'cron_id': 2, 'eje_fecha_ini': '1999-01-08 04:00:00-8:00', 'eje_fecha_fin': '1999-01-08 04:00:00-7:00', 'eje_log': '1999-01-08 04:00:00-6:00', 'eje_fecha_transferencia':'1999-01-08 04:00:00-5:00','eje_fecha_parseo':'1999-01-08 04:00:00-4:00'}
r = requests.post(url, json=payload)
#r = requests.get(url)
print(r.status_code)
if r.status_code == 200:  

	text = r.json()
	print("RESPUESTA DEL VERIFICACION WEBSERVICE")
	print(text)