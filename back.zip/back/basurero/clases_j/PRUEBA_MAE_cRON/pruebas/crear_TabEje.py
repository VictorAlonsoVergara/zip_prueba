import requests
url = 'http://81.17.56.130:33380/ejeciones/crear'

payload = {'tobj_id': 2, 'cron_tipo': 'p', 'cron_periodo': 'j_tes10', 'cron_estado': 'a'}
r = requests.post(url, json=payload)
#r = requests.get(url)
print(r.status_code)
if r.status_code == 200:  

	text = r.json()
	print("RESPUESTA DEL VERIFICACION WEBSERVICE")
	print(text)