import psycopg2
import sys
import generico
import logging
import datetime

class MAT_TIPO_OBJ :

    def __init__(self,tobj_desc,tobj_estado,tobj_consulta,tobj_ldesc,tobj_id=None):
    
        self.tobj_id = tobj_id #serial
        self.tobj_desc = tobj_desc #varchar(200)
        self.tobj_estado = tobj_estado #char(1)
        self.tobj_consulta = tobj_consulta #char(1)
        self.tobj_ldesc = tobj_ldesc #text
        #nombre_log = 'Log_programa_'+generico.diahora()+'.log'
        #logging.basicConfig(filename=nombre_log,level=logging.DEBUG)

    def guardar_dato(self):
        try:
            con = generico.entraBD()
            cur = con.cursor()
            tup = (self.tobj_desc,self.tobj_estado,self.tobj_consulta,self.tobj_ldesc)

            cur.execute('INSERT INTO "MAT_TIPO_OBJ" (tobj_desc,tobj_estado,tobj_consulta,tobj_ldesc) VALUES (%s,%s,%s,%s)',tup)
            con.commit()
            cur.execute('SELECT * FROM "MAT_TIPO_OBJ" WHERE tobj_desc =\''+ self.tobj_desc+'\' AND tobj_estado =\''+ self.tobj_estado+'\' AND tobj_consulta=\''+self.tobj_consulta+'\' AND tobj_ldesc=\''+self.tobj_ldesc+'\' ')
            version = cur.fetchall()
            self.tobj_id = version[len(version)-1][0]
            dato='ok'
        #     logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla MAE_USUARIOS')
        except psycopg2.DatabaseError as e:
            dato = 'error'
            print(f'Error {e}')
 #     logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_TIPO_USU')
        except :
            dato = 'error'
 #     logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_TIPO_USU')
        finally:
            if con:
                con.close()
        return dato

    def buscar_dato(self):
        try:
            con = generico.entraBD()
            cur = con.cursor()
            cur.execute('SELECT * FROM "MAT_TIPO_OBJ" WHERE tobj_id ='+ str(self.tobj_id))
            version = cur.fetchall()

            self.tobj_desc = version[0][1] #varchar(200)
            self.tobj_estado = version[0][2] #char(1)
            self.tobj_consulta = version[0][3] #char(1)
            self.tobj_ldesc = version[0][4] #text
            dato = 'ok'
        except psycopg2.DatabaseError as e:
            dato = 'error'
            print(f'Error {e}')
        except :
            dato = 'error'
        finally:
            if con:
                con.close()
            return dato

    def consultar(self):
        print('consulta')

    