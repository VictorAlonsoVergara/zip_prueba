import psycopg2
import sys
import generico
from MAE_CRON import MAE_CRON
from MAT_TIPO_OBJ import MAT_TIPO_OBJ
import logging
import datetime
import os 

class MAE_INDICADORES :

	def __init__(self,ind_desc,ind_estado,ind_ldesc,ind_alerta,cron_id,ind_trap,ind_trap_definicion,ind_id=0):
	
		self.ind_id = ind_id #serial
		self.ind_desc = ind_desc #varchar(200)
		self.ind_estado = ind_estado #smallint
		self.ind_ldesc = ind_ldesc #smallint
		self.ind_alerta = ind_alerta #char(1)
		self.cron_id = cron_id #integer
		self.ind_trap = ind_trap #char(1)
		self.ind_trap_definicion = ind_trap_definicion #text
		self.mae_cron = MAE_CRON('1','','','',cron_id)
		self.mae_cron.buscar_dato()
		
		#nombre_log = 'Log_programa_'+generico.diahora()+'.log'
		#	logging.basicConfig(filename=nombre_log,level=logging.DEBUG)		

	def guardar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			tup = (self.ind_desc,self.ind_estado,self.ind_ldesc,self.ind_alerta,self.cron_id,self.ind_trap,self.ind_trap_definicion)
		   
			cur.execute('INSERT INTO "MAE_INDICADORES" (ind_desc,ind_estado,ind_ldesc,ind_alerta,cron_id,ind_trap,ind_trap_definicion) VALUES (%s,%s,%s,%s,%s,%s,%s)',tup)
			con.commit()
			cur.execute('SELECT * FROM "MAE_INDICADORES" WHERE ind_desc =\''+ self.ind_desc+'\' AND ind_estado ='+ str(self.ind_estado)+' AND ind_ldesc='+str(self.ind_ldesc)+' AND ind_alerta =\''+ str(self.ind_alerta)+'\' AND cron_id='+ str(self.cron_id))
			version = cur.fetchall()
			self.ind_id = version[len(version)-1][0]
			dato = ['ok','']
			
			#logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla MAE_INDICADORES')
		except psycopg2.DatabaseError as e:
			dato = ['error',str(e)]
			
			#logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_INDICADORES')
		except:
			dato = ['error', str(e)]
			
			#logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_INDICADORES')
		finally:
			if con:
				con.close()
			return dato

	def buscar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "MAE_INDICADORES" WHERE ind_id ='+ str(self.ind_id))
			version = cur.fetchall()

			if (len(version)!=0):

				self.ind_desc = version[0][1] #varchar(200)
				self.ind_estado = version[0][2] #smallint
				self.ind_ldesc = version[0][3] #smallint
				self.ind_alerta = version[0][4] #char(1)
				self.cron_id = version[0][5] #integer
				self.ind_trap = version[0][6] #char(1)
				self.ind_trap_definicion = version[0][7] #text			
				dato = ['ok','']
			else:
				dato = ['error', 'No se encontro un elemento en MAE_INDICADORES con ese ID']
		except psycopg2.DatabaseError as e:
			dato = ['error',str(e)]
			print(f'Error {e}')
		except :
			dato = ['error',str(e)]		
		finally:
			if con:
				con.close()
			return dato


	@staticmethod
	def consultar_lista():
		try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "MAE_INDICADORES"')
			version = cur.fetchall()
			lista = []
			num=0
			for indicadores in version:
				data = {}
				data['ind_id']=indicadores[0]
				data['ind_desc']= indicadores[1]
				data['ind_estado']= indicadores[2]
				data['ind_ldesc']= indicadores[3]
				data['ind_alerta']= indicadores[4]
				data['ind_trap']= indicadores[6]
				data['ind_trap_definicion']= indicadores[7]
				data['cron_id']= indicadores[5]
				
				obj2 = MAE_CRON('1','','','',int(indicadores[5]))
				obj2.buscar_dato()

				data['cron_tipo']= obj2.cron_tipo
				data['cron_periodo']= obj2.cron_periodo
				data['cron_estado']= obj2.cron_estado
				data['tobj_id']= obj2.tobj_id

				obj3 = MAT_TIPO_OBJ(' ',' ',' ',' ',int(obj2.tobj_id))
				obj3.buscar_dato()
				data['tobj_desc']=obj3.tobj_desc
				data['tobj_estado']=obj3.tobj_estado
				data['tobj_consulta']=obj3.tobj_consulta
				data['tobj_ldesc']=obj3.tobj_ldesc

				lista.append(data)
				num = num + 1
		except psycopg2.DatabaseError as e:
			lista = {}
			lista['Error']='1'
			print(f'Error {e}')
		except Exception as e:
			lista = {}
			lista['Error'] ='2'
			print(e)
		finally:
			if con:
				con.close()
			return lista


	def modificar(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			my_sql = 'UPDATE "MAE_INDICADORES" SET ind_desc = \''+self.ind_desc+'\' , ind_estado='+str(self.ind_estado)+' , ind_ldesc='+str(self.ind_ldesc)+'  , ind_alerta=\''+self.ind_alerta+'\' , cron_id='+str(self.cron_id)+' ,ind_trap=\''+self.ind_trap+'\' , ind_trap_definicion=\''+self.ind_trap_definicion+'\'   WHERE ind_id = '+str(self.ind_id)
			cur.execute(my_sql)
			con.commit()	
		except psycopg2.DatabaseError as e:
			#lista = {}
			#lista['result']='failed'
			#lista['error']='Sucedio un error'
			#lista['error_cod']=412
			#lista['val_errors']=str(e)
			lista = ['error',str(e)]

		except Exception as e:
			#lista = {}
			#lista['result']='failed'
			#lista['error']='Sucedio un error'
			#lista['error_cod']=412
			#lista['val_errors']=str(e)
			lista = ['error',str(e)]
		else:
			#lista = {}
			#lista['result']='ok'
			lista = ['ok',' ']
		finally:
			if con:
				con.close()
			return lista


	def borrar(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			my_sql = 'DELETE FROM "MAE_INDICADORES" WHERE ind_id='+str(self.ind_id)
			cur.execute(my_sql)
			con.commit()
		except psycopg2.DatabaseError as e:
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)

		except Exception as e:
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)      
		else:
			lista = {}
			lista['result']='ok'
		finally:
			if con:
				con.close()
			return lista
	def consultar(self):
		print('consulta')

	