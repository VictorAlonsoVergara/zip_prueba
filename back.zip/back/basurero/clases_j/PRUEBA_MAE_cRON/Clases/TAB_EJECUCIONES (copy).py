import psycopg2
import sys
import generico
from MAE_CRON import MAE_CRON
from MAT_TIPO_OBJ import MAT_TIPO_OBJ
import logging
import datetime
import os 

class TAB_EJECUCIONES :

	def __init__(self,cron_id,eje_fecha_ini,eje_fecha_fin,eje_log,eje_fecha_transferencia,eje_fecha_parseo,eje_id=0,eje_fecha=0):
	
		self.eje_id = eje_id #serial
		self.eje_fecha = eje_fecha #datetime timestamp with time zone
		self.cron_id = cron_id #integer
		self.eje_fecha_ini = eje_fecha_ini #datetime timestamp with time zone
		self.eje_fecha_fin = eje_fecha_fin #datetime timestamp with time zone
		self.eje_log = eje_log # varchar(50)
		self.eje_fecha_transferencia = eje_fecha_transferencia #datetime timestamp with time zone
		self.eje_fecha_parseo = eje_fecha_parseo #datetime timestamp with time zone
		self.mae_cron = MAE_CRON('1','','','',cron_id)
		self.mae_cron.buscar_dato()
		#nombre_log = 'Log_programa_'+generico.diahora()+'.log'
		#logging.basicConfig(filename=nombre_log,level=logging.DEBUG)

		
	def guardar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			tup = (self.cron_id,self.eje_fecha_ini,self.eje_fecha_fin,self.eje_log,self.eje_fecha_transferencia,self.eje_fecha_parseo)

			cur.execute('INSERT INTO "TAB_EJECUCIONES" (cron_id,eje_fecha_ini,eje_fecha_fin,eje_log,eje_fecha_transferencia,eje_fecha_parseo) VALUES (%s,%s,%s,%s,%s,%s)',tup)
			con.commit()
			cur.execute('SELECT * FROM "TAB_EJECUCIONES" WHERE cron_id ='+ str(self.cron_id)+' AND eje_fecha_ini = \''+self.eje_fecha_ini+'\' AND eje_fecha_fin = \''+self.eje_fecha_fin+'\' AND eje_log = \''+self.eje_log+'\'AND eje_fecha_transferencia = \''+self.eje_fecha_transferencia+'\'AND eje_fecha_parseo = \''+self.eje_fecha_parseo+'\' ')
			version = cur.fetchall()
			self.eje_id = version[len(version)-1][0]
			self.eje_fecha=version[len(version)-1][1]
			dato = ['ok','']
			
			#logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla MAE_INDICADORES')
		except psycopg2.DatabaseError as e:
			dato = ['error',str(e)]
			print(f'Error {e}')
			print(exc_type, fname, exc_tb.tb_lineno)
			#logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_INDICADORES')
		except:
			dato = 'error'
			print(exc_type, fname, exc_tb.tb_lineno)
			#logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_INDICADORES')
		finally:
			if con:
				con.close()
			return dato

	def buscar_dato(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "TAB_EJECUCIONES" WHERE eje_id ='+ str(self.eje_id))
			version = cur.fetchall()

			if (len(version)!=0):
				self.eje_fecha = str(version[0][1]) #datetime timestamp with time zone
				self.cron_id = version[0][2] #integer
				self.eje_fecha_ini = str(version[0][3]) #datetime timestamp with time zone
				self.eje_fecha_fin = str(version[0][4]) #datetime timestamp with time zone
				self.eje_log = str(version[0][5]) # varchar(50)
				self.eje_fecha_transferencia = str(version[0][6]) #datetime timestamp with time zone
				self.eje_fecha_parseo = str(version[0][7]) #datetime timestamp with time zone
				dato = ['ok','']
			else:
				dato = ['error', 'No se encontro un elemento en MAE_INDICADORES con ese ID']
		except psycopg2.DatabaseError as e:
			dato = ['error',str(e)]
			print(f'Error {e}')
		except :
			dato = ['error',str(e)]		
		finally:
			if con:
				con.close()
			return dato

	@staticmethod
	def consultar_lista():
		try:
			con = generico.entraBD()
			cur = con.cursor()
			cur.execute('SELECT * FROM "TAB_EJECUCIONES"')
			version = cur.fetchall()
			lista = []
			num=0
			for indicadores in version:
				data = {}
				data['eje_id']=str(indicadores[0])
				data['eje_fecha']= str(indicadores[1])
				data['eje_fecha_ini']= str(indicadores[3])
				data['eje_fecha_fin']= str(indicadores[4])
				data['eje_log']= str(indicadores[5])
				data['eje_fecha_transferencia']= str(indicadores[6])
				data['eje_fecha_parseo']= str(indicadores[7])
				data['cron_id']= indicadores[2]
				
				obj2 = MAE_CRON('1','','','',int(indicadores[2]))
				obj2.buscar_dato()

				data['cron_tipo']= obj2.cron_tipo
				data['cron_periodo']= obj2.cron_periodo
				data['cron_estado']= obj2.cron_estado
				data['tobj_id']= obj2.tobj_id

				obj3 = MAT_TIPO_OBJ(' ',' ',' ',' ',int(obj2.tobj_id))
				obj3.buscar_dato()
				data['tobj_desc']=obj3.tobj_desc
				data['tobj_estado']=obj3.tobj_estado
				data['tobj_consulta']=obj3.tobj_consulta
				data['tobj_ldesc']=obj3.tobj_ldesc

				lista.append(data)
				num = num + 1
		except psycopg2.DatabaseError as e:
			lista = {}
			lista['Error']='1'
			print(f'Error {e}')
		except Exception as e:
			lista = {}
			lista['Error'] ='2'
			print(e)
		finally:
			if con:
				con.close()
			return lista

	def modificar(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			my_sql = 'UPDATE "TAB_EJECUCIONES" SET  cron_id='+str(self.cron_id)+' , eje_fecha_ini=\''+self.eje_fecha_ini+'\' , eje_fecha_fin=\''+self.eje_fecha_fin+'\' , eje_log=\''+self.eje_log+'\', eje_fecha_transferencia=\''+self.eje_fecha_transferencia+'\'  , eje_fecha_parseo=\''+self.eje_fecha_parseo+'\' WHERE eje_id = '+str(self.eje_id)
			cur.execute(my_sql)
			con.commit()	
		except psycopg2.DatabaseError as e:

			lista = ['error',str(e)]

		except Exception as e:
		
			lista = ['error',str(e)]
		else:
			
			lista = ['ok',' ']
		finally:
			if con:
				con.close()
			return lista

	def borrar(self):
		try:
			con = generico.entraBD()
			cur = con.cursor()
			my_sql = 'DELETE FROM "TAB_EJECUCIONES" WHERE eje_id='+str(self.eje_id)
			cur.execute(my_sql)
			con.commit()
		except psycopg2.DatabaseError as e:
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)

		except Exception as e:
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)      
		else:
			lista = {}
			lista['result']='ok'
		finally:
			if con:
				con.close()
			return lista

	def consultar(self):
		print('consulta')