import generico 	
import psycopg2

def validate_string(data):
	words  = str(data) 
	try:
		number = int(words)
		#print('Solo esta permitido cadenas y usted ha ingresado un numero')
		return [False ,'ha ingresado un numero']
	except ValueError:
		pass   

	lenght = len(data) 
	for i in range(lenght):
		try:
			character = int(words[i])
			#print('Todos los caracteres de la data deben ser letras y no numeros')
			return [False,'se encontro un numero como caracter']
		except ValueError:
		# print('todo ok con el caracter ')
			continue

	return [True,'ok']


def validate_varchar(data,maximum_length):
	words = str(data) 
	try:
		number = int(words)
		#print('Solo esta permitido cadenas y usted ha ingresado un numero')
		return [False ,'ha ingresado un numero']
	except ValueError:
		pass

	lenght = len(data) 
	if (lenght > maximum_length):
		#print('La longitud de la entrada no debe ser mayor a {}'.format(maximum_length))
		return [False,'Sobrepaso longitud maxima de '+str(maximum_length)]

	return [True,'ok']

def validate_int(data):
	try:
		number = int(data)		
		return [True,'ok']
	except ValueError:
		return [False,'ValueError en el int']
		
def validate_char(data):
	words  = str(data) 
	try:
		number = int(words)
		#print('Solo esta permitido cadenas y usted ha ingresado un numero')
		return [False,'Ha ingresado un numero']
	except ValueError:
		pass   
		#print('La entrada {} no se pudo convertir a int'.format(words))

	#largo del input
	lenght = len(data) 
	if (lenght > 1):
		#print('La longitud de la entrada no debe ser mayor a {}'.format(1))
		return [False,'Sobrepaso la longitud de 1']

	return [True,'ok']

def validate_date_time(data):

    fecha = str(data)

    try:
        int(fecha)
        return [False,'Ha ingresado un numero']

    except ValueError:
        pass

    #1999-01-08 04:05:06-8:00     #formato xxxx-xx-xx xx:xx:xx-x:xx 
    formato = "-- ::" # 

    a = fecha[4] + fecha[7] + fecha[10] + fecha[13] + fecha[16]
    utc = fecha[19]

    if (a == formato) and (utc == "+" or utc == "-"):

        return [True,'ok']

    else:
        return [False,'Formato no valido']


def foreign_Mae_Usu(tusu_id):
	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT COUNT(tusu_id) FROM "MAE_TIPO_USU" WHERE tusu_id ='+ str(tusu_id))
		version = cur.fetchall()
		if version[0][0]!=0:# sí existe un dato con el codigo tusu_id 
			dato = [True,' '] #'ok'
		else: 
			dato = [False,'No existe el tipo de usuario seleccionado'] #'error'
		
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		if con:
			con.close()
		return dato	


def id_Mae_Usu(usu_id):
	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT COUNT(usu_id) FROM "MAE_USUARIOS" WHERE usu_id ='+ str(usu_id))
		version = cur.fetchall()
		if version[0][0]!=0:# sí existe un dato con el codigo tusu_id 
			dato = [True,' '] #'ok'
		else: 
			dato = [False,'No existe el usuario seleccionado'] #'error'
		
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		if con:
			con.close()
		return dato

#MAE_CRON

def foreign_Mae_Cron(tobj_id):          

	try:
		con = generico.entraBD()
		cur = con.cursor()

		cur.execute('SELECT COUNT(tobj_id) FROM "MAT_TIPO_OBJ" WHERE tobj_id ='+ str(tobj_id))
		version = cur.fetchall()

		if version[0][0]!=0:# sí existe un dato con el codigo tusu_id 
			dato = [True,' '] #'ok'
		else: 
			dato = [False,'No existe el tipo de objeto seleccionado'] #'error'
		
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		if con:
			con.close()
		return dato	

def id_Mae_Cron(cron_id):
	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT COUNT(cron_id) FROM "MAE_CRON" WHERE cron_id ='+ str(cron_id))
		version = cur.fetchall()
		if version[0][0]!=0:# sí existe un dato con el codigo tusu_id 
			dato = [True,' '] #'ok'
		else: 
			dato = [False,'No existe el cron seleccionado'] #'error'
		
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		if con:
			con.close()
		return dato

#MAE_INDICADORES

def id_Mae_Ind(ind_id):
	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT COUNT(ind_id) FROM "MAE_INDICADORES" WHERE ind_id ='+ str(ind_id))
		version = cur.fetchall()
		if version[0][0]!=0:# sí existe un dato con el codigo tusu_id 
			dato = [True,' '] #'ok'
		else: 
			dato = [False,'No existe el indicador seleccionado'] #'error'
		
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		if con:
			con.close()
		return dato

#TAB_EJE

def id_Tab_Eje (eje_id):

	try:
		con = generico.entraBD()
		cur = con.cursor()
		cur.execute('SELECT COUNT(eje_id) FROM "TAB_EJECUCIONES" WHERE eje_id ='+ str(eje_id))
		version = cur.fetchall()
		if version[0][0]!=0:# sí existe un dato con el codigo eje_id
			dato = [True,' '] #'ok'
		else: 
			dato = [False,'No existe TAB_EJECUCIONES seleccionado'] #'error'
		
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		if con:
			con.close()
		return dato

