
import datetime
import logging
import sys
import time
import psycopg2

def diahora():
  text = str(datetime.datetime.utcnow() + datetime.timedelta(hours=-5))
  return text.split(".")[0]

def listaVacia(str_lista):
  if not str_lista:
    str_result = "vacio"
  else:
    str_result = "no vacio"
  return str_result

def entraBD():
  try:
    con = psycopg2.connect(database='cotener',user='cotener',password='cotener')

  except psycopg2.DatabaseError as e:

    print(f'Error {e}')
    con = ''
  except:
    con = ''
  finally:
    return con

  