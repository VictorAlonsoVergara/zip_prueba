import psycopg2
import sys
import generico
from MAT_TIPO_OBJ import MAT_TIPO_OBJ
import logging
import datetime
import os

class MAE_CRON :

    def __init__(self,tobj_id,cron_tipo,cron_periodo,cron_estado,cron_id=0):
    
        self.cron_id = cron_id #serial
        self.tobj_id = tobj_id #integer
        self.cron_tipo = cron_tipo #char(1)
        self.cron_periodo = cron_periodo #varchar(20)
        self.cron_estado = cron_estado #char(1)
        self.mat_tipo_obj = MAT_TIPO_OBJ('','','','',tobj_id)
        self.mat_tipo_obj.buscar_dato()
        #nombre_log = 'Log_programa_'+generico.diahora()+'.log'
        #logging.basicConfig(filename=nombre_log,level=logging.DEBUG)        

    def guardar_dato(self):
        try:
            con = generico.entraBD()
            cur = con.cursor()
            tup = (self.tobj_id,self.cron_tipo,self.cron_periodo,self.cron_estado)

            cur.execute('INSERT INTO "MAE_CRON" (tobj_id,cron_tipo,cron_periodo,cron_estado) VALUES (%s,%s,%s,%s)',tup)
            con.commit()
            cur.execute('SELECT * FROM "MAE_CRON" WHERE tobj_id ='+ str(self.tobj_id)+' AND cron_tipo =\''+ self.cron_tipo+'\' AND cron_periodo=\''+self.cron_periodo+'\' AND cron_estado=\''+self.cron_estado+'\' ')
            version = cur.fetchall()
            self.cron_id = version[len(version)-1][0]
            dato = ['ok',' ']
        #     logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla MAE_USUARIOS')
        except psycopg2.DatabaseError as e:
            dato = ['error',str(e)]
            print(f'Error {e}')
            print(exc_type, fname, exc_tb.tb_lineno)
        #       logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_USUARIOS')
        except Exception as e:
            dato = ['error',str(e)]
            print(exc_type, fname, exc_tb.tb_lineno)
        #     logging.error(str(datetime.datetime.today())+'sucedio un error guardando en la tabla MAE_USUARIOS')
        finally:
            if con:
                con.close()
            return dato

    def buscar_dato(self):
        try:
            con = generico.entraBD()
            cur = con.cursor()
            cur.execute('SELECT * FROM "MAE_CRON" WHERE cron_id ='+ str(self.cron_id))
            version = cur.fetchall()
            if (len(version)!=0):

                self.tobj_id = version[0][1] #integer
                self.cron_tipo = version[0][2] #char(1)
                self.cron_periodo = version[0][3] #varchar(20)
                self.cron_estado = version[0][4] #char(1)
                dato = ['ok',' ']
            else:
                dato=['error','No se encontro el cron con ese ID']
        except psycopg2.DatabaseError as e:
            dato = ['error',str(e)]
            print(f'Error {e}')
        except Exception as e:
            dato = ['error',str(e)]
        finally:
            if con:
                con.close()
            return dato

    @staticmethod
    
    def consultar_lista():
    
        try:
            con = generico.entraBD()
            cur = con.cursor()
            cur.execute('SELECT * FROM "MAE_CRON"')
            version = cur.fetchall()
            lista = []
            num=0
            for cron in version:
                data = {}
                data['cron_id']=cron[0]
                data['cron_tipo']= cron[2]
                data['cron_periodo']= cron[3]
                data['cron_estado']= cron[4]
                data['tobj_id']= cron[1]

                obj2 = MAT_TIPO_OBJ(' ',' ',' ',' ',int(cron[1]))
                obj2.buscar_dato()
                data['tobj_desc']=obj2.tobj_desc
                data['tobj_estado']=obj2.tobj_estado
                data['tobj_consulta']=obj2.tobj_consulta
                data['tobj_ldesc']=obj2.tobj_ldesc
                lista.append(data)
                num = num + 1
        except psycopg2.DatabaseError as e:
            lista = {}
            lista['Error']='1'
            print(f'Error {e}')
        except Exception as e:
            lista = {}
            lista['Error'] ='2'
            print(e)
        finally:
            if con:
                con.close()
            return lista

    def modificar(self):
        try:
            con = generico.entraBD()
            cur = con.cursor()
            my_sql = 'UPDATE "MAE_CRON" SET tobj_id = '+str(self.tobj_id)+' , cron_tipo= \''+self.cron_tipo+'\' , cron_periodo=\''+self.cron_periodo+'\' , cron_estado=\''+self.cron_estado+'\' WHERE cron_id = '+str(self.cron_id) 
            cur.execute(my_sql)
            con.commit()
        except psycopg2.DatabaseError as e:
            #lista = {}
            #lista['result']='failed'
            #lista['error']='Sucedio un error'
            #lista['error_cod']=412
            lista = ['error',str(e)]

        except Exception as e:
            #lista = {}
            #lista['result']='failed'
            #lista['error']='Sucedio un error'
            #lista['error_cod']=412
            lista = ['error',str(e)]
        else:
            #lista = {}
            lista = ['ok',' ']
        finally:
            if con:
                con.close()
            return lista

    def borrar(self):
        try:
            con = generico.entraBD()
            cur = con.cursor()
            my_sql = 'DELETE FROM "MAE_CRON" WHERE cron_id='+str(self.cron_id)
            cur.execute(my_sql)
            con.commit()
        except psycopg2.DatabaseError as e:
            lista = {}
            lista['result']='failed'
            lista['error']='Sucedio un error'
            lista['error_cod']=505
            lista['val_errors']=str(e)

        except Exception as e:
            lista = {}
            lista['result']='failed'
            lista['error']='Sucedio un error'
            lista['error_cod']=505
            lista['val_errors']=str(e)      
        else:
            lista = {}
            lista['result']='ok'
        finally:
            if con:
                con.close()
            return lista

    def consultar(self):
        print('consulta')