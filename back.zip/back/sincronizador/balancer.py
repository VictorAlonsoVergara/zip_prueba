import time
import os
from threading import Thread

class Balancer:
    def __init__(self,numHilos,tarea):
        self.numHilos = numHilos
        #self.ruta_origen = ruta_origen
        self.tarea = tarea
        self.hilosActivos = 0
        
    def __thread_execute(self,args):
        self.tarea(*args)
        self.hilosActivos-=1

    def __start_thread(self,args):
        t = Thread(target=self.__thread_execute,args=(args,))
        t.start()

    def execute_tasks(self,lista):
        if len(lista) <= 0:
            return
        self.hilosActivos = 0
        pos = 0
        while pos < len(lista):
            if self.hilosActivos < self.numHilos:
                item = lista[pos]
                self.__start_thread((item,))
                self.hilosActivos+=1
                pos+=1
        while self.hilosActivos > 0:
            pass