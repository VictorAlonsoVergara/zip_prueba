import socket
import threading
import hashlib

class ClientConn(threading.Thread):
    def __init__(self,connection:socket.socket,address,dest_route):
        threading.Thread.__init__(self)
        self.conn = connection
        self.addr = address
        self.dest_route = dest_route
        self.connected = True

    def __receive(self,msg_len:int = 1024,is_string:bool = True):
        msg = self.conn.recv(msg_len)
        if is_string:
            msg = msg.decode('utf-8')
        return msg

    def __send(self,payload,is_string:bool = True):
        if is_string:
            payload = payload.encode('utf-8')
        self.conn.send(payload)

    def __receive_file(self):
        filename = self.__receive()
        self.__send('recibido filename: ' + filename)
        hash_md5 = self.__receive()
        self.__send('received hash')
        file_dest = self.dest_route + filename
        f = open(file_dest,'wb')
        file_data = self.__receive(1024,False)
        while file_data:
            f.write(file_data)
            file_data = self.__receive(1024,False)
        f.close()
        if self.__checksum(hash_md5,file_dest):
            self.__send('ok')
        else:
            self.__send('failed')
            
    def __checksum(self,hashed,file_route):
        #Tamaño que se leerá el arrchivo para no guardar todo en memoria
        BUF_SIZE = 65536
        hash_data = hashlib.md5()
        with open(file_route,'rb') as archivo:
            file_data = archivo.read(BUF_SIZE)
            #Mientras haya data que leer se sigue leyendo el archivo
            while file_data:
                #Se actualiza el hash con cada trozo de data que se lee
                hash_data.update(file_data)
                file_data = archivo.read(BUF_SIZE)
        #Se obtiene el Hash
        hash_string = hash_data.hexdigest()
        print("Hash file:",hash_string)
        if hashed == hash_string:
            return True
        return False


    def __check_keyword(self):
        keyword = self.__receive()
        print(keyword)
        if keyword == 'kirby':
            self.__send('ok')
        else:
            self.__send('failed')
            self.connected = False

    def __close(self):
        self.conn.close()

    def run(self):
        self.__check_keyword()
        self.__receive_file()
        # while self.connected:
        #     msg = self.__receive()
        #     print(msg)
        #     if msg == 'close':
        #         print('Closing connection')
        #         self.__send('closing...')
        #         break
        #     self.__send('Received Message ' + msg)
        print('Cliente desconectado: %s'%str(self.addr))
        self.__close()


class MultiServer:
    def __init__(self,dest_route):
        self.conn = None
        self.addr = None
        self.sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        self.dest_route = dest_route

    def bind(self,port:int,hostname = ''):
        self.sock.bind((hostname,port))
        
    def listen(self, backlog:int = 5):
        self.sock.listen(backlog)
        self.conn,self.addr = self.sock.accept()
        client = ClientConn(self.conn,self.addr,self.dest_route)
        client.start()
    
    def close(self):
        self.sock.close()