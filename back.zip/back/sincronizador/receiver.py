import logging
import hashlib
import configparser
import os
import time

from mysocket import MySocket
from MultiServer import MultiServer

#Se lee el archivo de configuracion
config = configparser.ConfigParser()
config.read('config.ini')

#se inician variables de configuracion
default_vars = config['DEFAULT']
receiver_vars = config['RECEIVER']

puerto = receiver_vars.getint('puerto')
activado = default_vars.getboolean('activado')
tipo = default_vars['tipo']
intervalo = receiver_vars.getint('intervalo')
ruta_dest = receiver_vars['ruta_destino']
scp_timer = 0
if tipo == 'socket':
    #Se crea el socket
    socket = MySocket()
    socket.bind(puerto,'')

def checksum(hashed,file_route):
    #Tamaño que se leerá el arrchivo para no guardar todo en memoria
    BUF_SIZE = 65536
    hash_data = hashlib.md5()
    with open(file_route,'rb') as archivo:
        file_data = archivo.read(BUF_SIZE)
        #Mientras haya data que leer se sigue leyendo el archivo
        while file_data:
            #Se actualiza el hash con cada trozo de data que se lee
            hash_data.update(file_data)
            file_data = archivo.read(BUF_SIZE)
    #Se obtiene el Hash
    hash_string = hash_data.hexdigest()
    print("Hash file:",hash_string)
    if hashed == hash_string:
        return True
    return False

def check_hash_files():
    hash_dir = receiver_vars['hash_dir']
    lista_hashes = os.listdir(hash_dir)
    if len(lista_hashes) > 0:
        for filename in lista_hashes:
            dir_file = hash_dir+filename
            with open(dir_file) as f:
                hash_md5 = f.readline()
            scp_check(filename,hash_md5)

def scp_check(filename,hash_md5):
    file_dest = receiver_vars['ruta_destino']+filename
    if checksum(hash_md5,file_dest):
        socket.send("ok")
    else:
        socket.send("failed")
        os.remove(file_dest)
    socket.close_conn()

def socket_server():
    socket.listen()
    secure = socket.receive()
    #Palabra clave para ver si es el programa que envia que se está conectando
    if secure != 'kirby':
        socket.send('fail')
        socket.close_conn()
        return
    socket.send('ok')
    #recibir nombre de archivo
    filename = socket.receive()
    msg = 'recibido nombre: '+filename
    socket.send(msg)
    #Recibir hash en md5
    hash_md5 = socket.receive()
    print("Received Hash:",hash_md5)
    socket.send('received hash')
    #Se crea el archivo del que se va a enviar data
    file_dest = receiver_vars['ruta_destino']+filename
    arch = open(file_dest,'wb')
    data = socket.receive(False,4096)
    #Se recibe el archivo en paquetes de 4096 bytes
    while data:
        arch.write(data)
        data = socket.receive(False,4096)
    arch.close()
    #Se hace el checksum para verificar el archivo
    if checksum(hash_md5,file_dest):
        socket.send('ok')
    else:
        #si hay un error en el checksum se envia failed y se elimina el archivo recibido
        socket.send('failed')
        os.remove(file_dest)
    #Se cierra la conexion con el cliente
    socket.close_conn()
    # socket.close()

MultiServ = MultiServer(dest_route=ruta_dest)

MultiServ.bind(puerto)

MultiServ.listen()

MultiServ.close()

# while activado is True:
#     if tipo == 'scp':
#         now = time.time()
#         if now - scp_timer >= intervalo:
#             check_hash_files()
#             scp_timer = time.time()
#     elif tipo == 'socket':
#         socket_server()
#     else:
#         raise Exception('No se reconoce el tipo ingresado')
# if tipo == 'socket':
#     socket.close()
# while activado is True:
#     socket.listen()
#     secure = socket.receive()
#     #Palabra clave para ver si es el programa que envia que se está conectando
#     if secure != 'kirby':
#         socket.send('fail')
#         socket.close_conn()
#         continue
#     socket.send('ok')
#     #recibir nombre de archivo
#     filename = socket.receive()
#     msg = 'recibido nombre: '+filename
#     socket.send(msg)
#     #Recibir hash en md5
#     hash_file = socket.receive()
#     print("Received Hash:",hash_file)
#     socket.send('received hash')
    # if tipo == 'socket':
    #     socket_server(hash_file,filename)
    # elif tipo == 'scp':
    #     scp_check(hash_file,filename)
    # else:
    #     raise Exception('No se reconoce el tipo ingresado')
# socket.close()
