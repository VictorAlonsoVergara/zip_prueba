import zc.lockfile
import sys
import configparser

from sync_files import File_Sync


config = configparser.ConfigParser()
config.read('config.ini')

try:
    lock = zc.lockfile.LockFile('sincronizador.lock')
except Exception:
    print('El proceso ya se encuentra ejecutando')
    sys.exit()

default_vars = config['DEFAULT']
sender_vars = config['SENDER']
puertos_vars = config['PUERTOS']

tipo = default_vars['tipo']
puerto = puertos_vars.getint(tipo)

fs = File_Sync(sender_vars.getint('intervalo'),
                default_vars.getboolean('activado'),
                sender_vars['ruta_origen'],
                sender_vars['ruta_destino'],
                sender_vars['ruta_subidos'],
                sender_vars['hostname_destino'],
                puerto,
                sender_vars['username'],
                sender_vars['password'],
                default_vars['tipo'],
                sender_vars.getint('numHilos'))

fs.start()

while True:
    cmd = input('Ingrese comando: ')
    if cmd == 'start':
        fs.start()
    if cmd == 'stop':
        fs.stop()
    if cmd == 'exit':
        fs.stop()
        break
lock.close()