import socket

class MySocket:
    def __init__(self,sock = None):
        self.MSGLEN = 1024
        self.conn = None
        self.addr = None
        self.is_serv = False
        if sock is None:
            self.sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        else:
            self.sock = sock
        
    def connect(self,port,host = '0.0.0.0'):
        try:
            self.__connect(host,port)
        except Exception as e:
            print(e)
            #self.__bind(host,port)
            #self.is_serv = True

    def bind(self,port,host):
        self.__bind(host,port)
        self.is_serv = True

    def listen(self):
        if self.is_serv:
            self.__accept()
        else:
            print("Socket is not server, can't listen")

    def __bind(self,host,port):
        self.sock.bind((host,port))
        #self.__accept()

    def __connect(self,host,port):
        self.sock.connect((host,port))
        #self.__accept()

    def __accept(self):
        self.sock.listen(5)
        self.conn,self.addr = self.sock.accept()

    def send(self,msg,is_string = True):
        #totalsent = 0
        if is_string:
            msg = msg.encode('utf-8')
        if self.is_serv:
            self.conn.send(msg)
        else:
            self.sock.send(msg)

    def receive(self,is_string = True,num_bytes = 1024):
        if self.is_serv:
            data = self.conn.recv(num_bytes)
        else:
            data = self.sock.recv(num_bytes)
        if is_string:
            data = data.decode('utf-8')
        return data
    
    def close_conn(self):
        self.conn.close()

    def close(self):
        self.sock.close()
    
    def shutdown(self):
        self.sock.shutdown(socket.SHUT_WR)