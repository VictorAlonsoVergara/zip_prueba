import time
from threading import Thread
import os
import paramiko
from scp import SCPClient
import shutil
import hashlib
#import pathlib

from mysocket import MySocket
from balancer import Balancer

class File_Sync:
    def __init__(self,intervalo,active,
                    ruta_origen,ruta_destino,
                    ruta_subidos,host_destino,
                    puerto,username,password,tipo,numHilos):
        self.active = active
        self.intervalo = intervalo
        self.ruta_origen = ruta_origen
        self.ruta_destino = ruta_destino
        self.host_destino = host_destino
        self.ruta_subidos = ruta_subidos
        self.puerto = puerto
        self.username = username
        self.password = password
        self.tipo = tipo
        self.timer = 0
        if self.tipo == 'socket':
            send_func = self.__socket_send
        elif self.tipo == 'scp':
            send_func = self.__scp_send
        else:
            self.active = False
            send_func = None
            raise Exception('El tipo no existe')
        self.balancer = Balancer(numHilos,send_func)

    def __execute(self):
        while self.active is True:
            now = time.time()
            if now - self.timer >= self.intervalo:
                self.timer = time.time()
                lista_files = []
                lista_files = os.listdir(self.ruta_origen)
                if len(lista_files) > 0:
                    #self.send_func(lista_files)
                    self.balancer.execute_tasks(lista_files)
                
    def start(self):
        t = Thread(target=self.__execute)
        t.start()
        #t.join()
    
    def stop(self):
        self.active = False

    def __scp_send(self,lista_files):
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.load_system_host_keys()
        client.connect(hostname=self.host_destino,port=self.puerto,username=self.username,password=self.password)
        scp = SCPClient(client.get_transport())
        for filename in lista_files:
            origen = self.ruta_origen + filename
            destino = self.ruta_destino + filename
            scp.put(origen,destino)
            self.__move_file(filename)
        scp.close()
        client.close()
        sock = MySocket()
        sock.connect(self.puerto,self.host_destino)
        #TODO completar con validaciones
        sock.send(filename)
        msg_ok = sock.receive()
        print(msg_ok)
            
    def __socket_send(self,lista_files):
        for filename in lista_files:
            ruta_fin = self.ruta_origen + filename
            #Se obtiene el hash del archivo
            hash_data = self.__hash_file(ruta_fin)
            #Se crea y conecta el socket
            sock = MySocket()
            sock.connect(self.puerto,self.host_destino)
            #Se envia la clave para que se verifique que este es el programa que se esta conectando
            sock.send('kirby')
            resp = sock.receive()
            if resp!='ok':
                print(resp)
                sock.shutdown()
                sock.receive()
                sock.close()
                continue
            #Se envia el nombre del archivo
            sock.send(filename)
            msg = sock.receive()
            print(msg)
            #Se envia el hash en md5
            sock.send(hash_data)
            resp_hash = sock.receive()
            print(resp_hash)
            # Se abre el archivo
            arch = open(ruta_fin,'rb')
            data = arch.read(4096)
            #file_size = pathlib.Path(self.ruta_origen + filename).stat().st_size
            #Se envia el archivo en bloques de 4096 bytes
            while data:
                sock.send(data,False)
                data = arch.read(4096)
            #El socket deja de enviar
            sock.shutdown()
            msg = sock.receive()
            print(msg)
            sock.close()
            arch.close()
            # Si el archivo se envio correctamente se mueve el archivo a la carpeta de subidos
            if msg != 'failed':
                self.__move_file(filename)
    
    def __move_file(self,filename):
        origen = self.ruta_origen + filename
        destino = self.ruta_subidos + filename
        shutil.move(origen,destino)
    
    def __hash_file(self,file_route):
        BUF_SIZE = 65536
        hash_data = hashlib.md5()
        with open(file_route,'rb') as archivo:
            file_data = archivo.read(BUF_SIZE)
            while file_data:
                hash_data.update(file_data)
                file_data = archivo.read(BUF_SIZE)
        hash_string = hash_data.hexdigest()
        print(hash_string)
        return hash_string