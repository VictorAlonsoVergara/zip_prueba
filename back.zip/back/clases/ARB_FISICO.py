import psycopg2
import sys
import os
import logging
import datetime
from MyDB import MyDB


class ARB_FISICO:

    def __init__(self, fis_id=None, fis_id_padre=None, fis_desc=None, fis_orden=None):

        self.fis_id = fis_id  # integer
        self.fis_id_padre = fis_id_padre  # integer
        self.fis_desc = fis_desc  # varchar(200)
        self.fis_orden = fis_orden  # varchar(30)

        self.clase_MyDB = MyDB()

    def get_diccionario(self):
        diccionario = vars(self)
        diccionario.pop('clase_MyDB')
        return diccionario

    def guardar_dato(self):
        try:
            if (self.fis_id_padre != "NULL"):
                datos = (self.fis_id_padre, self.fis_desc, self.fis_orden,)
                query = 'INSERT INTO "ARB_FISICO" (fis_id_padre,fis_desc,fis_orden) VALUES (%s,%s,%s) RETURNING fis_id'

            else:
                datos = (self.fis_desc, self.fis_orden,)
                query = 'INSERT INTO "ARB_FISICO" (fis_id_padre,fis_desc,fis_orden) VALUES (NULL,%s,%s) RETURNING fis_id'
            version = self.clase_MyDB.conectar(query, datos, False)
            if version[0] == 'ok':
                self.fis_id = version[1][0][0]
                dato = ['ok', ' ']
            else:
                dato = ['error', 'Error en la base de datos']

        except Exception as e:
            dato = ['error', str(e)]
        finally:
            return dato

    def buscar_dato(self):
        try:
            datos = (self.fis_id,)
            query = 'SELECT * FROM "ARB_FISICO" WHERE fis_id = %s '
            version = self.clase_MyDB.conectar(query, datos, True)
            if (version[0] == 'ok'):
                if (version[1] != False):
                    self.fis_id_padre = version[1][0][1]  # integer
                    self.fis_desc = version[1][0][2]  # integer
                    self.fis_orden = version[1][0][3]  # integer
                    dato = ['ok', ' ']
                else:
                    dato = [
                        'error', 'No se encontro un elemento en ARB_FISICO con ese ID']
            else:
                dato = ['error', 'Error con la base de datos']
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            dato = ['error', str(e)+' - '+str(exc_type) +
                                 ' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
        finally:
            return dato

    @staticmethod
    def validations_crear(fis_id_padre):
        try:
            if (fis_id_padre == ""):
                dato = [True, 'ok']
            else:
                datos = (fis_id_padre,)
                query = 'SELECT * FROM "ARB_FISICO" WHERE fis_id = %s'
                clase_MyDB = MyDB()
                version = clase_MyDB.conectar(query, datos, True)
                if (version[0] == 'ok'):
                    if (version[1] != False):  # ya existe
                        dato = [True, 'ok']
                    else:
                        dato = [
                            False, 'No existe un arb_fisico con ese fis_id_padre']
                else:
                    dato = ['error', 'Error con la base de datos']
        except Exception as e:
            dato = [False, str(e)]
        finally:
            return dato

    @staticmethod
    def consultar_lista():
        try:
            query = 'SELECT * FROM "ARB_FISICO" '
            datos = ()
            clase_MyDB = MyDB()
            version = clase_MyDB.conectar(query, datos, True)
            if (version[0] == 'ok'):
                if (version[1] != False):
                    lista = []
                    for arb in version[1]:
                        data = {}
                        arb_fisico = ARB_FISICO.from_list(arb)
                        data.update(arb_fisico.get_diccionario())
                        lista.append(data)
                else:
                    lista = {}
                    lista['ARB_FISICO'] = 'Lista vacia'
            else:
                lista = {}
                lista['Error'] = 'Error en la base de datos'

        except Exception as e:
            lista = {}
            lista['Error'] = str(e)
        finally:
            return lista

    @staticmethod
    def validations_borrar(fis_id):
        try:
            query = 'SELECT * FROM "ARB_FISICO" WHERE fis_id_padre = %s'
            datos = (fis_id,)
            clase_MyDB = MyDB()
            version = clase_MyDB.conectar(query, datos, True)
            if (version[0] == 'ok'):
                if (version[1] != False):  # existe
                    dato = [False, 'No se puede eliminar un fis_id_padre']
                else:
                    dato = [True, 'ok']
        except Exception as e:
            dato = [False, str(e)]
        finally:
            return dato

    def modificar(self):
        try:
            if self.fis_id_padre != "NULL":
                pass_flag = True
                arb_aux = ARB_FISICO(fis_id=self.fis_id_padre)
                dict_padres = arb_aux.buscar_padres()
                if dict_padres['result'] == 'failed':
                    lista = ['error',dict_padres['val_errors']]
                    return lista
                lista_padres = dict_padres['listas']
                for objeto in lista_padres:
                    try:
                        id_padre = objeto['padre']
                        if id_padre == self.fis_id:
                            pass_flag = False
                            break
                    except Exception:
                        pass
                if pass_flag is False:
                    lista = [
                        'error', 'Referencia ciruclar encontrada ingrese otro id de padre']
                    return lista

            if ((self.fis_id_padre) != "NULL"):
                query = ('UPDATE "ARB_FISICO" SET fis_id_padre= COALESCE(%s,fis_id_padre),'
                    'fis_desc=COALESCE(%s,fis_desc), fis_orden=COALESCE(%s,fis_orden) WHERE fis_id = %s')
                datos = (self.fis_id_padre, self.fis_desc,
                         self.fis_orden, self.fis_id,)
            else:
                query = ('UPDATE "ARB_FISICO" SET fis_id_padre= NULL,'
                    'fis_desc=COALESCE(%s,fis_desc), fis_orden=COALESCE(%s,fis_orden) WHERE fis_id = %s')
                datos = (self.fis_desc, self.fis_orden, self.fis_id,)
            respu = self.clase_MyDB.conectar(query, datos, False)
            if (respu[0] == 'ok'):
                lista = ['ok', ' ']
            else:
                lista = ['error', 'Error en la base de datos']
        except Exception as e:
            lista = ['error', str(e)]
        finally:
            return lista

    def borrar(self):
        try:
            query = 'DELETE FROM "ARB_FISICO" WHERE fis_id= %s'
            datos = (self.fis_id,)
            respu = self.clase_MyDB.conectar(query, datos, False)
            if (respu[0] == 'ok'):
                lista = {}
                lista['result'] = 'ok'  # +str(respu)
            else:
                lista = {}
                lista['result'] = 'failed'
                lista['error'] = 'Sucedio un error'
                lista['error_cod'] = 505
                lista['val_errors'] = 'Error en la base de datos'
        except Exception as e:
            lista = {}
            lista['result'] = 'failed'
            lista['error'] = 'Sucedio un error'
            lista['error_cod'] = 505
            lista['val_errors'] = str(e)
        finally:
            return lista

    def borrar_rama(self):
        try:
            function = 'call borrar_rama_arbol_fisico(%s,%s)'
            params = (self.fis_id,[],)
            resultado = self.clase_MyDB.conectar(function,params,True)
            respuesta = {}
            if resultado[0] == 'ok':
                if resultado[1] is not False:
                    respuesta['result'] = 'ok'
                    respuesta['listas'] = resultado[1][0][0]
                else:
                    respuesta['result'] = 'failed'
                    respuesta['error'] = 'Sucedio un error'
                    respuesta['error_cod'] = 501
                    respuesta['val_errors'] = 'No se encontro elementos'
            else:
                respuesta['result'] = 'failed'
                respuesta['error'] = 'Sucedio un error'
                respuesta['error_cod'] = 502
                respuesta['val_errors'] = 'Error en la base de datos ' + str(resultado)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            respuesta = {}
            respuesta['result']='failed'
            respuesta['error']='Sucedio un error'
            respuesta['error_cod']=505
            respuesta['val_errors']=str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)
        finally:
            return respuesta

    def buscar_padres(self):
        resultado = self.__execute_buscar('buscar_padres_arbol_fisico')
        return resultado

    def buscar_hijos(self):
        resultado = self.__execute_buscar('buscar_hijos_arbol_fisico')
        return resultado

    def __execute_buscar(self, function):
        try:
            funct = function
            datos = [self.fis_id]
            resultado = self.clase_MyDB.execute_procedure(funct, datos)
            result_lista = []
            if resultado[0] == 'ok':
                if resultado[1] is not False:
                    for nodos in resultado[1]:
                        data = {}
                        data['padre'] = nodos[1]
                        data['hijo'] = nodos[0]
                        if nodos[1] != None :
                            result_lista.append(data)
                    respuesta = {}
                    respuesta['result'] = 'ok'
                    respuesta['listas'] = result_lista
                else:
                    respuesta = {}
                    respuesta['result'] = 'failed'
                    respuesta['error'] = 'Sucedio un error'
                    respuesta['cod'] = 501
                    respuesta['val_errors'] = 'No se obtuvo resultados'
            else:
                respuesta = {}
                respuesta['result'] = 'failed'
                respuesta['error'] = 'Sucedio un error'
                respuesta['cod'] = 502
                respuesta['val_errors'] = 'Error en la base de datos ' + str(resultado)
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            respuesta = {}
            respuesta['result']='failed'
            respuesta['error']='Sucedio un error'
            respuesta['error_cod']=503
            respuesta['val_errors']=str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)
        finally:
            return respuesta

    def buscar_hermanos(self):
        try:
            flag = False
            listas = []
            cad = {}
            cad["hijo"] = self.fis_id
            # listas.append("el hijo es "+str(self.id_obj_hijo))
            listas.append(cad)
            temp = self.fis_id
            query = 'SELECT (fis_id_padre) FROM "ARB_FISICO" WHERE fis_id = %s'
            datos = (temp,)
            respu3 = self.clase_MyDB.conectar(query,datos,True)
            if (respu3[0]=='ok' and respu3[1] != False ):
                cad = {}
                cad["padre"] = respu3[1][0][0]
                listas.append(cad)
                temp = respu3[1][0][0]
                query = 'SELECT (fis_id) FROM "ARB_FISICO" WHERE fis_id_padre = %s AND fis_id != %s'
                datos = (temp,self.fis_id)
                respu2 = self.clase_MyDB.conectar(query,datos,True)
                if (respu2[0]=='ok' ):
                    if (respu2[1]!=False):
                        cad = {}
                        temporal = []
                        for re in respu2[1] :
                            temporal.append(re[0])
                        cad["hermanos"] = temporal
                        listas.append(cad)
                        # listas = respu2[1]
                        respu = ['ok',' ']
                    else:
                        listas = "No tiene hermanos el Id seleccionado"
                        respu = ['ok','error']

                else:
                    listas = "Sucedio un error buscando a los hijos"
                    respu = ['ok','error']
            else:
                listas = "No existe un hijo con ese Id"
                respu = ['error','No existe un hijo con ese Id']

            if (respu[0] == 'ok'):
                lista = {}
                lista['result']='ok'#+str(respu)
                if (respu[1] == 'error'):
                    lista['error'] = listas
                else:
                    lista['listas'] = listas
            else:
                lista = {}
                lista['result']='failed'
                lista['error']='Sucedio un error'
                lista['error_cod']=505
                lista['val_errors']='Error '+ str(respu[1]) 
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            lista = {}
            lista['result']='failed'
            lista['error']='Sucedio un error'
            lista['error_cod']=505
            lista['val_errors']=str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)
        finally:
            return lista

    def borrar_foraneo(self): # elimina el objeto ARB_FISICO y asigna NULL al atributo id_obj_padre de sus hijos
        try:
            query= 'UPDATE "ARB_FISICO" SET fis_id_padre= NULL WHERE fis_id_padre = %s'
            datos=(self.fis_id,)
            respu = self.clase_MyDB.conectar(query,datos,False)

            query = 'DELETE FROM "ARB_FISICO" WHERE fis_id='+str(self.fis_id)
            datos=(self.fis_id,)
            respu = self.clase_MyDB.conectar(query,datos,False) 
            if (respu[0] == 'ok'):
                lista = {}
                lista['result']='ok'#+str(respu)
            else:
                lista = {}
                lista['result']='failed'
                lista['error']='Sucedio un error'
                lista['error_cod']=505
                lista['val_errors']='Error en la base de datos' 
        except Exception as e:
            lista = {}
            lista['result']='failed'
            lista['error']='Sucedio un error'
            lista['error_cod']=505
            lista['val_errors']=str(e)
        finally:
            return lista

    def consultar(self):
        print('consulta')

    @staticmethod
    def from_list(lista):
        arb_fisico = ARB_FISICO(
            fis_id=lista[0],
            fis_id_padre =lista[1],
            fis_desc=lista[2],
            fis_orden=lista[3]
        )
        return arb_fisico

    # Crea un objeto de ARB_FISICO a partir de un diccionario json, los datos del json
    # deben tener los mismos nombres que en la clase arb_fisico
    @staticmethod
    def from_json(json):
        arb_fisico = ARB_FISICO()
        diccio_arb_fisico = vars(arb_fisico)
        for key,value in json.items():
            if type(value) is str:
                if len(value) <= 0:
                    value = None
            diccio_arb_fisico[key] = value
        return arb_fisico
