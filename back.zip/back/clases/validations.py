import psycopg2
from MyDB import MyDB

def id_Mae_Obj_Con(obj_id,con_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(con_id) FROM "MAE_OBJETOS_CONSULTAS" WHERE con_id = %s and obj_id = %s '
		datos = (con_id,obj_id)
		version = clase_MyDB.conectar(query,datos,True)
		if(version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id
				dato = [True,' '] #'ok'
			else:
				dato = [False,'No existe el objeto - consultas seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato

#datatype validation
def validate_string(data):
	words  = str(data) 
	try:
		number = int(words)
		#print('Solo esta permitido cadenas y usted ha ingresado un numero')
		return [False ,'ha ingresado un numero']
	except ValueError:
		pass   

	lenght = len(data) 
	for i in range(lenght):
		try:
			character = int(words[i])
			#print('Todos los caracteres de la data deben ser letras y no numeros')
			return [False,'se encontro un numero como caracter']
		except ValueError:
		# print('todo ok con el caracter ')
			continue

	return [True,'ok']

def validate_varchar(data,maximum_length):
	words = str(data) 
	try:
		number = int(words)
		#print('Solo esta permitido cadenas y usted ha ingresado un numero')
		return [False ,'ha ingresado un numero']
	except ValueError:
		pass

	lenght = len(data) 
	if (lenght > maximum_length ):
		#print('La longitud de la entrada no debe ser mayor a {}'.format(maximum_length))
		return [False,'Sobrepaso longitud maxima de '+str(maximum_length)]

	return [True,'ok']
	
def validate_boolean(data):
	words=data
	
	try:
		number = int(words)
		#print('Solo esta permitido cadenas y usted ha ingresado un numero')
		if (number is 0 or number is 1):
			return [True ,'boolean']
		
		return [False ,'ha ingresado un numero']
	except ValueError:
		return [False ,'No es boolean'] 

def validate_int(data):
	try:
		number = int(data)  
		return [True,'ok']
	except ValueError:
		return [False,'ValueError en el int']
		#string= str(data)
		#if (len(string)==0):
		#	return [True,"ok"]
		#else:
		#	return[False,"No es doble comilla"]
		
def validate_char(data):
	words  = str(data) 
	try:
		number = int(words)
		#print('Solo esta permitido cadenas y usted ha ingresado un numero')
		return [False,'Ha ingresado un numero']
	except ValueError:
		pass   
		#print('La entrada {} no se pudo convertir a int'.format(words))

	#largo del input
	lenght = len(data) 
	if (lenght > 1):
		return [False,'Sobrepaso la longitud de 1']

	return [True,'ok']

def validate_date_time(data):
	fecha = str(data)
	try:
		int(fecha)
		return [False,'Ha ingresado un numero']
	except ValueError:
		pass
	#1999-01-08 04:05:06-8:00     #formato xxxx-xx-xx xx:xx:xx-x:xx 
	formato = "-- ::" # 
	a = fecha[4] + fecha[7] + fecha[10] + fecha[13] + fecha[16]
	#utc = fecha[19]
	if (a == formato) :#and (utc == "+" or utc == "-"):

		return [True,'ok']
	else:
		return [False,'Formato no valido']

def validate_numeric(num,size,decimal):
    try:
        num_str = str(num)
        float(num_str)
        if len(num_str) > (size+1):
            return [False,"Numero demasiado grande"]
        dot_pos = num_str.find('.')
        ent = num_str[:dot_pos]
        if len(ent) > (size-decimal):
            return [False,"Parte entera demasiado grande"]
        if dot_pos != -1:
            dec = num_str[dot_pos+1:]
            if len(dec) > decimal:
                return [False, "Parte decimal demasiado grande"]
        return [True,"ok"]
    except Exception:
        return [False,"No se ingreso un numero decimal"]

def validate_empty(data):
	string= str(data)
	if (len(string)==0):
		return [True,"Campo vacio"]
	else:
		return[False,"Campo no vacio"]


def id_Tipo_Usu(tusu_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(tusu_id) FROM "MAE_TIPO_USU" WHERE tusu_id = %s'
		datos = (tusu_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if (version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id 
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el tipo de usuario seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato 

def id_Mae_Usu(usu_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(usu_id) FROM "MAE_USUARIOS" WHERE usu_id = %s'
		datos = (usu_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if (version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id 
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el usuario seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'			
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato     

def id_Tipo_Obj(tobj_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(tobj_id) FROM "MAT_TIPO_OBJ" WHERE tobj_id = %s'
		datos = (tobj_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if (version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el tipo de objeto seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'			
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato 

def id_Consultas(con_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(con_id) FROM "MAE_CONSULTAS" WHERE con_id = %s'
		datos = (con_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if (version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el id_consultas seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'	
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato

def id_Mae_Obj(obj_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(obj_id) FROM "MAE_OBJETOS" WHERE obj_id = %s'
		datos = (obj_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0]=='ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo obj_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el objeto seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
		
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato


def id_Mae_Cron(cron_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(cron_id) FROM "MAE_CRON" WHERE cron_id = %s'
		datos = (cron_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if (version[0]=='ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id 
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el cron seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato     

def id_Tab_Rep(rep_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(rep_id) FROM "TAB_REPORTES" WHERE rep_id = %s'
		datos = (rep_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0] == 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id 
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el reporte seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato

def id_Tab_Eje (eje_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(eje_id) FROM "TAB_EJECUCIONES" WHERE eje_id = %s'
		datos = (eje_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0] == 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo eje_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe TAB_EJECUCIONES seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato

def id_Tab_Prot (prot_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(prot_id) FROM "TAB_PROTOCOLO" WHERE prot_id = %s'
		datos = (prot_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0] == 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo eje_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe TAB_PROTOCOLO seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato


def id_Tab_Menu (menu_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(menu_id) FROM "TAB_MENU" WHERE menu_id = %s'
		datos = (menu_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0] == 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo eje_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe TAB_MENU seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato

def id_Mae_Usu_Accesos_Reportes (urep_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(urep_id) FROM "MAE_USU_ACCESOS_REPORTES" WHERE urep_id = %s'
		datos = (urep_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if (version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id 
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el usuario accesos reportes seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'			
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato   


def id_Mae_Usu_Aler (rep_id,usu_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(rep_id) FROM "MAE_USUARIOS_ALERTAS" WHERE rep_id = %s AND usu_id = %s'
		datos = (rep_id,usu_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0]=='ok':
			if (version[1][0][0]!=0): #ya existe 
				dato = [True,'ok']
			else:
				dato = [False,'No existe MAE_USUARIOS_ALERTAS con esos id']
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)]
		
	except Exception as e:
		dato = [False,str(e)]
	finally:
		return dato

def id_Mae_Usu_Acc_Arb (uarb_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(uarb_id) FROM "MAE_USU_ACCESOS_ARBOLES" WHERE uarb_id = %s'
		datos = (uarb_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0]=='ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo uarb_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,"No existe MAE_USU_ACCESOS_ARBOLES seleccionado"] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato

def id_Arb_Fis (fis_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(fis_id) FROM "ARB_FISICO" WHERE fis_id = %s'
		datos = (fis_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0] == 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo uarb_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,"No existe fis_id seleccionado"] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato

def id_Arb_Log (log_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(log_id) FROM "ARB_LOGICO" WHERE log_id = %s'
		datos = (log_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if version[0]== 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo uarb_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,"No existe log_id seleccionado"] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato

def id_Mae_Area (area_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(area_id) FROM "MAE_AREA" WHERE area_id = %s'
		datos = (area_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if version[0]== 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo uarb_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,"No existe  el area seleccionado"] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato
def id_Mae_Idiomas (idi_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(idi_id) FROM "MAE_IDIOMAS" WHERE idi_id = %s'
		datos = (idi_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if version[0]== 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo uarb_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,"No existe  el idioma seleccionado"] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato

def id_Mae_Marcas (marca_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(marca_id) FROM "MAE_MARCAS" WHERE marca_id = %s'
		datos = (marca_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if version[0]== 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo uarb_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,"No existe la marca seleccionada"] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato

def id_Mae_Modelo (mod_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(mod_id) FROM "MAE_MODELO" WHERE mod_id = %s'
		datos = (mod_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if version[0]== 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo uarb_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,"No existe el modelo seleccionado"] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato

def id_Mae_Obj_Fis(obj_id,fis_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(obj_id) FROM "MAE_OBJETO_FISICO" WHERE obj_id = %s and fis_id = %s '
		datos = (obj_id,fis_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if(version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id
				dato = [True,' '] #'ok'
			else:
				dato = [False,'No existe el objeto - fisico seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato

def id_Mae_Obj_Log(obj_id,log_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(obj_id) FROM "MAE_OBJETO_LOGICO" WHERE obj_id = %s and log_id = %s '
		datos = (obj_id,log_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if(version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id
				dato = [True,' '] #'ok'
			else:
				dato = [False,'No existe el objeto - logico seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato

def id_Mae_Usu_Menu(umenu_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(umenu_id) FROM "MAE_USUARIOS_MENU" WHERE umenu_id = %s'
		datos = (umenu_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if (version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id 
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el MAE_USUARIOS_MENU seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'			
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
	finally:
		return dato

def validate_parametro(grupo,param_id):
	try:
		db = MyDB()
		query = 'SELECT COUNT(param_valor) FROM "PARAM" WHERE param_grupo =%s AND param_id = %s'
		datos = (grupo,param_id,)
		results = db.conectar(query,datos,True)
		if results[0] == 'ok':
			if results[1][0][0] > 0:
				dato = [True,'Existe Parametro']
			else:
				dato = [False,'No existe el parametro ingresado']
		else:
			dato = [False,'Error en la BD al buscar parametros']
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)]
	except Exception as e:
		dato = [False,str(e)]
	finally:
		return dato
	

class HttpException(Exception):
	def __init__(self,code,error=None,val_errors=None):
		self.result = "failed"
		self.code = code
		self.message = ""
		self.status_code = ""
		self.error = error
		self.val_errors = val_errors
		self.__get_message()

	def __get_message(self):
		if self.code == 401:
			self.message = "Unauthorized"
		elif self.code == 405:
			self.message = "Method Not Allowed"
		elif self.code == 500:
			self.message = "Internal Server Error"
		elif self.code == 400:
			self.message = "400 Bad Request"
		else:
			self.message = "Not a Http Status Code"
		self.status_code = str(self.code) + " " +self.message
		if self.error is None:
			self.error = self.message
		if self.val_errors is None:
			self.val_errors = self.message

	def get_error_dict(self):
		error_dict = {}
		error_dict.update(vars(self))
		error_dict.pop('status_code')
		error_dict.pop('message')
		return error_dict