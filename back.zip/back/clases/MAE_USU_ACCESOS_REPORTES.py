import psycopg2
import sys
from MAE_USUARIOS import MAE_USUARIOS
from TAB_REPORTES import TAB_REPORTES
from MAE_CRON import MAE_CRON
from MAT_TIPO_OBJ import MAT_TIPO_OBJ
from MAE_TIPO_USU import MAE_TIPO_USU
import logging
import datetime
import os
from MyDB import MyDB

class MAE_USU_ACCESOS_REPORTES:

	def __init__(self,rep_id=None,usu_id=None,urep_id=None,urep_estado = None):	
		self.urep_id = urep_id #serial
		self.rep_id = rep_id #integer
		self.usu_id = usu_id #integer
		self.urep_estado = urep_estado #boolean
		self.mae_usuarios = MAE_USUARIOS(usu_id = usu_id)
		self.tab_reportes = TAB_REPORTES(rep_id = rep_id)
		self.mae_usuarios.buscar_dato()
		self.tab_reportes.buscar_dato()
		self.clase_MyDB = MyDB()

	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		diccionario['usuario'] = {}
		diccionario['usuario'].update(self.mae_usuarios.get_diccionario())
		diccionario['reporte'] = {}
		diccionario['reporte'].update(self.tab_reportes.get_diccionario())
		diccionario['usuario'].pop('tipo_usuario')
		diccionario['usuario'].pop('idioma')
		diccionario['usuario'].pop('area')
		diccionario.pop('mae_usuarios')
		diccionario.pop('tab_reportes')
		diccionario.pop('clase_MyDB')
		return diccionario

	def guardar_dato(self):
		try:
			datos = (self.rep_id,self.usu_id)
			query= 'INSERT INTO "MAE_USU_ACCESOS_REPORTES" (rep_id,usu_id) VALUES (%s,%s) RETURNING urep_id'
			version = self.clase_MyDB.conectar(query,datos,False)

			if version[0] == 'ok':
				self.urep_id = version[1][0][0]#version[len(version)-1][0]
				dato = ['ok',' ']
			else:
				dato = ['error','Error en la base de datos']
		except Exception as e:
			dato = ['error',str(e)]
		finally:
			return dato

	def buscar_dato(self):
		dato = ['error','No puedo entrar al init']
		try:
			query='SELECT * FROM "MAE_USU_ACCESOS_REPORTES" WHERE urep_id = %s'
			datos=(self.urep_id,)
			version = self.clase_MyDB.conectar(query,datos,True)
			if (version[0] == 'ok'):
				dato = ['error','Entre al ok del select']
				if (version[1]!=False):
					self.rep_id = version[1][0][1] #integer
					self.usu_id = version[1][0][2] #integer
					self.urep_estado = version[1][0][3]
					self.mae_usuarios = MAE_USUARIOS(usu_id = self.usu_id)
					self.mae_usuarios.buscar_dato()
					self.tab_reportes = TAB_REPORTES(rep_id=self.rep_id)
					self.tab_reportes.buscar_dato()
					dato = ['ok',' ']
				else:
					dato=['error','No se encontro el USU_ACCESOS_REPORTES con ese ID']
			else:
				dato = ['error', 'Error con la base de datos']
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]				
			dato = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
		finally:
			return dato

	@staticmethod
	def consultar_lista():
		try:
			query='SELECT * FROM "MAE_USU_ACCESOS_REPORTES" ORDER BY urep_id'
			datos = ( )
			clase_MyDB = MyDB()  
			version = clase_MyDB.conectar(query,datos,True)
			if (version[0]=='ok'):
				lista = []
				for alertas in version[1]:
					data = {}
					obj_acc_rep = MAE_USU_ACCESOS_REPORTES.from_lista(alertas)
					data.update(obj_acc_rep.get_diccionario())
					lista.append(data)
			else:
				lista = {}
				lista['Error']='Error en la base de datos'
		except Exception as e:
			lista = {}
			lista['Error'] =str(e)
		finally:
			return lista

	def modificar(self):
		try:
			query = ('UPDATE "MAE_USU_ACCESOS_REPORTES" SET '
						'rep_id = COALESCE(%s,rep_id),'
						'usu_id = COALESCE(%s,usu_id) '
						'WHERE urep_id = %s')
			datos= (self.rep_id,self.usu_id,self.urep_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)
			if (respu[0]=='ok'):
				lista = ['ok',' ']
				self.mae_usuarios = MAE_USUARIOS(usu_id = self.usu_id)
				self.tab_reportes = TAB_REPORTES(rep_id = self.rep_id)
				self.mae_usuarios.buscar_dato()
				self.tab_reportes.buscar_dato()				
			else:
				lista = ['error','Error en la base de datos']
		except Exception as e:
			lista = ['error',str(e)]
		finally:
			return lista

	def borrar(self):
		try:
			query = 'DELETE FROM "MAE_USU_ACCESOS_REPORTES" WHERE urep_id= %s'
			datos=(self.urep_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)	
			if (respu[0] == 'ok'):
				lista = {}
				lista['result'] = 'ok'#+str(respu)
			else:
				lista = {}
				lista['result']='failed'
				lista['error']='Sucedio un error'
				lista['error_cod']=505
				lista['val_errors']='Error en la base de datos'
		except Exception as e:
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)
		finally:
			return lista

	def editar_accesos(self,rep_ids):
		new_usu = not self.__verificar_usu_id()
		if new_usu is True:
			response = self.__insert_lista(rep_ids)
		else:
			response = self.__editar(rep_ids)
		return response

	def __verificar_usu_id(self):
		try:
			query = 'SELECT COUNT(usu_id) FROM "MAE_USU_ACCESOS_REPORTES" WHERE usu_id = %s'
			datos = (self.usu_id,)
			version = self.clase_MyDB.conectar(query,datos,True)
			if version[0]=='ok':
				if (version[1][0][0]!=0): #ya existe 
					dato = True
				else:
					dato = False
			else:
				dato = False #'error'
		except Exception:
			dato = False
		finally:
			return dato

	def __insert_lista(self,rep_ids):
		try:
			responses = []
			for rep in rep_ids:
				query_insert = ('INSERT INTO "MAE_USU_ACCESOS_REPORTES" (usu_id,rep_id) VALUES (%s,%s)')
				datos = (self.usu_id,rep,)
				result = self.clase_MyDB.conectar(query_insert,datos,False)
				if result[0] == 'ok':
					responses.append(['ok','Se insertaron nuevos accesos a reportes'])
				else:
					responses.append(['error','Error al insertar lista de reporte '+str(rep)])
			response = ['ok','Se insertaron nuevos accesos a reportes']
			for resp in responses:
				if resp[0] != 'ok':
					response = ['error',resp[1]]
					break
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			response = ["error",str(e)+" - "+ str(exc_type)+" - "+ str(fname)+" - "+ str(exc_tb.tb_lineno)]
		finally:
			return response

	def __editar(self,rep_ids):
		try:
			query_get_datos = ('select rep_id,urep_estado from  "MAE_USU_ACCESOS_REPORTES" where usu_id = %s and rep_id in %s')
			data_select = (self.usu_id,tuple(rep_ids),)
			resultado = self.clase_MyDB.conectar(query_get_datos,data_select,True)
			results_querys = []
			if resultado[0] == 'ok':
				if resultado[1] != False:
					list_results = resultado[1]
					list_not_new = []
					dictio_estado = {}
					for res in list_results:
						list_not_new.append(res[0])
						dictio_estado[res[0]] = res[1]
					for rep in rep_ids:
						if rep not in list_not_new:
							query_insert = ('INSERT INTO "MAE_USU_ACCESOS_REPORTES" (usu_id,rep_id) VALUES (%s,%s) RETURNING usu_id')
							dato_insert = (self.usu_id,rep,)
							result_insert = self.clase_MyDB.conectar(query_insert,dato_insert,False)
							results_querys.append(result_insert)
						else:
							query_update = ('UPDATE "MAE_USU_ACCESOS_REPORTES" set urep_estado = %s WHERE usu_id = %s AND rep_id = %s')
							new_estado = not bool(dictio_estado[rep])
							datos_update = (new_estado,self.usu_id,rep)
							result_update = self.clase_MyDB.conectar(query_update,datos_update,False)
							results_querys.append(result_update)
					response = ['ok','No hay errores']
					for results in results_querys:
						if results[0] != 'ok':
							response = ['error','Error al ejecutar queries']
							break
				else:
					response = ['error','No se encontraron accesos con estos datos']
			else:
				response = ['error','Error en la base de datos']
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			response = ["error",str(e)+" - "+ str(exc_type)+" - "+ str(fname)+" - "+ str(exc_tb.tb_lineno)]
		finally:
			return response


	@staticmethod
	def listar_accesos_reportes(usu_id):
		try:
			db = MyDB()
			query = ('SELECT * FROM "MAE_USU_ACCESOS_REPORTES" WHERE usu_id = %s and urep_estado = true')
			datos = (usu_id,)
			resultados = db.conectar(query,datos,True)
			if resultados[0] == 'ok':
				lista_rep = []
				if resultados[1] is not False:
					for acceso in resultados[1]:
						data = {}
						obj_acc = MAE_USU_ACCESOS_REPORTES.from_lista(acceso)
						data.update(obj_acc.get_diccionario())
						lista_rep.append(data)
					lista = {}
					lista['result'] = 'ok'
					lista['listas'] = lista_rep
				else:
					lista = {}
					lista['result'] = 'failed'
					lista['val_errors'] = 'No se encontraron reportes de ese usuario'
			else:
				lista = {}
				lista['result'] = 'failed'
				lista['val_errors'] = 'Error al obtener reportes de usuario' + str(resultados)
		except Exception as e:
			lista = {}
			lista['result'] = 'failed'
			lista['val_errors'] = str(e)
		finally:
			return lista


	def consultar(self):
		print('consulta')

	@staticmethod
	def from_lista(lista):
		acc_rep = MAE_USU_ACCESOS_REPORTES(
			urep_id=lista[0],
			rep_id=lista[1],
			usu_id=lista[2],
			urep_estado=lista[3]
		)
		return acc_rep

	@staticmethod
	def from_json(json):
		acc_rep = MAE_USU_ACCESOS_REPORTES()
		diccio = vars(acc_rep)
		for key,value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			diccio[key] = value
		return acc_rep


