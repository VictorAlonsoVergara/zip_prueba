import psycopg2
import sys
from MAE_USUARIOS import MAE_USUARIOS
from TAB_REPORTES import TAB_REPORTES
from MAE_CRON import MAE_CRON
from MAT_TIPO_OBJ import MAT_TIPO_OBJ
from MAE_TIPO_USU import MAE_TIPO_USU
import logging
import datetime
import os
from MyDB import MyDB
class MAE_USUARIOS_ALERTAS :

	def __init__(self,rep_id=None,usu_id=None):
		self.rep_id = rep_id #integer
		self.usu_id = usu_id #integer
		self.mae_usuarios = MAE_USUARIOS(usu_id=usu_id)
		self.tab_reportes = TAB_REPORTES(rep_id=rep_id)
		self.mae_usuarios.buscar_dato() 
		self.tab_reportes.buscar_dato()
		self.clase_MyDB = MyDB()  

	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		diccionario['usuario'] = {}
		diccionario['usuario'].update(self.mae_usuarios.get_diccionario())
		diccionario['reporte'] = {}
		diccionario['reporte'].update(self.tab_reportes.get_diccionario())
		diccionario.pop('clase_MyDB')
		diccionario.pop('mae_usuarios')
		diccionario.pop('tab_reportes')
		return diccionario
		
		
	def guardar_dato(self):
		try:
			datos = (self.rep_id,self.usu_id,)
			query='INSERT INTO "MAE_USUARIOS_ALERTAS" (rep_id,usu_id) VALUES (%s,%s)'
			version = self.clase_MyDB.conectar(query,datos,False)
			if version[0] == 'ok':
				dato = ['ok',' ']
			else:
				dato = ['error','Error en la base de datos']
		except Exception as e:
			dato = ['error',str(e)]
		finally:
			return dato

	def buscar_dato(self):
		try:
			query='SELECT * FROM "MAE_USUARIOS_ALERTAS" WHERE rep_id = %s AND usu_id = %s'
			datos=(self.rep_id,self.usu_id,)
			version = self.clase_MyDB.conectar(query,datos,True)
			if (version[0] == 'ok'):
				if (version[1] != False):
					self.mae_usuarios = MAE_USUARIOS(usu_id=self.usu_id)
					self.mae_usuarios.buscar_dato()
					self.tab_reportes = TAB_REPORTES(rep_id=self.rep_id)
					self.tab_reportes.buscar_dato()
					dato = ['ok',' ']
				else:
					dato = ['error', 'No se encontro el usuario_alertas con esos ID']
			else:
				dato = ['error', 'Error con la base de datos']
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]				
			dato = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
		finally:
			return dato
	
	@staticmethod
	def validations_crear(rep_id,usu_id):
		try:
			query='SELECT * FROM "MAE_USUARIOS_ALERTAS" WHERE rep_id =%s AND usu_id = %s'
			datos=(rep_id,usu_id,)
			clase_MyDB = MyDB()  
			version = clase_MyDB.conectar(query,datos,True)
			if (version[0] == 'ok'):
				if (version[1]!=False): #ya existe 
					dato = [False,'ya existe MAE_USUARIOS_ALERTAS con esos ID']
				else:
					dato = [True,'ok']
			else:
				dato = ['error', 'Error con la base de datos']
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]				
			dato = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
		finally:
			return dato


	@staticmethod
	def consultar_lista():
		try:
			query='SELECT * FROM "MAE_USUARIOS_ALERTAS"'
			datos = ( )
			clase_MyDB = MyDB()  
			version = clase_MyDB.conectar(query,datos,True)
			if (version[0]=='ok'):
				if (version[1]!=False):
					lista = []
					for alertas in version[1]:
						data = {}
						usu_aler = MAE_USUARIOS_ALERTAS.from_list(alertas)
						data.update(usu_aler.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista['MAE_USUARIOS_ALERTAS']='Lista vacia'
			else:
				lista = {}
				lista['Error']='Error en la base de datos'
		except Exception as e:
			lista = {}
			lista['Error'] =str(e)
		finally:
			return lista

	def modificar(self,rep_id,usu_id):  
		try:
			query = 'UPDATE "MAE_USUARIOS_ALERTAS" SET rep_id = %s , usu_id = %s WHERE usu_id = %s and rep_id= %s'
			datos=(rep_id,usu_id,self.usu_id,self.rep_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)
			if (respu[0]=='ok'):
				lista = ['ok',' ']
				self.rep_id = rep_id
				self.usu_id = usu_id				
				self.mae_usuarios = MAE_USUARIOS(usu_id=usu_id)
				self.tab_reportes = TAB_REPORTES(rep_id=rep_id)
				self.mae_usuarios.buscar_dato() 
				self.tab_reportes.buscar_dato()				
			else:
				lista = ['error','Error en la base de datos']
		except Exception as e:
			lista = ['error',str(e)]
		finally:
			return lista

	def borrar(self):
		try:
			query = 'DELETE FROM "MAE_USUARIOS_ALERTAS" WHERE rep_id = %s AND usu_id = %s'
			datos= (self.rep_id,self.usu_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)	
			if (respu[0] == 'ok'):
				lista = {}
				lista['result']='ok'#+str(respu)
			else:
				lista = {}
				lista['result']='failed'
				lista['error']='Sucedio un error'
				lista['error_cod']=505
				lista['val_errors']='Error en la base de datos'	
		except Exception as e:
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)
		finally:
			return lista

	def consultar(self):
		print('consulta')

	@staticmethod
	def from_list(lista):
		usu_aler = MAE_USUARIOS_ALERTAS(
			rep_id = lista[0],
			usu_id = lista[1]
		)
		return usu_aler

	@staticmethod
	def from_json(json):
		usu_aler = MAE_USUARIOS_ALERTAS()
		diccio = vars(usu_aler)
		for key,value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			diccio[key] = value
		return usu_aler

	