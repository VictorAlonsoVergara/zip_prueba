import psycopg2
import sys,os
from MAT_TIPO_OBJ import MAT_TIPO_OBJ
from TAB_PROTOCOLO import TAB_PROTOCOLO
from MAE_MARCAS import MAE_MARCAS
from MAE_MODELO import MAE_MODELO
import logging
import datetime
from MyDB import MyDB #2 espacios


class MAE_OBJETOS:
    def __init__(self, obj_id=None,obj_desc=None, tobj_id=None,
                    obj_estado=None, obj_ldesc=None,
                    obj_latitud = None, obj_longitud=None,
                    obj_ip_address = None,
                    prot_id = None,marca_id=None,
                    obj_firmware =None,obj_hardware = None,
                    fch_creacion=None,fch_actualizacion=None,
                    fch_inscripcion=None,obj_usuario=None,
                    obj_password=None,mod_id=None,obj_respuesta=None,obj_respuesta_flag=None):
        self.obj_id = obj_id  # serial
        self.obj_desc = obj_desc  # varchar(200)
        self.tobj_id = tobj_id  # integer
        self.obj_estado = obj_estado  # char(1)
        self.obj_ldesc = obj_ldesc  # text
        self.obj_latitud = obj_latitud #numeric (11,8)
        self.obj_longitud = obj_longitud #numeric (11,8)
        self.obj_ip_address = obj_ip_address #varchar(16)
        self.prot_id = prot_id #integer
        self.marca_id = marca_id #integer
        self.obj_firmware = obj_firmware #varchar(100)
        self.obj_hardware = obj_hardware #varchar(100)
        self.fch_creacion = fch_creacion #timestamp
        self.fch_actualizacion = fch_actualizacion #timestamp
        self.fch_inscripcion = fch_inscripcion #timestamp
        self.obj_usuario = obj_usuario #varchar(50)
        self.obj_password = obj_password #varchar(50)
        self.mod_id = mod_id #integer
        self.obj_respuesta = obj_respuesta #varchar(500)
        self.obj_respuesta_flag = obj_respuesta_flag #boolean
        self.mae_marca = MAE_MARCAS(marca_id = marca_id)
        self.tab_protocolo = TAB_PROTOCOLO(prot_id = prot_id)
        self.mat_tipo_obj = MAT_TIPO_OBJ(tobj_id=tobj_id)
        self.mae_modelo = MAE_MODELO(mod_id=mod_id)
        self.mat_tipo_obj.buscar_dato()
        self.tab_protocolo.buscar_dato()
        self.mat_tipo_obj.buscar_dato()
        self.mae_modelo.buscar_dato()
        # si bSelect es False delete ,update ,insert si es True select
        self.clase_MyDB = MyDB()

    #metodo para obtener un diccionario a partir de los atributos de la clase
    def get_diccionario(self):
        diccionario = {} #incializo el diccionario
        diccionario.update(vars(self)) #actualizo el diccionario con los valores de la clase ejem(obj_id,obj_desc,etc)
        if self.obj_latitud is not None:
            diccionario['obj_latitud'] = float(self.obj_latitud) #convierto a float para que pueda convertirlo a JSON
        if self.obj_longitud is not None:
            diccionario['obj_longitud'] = float(self.obj_longitud)#convierto a float para que pueda convertirlo a JSON
        if self.fch_creacion is not None:
            diccionario['fch_creacion'] = self.fch_creacion.strftime("%Y-%m-%d %H:%M:%S")#convierto a string para que pueda convertirlo a JSON
        if self.fch_actualizacion is not None:
            diccionario['fch_actualizacion'] = self.fch_actualizacion.strftime("%Y-%m-%d %H:%M:%S")#convierto a string para que pueda convertirlo a JSON
        if self.fch_inscripcion is not None:
            diccionario['fch_actualizacion'] = self.fch_inscripcion.strftime("%Y-%m-%d %H:%M:%S")#convierto a string para que pueda convertirlo a JSON
        diccionario['tipo_obj'] = {} #inicio el diccionario de tipo de objeto
        diccionario['tipo_obj'].update(self.mat_tipo_obj.get_diccionario())#obtengo los valores del tipo de objeto
        diccionario['protocolo'] = {}#inicio el diccionario del protocolo
        diccionario['protocolo'].update(self.tab_protocolo.get_diccionario())#obtengo los valores del protocolo
        diccionario['marca'] = {}#inicio el diccionario de marca
        diccionario['marca'].update(self.mae_marca.get_diccionario())#obtengo los valores de marca
        diccionario['modelo'] = {}#incio el diccionario de modelo
        diccionario['modelo'].update(self.mae_modelo.get_diccionario())#obtengo los valores de modelo
        diccionario['modelo'].pop('tipo_obj')#quito el diccionario tipo_obj que viene dentro de la clase modelo
        diccionario['modelo'].pop('marca')#quito el diccionario marca que viene dentro de la clase modelo
        diccionario.pop('mae_marca')#quito la clase mae_marca del diccionario para no mandarlo al JSON
        diccionario.pop('tab_protocolo')#quito la clase tab_protocolo del diccionario para no mandarlo al JSON
        diccionario.pop('mae_modelo')#quito la clase mae_modelo del diccionario para no mandarlo al JSON
        diccionario.pop('mat_tipo_obj')#quito la clase mat_tipo_obj del diccionario para no mandarlo al JSON
        diccionario.pop('clase_MyDB')#quito la clase clase_MyDB del diccionario para no mandarlo al JSON
        return diccionario #devuelvo el diccionario

    #Metodo para obtener la tupla que se usara en el metodo guardar
    def __get_insert_tuple(self):
        return (self.obj_desc, self.tobj_id,
                self.obj_estado, self.obj_ldesc,
                self.obj_latitud,self.obj_longitud,
                self.obj_ip_address,self.prot_id,
                self.marca_id,self.obj_firmware,
                self.obj_hardware,self.obj_usuario,
                self.obj_password,self.mod_id,self.obj_respuesta,
                self.obj_respuesta_flag)
    
    #Metodo para obtener la tupla que se usara en el metodo modificar
    def __get_update_tuple(self):
        return (self.obj_desc, self.tobj_id,
                self.obj_estado, self.obj_ldesc,
                self.obj_latitud,self.obj_longitud,
                self.obj_ip_address,self.prot_id,
                self.marca_id,self.obj_firmware,
                self.obj_hardware,None,
                datetime.datetime.now(),None,
                self.obj_usuario,self.obj_password,
                self.mod_id,self.obj_respuesta,
                self.obj_respuesta_flag,self.obj_id)

    #metodo para obtener la tupla que se usara en el metodo buscar_lista
    def __get_params_tuple(self):
        return (self.obj_desc, self.tobj_id,
                self.obj_estado, self.obj_ldesc,
                self.obj_latitud,self.obj_longitud,
                self.obj_ip_address,self.prot_id,
                self.marca_id,self.obj_firmware,
                self.obj_hardware,self.fch_creacion,
                self.fch_actualizacion,self.fch_inscripcion,
                self.obj_usuario,self.obj_password,
                self.mod_id,self.obj_respuesta,self.obj_respuesta_flag)

    #Metodo para guardar un objeto en la base de datos con los atributos de la clase
    def guardar_dato(self):
        try:
            query = ('INSERT INTO "MAE_OBJETOS" ('
                        'obj_desc, tobj_id,'
                        'obj_estado, obj_ldesc,'
                        'obj_latitud,obj_longitud,'
                        'obj_ip_address,prot_id,'
                        'marca_id,obj_firmware,'
                        'obj_hardware,obj_usuario,'
                        'obj_password,mod_id,obj_respuesta,'
                        'obj_respuesta_flag) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING obj_id')
            datos = self.__get_insert_tuple()
            version = self.clase_MyDB.conectar(query, datos, False)
            if (version[0]) == "ok":
                self.obj_id = version[1][0][0]  # version[len(version) - 1][0]
                dato = ["ok", ""]
            else:
                dato = ["error", "Error en la base de datos"]
        except psycopg2.DatabaseError as e:
            dato = ["error", str(e)]
            logging.error(
                str(datetime.datetime.today())
                + "sucedio un error guardando en la tabla MAE_OBJETOS"
            )

        except Exception as e:
            print(str(e))
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            dato = [
                "error",
                str(e)
                + " - "
                + str(exc_type)
                + " - "
                + str(fname)
                + " - "
                + str(exc_tb.tb_lineno)
                + "vlll"
                + str(version),
            ]
            print(exc_type, fname, exc_tb.tb_lineno)
            logging.error(
                str(datetime.datetime.today())
                + "sucedio un error guardando en la tabla MAE_OBJETOS"
            )
        finally:
            return dato
    
    #Metodo para buscar un dato especifico en base al obj_id
    def buscar_dato(self):
        try:
            query = """SELECT * FROM "MAE_OBJETOS" WHERE obj_id = %s AND obj_estado= 'A'"""
            datos = (self.obj_id,)
            version = self.clase_MyDB.conectar(query, datos, True)

            if version[0] == "ok":
                if version[1] != False:
                    self.obj_desc = version[1][0][1]  # varchar(200)
                    self.tobj_id = version[1][0][2]  # integer
                    self.obj_estado = version[1][0][3]  # char(1)
                    self.obj_ldesc = version[1][0][4]  # text
                    self.obj_latitud = version[1][0][5] #numeric (11,8)
                    self.obj_longitud = version[1][0][6] #numeric (11,8)
                    self.obj_ip_address = version[1][0][7] #varchar(16)
                    self.marca_id = version[1][0][8] #integer                    
                    self.prot_id = version[1][0][9] #integer                    
                    self.obj_firmware = version[1][0][10] #varchar(100)
                    self.obj_hardware = version[1][0][11] #varchar(100)
                    self.fch_creacion = version[1][0][12] #timestamp
                    self.fch_actualizacion = version[1][0][13] #timestamp
                    self.fch_inscripcion = version[1][0][14] #timestamp
                    self.obj_usuario = version[1][0][15] #varchar(50)
                    self.obj_password = version[1][0][16] #varchar(50)
                    self.mod_id = version[1][0][17] #integer
                    self.obj_respuesta = version[1][0][18] #varchar(500)
                    self.obj_respuesta_flag = version[1][0][19] #varchar(500)

                    self.mat_tipo_obj = MAT_TIPO_OBJ(tobj_id = self.tobj_id)
                    self.mat_tipo_obj.buscar_dato()
                    self.mae_marca = MAE_MARCAS(marca_id=self.marca_id)
                    self.mae_marca.buscar_dato()
                    self.tab_protocolo = TAB_PROTOCOLO(prot_id=self.prot_id)
                    self.tab_protocolo.buscar_dato()
                    self.mae_modelo = MAE_MODELO(mod_id=self.mod_id)
                    self.mae_modelo.buscar_dato()

                    dato = ["ok", ""]
                else:
                    dato = ["error", "No se encontro el objeto con ese ID"]
            else:
                dato = ["error", "Error con la base de datos"]

        except psycopg2.DatabaseError as e:
            dato = ["error", str(e)]
        except Exception as e:
            dato = ["error", str(e)]
        finally:
            return dato
    
    #Metodo para consultar todos los objetos y devolver una lista con todos
    @staticmethod
    def consultar_lista():
        try:
            query = """SELECT * FROM "MAE_OBJETOS" WHERE obj_estado='A' ORDER BY obj_id"""
            datos = ()
            clase_MyDB = MyDB()
            version = clase_MyDB.conectar(query, datos, True)

            if version[0] == "ok":
                lista = []
                for obj in version[1]:
                    objeto = MAE_OBJETOS.from_list(obj)
                    #lista.append(MAE_OBJETOS.dict_from_lista(obj))
                    objeto.buscar_dato()
                    lista.append(objeto.get_diccionario())
            else:
                lista = {}
                lista["Error"] = "Error en la base de datos"+str(version)
        except psycopg2.DatabaseError as e:
            lista = {}
            lista["Error"] = "1"
            print(f"Error {e}")
        except Exception as e:
            lista = {}
            lista["Error"] = e
            print(e)
        finally:
            return lista

    #Metodo que modifica un objeto con obj_id, los valores en None no seran modificados
    def modificar(self):
        try:
            
            query = ('UPDATE "MAE_OBJETOS" SET obj_desc = COALESCE(%s,obj_desc),'
                    'tobj_id = COALESCE(%s,tobj_id), obj_estado = COALESCE(%s,obj_estado),'
                    'obj_ldesc = COALESCE(%s,obj_ldesc), obj_latitud= COALESCE(%s,obj_latitud),'
                    'obj_longitud = COALESCE(%s,obj_longitud),obj_ip_address= COALESCE(%s,obj_ip_address),'
                    'prot_id = COALESCE(%s,prot_id), marca_id= COALESCE(%s,marca_id),'
                    'obj_firmware = COALESCE(%s,obj_firmware),obj_hardware = COALESCE(%s,obj_hardware),'
                    'fch_creacion = COALESCE(%s,fch_creacion),fch_actualizacion = COALESCE(%s,fch_actualizacion),'
                    'fch_inscripcion = COALESCE(%s,fch_inscripcion),obj_usuario = COALESCE(%s,obj_usuario),'
                    'obj_password = COALESCE(%s,obj_password),mod_id = COALESCE(%s,mod_id),'
                    'obj_respuesta = COALESCE(%s,obj_respuesta),obj_respuesta_flag = COALESCE(%s,obj_respuesta_flag)'
                    'WHERE obj_id = %s')
            datos = self.__get_update_tuple()
            respu = self.clase_MyDB.conectar(query, datos, False)

            if respu[0] == "ok":
                lista = ["ok", " "]
                self.mae_marca = MAE_MARCAS(marca_id = self.marca_id)
                self.tab_protocolo = TAB_PROTOCOLO(prot_id = self.prot_id)
                self.mat_tipo_obj = MAT_TIPO_OBJ(tobj_id=self.tobj_id)
                self.mae_modelo = MAE_MODELO(mod_id=self.mod_id)
                self.mat_tipo_obj.buscar_dato()
                self.tab_protocolo.buscar_dato()
                self.mat_tipo_obj.buscar_dato()
                self.mae_modelo.buscar_dato()
            else:
                lista = ["error", "Error en la base de datos"]
        except psycopg2.DatabaseError as e:
            lista = ["error", str(e)]

        except Exception as e:
            print(str(e))
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]

            lista = [
                "error",
                str(e)
                + " - "
                + str(exc_type)
                + " - "
                + str(fname)
                + " - "
                + str(exc_tb.tb_lineno),
                self.tobj_id,
            ]
        else:
            lista = ["ok", ""]
        finally:
            return lista

    #Metodo para borrar un elemento de la base de datos a partir de un obj_id
    def borrar(self):
        try:
            query = 'DELETE FROM "MAE_OBJETOS" WHERE obj_id= %s'
            datos = (self.obj_id,)
            respu = self.clase_MyDB.conectar(query, datos, False)
            if respu[0] == "ok":
                lista = {}
                lista["result"] = "ok"
            else:
                lista = {}
                lista["result"] = "failed"
                lista["error"] = "Sucedio un error"
                lista["error_cod"] = 505
                lista["val_errors"] = "Error en la base de datos"
        except psycopg2.DatabaseError as e:
            lista = {}
            lista["result"] = "failed"
            lista["error"] = "Sucedio un error"
            lista["error_cod"] = 505
            lista["val_errors"] = str(e)

        except Exception as e:
            lista = {}
            lista["result"] = "failed"
            lista["error"] = "Sucedio un error"
            lista["error_cod"] = 505
            lista["val_errors"] = str(e)
        else:
            lista = {}
            lista["result"] = "ok"
        finally:
            return lista

    def consultar(self):
        print("consulta")
    
    #Metodo para buscar una lista de objetos a partir de cualquier parametro que
    # se pase al objeto
    def buscar_lista(self):
        try:
            query = ('SELECT * FROM "MAE_OBJETOS" WHERE (obj_desc = COALESCE(%s,obj_desc) OR obj_desc is NULL) '
                        'AND (tobj_id = COALESCE(%s,tobj_id) OR tobj_id is NULL) '
                        'AND (obj_estado = COALESCE(%s,obj_estado) OR obj_estado is NULL) '
                        'AND (obj_ldesc = COALESCE(%s,obj_ldesc) OR obj_ldesc is NULL) '
                        'AND (obj_latitud = COALESCE(%s,obj_latitud) OR obj_latitud is NULL) '
                        'AND (obj_longitud = COALESCE(%s,obj_longitud) OR obj_longitud is NULL) '
                        'AND (obj_ip_address = COALESCE(%s,obj_ip_address) OR obj_ip_address is NULL) '
                        'AND (marca_id = COALESCE(%s,marca_id) OR marca_id is NULL)'
                        'AND (prot_id = COALESCE(%s,prot_id) OR prot_id is NULL) '
                        'AND (obj_firmware = COALESCE(%s,obj_firmware) OR obj_firmware is NULL)'
                        'AND (obj_hardware = COALESCE(%s,obj_hardware) OR obj_hardware is NULL)'
                        'AND (fch_creacion = COALESCE(%s,fch_creacion) OR fch_creacion is NULL)'
                        'AND (fch_actualizacion = COALESCE(%s,fch_actualizacion) OR fch_actualizacion is NULL)'
                        'AND (fch_inscripcion = COALESCE(%s,fch_inscripcion) OR fch_inscripcion is NULL)'
                        'AND (obj_usuario = COALESCE(%s,obj_usuario) OR obj_usuario is NULL)'
                        'AND (obj_password = COALESCE(%s,obj_password) OR obj_password is NULL)'
                        'AND (mod_id = COALESCE(%s,mod_id) OR mod_id is NULL)'
                        'AND (obj_respuesta = COALESCE(%s,obj_respuesta) OR obj_respuesta is NULL)'
                        'AND (obj_respuesta_flag = COALESCE(%s,obj_respuesta_flag) OR obj_respuesta_flag is NULL)')
            datos = self.__get_params_tuple()
            resultados = self.clase_MyDB.conectar(query,datos,True)
            if resultados[0] == "ok":
                lista = []
                for obj in resultados[1]:
                    objeto = MAE_OBJETOS.from_list(obj)
                    #lista.append(MAE_OBJETOS.dict_from_lista(obj))
                    lista.append(objeto.get_diccionario())
                else:
                    lista = {}
                    lista["Error"] = "Error en la base de datos"+str(resultados)
        except psycopg2.DatabaseError as e:
            lista = {}
            lista["Error"] = "1"
            print(f"Error {e}")
        except Exception as e:
            lista = {}
            lista["Error"] = "2"
            print(e)
        finally:
            return lista 

    #El metodo crea un objeto a partir de una lista mandada por la base de datos
    @staticmethod
    def from_list(lista):
        objeto = MAE_OBJETOS(
            obj_id = lista[0],
            obj_desc = lista[1],
            tobj_id = lista[2],
            obj_estado = lista[3],
            obj_ldesc = lista[4],
            obj_latitud = lista[5],
            obj_longitud = lista[6],
            obj_ip_address = lista[7],
            marca_id = lista[8],
            prot_id = lista[9],
            obj_firmware = lista[10],
            obj_hardware = lista[11],
            fch_creacion = lista[12],
            fch_actualizacion = lista[13],
            fch_inscripcion = lista[14],
            obj_usuario = lista[15],
            obj_password = lista[16],
            mod_id = lista[17],
            obj_respuesta = lista[18],
            obj_respuesta_flag = lista[19]
        )
        return objeto

    #Crea un objeto de MAE_OBJETOS a partir de un diccionario json, los datos del json
    #deben tener los mismos nombres que en la clase objeto
    @staticmethod
    def from_json(json):
        objeto = MAE_OBJETOS()
        diccio_objeto = vars(objeto)
        for key,value in json.items():
            if type(value) is str:
                if len(value) <= 0:
                    value = None
            diccio_objeto[key] = value
        return objeto
