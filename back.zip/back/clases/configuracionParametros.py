import datetime
import os
import logging
import sys
import time

try:
	variable = os.listdir(os.getcwd())
	std = 0
	for var in variable :
		if(var == '/home/sistema/clases/parametros.txt'):
			std = std + 1

	if (std == 0):
		f= open("/home/sistema/clases/parametros.txt","w+")
		f.write("COMENTARIO: Escoje el tipo de separador el cual estara entre los datos->(#)  No cambiar el orden de los parametros\n")
		f.write("1 nombre base de datos:	#cotener#\n")
		f.write("2 usuario base de datos:	#cotener#\n")
		f.write("3 clave base de datos:		#cotener#\n")
		f.close()

except Exception as e:
	pass
	
except :
	pass

def captarSeparador():
	f = open("/home/sistema/clases/parametros.txt","r")
	if f.mode == "r":
		contents = f.read()
		partes = contents.split('\n')
	f.close
	numI = partes[0].find("(")
	numF = partes[0].find(")")
	return partes[0][numI+1:numF]

def captarDatos(num):
	try:
		int_numero = (num*2)

		f = open("/home/sistema/clases/parametros.txt","r")
		if f.mode == "r":
			contents = f.read()
			#print "captar datos $$$$$$$$$$$"
			separador = captarSeparador()
			#print separador
			partes = contents.split(separador)
		f.close
		string = partes[int_numero]

	except Exception as e:
		string = 'Error404'
	finally:
		return string

def buscarDatoxLinea(numero_de_linea,string):
	try:
		f = open("/home/sistema/clases/parametros.txt","r")
		if f.mode == "r":
			contents = f.read()
			partes = contents.split('\n')
		f.close
		cadena = partes[numero_de_linea]
		indice = cadena.find(string)
		indice2 = cadena.find(str(numero_de_linea))
		devol = 'ok'	
		if(indice == -1):
			devol = 'hay un error'
		elif (indice2 == -1):
			devol = 'hay un error'
		return devol
	except :
		devol = 'hay un error'
		return devol

def NombreDataBase():
	try:
		msg = captarDatos(1)
		feedback = buscarDatoxLinea(1,msg)
		if (feedback == 'hay un error'):
			msg= "Error404"
			#raise Exception('error', 'error')
	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]		
		msg = 'Error404'+' '+str(exc_type)+" "+str(fname)+" "+str(exc_tb.tb_lineno)
	except :
		msg = 'Error404'
	finally:
		return msg

def UsuarioDataBase():
	try:
		msg = captarDatos(2)
		feedback = buscarDatoxLinea(2,msg)
		if (feedback == 'hay un error'):
			msg= "Error404"
			#raise Exception('error', 'error')
	except Exception as e:
		msg = 'Error404'
	except :
		msg = 'Error404'
	finally:
		return msg

def ClaveDataBase():
	try:
		msg = captarDatos(3)
		feedback = buscarDatoxLinea(3,msg)
		if (feedback == 'hay un error'):
			msg= "Error404"
			#raise Exception('error', 'error')
	except Exception as e:
		msg = 'Error404'
	except :
		msg = 'Error404'
	finally:
		return msg


def comprobarDatos():
	try:
		lista = []
		lista.append(NombreDataBase())
		lista.append(UsuarioDataBase())
		lista.append(ClaveDataBase())
		
		flag = 'no hay problema'
		i=0
		for cosa in lista :
			i=i+1
			if (cosa == 'Error404'):
				print(i)
				flag = 'hay problema'
				break
	except :
		flag = 'hay problema'
	finally:
		return flag