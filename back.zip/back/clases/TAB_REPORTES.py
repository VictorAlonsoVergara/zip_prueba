import psycopg2
import sys
from MAE_CRON import MAE_CRON
from MAT_TIPO_OBJ import MAT_TIPO_OBJ
import logging
import datetime
import os 
from MyDB import MyDB

#clase que gestiona la tabla reportes
class TAB_REPORTES :
	#se inicializa
	def __init__(
		self,
		rep_desc = None,
		rep_estado = None,
		rep_ldesc = None,
		rep_alerta = None,
		rep_trap = None,
		rep_trap_definicion = None,
		rep_id=None
	):
		self.rep_id = rep_id #serial
		self.rep_desc = rep_desc #varchar(200)
		self.rep_estado = rep_estado #smallint
		self.rep_ldesc = rep_ldesc #smallint
		self.rep_alerta = rep_alerta #char(1)
		self.rep_trap = rep_trap #char(1)
		self.rep_trap_definicion = rep_trap_definicion #text
		#si bSelect es False delete,update,insert si es True select
		self.clase_MyDB = MyDB()

	#devuelve los datos importantes de la clase reportes
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		diccionario.pop('clase_MyDB')
		return diccionario

	#guarda datos en la tabla reportes
	def guardar_dato(self):
		try:
			query = ('INSERT INTO "TAB_REPORTES" ('
						'rep_desc,rep_estado,rep_ldesc,'
						'rep_alerta,rep_trap,rep_trap_definicion)'
						' VALUES (%s,%s,%s,%s,%s,%s)')
			datos = (self.rep_desc,self.rep_estado,
						self.rep_ldesc,self.rep_alerta,
						self.rep_trap,self.rep_trap_definicion)
			version = self.clase_MyDB.conectar(query,datos,False)
			if (version[0]) == 'ok':
				self.obj_id = version[1][0][0] #version[len(version) - 1][0]
				dato = ['ok','']
			else:
				dato = ['error','Error en la base de datos']			
		except psycopg2.DatabaseError as e:
			dato = ['error',str(e)]		
		except:
			dato = ['error', str(e)]			
		finally:			
			return dato

	#busca datos en la tabla de reportes
	def buscar_dato(self):
		try:
			query = ('SELECT * FROM "TAB_REPORTES" WHERE rep_id = %s')
			datos = (self.rep_id,)
			version = self.clase_MyDB.conectar(query,datos,True)
			if(version[0] == 'ok'):				
				if (version[1] != False):
					self.rep_desc = version[1][0][1] #varchar(200)
					self.rep_estado = version[1][0][2] #smallint
					self.rep_ldesc = version[1][0][3] #smallint
					self.rep_alerta = version[1][0][4] #char(1)
					self.rep_trap = version[1][0][5] #char(1)
					self.rep_trap_definicion = version[1][0][6] #text
					dato = ['ok','']
				else:
					dato = ['error', 'No se encontro un elemento en TAB_REPORTES con ese ID']
			else:
				dato = ['error', version[1]]
		except psycopg2.DatabaseError as e:
			dato = ['error',str(e)]
			#print(f'Error {e}')
		except Exception as e:
			dato = ['error',str(e)]		
		finally:			
			return dato

	#consulta la lista completa de la tabla de reportes
	@staticmethod
	def consultar_lista():
		try:
			query = ('SELECT * FROM "TAB_REPORTES" ORDER BY rep_id')
			datos = ()
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)
			if (version[0] == 'ok'):
				if (version[1]!=False):
					lista = []
					for indicadores in version[1]:
						data = {}
						obj_rep = TAB_REPORTES.from_list(indicadores)
						data.update(obj_rep.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista['result'] = 'failed'
					lista['error'] = 'Lista vacia'
					lista['error_cod'] = 500
			else:
				lista = {}
				lista['result'] = 'failed'
				lista['error'] = 'Error en la base de datos'
				lista['val_errors'] = version[1]
				lista['error_cod'] = 501
		except psycopg2.DatabaseError as e:
			lista = {}
			lista['result'] = 'failed'
			lista['error']='Error en ejecucion de base de datos'
			lista['val_errors'] = str(e)
			lista['error_cod'] = 502
			#print(f'Error {e}')
		except Exception as e:
			lista = {}
			lista['result'] = 'failed'
			lista['error'] ='Error inesperado'
			lista['val_errors'] = str(e)
			lista['error_cod'] = 503
			#print(e)
		finally:			
			return lista

	#modifica el dato seleccionado de tabla reportes
	def modificar(self):
		try:
			query = ('UPDATE "TAB_REPORTES" SET rep_desc = COALESCE(%s,rep_desc),'
						'rep_estado= COALESCE(%s,rep_estado), rep_ldesc= COALESCE(%s,rep_ldesc),'
						'rep_alerta= COALESCE(%s,rep_alerta),'
						'rep_trap= COALESCE(%s,rep_trap), rep_trap_definicion= COALESCE(%s,rep_trap_definicion) '
						'WHERE rep_id = %s')
			datos = (self.rep_desc,self.rep_estado,
						self.rep_ldesc,self.rep_alerta,
						self.rep_trap,self.rep_trap_definicion,
						self.rep_id)
			respu = self.clase_MyDB.conectar(query,datos,False)
			
			if (respu[0] == 'ok'):
				lista = ['ok', ' ']
			else:
				lista = ['error', 'Error en la base de datos']
		except psycopg2.DatabaseError as e:	
			lista = ['error',str(e)]
		except Exception as e:			
			lista = ['error',str(e)]
		else:		
			lista = ['ok',' ']
		finally:			
			return lista

	#se borra el dato seleccionado en la tabla de reportes
	def borrar(self):
		try:
			query = 'DELETE FROM "TAB_REPORTES" WHERE rep_id= %s'
			datos = (self.rep_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)
			if (respu[0] == 'ok'):
				lista = {}
				lista['result'] = 'ok'
			else:
				lista = {}
				lista['result'] = 'failed'
				lista['error'] = 'Sucedio un error'
				lista['error_cod']= 505
				lista['val_errors']='Error en la base de datos'
		except psycopg2.DatabaseError as e:
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)
		except Exception as e:
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)      
		else:
			lista = {}
			lista['result']='ok'
		finally:
			return lista

	# se genera la clase con un array
	@staticmethod
	def from_list(lista):
		reporte = TAB_REPORTES(
			rep_id = lista[0],
			rep_desc = lista[1],
			rep_estado = lista[2],
			rep_ldesc = lista[3],
			rep_alerta = lista[4],
			rep_trap = lista[5],
			rep_trap_definicion = lista[6]
		)
		return reporte

	
	