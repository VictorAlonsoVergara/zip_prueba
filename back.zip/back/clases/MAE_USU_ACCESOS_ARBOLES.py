import psycopg2
import sys
from MAE_USU_ACCESOS_REPORTES import MAE_USU_ACCESOS_REPORTES
from MAE_USUARIOS import MAE_USUARIOS
from TAB_REPORTES import TAB_REPORTES
from MAE_CRON import MAE_CRON
from MAT_TIPO_OBJ import MAT_TIPO_OBJ
from MAE_TIPO_USU import MAE_TIPO_USU
import logging
import datetime
import os
from MyDB import MyDB
#clase que gestiona el usuario acceso arboles
class MAE_USU_ACCESOS_ARBOLES :
	#se inicializa 
	def __init__(
		self,
		urep_id = None,
		uarb_tipo = None,
		arb_id = None,
		uarb_id = None,
		uarb_estado = None
		):
		self.uarb_id = uarb_id #serial
		self.urep_id = urep_id #integer
		self.uarb_tipo = uarb_tipo #char(1)
		self.arb_id = arb_id #integer
		self.uarb_estado = uarb_estado
		self.mae_usu_accesos_reportes = MAE_USU_ACCESOS_REPORTES(urep_id = urep_id)
		self.mae_usu_accesos_reportes.buscar_dato()
		self.clase_MyDB = MyDB()   
		
	#devuelve datos importantes de la clase
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		diccionario['reporte'] = {}
		diccionario['usuario'] = {}
		diccionario['reporte'].update(self.mae_usu_accesos_reportes.tab_reportes.get_diccionario())
		diccionario['usuario'].update(self.mae_usu_accesos_reportes.mae_usuarios.get_diccionario())
		diccionario['usuario'].pop('tipo_usuario')
		diccionario['usuario'].pop('idioma')
		diccionario['usuario'].pop('area')
		diccionario.pop('mae_usu_accesos_reportes')
		diccionario.pop('clase_MyDB')
		return diccionario

	#guarda datos en la tabla de usuario accesos arboles
	def guardar_dato(self):
		try:
			datos = (self.urep_id,self.uarb_tipo,self.arb_id,)
		   
			query='INSERT INTO "MAE_USU_ACCESOS_ARBOLES" (urep_id,uarb_tipo,arb_id) VALUES (%s,%s,%s) RETURNING uarb_id'
			version = self.clase_MyDB.conectar(query,datos,False)
			if version[0] == 'ok':
				self.uarb_id = version[1][0][0]#version[len(version)-1][0]
				dato = ['ok',' ']
			else:
				dato = ['error',version[1]]
			#logging.info(str(datetime.datetime.today())+'se guardo un dato en tabla MAE_USU_ACCESO_ARBOLES')
		except Exception as e:
			dato = ['error',str(e)]
		finally:
			return dato

	#busca informacion del dato en la tabla 
	def buscar_dato(self):
		try:
			datos=(self.uarb_id,)
			query='SELECT * FROM "MAE_USU_ACCESOS_ARBOLES" WHERE uarb_id = %s'
			version = self.clase_MyDB.conectar(query,datos,True)
			if (version[0] == 'ok'):
				if (version[1]!=False):
					self.urep_id = version[1][0][1] #integer
					self.uarb_tipo = version[1][0][2] #char(1)
					self.arb_id = version[1][0][3] #integer
					self.uarb_estado = version[1][0][4]
					self.mae_usu_accesos_reportes=MAE_USU_ACCESOS_REPORTES(1,1,self.urep_id)
					self.mae_usu_accesos_reportes.buscar_dato()
					dato = ['ok',' ']
				else:
					dato=['error','No se encontro el MAE_USU_ACCESOS_ARBOLES con ese ID']
			else:
				dato = ['error', str (version[1])]
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]				
			dato = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
		finally:
			return dato

	#consulta la lista de la tabla de usuario accesos arboles
	@staticmethod
	def consultar_lista():
		try:
			query ='SELECT * FROM "MAE_USU_ACCESOS_ARBOLES"'
			datos = ( )
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)
			if (version[0]=='ok'):
				if version[1]!=False:
					lista = []
					for alertas in version[1]:
						data = {}
						obj_acc_arb = MAE_USU_ACCESOS_ARBOLES.from_list(alertas)
						data.update(obj_acc_arb.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista["result"] = "failed"
					lista["error"] = "Sucedio un error"
					lista["error_cod"] = 412
					lista["val_errors"] = "Lista vacia"
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 412
				lista["val_errors"] = str(version[1])
					
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 412
			lista["val_errors"] = str(e)
		finally:
			return lista

	#modifica los datos de la tabla usuario accesos arboles
	def modificar(self):
		try:
			query = ('UPDATE "MAE_USU_ACCESOS_ARBOLES" SET '
						'urep_id = COALESCE(%s,urep_id),'
						'uarb_tipo = COALESCE(%s,uarb_tipo),'
						'uarb_estado = COALESCE(%s,uarb_estado),'
						'arb_id = COALESCE(%s,arb_id) '
						'WHERE uarb_id = %s')
			datos=(self.urep_id,self.uarb_tipo,str(self.uarb_estado),self.arb_id,self.uarb_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)	
			if (respu[0]=='ok'):
				lista = ['ok',' ']
				self.mae_usu_accesos_reportes = MAE_USU_ACCESOS_REPORTES(urep_id = self.urep_id)
				self.mae_usu_accesos_reportes.buscar_dato()				
			else:
				lista = ['error',respu[1]]
		except Exception as e:
			lista = ['error',str(e)]
		finally:
			return lista
		
	#borra el dato seleccionado
	def borrar(self):
		try:
			query = 'DELETE FROM "MAE_USU_ACCESOS_ARBOLES" WHERE uarb_id= %s'
			datos=(self.uarb_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)	
			if (respu[0] == 'ok'):
				lista = {}
				lista['result']='ok'#+str(respu)
			else:
				lista = {}
				lista['result'] = 'failed'
				lista['error'] = 'Sucedio un error'
				lista['error_cod'] = 505
				lista['val_errors'] = str(respu[1])	
		except Exception as e:
			lista = {}
			lista['result'] = 'failed'
			lista['error'] = 'Sucedio un error'
			lista['error_cod'] = 505
			lista['val_errors'] = str(e)
		finally:
			return lista

	#edita el acceso a la tabla
	def editar_accesos(self,arb_ids):
		is_new_acceso = not self.__validar_acceso_reporte()
		if len(arb_ids) <= 0:
			response = self.__borrar_todos_accesos()
			return response
		if is_new_acceso is True:
			response = self.__inertar_lista(arb_ids)
		else:
			response = self.__editar_acceso_arboles(arb_ids)
		return response

	#borra los datos de los accesos
	def __borrar_todos_accesos(self):
		try:
			query = ('SELECT arb_id FROM "MAE_USU_ACCESOS_ARBOLES" WHERE urep_id = %s AND uarb_tipo = %s')
			datos = (self.urep_id,self.uarb_tipo,)
			result = self.clase_MyDB.conectar(query,datos,True)
			query_results = []
			if result[0] == 'ok':
				if result[1] is not False:
					lista_arbs = result[1]
					for arb in lista_arbs:
						query_update = ('UPDATE "MAE_USU_ACCESOS_ARBOLES" '
										'SET uarb_estado = false WHERE urep_id = %s AND arb_id = %s AND uarb_tipo = %s')
						datos_update = (self.urep_id,arb,self.uarb_tipo,)
						result_update = self.clase_MyDB.conectar(query_update,datos_update,False)
						query_results.append(result_update)
					response = ['ok','Los accesos a arboles se desactivaron']
					for res in query_results:
						if res[0] != 'ok':
							response = ['error',res[1]]
				else:
					response = ['error','No se encontraron accesos a arboles']
			else:
				response['error','Error en la base de datos '+str(result[1])]
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			response = ["error",str(e)+" - "+ str(exc_type)+" - "+ str(fname)+" - "+ str(exc_tb.tb_lineno)]
		finally:
			return response

	#valida el acceso del reporte
	def __validar_acceso_reporte(self):
		try:
			query = 'SELECT COUNT(urep_id) FROM "MAE_USU_ACCESOS_ARBOLES" WHERE urep_id = %s'
			datos = (self.urep_id,)
			version = self.clase_MyDB.conectar(query,datos,True)
			if version[0]=='ok':
				if (version[1][0][0]!=0): #ya existe 
					dato = True
				else:
					dato = False
			else:
				dato = False #'error'
		except Exception:
			dato = False
		finally:
			return dato

	#insert datos en la tabla de usuario acceso arboles
	def __inertar_lista(self,arb_ids):
		try:
			responses = []
			for arb in arb_ids:
				query_insert = ('INSERT INTO "MAE_USU_ACCESOS_ARBOLES" (urep_id,arb_id,uarb_tipo) VALUES (%s,%s,%s)')
				datos = (self.urep_id,arb,self.uarb_tipo,)
				result = self.clase_MyDB.conectar(query_insert,datos,False)
				if result[0] == 'ok':
					responses.append(['ok','Se insertaron nuevos accesos a reportes'])
				else:
					responses.append(['error','Error al insertar lista de arboles '+str(arb)])
			response = ['ok','Se insertaron nuevos accesos a arboles']
			for resp in responses:
				if resp[0] != 'ok':
					response = ['error',resp[1]]
					break
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			response = ["error",str(e)+" - "+ str(exc_type)+" - "+ str(fname)+" - "+ str(exc_tb.tb_lineno)]
		finally:
			return response
		
	#edita los datos de la tabla
	def __editar_acceso_arboles(self,arb_ids):
		try:
			query = ('SELECT arb_id,uarb_estado FROM "MAE_USU_ACCESOS_ARBOLES" WHERE urep_id = %s and arb_id in %s and uarb_tipo = %s')
			datos = (self.urep_id,tuple(arb_ids),self.uarb_tipo,)
			result = self.clase_MyDB.conectar(query,datos,True)
			results_querys = []
			if result[0] == 'ok':
				if result[1] is not False:
					list_results = result[1]
				else:
					list_results = []
				list_not_new = []
				dictio_estado = {}
				for res in list_results:
					list_not_new.append(res[0])
					dictio_estado[res[0]] = res[1]
				for arb in arb_ids:
					if arb not in list_not_new:
						query_insert = ('INSERT INTO "MAE_USU_ACCESOS_ARBOLES" (urep_id,arb_id,uarb_tipo) VALUES (%s,%s,%s) RETURNING urep_id')
						dato_insert = (self.urep_id,arb,self.uarb_tipo)
						result_insert = self.clase_MyDB.conectar(query_insert,dato_insert,False)
						results_querys.append(result_insert)
					else:
						query_update = ('UPDATE "MAE_USU_ACCESOS_ARBOLES" set uarb_estado = %s WHERE urep_id = %s AND arb_id = %s AND uarb_tipo = %s')
						new_estado = not bool(dictio_estado[arb])
						datos_update = (new_estado,self.urep_id,arb,self.uarb_tipo,)
						result_update = self.clase_MyDB.conectar(query_update,datos_update,False)
						results_querys.append(result_update)
				response = ['ok','No hubo problemas']
				for results in results_querys:
					if results[0] != 'ok':
						response = ['error','Error al ejecutar queries']
						break
				# else:
				# 	response = ['error','No se encontraron accesos con estos datos']
			else:
				response = ['error','Error en la base de datos']
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			response = ["error",str(e)+" - "+ str(exc_type)+" - "+ str(fname)+" - "+ str(exc_tb.tb_lineno)]
		finally:
			return response

	#devuelve la lista de la tabla de usuario accesos arboles
	@staticmethod
	def listar_accesos_arboles(urep_id,uarb_estado):
		try:
			db = MyDB()
			query = ('SELECT * FROM "MAE_USU_ACCESOS_ARBOLES" WHERE urep_id = %s and uarb_estado = COALESCE(%s,uarb_estado)')
			datos = (urep_id,uarb_estado,)
			resultados = db.conectar(query,datos,True)
			if resultados[0] == 'ok':
				lista_rep = []
				if resultados[1] is not False:
					for acceso in resultados[1]:
						data = {}
						obj_acc = MAE_USU_ACCESOS_ARBOLES.from_list(acceso)
						data.update(obj_acc.get_diccionario())
						lista_rep.append(data)
					lista = {}
					lista['result'] = 'ok'
					lista['listas'] = lista_rep
				else:
					lista = {}
					lista['result'] = 'failed'
					lista['val_errors'] = 'No se encontraron arboles de ese acceso a reporte'
			else:
				lista = {}
				lista['result'] = 'failed'
				lista['val_errors'] = 'Error al obtener arboles del acceso a reporte' + str(resultados)
		except Exception as e:
			lista = {}
			lista['result'] = 'failed'
			lista['val_errors'] = str(e)
		finally:
			return lista
			
	#busca reportes de los usuarios accesos arboles
	@staticmethod
	def buscar_con_reportes(urep_id):
		try:
			query ='SELECT * FROM "MAE_USU_ACCESOS_ARBOLES" WHERE urep_id = %s'
			datos = (urep_id)
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)
			if (version[0]=='ok'):
				lista = []
				for alertas in version[1]:
					data = {}
					obj_acc_arb = MAE_USU_ACCESOS_ARBOLES.from_list(alertas)
					data.update(obj_acc_arb.get_diccionario())
					lista.append(data)
			else:
				lista = {}
				lista['Error']='Error en la base de datos'
					
		except Exception as e:
			lista = {}
			lista['Error'] =str(e)
		finally:
			return lista

	#crea la clase con un array
	@staticmethod
	def from_list(lista):
		acc_arb = MAE_USU_ACCESOS_ARBOLES(
			uarb_id=lista[0],
			uarb_tipo=lista[2],
			arb_id=lista[3],
			urep_id=lista[1],
			uarb_estado=lista[4]
		)
		return acc_arb

	#crea la clase con un json
	@staticmethod
	def from_json(json):
		acc_arb = MAE_USU_ACCESOS_ARBOLES()
		diccio = vars(acc_arb)
		for key,value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			diccio[key] = value
		return acc_arb