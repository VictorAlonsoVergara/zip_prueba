import psycopg2
import sys
import logging
import datetime
import os
from ARB_LOGICO import ARB_LOGICO
from MyDB import MyDB

#esta clase gestiona los servidores del proyecto
class MAE_SERVERS_PULL:
	def __init__(self, serv_id=None, serv_ip=None, serv_hostname=None, log_id=None):
		self.serv_id = serv_id  # serial
		self.serv_ip = serv_ip  # varchar(20)
		self.serv_hostname = serv_hostname  # varchar(50)
		self.log_id = log_id  # integer
		self.arb_logico = ARB_LOGICO(log_id=log_id)
		self.arb_logico.buscar_dato()
		self.clase_MyDB = MyDB()

	#devuelve los datos importantes de los servidores
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		diccionario['arb_logico'] = {}
		diccionario['arb_logico'].update(self.arb_logico.get_diccionario())
		diccionario.pop("clase_MyDB")
		diccionario.pop('arb_logico')		
		return diccionario

	# Metodo para obtener la tupla que se usara en el metodo guardar
	def _get_insert_tuple(self):
		return (self.serv_ip, self.serv_hostname, self.log_id)

	# Metodo para obtener la tupla que se usara en el metodo modificar
	def _get_update_tuple(self):
		return (self.serv_ip, self.serv_hostname, self.log_id, self.serv_id)

	# Metodo para obtener la tupla que se usara en el metodo buscar_lista
	def _get_params_tuple(self):
		return (self.serv_ip, self.serv_hostname, self.log_id)

	#guarda el dato en la tabla
	def guardar_dato(self):
		try:
			query = 'INSERT INTO "MAE_SERVERS_PULL" (serv_ip,serv_hostname,log_id) VALUES (%s,%s,%s) RETURNING serv_id'
			datos = self._get_insert_tuple()
			version = self.clase_MyDB.conectar(query, datos, False)
			if version[0] == "ok":
				self.serv_id = version[1][0][0]
				dato = ["ok", " "]
			else:
				dato = ["error", version[1]]
		except Exception as e:
			dato = ["error", str(e)]
		finally:
			return dato

	#Busca el dato en la tabla que se encuentran activados
	def buscar_dato(self):
		try:
			query = """SELECT * FROM "MAE_SERVERS_PULL" WHERE serv_id = %s"""
			datos = (self.serv_id,)
			version = self.clase_MyDB.conectar(query, datos, True)

			if version[0] == "ok":
				if version[1] != False:
					self.serv_ip = version[1][0][1]
					self.serv_hostname = version[1][0][2]
					self.log_id = version[1][0][3]
					self.arb_logico=ARB_LOGICO(log_id=version[1][0][3])
					self.arb_logico.buscar_dato()
					dato = ["ok", " "]
				else:
					dato = ["error", "No se encontro el servidor con ese ID"]
			else:
				dato = ["error", version[1]]
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			dato = [
				"error",
				str(e)
				+ " - "
				+ str(exc_type)
				+ " - "
				+ str(fname)
				+ " - "
				+ str(exc_tb.tb_lineno),
			]
		finally:
			return dato

	# Metodo para consultar todos los servidores
	@staticmethod
	def consultar_lista():
		try:
			query = """SELECT * FROM "MAE_SERVERS_PULL" ORDER BY serv_id"""
			datos = ()
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query, datos, True)

			if version[0] == "ok":
				lista = []
				if version[1] != False:
					for servidor in version[1]:
						servidor = MAE_SERVERS_PULL.from_list(servidor)
						lista.append(servidor.get_diccionario())
				else:
					lista = {}
					linea['result'] = "failed"
					linea['error'] = "Sucedio un error"
					linea['error_cod'] = 411
					lista["val_errors"] = "lista vacia"
			else:
				lista = {}
				linea['result'] = "failed"
				linea['error'] = "Sucedio un error"
				linea['error_cod'] = 411
				lista["val_errors"] = version[1]
		except Exception as e:
			lista = {}
			linea['result'] = "failed"
			linea['error'] = "Sucedio un error"
			linea['error_cod'] = 411
			lista["val_errors"] = str(e)
		finally:
			return lista

	# Metodo que modifica un servidor con serv_id,los valores en None no seran modificados
	def modificar(self):
		
		try:
			query = (
				'UPDATE "MAE_SERVERS_PULL" SET serv_ip = COALESCE(%s,serv_ip),'
				"serv_hostname = COALESCE(%s,serv_hostname),log_id = COALESCE(%s,log_id) WHERE serv_id = %s"
			)
			datos = self._get_update_tuple()
			respu = self.clase_MyDB.conectar(query, datos, False)

			if respu[0] == "ok":
				lista = ["ok", " "]
			else:
				lista = ["error", respu[1]]
		except Exception as e:
			lista = ["error", str(e)]
		finally:
			return lista

	# Metodo para borrar un elemento de la base de datos a partir de un ind_id
	def borrar(self):
		try:
			query = 'DELETE FROM "MAE_SERVERS_PULL" WHERE serv_id= %s'
			datos = (self.serv_id,)
			respu = self.clase_MyDB.conectar(query, datos, False)

			if respu[0] == "ok":
				lista = {}
				lista["result"] = "ok"  # +str(respu)
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 505
				lista["val_errors"] = respu[1]
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 505
			lista["val_errors"] = str(e)
		finally:
			return lista

	# El metodo crea un objeto a partir de una lista mandada por
	# la base de datos
	@staticmethod
	def from_list(lista):
		servidor = MAE_SERVERS_PULL(
			serv_id=lista[0], serv_ip=lista[1], serv_hostname=lista[2], log_id=lista[3]
		)
		return servidor

	# Crea un servidor de MAE_SERVERS_PULL a partir de un diccionario json,
	# los datos del json deben tener los mismos nombres que en la clase del servidor
	@staticmethod
	def from_json(json):
		servidor = MAE_SERVERS_PULL()
		dicc_servidor = vars(servidor)
		for key, value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			dicc_servidor[key] = value
		return servidor
