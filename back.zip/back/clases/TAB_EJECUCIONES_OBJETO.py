import psycopg2
import sys
from MAE_OBJETOS import MAE_OBJETOS
from TAB_EJECUCIONES import TAB_EJECUCIONES
import logging
import datetime
import os
from MyDB import MyDB

#clase que gestiona las ejecuciones con objeto
class TAB_EJECUCIONES_OBJETO:
    def __init__(
        self,
        eobj_id=None,
		eobj_cod = None,
        eobj_fch_inicio = None,
        eobj_fch_fin = None,
        eobj_subido = None,
        eje_id = None,
        obj_id = None 
    ):

        self.eobj_id = eobj_id  # serial
        self.eobj_cod = eobj_cod  # varchar(100)
        self.eobj_fch_inicio = eobj_fch_inicio  # datetime timestamp with time zone
        self.eobj_fch_fin = eobj_fch_fin  # datetime timestamp with time zone
        self.eobj_subido = eobj_subido   # bool
        self.eje_id = eje_id  # integer
        self.obj_id = obj_id  # integer 
        self.tab_ejecucines = TAB_EJECUCIONES(eje_id = eje_id) 
        self.mae_objetos = MAE_OBJETOS(obj_id = obj_id)
        if eje_id is not None:
            self.tab_ejecucines.buscar_dato()
        if obj_id is not None:
            self.mae_objetos.buscar_dato()
        # si bSelect es False delete ,update ,insert si es True select
        self.clase_MyDB = MyDB()

    #devuelve los datos importantes de la clase
    def get_diccionario(self):
        diccionario = {}
        diccionario.update(vars(self))
        if self.eobj_fch_inicio is not None:
            diccionario['eobj_fch_inicio'] = self.eobj_fch_inicio.strftime("%Y-%m-%d %H:%M:%S")#convierto a string para que pueda convertirlo a JSON
        if self.eobj_fch_fin is not None:
            diccionario['eobj_fch_fin'] = self.eobj_fch_fin.strftime("%Y-%m-%d %H:%M:%S")#convierto a string para que pueda convertirlo a JSON
        diccionario['objeto'] = {}
        diccionario['objeto'].update(self.mae_objetos.get_diccionario())
        diccionario['objeto'].pop('tipo_obj')
        diccionario['objeto'].pop('protocolo')
        diccionario['objeto'].pop('marca')
        diccionario['objeto'].pop('modelo')
        diccionario['ejecucion']={}
        diccionario['ejecucion'].update(self.tab_ejecucines.get_diccionario())
        diccionario['ejecucion'].pop('cron')
        diccionario.pop('clase_MyDB')
        diccionario.pop('mae_objetos')
        diccionario.pop('tab_ejecucines')
        return diccionario

    # busca los datos de la tabla ejecuciones objeto
    def buscar_dato(self):
        try:
            query = 'SELECT * FROM "TAB_EJECUCIONES_OBJETO" WHERE eobj_id = %s'
            datos = (self.eobj_id,)
            version = self.clase_MyDB.conectar(query, datos, True)

            if version[0] == "ok":
                if version[1] != False:
                    self.eobj_cod = version[1][0][1]  # varchar(100)
                    self.eobj_fch_inicio = version[1][0][2]  # datetime timestamp with time zone
                    self.eobj_fch_fin = version[1][0][3]  # datetime timestamp with time zone
                    self.eobj_subido = version[1][0][4]   # bool
                    self.eje_id = version[1][0][5]  # integer
                    self.obj_id = version[1][0][6]  # integer 
                    self.tab_ejecucines = TAB_EJECUCIONES(eje_id = self.eje_id) 
                    self.mae_objetos = MAE_OBJETOS(obj_id = self.obj_id)
                    self.tab_ejecucines.buscar_dato()
                    self.mae_objetos.buscar_dato()
                    dato = ["ok", ""]
                else:
                    dato = ["error", "No se encontro la ejecucion-obj con ese ID"]
            else:
                dato = ["error", "Error con la base de datos"]
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            dato = [
                "error",
                str(e)
                + " - "
                + str(exc_type)
                + " - "
                + str(fname)
                + " - "
                + str(exc_tb.tb_lineno),
            ]
        finally:            
            return dato

    # consulta la lsita de la tabla ejecuciones de objeto
    @staticmethod
    def consultar_lista():
        try:
            query = 'SELECT * FROM "TAB_EJECUCIONES_OBJETO" ORDER BY eobj_id'
            datos = ()
            clase_MyDB = MyDB()
            version = clase_MyDB.conectar(query, datos, True)

            if version[0] == "ok":
                if version[1]!=False:
                    lista = []
                    for eje_obj in version[1]:
                        data = {}
                        ejecuciones = TAB_EJECUCIONES_OBJETO.from_list(eje_obj)
                        ejecuciones.buscar_dato()
                        data.update(ejecuciones.get_diccionario())
                        lista.append(data)
                else:
                    lista = {}
                    lista["result"] = "failed"
                    lista["error"] = "Sucedio un error"
                    lista["error_cod"] = 412
                    lista["val_errors"] = "Lista vacia"
            else:
                lista = {}
                lista["result"] = "failed"
                lista["error"] = "Sucedio un error"
                lista["error_cod"] = 412
                lista["val_errors"] = version[1]
        except Exception as e:
            lista["result"] = "failed"
            lista["error"] = "Sucedio un error"
            lista["error_cod"] = 412
            lista["val_errors"] = e
        finally:            
            return lista

    #crea la clase con un array
    @staticmethod
    def from_list(lista):
        ejecuciones = TAB_EJECUCIONES_OBJETO(
            eobj_id = lista[0],
            eobj_cod = lista[1],
            eobj_fch_inicio = lista[2],
            eobj_fch_fin = lista[3],
            eobj_subido = lista[4],
            eje_id = lista[5],
            obj_id = lista[6] 
        )
        return ejecuciones
