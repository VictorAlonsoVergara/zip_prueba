from MyDB import MyDB
import configuracionParametros

#prueba de base de datos 

clase_MyDB = MyDB('cotener','cotener','cotener')

query = 'select * from "MAE_USUARIOS" returning id'
datos = ()
clase= clase_MyDB.conectar(query,datos,True)
print(clase)


'''
print(configuracionParametros.NombreDataBase())
print(configuracionParametros.UsuarioDataBase())
print(configuracionParametros.ClaveDataBase())
print(configuracionParametros.Nombredevariable())'''