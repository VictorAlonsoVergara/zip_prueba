import sys ,os
sys.path.insert(0,'/home/sistema/clases')

import logging
import random
import json
import psycopg2
from MAE_USUARIOS import MAE_USUARIOS
#import time
from hashlib import blake2b
from datetime import datetime
from MyDB import MyDB


#esta clase maneja todas las sesiones
class Session:

	def __init__(self):
			self.clase_MyDB = MyDB()

	#tiempo en segundos que es valido un token
	__expiracion = 10 * 60 * 60  #10 horas
	
	#tiempo maximo hacia atrás en que se consideran los tokens, en horas
	__oldtoken = 10

	#token a usar
	__token = ""

	#data para el cookie
	__data = "{}"
	
	#db
	#__db = psycopg2.connect(database="cotener", user="cotener", password="cotener", host="localhost")

	#usuario ID
	__usuid = -1
	
	#el token sera nuestro control de sesion
	def generaToken(self):
		iNum = random.randint(100000000000,999999999999)# se genera un token aleatorio
		sNum = str(iNum)
		self.__token = sNum
		sToken = self.__tokenizer(sNum)#se difumina el valor
		# se inserta los valores en la tabla de log sesiones
		sQry= 'insert into "LOG_SESIONES" (ses_token) values (%s)'
		tData= (sToken, )
				
		self.__dbAccion(sQry, tData)

		return True
		
	def getToken(self):# se devuelve el valor del token
		return self.__token
		
	def setToken(self, sNum):# se setea el valor del token
		self.__token = sNum
		return True
		
	#verifica el login
	def ValidaUsuario( self, sUsuario, sPassword):# valida el usuario
		if self.__hayToken():
			sResultado, sMensaje, iId = MAE_USUARIOS.verificar_usuario(sUsuario,sPassword)
			#logging.info(sResultado)
			#logging.info(sMensaje)
			#logging.info(iId)
			#logging.info(type(iId))
			if iId == -1:
				return False
			else:    
				sToken= self.__tokenizer(self.__token)
				#se modifica los valores de la tabla de log sesiones con los valores del usu_id y ses_token
				sQry='update "LOG_SESIONES" set ses_logeado = %s, usu_id = %s where ses_token = %s'
				tData = ("S", iId, sToken)
				self.__dbAccion(sQry,tData)
				return True
		else:
			return False

	#verifica el login
	def ValidaToken( self ,usu_id ,usu_ip):
		if self.__hayToken():
			sToken= self.__tokenizer(self.__token)
			sQry='update "LOG_SESIONES" set usu_id = %s ,ses_logeado = %s,client_ip = %s where ses_token = %s'
			tData = (usu_id,"S",usu_ip, sToken,)
			self.__dbAccion(sQry,tData)
			return True
		else:
			return False      

	#verifica que el token sea valido      
	def __hayToken(self):
		if len(self.__token) !=  12:
			return False
		else:
			return True
			
	#devuelve la data guardada en json      
	def getData(self):
		if self.__hayToken():
			return self.__data
		else:
			return False

	#devuelve el ID del usuario, primero validar el token para obtener data
	def getUsuId(self):
		if self.__hayToken():
			return self.__usuid
		else:
			return False
			

	#anade atributos a la data
	def setAtributo(self, sAtributo, sValor):
		if self.__hayToken():
				dDatos = json.loads(self.__data)
				for sKey,sVal in dDatos.items():
					if sKey == sAtributo:
						dDatos[sAtributo] = sValor
						self.__data = json.dumps(dDatos)
						return True
						
				dDatos[sAtributo] = sValor
				self.__data = json.dumps(dDatos)
				return True
		else:
			return False


	#borra un atributo
	def delAtributo(self, sAtributo):
		if self.__hayToken():
				dDatos = json.loads(self.__data)
				bEsta = False
				for sKey,sVal in dDatos.items():
					if sKey == sAtributo:
						bEsta = True

						print(sKey)
						
				#si no existe la variable retorna False
				if bEsta == False:
					return False
				else:
					del dDatos[sAtributo]
					self.__data = json.dumps(dDatos)
				
				return True
			
		else:
			return False
	
	#borra toda la data
	def delData(self):
		if self.__hayToken():  
			self.__data = "{}"
			return True
		else:
			return False
			
	def getDataDic(self):
		if self.__hayToken():
			return json.loads(self.__data)
		else:
			return False

	#ofuzca el token numerico   
	def __tokenizer(self, sNum):
		hToken = blake2b(digest_size=32)
		hToken.update(sNum.encode())
		return hToken.hexdigest()


	#graba la data
	def saveData(self):
		if self.__hayToken():
			sToken= self.__tokenizer(self.__token)
			sQry='update "LOG_SESIONES" set ses_data = %s where ses_token = %s'
			tData=(self.__data, sToken)
			self.__dbAccion(sQry,tData)
			return True;
		else:
			return False

	#lee la data de la db
	def __loadData(self):
		if self.__hayToken():
			sToken= self.__tokenizer(self.__token)
			sQry='select ses_data from  "LOG_SESIONES" where ses_token = %s limit 1'
			tData = (sToken,)
			rRow = self.__dbAccion(sQry, tData, True)
			self.__data = json.dumps(rRow[0][0])
			#print(rRow)
			
			return True;
		else:
			return False

	#valida token para ver si ha exipirado
	def valToken(self, sNum):
		#tokenizamos y lo cargamos al objeto
		sToken = self.__tokenizer(sNum)
		self.__token = sNum
		sResta = str(self.__oldtoken) + " hr"

		sQry='select ses_logeado, ses_activacion, ses_expirado, usu_id from "LOG_SESIONES" where ses_token = %s and ses_activacion > (now() - %s::INTERVAL ) and ses_expirado = %s order by ses_activacion desc limit 1'
		tData =(sToken, sResta, "N")
		rRows = self.__dbAccion(sQry, tData, True)
		bExiste = False
		#logging.info(rRows)
		#logging.info(type(rRows))
		
		if type(rRows) == bool:
			#logging.info("no retorna datos")
			return bExiste
				
		for rRow in rRows:
			#verifica si esta logeado
			if rRow[0] == "S":
				#verificando diferencia de tiempo
				tToken = rRow[1]
				if self.DiffTime(rRow[1]) > self.__expiracion:
					#actualizamos la sesion como expirada
					self.__ActualizaSesion('E')
					return bExiste
				else:
					bExiste = True
					#actualiza el tojken
					self.__token = sNum
					#actualiza id
					self.__usuid = rRow[3]
					logging.info(rRow[3])

					#lee la data en el objeto token
					self.__loadData()
					#actualizamos la sesion como vigente
					self.__ActualizaSesion('V')
					return True
			else:
				return False
		return bExiste

	def valIp(self, sNum,sIp):
		#tokenizamos y lo cargamos al objeto
		sToken = self.__tokenizer(sNum)
		self.__token = sNum
		#sResta = str(self.__oldtoken) + " hr"

		sQry='select ses_logeado, ses_activacion, ses_expirado, usu_id from "LOG_SESIONES" where ses_token = %s and client_ip = %s'
		tData =(sToken, sIp )
		rRows = self.__dbAccion(sQry, tData, True)
		
		if type(rRows) == bool:
			return False
		else:
			return True



	#operaciones en la db
	def __dbAccion(self, sQry, tData, bSelect = False):
		#logging.info(tData)
		#logging.info(sQry)
		#print(sQry)
		if self.__hayToken():
			if bSelect == False:
				version =  self.clase_MyDB.conectar(sQry,tData,False)
				if (version[0] == "ok"):
					dato = ["ok", " "]
					return True
				else:
					dato = [ "error", "Error en la base de datos"]
					return False
			else:
					version = self.clase_MyDB.conectar(sQry,tData,True)
					if(version[0]=="ok" and version[0]!=False):
						dato = ["ok", " "]
						return version[1]
					elif (version[0]=="ok" and version[0]==False):
						return []
					else:
						dato = ["error","Error en la base de datos"]
						return False
		#   cCursor = self.__db.cursor()
		#   cCursor.execute(sQry, tData)
			
		#   if bSelect == False:
		#     self.__db.commit()
		#     return True
		#   else:
		#     rRpt = cCursor.fetchall()
		#     if len(rRpt) == 0:
		#       #el select no devolvió elementos
		#       return False
		#     else:  
		#       return rRpt
				
		else:
			return False
			
			
	#diferencia entre un tiempo y el tiempo del server
	def DiffTime(self, tTime):
		tServer= datetime.now()
				
		tDifTime = tServer - tTime
		#print(tDifTime)
		return tDifTime.total_seconds()
	
	#cambia el estado de la sesion
	def __ActualizaSesion(self, sTipo):
		if self.__hayToken():
			sToken = self.__tokenizer(self.__token)
			
			if sTipo == "V":
				tData=("N",sToken)  
				sQry='update "LOG_SESIONES" set ses_expirado = %s, ses_activacion = now() where ses_token = %s'
			elif sTipo == "E":
				tData=("S","N",sToken)  
				sQry='update "LOG_SESIONES" set ses_expirado = %s , ses_logeado = %s, ses_fexpirado = now() where ses_token = %s'
			else:
				return False
			#actualiza el estado de la sesion
			rRow = self.__dbAccion(sQry, tData)
			return True
		else:
			return False
			
			
	#obtiene dato de un cookie
	def getCookie(self, sCookie, sDato):
		try:
			sValor=""
			lCookies = dict()
			#obtenemos la lista de cookies
			dCookies = str(sCookie).split(";")
			
			#cortamos cookie por cookie
			for dCookie in dCookies:
				dDato = dCookie.split("=")
				lCookies[dDato[0].strip()] =dDato[1]
			#buscamos el cookie solicitado
			
			for sIndex,sData in lCookies.items():
				if sIndex == sDato:
					sValor= sData
					break
		except Exception as e :
			svalor=""
		finally:
			return sValor
	def get_id_Usu(self,sNum):
		try:
			sToken = self.__tokenizer(sNum)
			tData = (str(sToken),)
			query = 'SELECT usu_id from "LOG_SESIONES" where ses_token = %s'
			usu_id = self.__dbAccion(query,tData,True)
			dato = usu_id[0][0]
		except Exception as e:
			dato = e
		finally:
			return dato

	def get_Datos_Usu(self, sNum):
		#tokenizamos 
		try:
			sToken = self.__tokenizer(sNum)
			tData =(str(sToken),)
			#sQry='select usu_id from "LOG_SESIONES" where ses_token = \''+tData+'\''
			sQry='select usu_id from "LOG_SESIONES" where ses_token = %s '
			usu_id = self.__dbAccion(sQry, tData, True)
			#cCursor = self.__db.cursor()
			#cCursor.execute(sQry)
			#usu_id = cCursor.fetchall()
			
			tData =(str(usu_id[0][0]),)
			#sQry='select usu_nombre,usu_estado,tusu_id from "MAE_USUARIOS" where usu_id = '+tData
			sQry='select usu_nombre,usu_estado,tusu_id,idi_id from "MAE_USUARIOS" where usu_id = %s '
			datos = self.__dbAccion(sQry, tData, True)
			#cCursor = self.__db.cursor()
			#cCursor.execute(sQry)
			#datos = cCursor.fetchall()
			dato={}
			dato["usu_nombre"]=datos[0][0]
			dato["usu_estado"]=datos[0][1]
			dato["tusu_id"]=str(datos[0][2])
			dato["idioma"]=datos[0][3]
			
		except Exception as e :
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]    
			dato = {}
			dato['result'] = "failed"+str(sToken)
			dato['error'] = "Sucedio un error -cookie: "+str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)+' - '+str(usu_id)#+str(cookie)
			dato['error_cod'] = "412"
			dato['val_errors'] = "token no validado"      
		finally:
			output = json.dumps(dato)
			return output

	#consulta si el usuario tiene acceso a la opción del menu deseada
	#se consulta con el id del Menu
	def AccesoMenu(self, iMenu):
		#no hay token, sale
		if self.__hayToken() == False:
			return False

		sQry='select 1 from "MAE_USUARIOS_MENU" where usu_id = %s and menu_id = %s'
		tData =(self.__usuid, iMenu)
		rRow = self.__dbAccion(sQry, tData, True)

		#no lo encuentra en los accesos, sale
		logging.info(rRow)
		logging.info(type(rRow))
		if type(rRow) == bool:
			return False
		else:
			return True

	def CerrarSesiones(self):
		#sToken = self.__tokenizer(sNum)
		#self.__token = sNum
		try:
			sResta = str(self.__oldtoken) + " hr"

			sToken = self.__tokenizer(self.__token)
		#self.__token = sNum
		
		#sQry='update "LOG_SESIONES" set ses_logeado = \'E\' where ses_token = \''+str(sToken)+'\' and usu_id = \''+str(self.__usuid)+'\''
			sQry = 'update "LOG_SESIONES" set ses_logeado = %s where ses_token = %s and usu_id = %s'
			tData =('E', str(sToken), str(self.__usuid))
		#sQry='select ses_logeado, ses_activacion, ses_expirado, usu_id from "LOG_SESIONES" where ses_token = %s and ses_activacion > (now() - %s::INTERVAL ) and ses_expirado = %s order by ses_activacion desc limit 1'
		#tData =(sToken, sResta, "N")
			self.__dbAccion(sQry, tData, False)
			rsp = ['ok','Se cerro la sesion correctamente']
		except Exception as e:
			rsp = ['error','Ocurrio un error cerrando la sesion']
		finally :
			return rsp
