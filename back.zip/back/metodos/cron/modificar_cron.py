import sys, os

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_CRON import MAE_CRON
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations


def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""
        status = "200 OK"
        if environ['REQUEST_METHOD'] != 'PUT' and environ['REQUEST_METHOD'] != 'POST':
            raise validations.HttpException(405)
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):
            jsdato = s.get_Datos_Usu(str(tk))
            lendata = int(environ.get("CONTENT_LENGTH", 0))
            bydata = environ["wsgi.input"].read(lendata)
            jsdata = json.loads(bydata.decode("utf-8"))
            try:

                extra = {}
                diccionario_respu = {}
                pass_flag = True
                #Validando el tipo de dato de cada atributo
                diccionario_respu["cron_id"] = validations.validate_int(jsdata["cron_id"])
                diccionario_respu["tobj_id"] = validations.validate_int(jsdata["tobj_id"])
                diccionario_respu["cron_tipo"] = validations.validate_char(jsdata["cron_tipo"])
                diccionario_respu["cron_periodo"] = validations.validate_varchar(jsdata["cron_periodo"], 20)
                diccionario_respu["cron_estado"] = validations.validate_char(jsdata["cron_estado"])
                diccionario_respu["cron_desc"] = validations.validate_varchar(jsdata["cron_desc"],200)
                diccionario_respu["prot_id"] = validations.validate_int(jsdata["prot_id"])
                #validando las foreign keys y primary key si el tipo de dato es correcto
                if diccionario_respu["cron_id"][0] is True:
                    diccionario_respu["cron_id"] = validations.id_Mae_Cron(int(jsdata["cron_id"]))
                if diccionario_respu["tobj_id"][0] is True:
                    diccionario_respu["tobj_id"] = validations.id_Tipo_Obj(int(jsdata["tobj_id"]))
                if diccionario_respu["prot_id"][0] is True:
                    diccionario_respu["prot_id"] = validations.id_Tab_Prot(int(jsdata["prot_id"]))

                #Validando si esta vacio en caso el tipo de dato haya sido incorrecto
                for key,value in jsdata.items():
                    if key != 'cron_id':
                        if diccionario_respu[key][0] is False:
                            diccionario_respu[key] = validations.validate_empty(value)

                #validando que no haya errores
                for _,value in diccionario_respu.items():
                    if value[0] is False:
                        pass_flag = False
                        break
                #Si no hay errores entra a modificar
                if pass_flag is True:
                    obj = MAE_CRON.from_json(jsdata)
                    resp = obj.modificar()
                    obj.buscar_dato()

                else:
                    resp = ["error", ""]

                    for key,respu in diccionario_respu.items():
                        if respu[0] == False:
                            # resp[1] = resp[1]+'-'+nombres[num]+': '+respu[1]+' \n'
                            extra[key] = respu[1]

            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
                resp = ["error", str(e) + " - " + str(exc_type)+ " - " + str(fname) + " - " + str(exc_tb.tb_lineno)]
            linea = {}

            if resp[0] == "ok":
                linea["result"] = "ok"
                linea["data"] = obj.get_diccionario()
                
                #Como la respuesta es correcta se guarda en el log de acciones
                usu_id = s.get_id_Usu(str(tk))
                filename = os.path.basename(__file__).split('.')[0]
                obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se modifico el cron con el siguiente PK cron_id: '+str(jsdata["cron_id"]),log_acc_id = 411)
                resp_log = obj_log.guardar_dato()
                if resp_log[0] == 'error':
                    linea['result'] = "failed"
                    linea['error'] = "Sucedio un error"
                    linea['error_cod'] = 411
                    status = "400 Internal Server Error"
                    linea['error_val'] = "No se pudo guardar en el log"
            else:
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 411
                status = "400 Internal Server Error"

                if bool(extra):
                    linea["val_errors"] = extra
                    linea["extra"] = 'extra'
                else:
                    linea["val_errors"] = resp[1]
                    linea["resp"] = 'resp'
        else:
            linea = {}
            linea["result"] = "failed"
            linea["error"] = "Sucedio un error -cookie:" + str(cookie)
            linea["error_cod"] = 410
            linea["val_errors"] = "token no valido"
            status = "401 Unauthorized"

    except validations.HttpException as e:
        linea = {}
        linea["result"] = "failed"
        linea["error_cod"] = e.code
        linea["error"] = e.message
        linea["val_errors"] = e.message
        status = e.status_code

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea = {}
        linea["result"] = "failed"
        linea["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        linea["error_cod"] = 413
        linea["val_errors"] = "token no validado"
        status = "500 Internal Server Error"

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
