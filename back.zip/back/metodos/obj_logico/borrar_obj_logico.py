import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_OBJETO_LOGICO import MAE_OBJETO_LOGICO
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
from clsSession import Session
import validations


def application(environ, start_response):
    try:
        jsdato = ""
        extra = {}
        status = "200 OK"
        if environ['REQUEST_METHOD'] != 'DELETE' and environ['REQUEST_METHOD'] != 'POST':
            #status = "405 Method Not Allowed"
            raise validations.HttpException(405)
        
        lendata = int(environ.get("CONTENT_LENGTH", 0))
        bydata = environ["wsgi.input"].read(lendata)
        jsdata = json.loads(bydata.decode("utf-8"))
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
            # dataIP = environ['HTTP_X_FORWARDED_FOR']
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):
            jsdato = s.get_Datos_Usu(str(tk))
            try:
                respu1 = validations.validate_int(jsdata["obj_id"])
                respu2 = validations.validate_int(jsdata["log_id"])
                if respu1[0] and respu2 [0] == True:
                    respu3 = validations.id_Mae_Obj_Log(int(jsdata["obj_id"]),int(jsdata["log_id"]))
                else:
                    respu3 = [False, "No se tiene un obj_id & log_id correctos"]
                
                list_respu = [respu1, respu2, respu3]
                nombres = ["obj_id", "log_id", "obj_id & log_id"]
                # se busca si todos los datos son correctos
                if respu1[0] and respu2[0] and respu3[0] :
                    obj = MAE_OBJETO_LOGICO(
                        int(jsdata["obj_id"]), int(jsdata["log_id"])
                    )
                    lista = obj.borrar()
                    if lista['result'] == "ok":
                        resp = ["ok", " "]
                    else:
                        resp = ["error", lista['val_errors']]
                else:
                    resp = ["error", ""]
                    num = 0
                    for respu in list_respu:
                        if respu[0] == False:
                            # resp[1] = resp[1]+'-'+respu[1]+'\n'
                            extra[nombres[num]] = respu[1]
                        num = num + 1

            except Exception as e:
                resp = ["error", str(e)]
                status = "400 Internal Server Error"
        else:
            resp = ["error", "token no validado"]
            status = "401 Unauthorized"

        linea = {}
        if resp[0] == "ok":
            linea = {}
            linea["result"] = "ok"
            #linea["descripcion"] = "Se borro correctamente" + str(resp)
            #Como la respuesta es correcta se guarda en el log de acciones
            usu_id = s.get_id_Usu(str(tk))
            filename = os.path.basename(__file__).split('.')[0]
            obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se borro el objeto logico con el siguiente PK log_id: '+str(jsdata["log_id"])+'  obj_id: '+str(jsdata["obj_id"]),log_acc_id = 486)
            resp_log = obj_log.guardar_dato()
            if resp_log[0] == 'error':
                linea['result'] = "failed"
                linea['error'] = "Sucedio un error"
                linea['error_cod'] = 411
                status = "400 Internal Server Error"
                linea['error_val'] = "No se pudo guardar en el log"

        else:
            linea["result"] = "failed"
            linea["error"] = "Sucedio un error"
            linea["error_cod"] = 412
            if bool(extra):
                linea["val_errors"] = extra
            else:
                linea["val_errors"] = resp[1]
    except validations.HttpException as e:
        linea = {}
        linea["result"] = "failed"
        linea["error_cod"] = e.code
        linea["error"] = e.message
        linea["val_errors"] = e.message
        status = e.status_code
    
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        resp = [
            "error",
            "token no validado"
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno),
        ]
        status =  "500 Internal Server Error"


    

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]