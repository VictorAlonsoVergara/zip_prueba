import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_USUARIOS_MENU import MAE_USUARIOS_MENU
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
from clsSession import Session
import validations
import generico


def application(environ, start_response):
    try:
        jsdato = ""
        linea = {}
        status = "200 OK"  # se crea la respuesta de estado
        lendata = int(environ.get("CONTENT_LENGTH", 0))
        bydata = environ["wsgi.input"].read(lendata)
        jsdata = json.loads(bydata.decode("utf-8"))
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)  # se obtiene la informacion del cookie
        tk = s.getCookie(
            cookie, "token"
        )  # se escoge la informacion guardada en la variable token

        if s.valToken(tk) and s.valIp(
            tk, str(dataIP)
        ):  # se valida si el token esta validado

            answer1 = validations.id_Mae_Usu(jsdata["usu_id"])
            if answer1[0]:
                jsdato = s.get_Datos_Usu(str(tk))
                usu_id = s.get_id_Usu(str(tk))
                obj_log = LOG_ACCIONES_USUARIO(
                    log_usu_id=usu_id,
                    log_desc="Se edito el usuario_menu con el siguiente PK umenu_id: "
                    + str(jsdata["datos"]),
                    log_acc_id=513,
                )
                linea = MAE_USUARIOS_MENU.editar_menu(jsdata["usu_id"], jsdata["datos"])
            else:
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 411
                linea["val_errors"] = answer1[1]
                status = "400 Internal Server Error"
        else:
            linea["result"] = "failed"
            linea["error"] = "Sucedio un error"
            linea["error_cod"] = 411
            linea["val_errors"] = "token no validado"
            status = "401 Unauthorized"
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea["result"] = "failed"
        linea["error"] = "Sucedio un error"
        linea["error_cod"] = 411
        linea["val_errors"] = (
            str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )
        status = "500 Internal Server Error"

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
