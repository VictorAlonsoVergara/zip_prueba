import sys, os

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_MARCAS import MAE_MARCAS
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations


def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""
        extra = {}
        status = "500 Internal Server Error"
        if environ['REQUEST_METHOD'] != 'PUT' and environ['REQUEST_METHOD'] != 'POST':
            #status = "405 Method Not Allowed"
            raise validations.HttpException(405)
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):
            jsdato = s.get_Datos_Usu(str(tk))
            lendata = int(environ.get("CONTENT_LENGTH", 0))
            bydata = environ["wsgi.input"].read(lendata)
            jsdata = json.loads(bydata.decode("utf-8"))
            try:
                extra = {}
                respuestas_dict = {}
                pass_flag = True

                respuestas_dict["marca_id"] = validations.validate_int(jsdata["marca_id"])
                respuestas_dict["marca_desc"] = (validations.validate_varchar(jsdata["marca_desc"], 100))
                respuestas_dict["marca_estado"] = (validations.validate_char(jsdata["marca_estado"]))

                if respuestas_dict["marca_id"][0] is True:
                    respuestas_dict["marca_id"] = (validations.id_Mae_Marcas(int(jsdata["marca_id"])))

                for key,value in jsdata.items():
                    if key != 'marca_id':
                        if respuestas_dict[key][0] is False:
                            respuestas_dict[key] = validations.validate_empty(value)

                for _,value in respuestas_dict.items():
                    if value[0] is False:
                        pass_flag = False
                        break

                if pass_flag is True:
                    obj = MAE_MARCAS.from_json(jsdata)
                    resp = obj.modificar()
                    status = "200 OK"
                else:
                    resp = ["error", ""]

                    for key,respu in respuestas_dict.items():
                        if respu[0] == False:
                            # resp[1] = resp[1]+'-'+respu[1]+'\n'
                            extra[key] = respu[1]
                    status = "400 Bad Request"
            except Exception as e:
                resp = ["error", str(e)]
                status = "400 Bad Request"
            linea = {}

            if resp[0] == "ok":
                linea["result"] = "ok"
                linea["data"] = obj.get_diccionario()
                '''linea["marca_id"] = obj.marca_id
                linea["marca_estado"] = obj.marca_estado
                linea["marca_desc"] = obj.marca_desc   '''             
                # linea["respuEmpty"] = respuEmpty[0]
                usu_id = s.get_id_Usu(str(tk))
                filename = os.path.basename(__file__).split('.')[0]
                obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se modifico la marca con el siguiente PK marca_id: '+str(jsdata["marca_id"]),log_acc_id = 490)
                resp_log = obj_log.guardar_dato()
                if resp_log[0] == 'error':
                    linea['result'] = "failed"
                    linea['error'] = "Sucedio un error"
                    linea['error_cod'] = 411
                    status = "500 Internal Server Error"
                    linea['error_val'] = "No se pudo guardar en el log"
            else:
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 412
                if bool(extra):
                    linea["val_errors"] = extra
                else:
                    linea["val_errors"] = resp[1]
                    # linea["val_errors2"] = resp[2]
        else:
            linea = {}

            linea["result"] = "failed"
            linea["error"] = "Sucedio un error -cookie:" + str(cookie)
            linea["error_cod"] = 412
            linea["val_errors"] = "token no valido"
            status = "401 Unauthorized"

    except validations.HttpException as e:
        linea = {}
        linea["result"] = "failed"
        linea["error_cod"] = e.code
        linea["error"] = e.message
        linea["val_errors"] = e.message
        status = e.status_code

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea = {}

        linea["result"] = "failed"
        linea["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        linea["error_cod"] = 420
        linea["val_errors"] = "token no validado  "
        status = "500 Internal Server Error"


    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
