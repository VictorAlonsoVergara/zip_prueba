import sys

sys.path.insert(0, "/var/python")
sys.path.insert(1, "/home/ernesto/login")

from clsSession import Session
import logging
from cgi import parse_qs, escape


def application(environ, start_response):

    logname = "/var/log/app/traza2.log"
    logging.basicConfig(filename=logname, level=logging.DEBUG)
    logging.info("autentica val")

    # logging.info(environ)
    # sacamos el token del cookie
    cookie = environ.get("HTTP_COOKIE", 0)
    # logging.info(cookie)

    s = Session()
    tk = s.getCookie(cookie, "token")
    logging.info(tk)
    if s.valToken(tk):
        # si el token esta activo y logeado entonces no se necesita autenticar
        output = "ya estas logeado<br><br>"
        s.setAtributo("campo2", "ya logeado")
        s.saveData()
        output += "<br><br><form method='post' action='/tautentica'><input type='submit' value='test sesion'></form>"
    else:
        # tenemos que autenticar o mandar a la pantalla de login
        if len(tk) < 1:
            output = "<br><br>No hay token"
            coo = ""
        else:
            s.setToken(tk)
            # llemos la data pasada por post
            ldata = int(environ.get("CONTENT_LENGTH", 0))
            bdata = environ["wsgi.input"].read(ldata)
            logging.info(bdata)
            data = parse_qs(bdata)
            # logging.info(data)
            d_user = data.get(b"usuario")
            d_pwd = data.get(b"password")
            logging.info(d_user)
            logging.info(d_pwd)

            if d_user != None:
                # valida el usuario
                if s.ValidaUsuario(d_user[0].decode(), d_pwd[0].decode()):
                    output = "logeado<br><br>"
                    # aqui cargamoas data que deseamos nos pasen por un cookie o que se acceda por back
                    s.setAtributo("campo1", "valor1")
                    s.setAtributo("campo2", "valor2")
                    s.setAtributo("nuevo1", "valor01")
                    # grabo esta data en la db
                    s.saveData()
                    output += (
                        "Usuario:"
                        + d_user[0].decode()
                        + "<br>"
                        + "Password:"
                        + d_pwd[0].decode()
                    )
                    output += "<br><br><form method='post' action='/tautentica'><input type='submit' value='test sesion'></form>"

                    # cargo la data guardada para el cookie
                    coo = "datos=" + s.getData()

                else:
                    output = "no logerado<br><br>"
                    coo = ""
            else:
                output = "<br><br>No pasaron datos"
                coo = ""

    output = output.encode()
    status = "200 OK"
    response_headers = [
        ("Content-type", "text/html"),
        ("Content-Length", str(len(output))),
        ("set-cookie", coo),
    ]
    # response_headers=[('Content-type','text/html'),('Content-Length',str(len(output)))]
    start_response(status, response_headers)
    return [output]
