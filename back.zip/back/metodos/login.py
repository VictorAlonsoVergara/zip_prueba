import sys

sys.path.insert(0, "/var/python")
sys.path.insert(1, "/home/ernesto/login")

from clsSession import Session
import random
import logging
import requests


def application(environ, start_response):

    logname = "/var/log/app/traza2.log"
    logging.basicConfig(filename=logname, level=logging.DEBUG)
    logging.info("autentica login")

    s = Session()
    s.generaToken()
    tk = s.getToken()
    logging.info(tk)

    status = "200 OK"
    output = b'<form method="POST" action="autentica/"> Hola<br><br>Usuario:<input name="usuario" type="text"><br><br>Password:<input type="text" name="password"><br><br><input type="submit"></form>'
    coo = "token=" + tk
    response_headers = [
        ("Content-type", "text/html"),
        ("Content-Length", str(len(output))),
        ("set-cookie", coo),
    ]
    start_response(status, response_headers)
    return [output]
