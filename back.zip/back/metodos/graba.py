import logging
from cgi import parse_qs, escape


def application(environ, start_response):

    logname = "/var/log/app/traza.log"
    logging.basicConfig(filename=logname, level=logging.DEBUG)
    logging.info("ENTRO")

    logging.info(environ)
    ldata = int(environ.get("CONTENT_LENGTH", 0))
    bdata = environ["wsgi.input"].read(ldata)
    logging.info(bdata)

    data = parse_qs(bdata)
    logging.info(data)
    d_nombre = data.get(b"nombre")
    d_apellido = data.get(b"apellido")
    logging.info(d_nombre)
    logging.info(d_apellido)

    status = "200 OK"
    output = (
        "Nombre:"
        + d_nombre[0].decode()
        + "</br>"
        + "Sobrenome:"
        + d_apellido[0].decode()
    )
    output = output.encode()

    response_headers = [
        ("Content-type", "text/html"),
        ("Content-Length", str(len(output))),
    ]
    start_response(status, response_headers)
    return [output]
