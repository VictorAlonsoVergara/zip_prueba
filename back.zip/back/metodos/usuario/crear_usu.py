import sys ,os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_USUARIOS import MAE_USUARIOS
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
from clsSession import Session
import validations
import generico

def application(environ, start_response):
    try: 
        coo = ""
        jsdato = ""
        extra = {}
        status = "200 OK"  # se crea la respuesta de estado
        if environ['REQUEST_METHOD'] != 'POST':
            raise validations.HttpException(405)
        lendata = int(environ.get("CONTENT_LENGTH", 0))  # se guarda los datos enviados
        bydata = environ["wsgi.input"].read(lendata)
        jsdata = json.loads(bydata.decode("utf-8"))  # se convierte los datos y json
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)  # se obtiene la informacion del cookie
        tk = s.getCookie(cookie, "token")  
        if (s.valToken(tk) and s.valIp(tk, str(dataIP))):  
            jsdato = s.get_Datos_Usu(str(tk))  
            try:
                #se valida que los datos recibidos por el json sean correctos
                diccionario_respu = {}
                pass_flag = True
                usu_id = s.get_id_Usu(str(tk))
                diccionario_respu['usu_nombre'] = validations.validate_varchar(jsdata["usu_nombre"], 300) 
                diccionario_respu['tusu_id'] = validations.validate_int(jsdata["tusu_id"])
                diccionario_respu['usu_estado'] = validations.validate_char(jsdata["usu_estado"])
                diccionario_respu['usu_correo'] = validations.validate_varchar(jsdata["usu_correo"], 100)
                diccionario_respu['usu_usuario'] = validations.validate_varchar(jsdata["usu_usuario"], 50)
                diccionario_respu['usu_password'] = validations.validate_clave(jsdata["usu_password"])
                diccionario_respu['idi_id'] = validations.validate_int(jsdata["idi_id"])
                diccionario_respu['area_id'] = validations.validate_int(jsdata["area_id"])
                diccionario_respu['usu_usuario_creador'] = validations.validate_int(usu_id)

                if diccionario_respu['usu_nombre'][0]  is True:
                    diccionario_respu['usu_nombre'] = validations.usu_nombre(jsdata["usu_nombre"])
                if diccionario_respu['usu_usuario'][0]  is True:
                    diccionario_respu['usu_usuario'] = validations.usu_usuario(jsdata["usu_usuario"])
                if diccionario_respu['usu_correo'][0]  is True:
                    diccionario_respu['usu_correo'] = validations.usu_correo(jsdata["usu_correo"])
                if diccionario_respu['tusu_id'][0]  is True:
                    diccionario_respu['tusu_id'] = validations.id_Tipo_Usu(int(jsdata["tusu_id"]))
                if diccionario_respu['idi_id'][0]  is True:
                    diccionario_respu['idi_id'] = validations.id_Mae_Idiomas(int(jsdata["idi_id"]))
                if diccionario_respu['area_id'][0]  is True:
                    diccionario_respu['area_id'] = validations.id_Mae_Area(int(jsdata["area_id"]))
                if diccionario_respu['usu_estado'][0] is True:
                    diccionario_respu['usu_estado'] = validations.validate_parametro('estado_usuario',jsdata['usu_estado'])
                if diccionario_respu['usu_usuario_creador'][0] is True:
                    jsdata["usu_usuario_creador"] = usu_id

                #se escribe los mensajes de error 
                for key,value in jsdata.items():
                    value_empty = validations.validate_empty(value)
                    if value_empty[0] is True:
                        diccionario_respu[key] = value_empty
                        diccionario_respu[key][0] = False

                #se verifica que las respuestas sean correctas
                for _,value in diccionario_respu.items():
                    if value[0] is False:
                        pass_flag = False
                        break
                #en caso las respuestas sean correctas se realiza la accion correspondiente 
                if pass_flag is True:
                    obj = MAE_USUARIOS.from_json(jsdata)

                    resp = obj.guardar_dato()
                    obj.buscar_dato()  
                else:
                    resp = ["error", ""]
                    num = 0
                    for key,respu in diccionario_respu.items():
                        if respu[0] == False:
                            
                            extra[key] = respu[1]
                        num = num + 1
                linea = {}
                if resp[0] == "ok":
                    linea["result"] = "ok"
                    linea["data"] = obj.get_diccionario()             
                    #Como la respuesta es correcta se guarda en el log de acciones
                    usu_id = s.get_id_Usu(str(tk))
                    filename = os.path.basename(__file__).split('.')[0]
                    obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se creo el usuario con el siguiente PK usu_id: '+str(obj.usu_id),log_acc_id = 395)
                    resp_log = obj_log.guardar_dato()
                    if resp_log[0] == 'error':
                        linea['result'] = "failed"
                        linea['error'] = "Sucedio un error"
                        linea['error_cod'] = 411
                        status = "400 Bad Request"

                        linea['val_errors'] = "No se pudo guardar en el log"
                else:
                    linea["result"] = "failed"
                    linea["error"] = "Sucedio un error"
                    linea["error_cod"] = 412
                    status = "400 Bad Request"

                    if bool(extra):
                        linea["val_errors"] = extra
                        #linea["tipo"] = "extra"
                    else:
                        linea["val_errors"] = resp[1]
            #en caso de error se entra al exception del programa
            except Exception as e:
                linea = {}
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
                resp = ["error", str(e)+' '+str(exc_type)+" "+str(fname)+" "+str(exc_tb.tb_lineno)]
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 412
                linea["val_errors"] = resp[1]
                status = "500 Internal Server Error"
        else:
            resp = ["error", "Token no validado"]#+str(tk)+" "+str(dataIP)]
            raise validations.HttpException(401,"Token no validado")
            status = "401 Unauthorized"

    except validations.HttpException as e:
        linea = {}
        linea.update(e.get_error_dict())
        status = e.status_code

    except Exception as e:
        linea = {}
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        resp = ["error", str(e)+' '+str(exc_type)+" "+str(fname)+" "+str(exc_tb.tb_lineno)]
        linea["result"] = "failed"
        linea["error"] = "Sucedio un error"
        linea["error_cod"] = 412
        linea["val_errors"] = resp[1]
        status = "500 Internal Server Error"

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
