import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_USUARIOS import MAE_USUARIOS
from clsSession import Session
import validations
import generico


def application(environ, start_response):
    try:
        coo = ""
        jsdato = ""
        status = "200 OK"  # se crea la respuesta de estado
        if environ['REQUEST_METHOD'] != 'GET':
            #status = "405 Method Not Allowed"
            raise validations.HttpException(405)
        bdata = environ["PATH_INFO"]  # se guarda el dato puesto en el url

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        respuest = validations.validate_int(bdata.split("/")[1])
        s = Session()  # se crea la sesion
        cookie = environ.get("HTTP_COOKIE", 0)  
        tk = s.getCookie(cookie, "token")  
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)): 

            jsdato = s.get_Datos_Usu(str(tk))  
            
            if respuest[0] == True:
                obj = MAE_USUARIOS(usu_id = int(bdata.split("/")[1]))
                dato = obj.buscar_dato()  
                respuest2 = generico.buscaParametro("estado_usuario", obj.usu_estado)  
                if dato[0] == "ok":
                    data = {}
                    data.update(obj.get_diccionario())
                    data["usu_estado_desc"] = respuest2
                else:
                    data = {}
                    data["result"] = "failed"
                    data["error"] = "Sucedio un error"
                    data["error_cod"] = 411
                    data["val_errors"] = dato[1]
                    status = "400 Bad Request"
                    # data['IP'] = dataIP
                    # data['environ'] = str(environ)

            else:
                data = {}
                data["result"] = "failed"
                data["error"] = "Sucedio un error"
                data["error_cod"] = 412
                data["val_errors"] = respuest[1]
                status = "400 Bad Request"
                # data['IP'] = dataIP
                # data['environ'] = str(environ)

        else:
            data = {}
            data["result"] = "failed"
            data["error"] = "Sucedio un error con el token:" + str(tk)
            data["error_cod"] = 413
            data["val_errors"] = "token no validado"
            status = "401 Unauthorized"
      

    except validations.HttpException as e:
        data = {}
        data.update(e.get_error_dict())
        status = e.status_code
    
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        data = {}
        data["result"] = "failed"
        data["error"] = (
            "Sucedio un error"
            + str(e)
            + " -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        data["error_cod"] = 414
        data["val_errors"] = "token no validado"
        status = "500 Internal Server Error"
        # data['IP'] = dataIP
        # data['environ'] = str(environ)

    preoutput = json.dumps(data)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
