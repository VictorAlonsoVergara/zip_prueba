import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_USUARIOS import MAE_USUARIOS
from MAE_USUARIOS_MENU import MAE_USUARIOS_MENU
from MAE_TIPO_USU import MAE_TIPO_USU
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations
from clsSession import Session


def application(environ, start_response):
    status = "200 OK"  # se crea la respuesta de estado
    lendata = int(environ.get("CONTENT_LENGTH", 0))  
    bydata = environ["wsgi.input"].read(lendata)  
    jsdata = json.loads(bydata.decode("utf-8")) 
    s = Session()  
    s.generaToken()  
    tk = s.getToken()  
    try:
        dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
    except KeyError:
        dataIP = environ["REMOTE_ADDR"]
    coo = "token=" + tk + "; path=/"  # se guarda la informacion en una cadena
    jsdato = ""
    coo2 = ""
    try:
        extra = {}
        #se valida que los datos recibidos en el json son correctos
        respu1 = validations.validate_varchar(jsdata["usu_usuario"], 50)  
        respu2 = validations.validate_varchar(jsdata["usu_password"], 2048)  
        list_respu = [respu1, respu2]
        nombres = ["usu_usuario", "usu_password"]
        #en caso no se encuentre algun error en las validaciones anteriores se realizara la accion
        if (respu1[0] == True and respu2[0] == True):
            resp = MAE_USUARIOS.verificar_usuario(jsdata["usu_usuario"], jsdata["usu_password"])
            if resp[0] == "ok":
                s.ValidaToken(int(resp[2]), dataIP)  
                jsdato = s.get_Datos_Usu(str(tk))  
            else:
                status = "400 Bad Request"
        else:
            resp = [
                "error",
                "",
            ]  
            num = 0
            for respu in list_respu:  # se busca en donde fue el error y se guarda la respuesta
                if respu[0] == False:
                    extra[nombres[num]] = respu[1]
                num = num + 1

    except Exception as e:  # en caso de algun error que entre en Exception
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        status = "500 Internal Server Error"
        resp = [
            "error",
            "Error en " + str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
    linea = {}
    if resp[0] == "ok":
        linea["result"] = "ok"  # -cookie :" + str(tk) + " *fin "
        linea["usu_id"] = resp[2]
        temporal = MAE_USUARIOS_MENU.devol_menu(resp[2])
        #if 'menus' in temporal :
        linea["menus"] = temporal
        #else:
        #    linea["menus"] = []

        obj2 = MAE_TIPO_USU(tusu_id=resp[3])
        ejemplo = obj2.buscar_dato()
        linea["tipo_usu"] = obj2.get_diccionario()

        #Como la respuesta es correcta se guarda en el log de acciones
        usu_id = resp[2]
        filename = os.path.basename(__file__).split('.')[0]
        obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se autentico el usuario con el siguiente PK usu_id: '+str(resp[2]),log_acc_id = 398)
        resp_log = obj_log.guardar_dato()
        if resp_log[0] == 'error':
            linea['result'] = "failed"
            linea['error'] = "Sucedio un error"
            linea['error_cod'] = 411
            status = "500 Internal Server Error"
            linea['error_val'] = resp_log[1]#"No se pudo guardar en el log"
    else:
        linea["result"] = "failed"
        linea["error"] = "Sucedio un error"
        linea["error_cod"] = 412
        if bool(extra):
            linea["val_errors"] = extra
        else:
            linea["val_errors"] = resp[1]

    preoutput = json.dumps(linea)  # se crea un json con los datos a mostrar
    output = bytes(preoutput, "utf-8")  # se convierte en bytes
    cook2 = 'dato="' + str(jsdato) + '" ;path=/'
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", coo),
        ("set-cookie", cook2),
    ]
    start_response(status, headers)
    return [output]
