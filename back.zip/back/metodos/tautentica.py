import sys

sys.path.insert(0, "/var/python")
sys.path.insert(1, "/home/ernesto/login")


from clsSession import Session
import logging
from cgi import parse_qs, escape


def application(environ, start_response):

    logname = "/var/log/app/traza2.log"
    logging.basicConfig(filename=logname, level=logging.DEBUG)
    logging.info("autentica test")

    logging.info(environ)

    s = Session()

    cookie = environ.get("HTTP_COOKIE", 0)
    tk = s.getCookie(cookie, "token")
    logging.info(tk)

    if len(tk) < 1:
        output = "<br><br>no hay token"
    else:
        if s.valToken(tk):
            output = "token valido<br><br>"
            output += "esto debe ser cargado en un cookie:" + s.getData()
        else:
            output = "token expirado o no valido"

    status = "200 OK"

    output = output.encode()
    response_headers = [
        ("Content-type", "text/html"),
        ("Content-Length", str(len(output))),
    ]
    start_response(status, response_headers)
    return [output]
