import json

lista = []
for i in range(5):
    data = {}
    data["usu_id"] = "hola"
    data["usu_nombre"] = "chau"
    data["usu_correo"] = "adios"
    data["usu_usuario"] = "tchau"
    lista.append(data)

preoutput = json.dumps(lista)
output = bytes(preoutput, "utf-8")

print(lista)
print(preoutput)
print(output)
