import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_USUARIOS_ALERTAS import MAE_USUARIOS_ALERTAS
from clsSession import Session
import validations


def application(environ, start_response):
    try:
        jsdato = ""
        extra = {}
        status = "500 Internal Server Error"
        if environ['REQUEST_METHOD'] != 'DELETE' and environ['REQUEST_METHOD'] != 'POST':
            #status = "405 Method Not Allowed"
            raise validations.HttpException(405)
        lendata = int(environ.get("CONTENT_LENGTH", 0))
        bydata = environ["wsgi.input"].read(lendata)
        jsdata = json.loads(bydata.decode("utf-8"))
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
            # dataIP = environ['HTTP_X_FORWARDED_FOR']
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)
        if s.valToken(tk) and s.valIp(tk, str(dataIP)):
            jsdato = s.get_Datos_Usu(str(tk))
            try:
                respu1 = validations.validate_int(jsdata["rep_id"])
                respu2 = validations.validate_int(jsdata["usu_id"])
                if respu1[0] and respu2 [0] == True:
                    respu3 = validations.id_Mae_Usu_Aler(int(jsdata["rep_id"]),int(jsdata["usu_id"]))
                else:
                    respu3 = [False, "No se tiene un rep_id y usu_id correctos"]
                
                list_respu = [respu1, respu2, respu3]
                nombres = ["rep_id", "usu_id", "rep_id & usu_id"]
                # se busca si todos los datos son correctos
                if respu1[0] and respu2[0] and respu3[0] :
                    obj = MAE_USUARIOS_ALERTAS(
                        int(jsdata["rep_id"]), int(jsdata["usu_id"])
                    )
                    lista = obj.borrar()
                    if lista['result'] == "ok":
                        resp = ["ok", " "]
                    else:
                        resp = ["error", lista['val_errors']]
                else:
                    resp = ["error", ""]
                    num = 0
                    status = "400 Bad Request"
                    for respu in list_respu:
                        if respu[0] == False:
                            # resp[1] = resp[1]+'-'+respu[1]+'\n'
                            extra[nombres[num]] = respu[1]
                        num = num + 1

            except Exception as e:
                resp = ["error", str(e)]
                status = "400 Bad Request"
            linea = {}
            if resp[0] == "ok":
                linea = {}
                linea["result"] = "ok"
                status = "200 OK"
                usu_id = s.get_id_Usu(str(tk))
                #filename = os.path.basename(__file__).split('.')[0]
                obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se borro el usuario_alerta con el siguiente PK rep_id: '+str(jsdata['rep_id']+' , usu_id: '+str()jsdata['usu_id']),log_acc_id = 453)
                resp_log = obj_log.guardar_dato()   
                if resp_log[0] == 'error':
                    linea['result'] = "failed"
                    linea['error'] = "Sucedio un error"
                    linea['error_cod'] = 411
                    status = "500 Internal Server Error"
                    linea['val_errors'] = "No se pudo guardar en el log"
                #linea["descripcion"] = "Se borro correctamente" + str(resp)+' * '+str(list_respu)
            else:
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 400
                status = "400 Bad Request"
                if bool(extra):
                    linea["val_errors"] = extra
                else:
                    linea["val_errors"] = resp[1]
        else:
            linea = {}
            linea["result"] = "failed"
            linea["error"] = "Sucedio un error"
            linea["error_cod"] = 401
            linea["val_errors"] = "token no validado"
            resp = ["error", "token no validado"]
            status = "401 Unauthorized"
        
    except validations.HttpException as e:
        linea = {}
        linea["result"] = "failed"
        linea["error_cod"] = e.code
        linea["error"] = e.message
        linea["val_errors"] = e.message
        status = e.status_code

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea = {}
        linea["result"] = "failed"
        linea["error"] = "Sucedio un error"
        linea["error_cod"] = 500
        linea["val_errors"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        status = "500 Internal Server Error"

    

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]


"""

			if(respuest1[0] == True and respuest2[0] == True):
				respu = validations.id_Mae_Usu_Aler(bdata2.split('-')[0],bdata2.split('-')[1])

				if (respu[0]):
					obj =  MAE_USUARIOS_ALERTAS(int(bdata2.split('-')[0]),int(bdata2.split('-')[1]))
					resp = obj.borrar()
				else:
					resp = {}
					resp['result'] = "failed"
					resp['error'] = "Sucedio un error"
					resp['error_cod'] = 412
					resp['val_errors'] = "No existe un MAE_USUARIOS_ALERTAS con esos ID"
			else:
				resp = {}
				resp['result'] = "failed"
				resp['error'] = "Sucedio un error"
				resp['error_cod'] = 412
				resp['val_errors'] = "ind:id"+respuest1[1]+" usu_id:"+respuest2[1]
		else :
			resp = {}
			resp['result'] = "failed"
			resp['error'] = "Sucedio un error -cookie:"+str(cookie)
			resp['error_cod'] = 412
			resp['val_errors'] = "token no validado"
	except Exception as e :
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]		
		resp = {}
		resp['result'] = "failed"
		resp['error'] = "Sucedio un error -cookie: "+str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)#+str(cookie)
		resp['error_cod'] = 412
		resp['val_errors'] = "token no validado"				


	preoutput = json.dumps(resp)
	output = bytes(preoutput, 'utf-8')
	cook = 'dato="'+str(jsdato)+'" ;path=/'
	headers =[('Access-Control-Allow-Origin','http://localhost:4200'),('Access-Control-Allow-Credentials','true'),('set-cookie',cook)]
	start_response(status,headers)
	return [output]"""
