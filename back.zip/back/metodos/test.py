def application(environ, start_response):
    status = "200 OK"
    bdata = environ["PATH_INFO"]
    cdata = environ["QUERY_STRING"]
    output = (
        b'<form method="POST" action="graba/"> Hola path:'
        + bdata.encode()
        + b" query:"
        + cdata.encode()
        + b'<br><br>Nombre:<input name="nombre" type="text"><br><br>Apellido:<input type="text" name="apellido"><br><br><input type="submit"></form>'
    )
    response_headers = [
        ("Content-type", "text/html"),
        ("Content-Length", str(len(output))),
    ]
    start_response(status, response_headers)
    return [output]
