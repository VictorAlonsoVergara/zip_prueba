import pymongo
import gridfs
import os,sys

class MongoDB:
    def __init__(self):
        self.__conn = pymongo.MongoClient(port=27017)
        self.__db = self.__conn.cotener_files
        self.colection_name = 'files_store'
        self.colection = self.__db[self.colection_name]

    def find(self,query_dict):
        try:
            result = self.colection.find(query_dict)
            respuesta = ['ok',result]
        except Exception as e:
            exc_type, _, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            respuesta = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
        finally:
            return respuesta
    def insert(self,doc_data):
        try:
            result = self.colection.insert_one(doc_data)
            respuesta = ['ok',result.inserted_id]
        except Exception as e:
            exc_type, _, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            respuesta = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
        finally:
            return respuesta
    def put_file(self,file,name):
        try:
            fs = gridfs.GridFS(database = self.__db,collection = self.colection_name)
            res = fs.put(file,filename= name)
            respuesta = ['ok',res]
        except Exception as e:
            exc_type, _, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            respuesta = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
        finally:
            return respuesta