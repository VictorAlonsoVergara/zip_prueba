import logging

from clases.snmp_connection import SNMP
from clases.ssh_connection import SSH
from clases.ssh_ejecuciones_conection import SSH_Ejecuciones
from clases.ssh_multiple_connection import  SSH_Multiple
from clases.telnet_multiple_connection import Telnet_Multiple
from clases.telnet_connection import Telnet_Connection
from clases.telnet_ejecuciones_connection import Telnet_Ejecuciones

log = logging.getLogger("programador_tareas")

class Dispositivo:
    def __init__(self, protocolo,hostname,user,password,port,community,comando):
        self.protocolo = protocolo.lower()
        self.hostname = hostname
        self.username = user
        self.password = password
        self.port = port
        self.community = community
        self.comando = comando
        self.connection = None
        self.__lazy_conn = False
    
    def conectar(self):
        try:
            if self.protocolo == 'snmp' or self.protocolo == 's':
                self.connection = SNMP(self.hostname,self.community,self.comando)
            elif self.protocolo == 'ssh':
                self.connection = SSH(self.hostname,self.username,self.password,self.port,self.comando)
            elif self.protocolo == 'ssh_lazy' or self.protocolo == 'h':
                self.__lazy_conn = True
                self.connection = SSH_Ejecuciones(self.hostname,self.username,self.password,self.port,self.comando)
            elif self.protocolo == 'ssh_multiplo':
                self.connection = SSH_Multiple(self.hostname,self.username,self.password,self.port,self.comando)
            elif self.protocolo == 'telnet_multiplo':
                self.connection = Telnet_Multiple(self.hostname,self.username,self.password,self.comando)
            elif self.protocolo == 'telnet' or self.protocolo == 't':
                self.__lazy_conn = True
                #self.connection = Telnet_Connection(hostname,user,password,comando)
                self.connection = Telnet_Ejecuciones(self.hostname,self.username,self.password,self.comando)
            else:
                raise Exception("No se ha encontrado el protoclo %s"%self.protocolo)
            log.debug("[Dispositivo] -- Conectado a traves de %s",self.protocolo)
        except Exception as e:
            log.exception("[Dispositivo] -- Error al conectar a traves de %s: %s",self.protocolo,e)

    def ejecutar(self):
        return self.connection.ejecutar()

    def es_lazy(self):
        return self.__lazy_conn

    def conectar_lazy(self):
        self.connection.conectar()

    def desconectar_lazy(self):
        self.connection.desconectar()

    def is_connected(self):
        if self.connection is None:
            return False
        else:
            return True