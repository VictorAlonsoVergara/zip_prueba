import logging
from time import ctime

from clases.dispositivo import Dispositivo
from clases.Hilo import Hilo
log = logging.getLogger("programador_tareas")

class Controlador_Multiple:
    def __init__(self,maxHilos,ejecuciones,datos_dispositivos):
        self.datos_dispositivos = datos_dispositivos
        self.maxHilos = maxHilos
        self.ejecuciones = ejecuciones

    def ejecutar(self):
        numHilo = 0
        dict_respuestas = {}
        log.info("[Controlador_Multiple] -- Hilos empezando -- %s",ctime())
        while numHilo < len(self.datos_dispositivos):
            hilos = []
            for ind in range(len(self.datos_dispositivos)):
                if ind >= self.maxHilos:
                    break
                dato = self.datos_dispositivos[numHilo]
                disp = Dispositivo(dato['protocolo'],
                                    dato['hostname'],
                                    dato['user'],
                                    dato['password'],
                                    dato['port'],
                                    dato['community'],
                                    dato['comando'])
                disp.conectar()
                h = Hilo(dato['id'],disp,self.ejecuciones,dict_respuestas)
                hilos.append(h)
                numHilo += 1

            for hilo in hilos:
                hilo.start()

            for hilo in hilos:
                hilo.join()
        log.info("[Controlador_Multiple] -- Hilos terminando -- %s",ctime())
        return dict_respuestas