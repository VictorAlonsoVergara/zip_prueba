import logging
import traceback
from threading import Thread,RLock,Lock
from datetime import datetime,timezone,timedelta

from clases.dispositivo import Dispositivo

log = logging.getLogger("programador_tareas")

class Hilo(Thread):
    def __init__(self,num,dispositivo,ejecuciones,dict_answers,lock = None):
        self.numero = num
        self.dispositivo = dispositivo
        self.ejecuciones = ejecuciones
        self.dict_answers = dict_answers
        self.lock = lock
        super(Hilo,self).__init__()
    
    def run(self):
        try:
            self.dict_answers[self.numero] = {}
            self.dict_answers[self.numero]['inicio'] = datetime.now(timezone(timedelta(hours=-5)))
            if self.dispositivo.es_lazy():
                datos_dispositivo = (self.dispositivo.protocolo,
                                        self.dispositivo.hostname,
                                        self.dispositivo.username,
                                        self.dispositivo.password,
                                        self.dispositivo.port,
                                        self.dispositivo.community,
                                        self.dispositivo.comando)
                self.dispositivo = None
                self.dispositivo = Dispositivo(*datos_dispositivo)
                self.dispositivo.conectar()
                self.dispositivo.conectar_lazy()
            respuestas = []
            for _ in range(self.ejecuciones):
                try:
                    if self.lock is not None:
                        self.lock.acquire()
                    if self.dispositivo.is_connected():
                        respuesta = self.dispositivo.ejecutar()
                    else:
                        raise Exception("No se ha podido conectar")
                    if self.lock is not None:
                        self.lock.release()
                    log.info("[Hilo] -- Respuesta de en hilo %d: %s",self.numero,respuesta)
                except Exception as e:
                    respuesta = str(e)
                    log.exception("[Hilo] -- Error en ejecucion en hilo %d: %s",self.numero,e)
                finally:
                    respuestas.append(str(respuesta) + '\n')
            
            if self.dispositivo.es_lazy():
                self.dispositivo.desconectar_lazy()
            log.debug("[Hilo] -- Fin de hilo %d",self.numero)
            self.dict_answers[self.numero]['respuestas'] = respuestas
        except Exception as e:
            self.dict_answers[self.numero]['error'] = str(e)
            log.exception("[Hilo] -- Error en hilo %d: %s"%(self.numero,e))
        finally:
            self.dict_answers[self.numero]['fin'] = datetime.now(timezone(timedelta(hours=-5)))

    def __del__(self):
        pass
        #print("Hello from Hilo destructor")
        #logging.debug("[Hilo] -- Hello from del")
