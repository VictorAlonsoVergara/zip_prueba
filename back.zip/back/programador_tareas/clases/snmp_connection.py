from easysnmp import Session,snmp_get


class SNMP:
    def __init__(self,host,com,comando):
        self.command = comando
        self.host = host
        self.community = com
        #self.session = Session(hostname=host,community=com,version=2)
    def ejecutar(self):
        #list_respuesta = []
        #for cmd in self.command:
        respuesta = snmp_get(self.command,hostname=self.host,community=self.community,version=2)
            #respuesta = self.session.get(self.command)
        #    list_respuesta.append(respuesta)
        return respuesta
    def __del__(self):
        pass