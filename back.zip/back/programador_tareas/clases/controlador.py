import logging
from time import perf_counter_ns,ctime

from clases.dispositivo import Dispositivo
from clases.Hilo import Hilo

log = logging.getLogger("programador_tareas")

class Controlador_Hilos:
    def __init__(self,tipo_conexion,numHilos,ejecuciones,lock,hostname,user,password,port,community,comando):
        self.dispositivo = Dispositivo(tipo_conexion,hostname,user,password,port,community,comando)
        if tipo_conexion != 'telnet':
            self.dispositivo.conectar()
        self.hilos = []
        self.numHilos = numHilos
        self.ejecuciones = ejecuciones
        self.tipo_conexion = tipo_conexion
        self.lock = lock
    
    def ejecutar(self):
        try:
            log.info("[Controlador] -- Hilos empezando -- %s",ctime())
            inicio = perf_counter_ns()
            for n in range(self.numHilos):
                h = Hilo(n,self.dispositivo,self.ejecuciones,self.lock)
                self.hilos.append(h)
                self.hilos[-1].start()
            log.info("[Controlador] -- Hilos ejecutando")

            for hilo in self.hilos:
                hilo.join()
            fin = perf_counter_ns()
            nano = fin-inicio
            sec = nano / 1000000000
            log.info("[Controlador] -- Tiempo de procesamiento en nanosegundos: %d",(nano))
            log.info("[Controlador] -- Tiempo de procesamiento en segundos: %d",(sec))
            print("Tiempo de ejecución: %d"%sec)
        except Exception as e:
            log.error("[Controlador] -- Error inesperado: %s",e)
        
