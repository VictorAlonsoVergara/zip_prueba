import time
import logging
import datetime
import sys,os

from clases.ejecuciones import Ejecuciones
from clases.ejecuciones_objeto import Ejecuciones_Objeto

log = logging.getLogger("programador_tareas")

class Tarea:
    def __init__(self,nombre,funcion,intervalo,estado,tipo,tipo_objeto):
        self.nombre = nombre
        self.__periodo = intervalo
        self.__intervalo = None
        self.__timer = 0
        self.__estado = estado
        self.__tarea = funcion
        self.__tipo = tipo
        self.__tipo_objeto = tipo_objeto

        self.__start_timer()

    def __start_timer(self):
        if self.__tipo is 'F':#Hora exacta
            self.__intervalo = time.strptime(self.__periodo,"%H:%M:%S")
        else:
            self.__periodo = str(self.__periodo)[1:]
            if self.__tipo is 'D':#Cada numero de dias
                dias = int(self.__periodo)
                horas =  dias*24
                minutos = horas*60
                segundos = minutos*60
                self.__intervalo = segundos

            elif self.__tipo is 'H':#Cada numero de horas
                horas = int(self.__periodo)
                minutos = horas*60
                segundos = minutos*60
                self.__intervalo = segundos

            elif self.__tipo is 'M':#Cada numero de minutos
                minutos = int(self.__periodo)
                segundos = minutos*60
                self.__intervalo = segundos
            elif self.__tipo is 'S':
                self.__intervalo = int(self.__periodo)
            else:
                raise Exception("El dato ingresado no esta en los parametros definidos")

    def __is_running(self):
        if self.__estado is 'A':
            return True
        elif self.__estado is 'D' or self.__estado is 'E':
            return False
        else:
            raise Exception("Dato ingresado no esta en los parametros definidos")
    def __is_active(self):
        if self.__estado != 'E':
            return True
        else:
            return False
    
    def update_datos(self,intervalo,estado,tipo):
        if self.__periodo != intervalo or self.__tipo != tipo:
            self.__tipo = tipo
            self.__periodo = intervalo
            self.__start_timer()
            self.__timer = 0
        if self.__estado != estado:
            self.__estado = estado
            self.__timer = 0
        
    def detener(self):
        self.__estado = 'D'

    def activar(self):
        self.__estado = 'A'
    
    def terminar(self):
        self.__estado = 'E'

    def set_estado(self,estado):
        self.__estado = estado

    def execute(self,time_now):
        while self.__is_active():
            try:
                time_now = time.time()
                if self.__is_running():
                    if self.__tipo is 'F':
                        local_now = time.localtime(time_now)
                        if (local_now.tm_hour == self.__intervalo.tm_hour and
                            local_now.tm_min == self.__intervalo.tm_min and
                            local_now.tm_sec == self.__intervalo.tm_sec):
                            #despues de verificar la hora exacta
                            log.debug("[Tarea] -- Hora Guardada: %s:%s:%s",self.__intervalo.tm_hour,self.__intervalo.tm_min,self.__intervalo.tm_sec)
                            log.info("[Tarea] -- Ejecutando tarea %s.... %s",self.nombre,time.strftime("%d-%m-%y %H:%M:%S"))
                            time_ini = datetime.datetime.now()
                            dict_resp = self.__tarea(self.nombre)#ejecucion de la tarea
                            log.info("[Tarea] -- Tarea terminada %s.... %s",self.nombre,time.strftime("%d-%m-%y %H:%M:%S"))
                            time_fin = datetime.datetime.now()
                            self.__guardar_ejecucion(time_ini,time_fin,dict_resp)
                            time.sleep(1)#sleep de 1 segundo para que la tarea no se vuelva a repetir
                    else:
                        if time_now - self.__timer >= self.__intervalo:
                            log.info("[Tarea] -- Ejecutando tarea %s.... %s",self.nombre,time.strftime("%d-%m-%y %H:%M:%S"))
                            time_ini = datetime.datetime.now()
                            dict_resp = self.__tarea(self.nombre)#ejecuicion de la tarea
                            log.info("[Tarea] -- Tarea terminada %s.... %s",self.nombre,time.strftime("%d-%m-%y %H:%M:%S"))
                            self.__timer = time.time()#se renueva el timer para que vuelva a contar
                            time_fin = datetime.datetime.now()
                            self.__guardar_ejecucion(time_ini,time_fin,dict_resp)
            except Exception as e:
                log.exception("[Tarea] -- Error inesperado: %s",e)

    def __guardar_ejecucion(self,tiempo_inicio,tiempo_fin,dict_response):
        try:
            ejec = Ejecuciones(
                cron_id=self.nombre,
                eje_fecha_ini=tiempo_inicio,
                eje_fecha_fin=tiempo_fin
            )
            response = ejec.guardar_dato()
            if response[0] == 'ok':
                numEjec = response[1]
                log.debug("[Tarea] -- Guardado en Ejecuciones con id: %s",numEjec)
                tobj = self.__tipo_objeto
                for key,value in dict_response.items():
                    obj_id = key
                    dirname = './txt_creados/'
                    codename = str(numEjec) + '-' + str(tobj) + '-' + str(obj_id)
                    filename = dirname + codename + '.txt'
                    inicio = value['inicio']
                    fin = value['fin']
                    eobj = Ejecuciones_Objeto(eobj_cod=codename,eobj_fch_inicio=inicio,
                                                eobj_fch_fin=fin,eobj_subido=False,
                                                eje_id=numEjec,obj_id=obj_id)
                    eobj_saved = eobj.guardar_dato()
                    if eobj_saved[0] != 'ok':
                        log.error("[Tarea] -- Error al guardar en Ejecuciones objeto %s",str(eobj_saved[1]))
                    else:
                        log.debug("[Tarea] -- Guardado en Ejecuciones objeto con id: %s",eobj.eobj_id)
                        if not os.path.isdir(dirname):
                            os.mkdir(dirname)
                        archivo = open(filename,"w+")    
                        archivo.writelines(value['respuestas'])
                        archivo.close()
                        log.info("[Tarea] -- Se ha guardado el archivo correctamente")
                        
            else:
                log.error("[Tarea] -- Error al guardar en Ejecuciones %s",response[1])
        except Exception as e:
            exc_type, _, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            error = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
            log.exception("[Tarea] -- Error inesperado: %s",error)