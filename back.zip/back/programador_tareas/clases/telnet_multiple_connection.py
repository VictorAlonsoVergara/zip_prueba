from telnetlib import Telnet

class Telnet_Multiple:
    def __init__(self,hostname,user,password,comando):
        self.comando = comando
        self.user = user
        self.password = password
        self.hostname = hostname
        
        
    
    def ejecutar(self):
        list_response = []
        tlnt_connection = Telnet(self.hostname,23)
        tlnt_connection.read_until("login: ".encode('ascii'))
        tlnt_connection.write((self.user+"\n").encode('ascii'))
        tlnt_connection.read_until("Password: ".encode('ascii'))
        tlnt_connection.write((self.password+"\n").encode('ascii'))

        for cmd in self.comando:    
            tlnt_connection.write((cmd+"\n").encode('ascii'))
            
        tlnt_connection.write("exit\n".encode('ascii'))
        response = tlnt_connection.read_all()
        list_response.append(response)
        tlnt_connection.close()
        return list_response
    
    def __del__(self):
        pass