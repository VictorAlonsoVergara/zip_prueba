import paramiko
from time import sleep,ctime


class SSH_Ejecuciones:
    def __init__(self,host,user,passwd,port,comando):
        self.comando = comando
        self.host = host
        self.user = user
        self.passwd = passwd
        self.port = port
        self.client = None

    def conectar(self):
        
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy()) #
        self.client.load_system_host_keys()
        self.client.connect(hostname=self.host, port=self.port, username=self.user, password=self.passwd,timeout=60,banner_timeout=60,auth_timeout=500)
        

    def ejecutar(self):
        list_response = []
        for cmd in self.comando:
            _, stdout, _ = self.client.exec_command(cmd)
            response = stdout.readlines()
            list_response.append(response)
        return list_response
    
    def desconectar(self):
        self.client.close()

