import sys,os

from clases.db_class import MyDB

class Ejecuciones:
	def __init__(self,eje_id = None, eje_fecha = None,
				cron_id = None, eje_fecha_ini = None,
				eje_fecha_fin = None,eje_log = None,
				eje_fecha_transferencia = None,eje_fecha_parseo = None
		):
		self.eje_id = eje_id
		self.eje_fecha = eje_fecha
		self.cron_id = cron_id
		self.eje_fecha_ini = eje_fecha_ini
		self.eje_fecha_fin = eje_fecha_fin
		self.eje_log = eje_log
		self.eje_fecha_transferencia = eje_fecha_transferencia
		self.eje_fecha_parseo = eje_fecha_parseo
		self.db = MyDB()

	def guardar_dato(self):
		try:
			query = ('insert into "TAB_EJECUCIONES"'
					'(eje_fecha,cron_id,'
					'eje_fecha_ini,eje_fecha_fin,'
					'eje_log,eje_fecha_transferencia,'
					'eje_fecha_parseo) values (%s,%s,%s,%s,%s,%s,%s) returning eje_id')
			datos = (self.eje_fecha,self.cron_id,
						self.eje_fecha_ini,self.eje_fecha_fin,
						self.eje_log,self.eje_fecha_transferencia,
						self.eje_fecha_parseo)
			
			result = self.db.conectar(query,datos,True)
			if result[0] == 'ok':
				if result[1] is not False:
					self.eje_id =result[1][0][0] 
					resp = ['ok',self.eje_id]
				else:
					resp['error','Error al insertar ejecucion']
			else:
				resp = ['error','Error en base de datos: ' + str(result[1])]
		except Exception as e:
			exc_type, _, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			resp = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
		finally:
			return resp
