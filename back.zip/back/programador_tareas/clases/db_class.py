import psycopg2
import sys,os

class MyDB:
    def __init__(self):
        #self.db_conn = psycopg2.connect("dbname = test_db user=equser3")
        self.db_conn = psycopg2.connect(database = 'cotener',user = 'cotener',password = 'cotener')
    
    def conectar(self,query,datos,returning):
        try:
            cur = self.db_conn.cursor()
            cur.execute(query,datos)
            self.db_conn.commit()
            if returning is True:
                results = cur.fetchall()
                if len(results) == 0:
                    respuesta = ['ok',False]
                else:
                    respuesta = ['ok',results]
            else:
                respuesta = ['ok',True]
        except Exception as e:
            exc_type, _, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            respuesta = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
        finally:
            if cur:
                cur.close()
            return respuesta
    def __del__(self):
        if self.db_conn:
            self.db_conn.close()