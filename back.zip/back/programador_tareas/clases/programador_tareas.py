import os
import time
import threading
import logging

from clases.tarea import Tarea
from uploader import upload_files
log = logging.getLogger("programador_tareas")

class Programador:
    def __init__(self):
        self.__tareas = {}
        self.__running = False
        self.__num_tareas = 0

    # def agregar_tarea(self,tarea,nombre,intervalo,estado,tipo):
    #     self.__tareas[nombre] = Tarea(funcion=tarea,nombre=nombre,intervalo=intervalo,estado=estado,tipo=tipo)
    def agregar_tarea(self,tarea):
        self.__tareas[str(tarea.nombre)] = tarea

    def __runProgramador(self):
        #while self.__running:
        try:
            actual = time.time()
            threads_tareas = []
            self.__num_tareas = len(self.__tareas.keys())
            for tarea in self.__tareas.values():
                try:
                    t = threading.Thread(target = tarea.execute,args=(actual,))
                    threads_tareas.append(t)
                except Exception as e:
                    log.exception("[Programador] -- Error al inicializar tareas: %s",str(e))
            for thread in threads_tareas:
                try:
                    thread.start()    
                except Exception as e:
                    log.exception("Error en tarea %s: %s",tarea.nombre,e)
            while self.__running:
                size_tareas = len(self.__tareas.keys())
                if self.__num_tareas < size_tareas:
                    list_keys = list(self.__tareas.keys())
                    for ind in range(self.__num_tareas,size_tareas):
                        key = list_keys[ind]
                        task = self.__tareas[key]
                        t = threading.Thread(target=task.execute,args=(actual,))
                        threads_tareas.append(t)
                        t.start()
                    self.__num_tareas = size_tareas
            # for thread in threads_tareas:
            #     thread.join()
        except Exception as e:
            log.exception("[Programador] -- Error en ejecucion de tareas: %s",str(e))
        log.info("[Programador] -- Se detuvo el programador de tareas")

    def iniciar(self):
        self.__running = True
        t = threading.Thread(target=self.__runProgramador)
        t.start()
        upl = threading.Thread(target=self.__file_uploader)
        upl.start()
        log.info("[Programador] -- Se inicio el programador de tareas")

    def __file_uploader(self):
        while self.__running:
            dir ='./txt_creados/'
            list_files = []
            if os.path.isdir(dir):
                list_files = os.listdir(dir)
            executes = len(list_files) > 0
            upload_files(executes)
            time.sleep(1)

    def detener(self):
        for tarea in self.__tareas.values():
            tarea.terminar()
        self.__running = False

    def pausar_tarea(self,nombre):
        name = str(nombre)
        if name in self.__tareas.keys():
            self.__tareas[name].detener()
            log.info("[Programador] -- Se pausó la tarea %s",name)
        else:
            log.error("[Programador] -- No existe la tarea de nombre %s",name)
            print("No existe la tarea de nombre %s"%name)

    def listar_nombres(self):
        lista = []
        for names in self.__tareas.keys():
            lista.append(names)
        return lista
    
    def actualizar(self,lista_crons):
        try:
            for cron in lista_crons:
                name = str(cron['nombre'])
                if name in self.__tareas.keys():
                    self.__tareas[name].update_datos(
                        cron['intervalo'],
                        cron['estado'],
                        cron['tipo']
                    )
                else:
                    task = Tarea(
                        nombre = cron['nombre'],
                        funcion = cron['funcion'],
                        intervalo = cron['intervalo'],
                        estado = cron['estado'],
                        tipo = cron['tipo'],
                        tipo_objeto = cron['tobj_id']
                    )
                    self.__tareas[str(task.nombre)] = task
        except Exception as e:
            log.exception('[Programador] -- Error al actualizar: %s',str(e))