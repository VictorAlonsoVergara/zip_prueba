import sys,os

from clases.db_class import MyDB

class Ejecuciones_Objeto:
    def __init__(self,eobj_id = None,eobj_cod = None,eobj_fch_inicio = None,
                    eobj_fch_fin = None,eobj_subido = None,
                    eje_id = None,obj_id = None):
        self.eobj_id = eobj_id
        self.eobj_cod = eobj_cod
        self.eobj_fch_inicio = eobj_fch_inicio
        self.eobj_fch_fin = eobj_fch_fin
        self.eobj_subido = eobj_subido
        self.eje_id = eje_id
        self.obj_id = obj_id
        self.db = MyDB()

    def guardar_dato(self):
        try:
            resp = []
            query = ('INSERT INTO "TAB_EJECUCIONES_OBJETO" '
                        '(eobj_cod,eobj_fch_inicio,'
                        'eobj_fch_fin,eobj_subido,'
                        'eje_id,obj_id)'
                        'VALUES (%s,%s,%s,%s,%s,%s) returning eobj_id')
            datos = (self.eobj_cod,self.eobj_fch_inicio,
                        self.eobj_fch_fin,self.eobj_subido,
                        self.eje_id,self.obj_id)
            result = self.db.conectar(query,datos,True)

            if result[0] == 'ok':
                if result[1] is not False:
                    self.eobj_id = result[1][0][0]
                    resp = ['ok',self.eobj_id]
                else:
                    resp = ['error','Error al insertar']
            else:
                resp = ['error','Error en la base de datos ' + str(result)]
        except Exception as e:
            exc_type, _, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            resp = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
        finally:
            return resp

    @staticmethod
    def consultar_lista():
        try:
            db = MyDB()
            query = ('SELECT * FROM "TAB_EJECUCIONES_OBJETO" WHERE eobj_subido = false')
            datos = ()
            result = db.conectar(query,datos,True)
            if result[0] == 'ok':
                lista = []
                if result[1] is not False:
                    for item in result[1]:
                        ej_obj = Ejecuciones_Objeto(
                            eobj_id=item[0],
                            eobj_cod=item[1],
                            eobj_fch_inicio=item[2],
                            eobj_fch_fin=item[3],
                            eobj_subido=item[4],
                            eje_id=item[5],
                            obj_id=item[6]
                        )
                        lista.append(ej_obj)
                resp = ['ok',lista]
            else:
                resp = ['error','Error en la base de datos: ' + str(result[1])]
        except Exception as e:
            exc_type, _, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            resp = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
        finally:
            return resp

    def subir_archivo(self):
        try:
            query = ('UPDATE "TAB_EJECUCIONES_OBJETO" SET eobj_subido = true WHERE eobj_id = %s')
            datos = (self.eobj_id,)
            result = self.db.conectar(query,datos,False)
            resp = result
        except Exception as e:
            exc_type, _, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            resp = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
        finally:
            return resp
            