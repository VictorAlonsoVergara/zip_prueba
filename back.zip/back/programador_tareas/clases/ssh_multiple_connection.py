import paramiko

class SSH_Multiple:
    def __init__(self,host,user,passwd,port,comando):
        self.comando = comando
        self.host = host
        self.user = user
        self.passwd = passwd
        self.port = port
    
    def ejecutar(self):
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy()) #
        client.load_system_host_keys()
        client.connect(hostname=self.host, port=self.port, username=self.user, password=self.passwd,timeout=60,banner_timeout=60,auth_timeout=500)
        list_response = []
        for cmd in self.comando:
            _, stdout, _ = client.exec_command(cmd)
            response = stdout.readlines()
            list_response.append(response)
        client.close()
        return list_response
    
    def __del__(self):
        pass