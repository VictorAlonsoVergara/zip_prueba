import paramiko
from time import sleep,ctime

class SSH:
    def __init__(self,host,user,passwd,port,comando):
        self.comando = comando
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy()) #
        self.client.load_system_host_keys()
        self.client.connect(hostname=host, port=port, username=user, password=passwd,timeout=5)
    
    def ejecutar(self):
        list_response = []
        for cmd in self.comando:
            _, stdout, _ = self.client.exec_command(cmd)
            response = stdout.readlines()
            list_response.append(response)
        return list_response
        #logging.info("[SSH] -- Respuesta de comando: %s",response)
    def __del__(self):
        #print("hello from del")
        #logging.info("--------------------Hello from del -------------")
        self.client.close()
        