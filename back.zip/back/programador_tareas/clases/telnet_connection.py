from telnetlib import Telnet

class Telnet_Connection:
    def __init__(self,hostname,user,password,comando):
        self.comando = comando
        self.user = user
        self.password = password
        self.hostname = hostname
        self.tlnt_connection = Telnet(self.hostname,23)
        self.tlnt_connection.read_until(b"login: ")
        self.tlnt_connection.write(self.user.encode('ascii')+b"\n")
        self.tlnt_connection.read_until(b"Password: ")
        self.tlnt_connection.write(self.password.encode('ascii')+b"\n")
        #self.tlnt_connection.set_debuglevel(1)

    def ejecutar(self):
        list_response = []
        #logging.debug("[Telnet] -- inicio de ejecutar")
        for cmd in self.comando:
            self.tlnt_connection.write(cmd.encode('ascii')+b"\n")
        #logging.debug("[Telnet] -- Fin de WRITES en hilo")
        self.tlnt_connection.write(b"echo -e \"fin \bcomandos\"\n")
        response = self.tlnt_connection.read_until(b"fincomandos",1)
        list_response.append(response.decode('ascii'))
        #logging.debug("[Telnet] -- Fin de READS en hilo: %d",num)
        return list_response

    def __del__(self):
        self.tlnt_connection.write(b"exit\n")
        #print(self.tlnt_connection.read_all().decode('ascii'))
        self.tlnt_connection.close()