import sys
import logging

import iniciar_crons

from clases.programador_tareas import Programador


logging.getLogger("paramiko").setLevel(logging.WARNING)
logging.getLogger("easysnmp").setLevel(logging.WARNING)
log = logging.getLogger("programador_tareas")
logging.basicConfig(filename="scheduler.log",level=logging.INFO)
log.info("----------------Inicio Programa--------------------")

p = Programador()

#p.agregar_tarea(tarea_snmp,"snmp_olt",t_SNMP_OLT)
#p.agregar_tarea(tarea_ssh,"ssh_olt",t_SSSH_OLT)

lista_tareas = iniciar_crons.obtener_tareas()
for task in lista_tareas:
    p.agregar_tarea(task)

while True:
    comando = input("Ejecute un comando: ")
    if comando == "start":
        p.iniciar()
    if comando == "stop":
        p.detener()
    if comando == "exit":
        p.detener()
        break
    if comando == "pausar":
        comando = input("Ingrese nombre de tarea: ")
        p.pausar_tarea(comando)
    if comando == "update":
        p.actualizar(iniciar_crons.actualizar_crons())
    if comando == 'listar':
        lista = p.listar_nombres()
        for n in lista:
            print(n)
    if comando == "kirby":
        kirby = "<(°.°<) ^(°.°)^ (>°.°)>"
        print(kirby)
        log.debug(kirby)
log.info("----------------Termino Programa--------------------")