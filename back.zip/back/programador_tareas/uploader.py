import shutil
import logging
import os
from clases.ejecuciones_objeto import Ejecuciones_Objeto
from clases.mongo_db import MongoDB


log = logging.getLogger("programador_tareas")
# logging.basicConfig(filename="uploader.log",level=logging.DEBUG)
def upload_files(does_execute):
    if does_execute is not True:
        log.debug("[Uploader] -- No hay archivos para subir")
        return
    try:
        log.info("[Uploader] -- Se encontraron archivos para subir")
        #Se obtienen los objetos que aun no tiene sus archivos subidos
        result_cons = Ejecuciones_Objeto.consultar_lista()
        mdb = MongoDB()
        if result_cons[0] == 'ok':
            #Si el resultado es ok se obtiene la lista de ejecuciones objeto
            lista_ejec = result_cons[1]
            for ejecucion in lista_ejec:
                cod = ejecucion.eobj_cod
                dir_origin = './txt_creados/'
                filename = cod + '.txt'
                origin_path = dir_origin + filename
                #se obtiene la direccion del archivo que se va a subir
                f = open(origin_path,'rb')
                #Se sube el archivo a mongodb
                res_mdb = mdb.put_file(f,cod)
                if res_mdb[0] == 'ok':
                    dir_destino = './txt_subidos/'
                    if not os.path.isdir(dir_destino):
                        os.mkdir(dir_destino)
                    destino_path = dir_destino + filename
                    #Se mueve el archivo a la carpeta de subidos
                    shutil.move(origin_path,destino_path)
                    #Se cambia el booleano en ejecuciones objeto para indicar que ya se subio el archivo
                    res_db = ejecucion.subir_archivo()
                    if res_db[0] == 'ok':
                        log.info("[Uploader] -- Se guardó correctamente el archivo %s",filename)
                    else:
                        log.error("[Uploader] -- Error al guardar el archivo: %s",res_db[1])
                else:
                    log.error("[Uploader] -- Error al subir el archivo: %s",res_mdb[1])
                f.close()
        else:
            log.error("[Uploader] -- Error al obtener datos: %s",result_cons[1])
    except Exception as e:
        log.exception("[Uploader] -- Error inesperado: %s",e)