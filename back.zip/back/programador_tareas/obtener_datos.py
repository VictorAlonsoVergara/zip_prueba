import sys,os
from clases.db_class import MyDB

def consultar_datos(cron_id):
    """Funcion para consultar los datos de la base de datos
    
    Arguments:
        cron_id {int} -- id del cron del que se quiere obtener los datos
    
    Returns:
        {list} -- Retorna lista con dos elementos el primero con el estado del resultado y el segundo con el error o los datos
    """    
    try:
        db = MyDB()
        #query = 'select * from view_crons_consultas_objetos where cron_id = %s'
        #query = 'select * from cron_test where cron_id = %s' #local
        query = 'select * from view_crons_consultas_objetos where cron_id = %s' #server
        datos = (cron_id,)
        resultados = db.conectar(query,datos,True)
        if resultados[0] == 'ok':
            if resultados[1] is not False:
                respuesta = ['ok',[]]
                for result in resultados[1]:
                    data = {}
                    data['cron_id'] = result[0]#cron_id
                    data['comando'] = result[1]#trama_pregunta
                    data['protocolo'] = result[2]#abrev_protocolo
                    data['obj_id'] = result[3]#obj_id
                    data['ip'] = result[4]#ip_address
                    data['username'] = result[5]#user
                    data['password'] = result[6]#password
                    respuesta[1].append(data)
            else:
                respuesta = ['error','No se encontraron datos']
        else:
            respuesta = ['error','Error en la base de datos '+ str(resultados)]
    except Exception as e:
        exc_type, _, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        respuesta = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
    return respuesta

def obtener_objetos(cron_id):
    try:
        query_cron = consultar_datos(cron_id)
        if query_cron[0] == 'ok':
            lista_objetos = []
            dict_objetos = {}
            for crons in query_cron[1]:
                obj_key = crons['obj_id']
                if obj_key not in dict_objetos.keys():
                    dict_objetos[obj_key] = {}
                dict_objetos[obj_key]['id'] = obj_key
                dict_objetos[obj_key]['hostname'] = crons['ip']
                dict_objetos[obj_key]['user'] = crons['username']
                dict_objetos[obj_key]['password'] = crons['password']
                dict_objetos[obj_key]['protocolo'] = crons['protocolo']
                dict_objetos[obj_key]['community'] = 'apesol'
                dict_objetos[obj_key]['port'] = 22
                if 'comando' not in dict_objetos[obj_key].keys():
                    dict_objetos[obj_key]['comando'] = []
                dict_objetos[obj_key]['comando'].append(crons['comando'])
            for _,value in dict_objetos.items():
                lista_objetos.append(value)
            respuesta = ['ok',lista_objetos]
        else:
            respuesta = ['error',query_cron[1]]
    except Exception as e:
        exc_type, _, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        respuesta = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
    finally:
        return respuesta