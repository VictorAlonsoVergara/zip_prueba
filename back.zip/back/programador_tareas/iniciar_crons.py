import sys
import logging
import obtener_datos
from clases.db_class import MyDB
from clases.tarea import Tarea
from clases.controlador_multiple import Controlador_Multiple

def funcion_tarea(id_cron):
    respuesta = obtener_datos.obtener_objetos(id_cron)
    if respuesta[0] == 'ok':
        control = Controlador_Multiple(100,10,respuesta[1])
        dict_resp = control.ejecutar()
        return dict_resp
    else:
        return respuesta[1]

def obtener_tareas():
    db_conn = MyDB()
    #query = "select * from mock_cron where cron_estado = %s"#local
    query = ('select * from "MAE_CRON" where cron_estado = %s')#server
    datos = ('A',)
    result = db_conn.conectar(query,datos,True)
    lista_tareas = []
    if result[0] == 'ok':
        if result[1] is not False:
            for cron in result[1]:
                t = Tarea(
                    nombre = cron[0],
                    tipo = cron[2],
                    intervalo = cron[3],
                    estado = cron[4],
                    funcion = funcion_tarea,
                    tipo_objeto = cron[1]
                )
                lista_tareas.append(t)
    return lista_tareas

def actualizar_crons():
    db_conn = MyDB()
    #query = ('select * from mock_cron')#local
    query = ('select * from "MAE_CRON"')#server
    datos = ()
    result = db_conn.conectar(query,datos,True)
    lista_crons = []
    if result[0] == 'ok':
        if result[1] is not False:
            for cron in result[1]:
                data = {}
                data['nombre'] = cron[0]
                data['tipo'] = cron[2]
                data['intervalo'] = cron[3]
                data['estado'] = cron[4]
                data['funcion'] = funcion_tarea
                data['tobj_id'] = cron[1]
                lista_crons.append(data)
    return lista_crons
