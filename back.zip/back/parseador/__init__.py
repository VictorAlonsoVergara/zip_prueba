
import zc.lockfile
import sys
from read_config  import config_vars
from parseador import Parseador


try:
    lock = zc.lockfile.LockFile('parseador.lock')
except Exception as e:
    print("El proceso ya se encuentra ejecutando")
    sys.exit()


p = Parseador(config_vars['ruta_origen'],config_vars['ruta_destino'])


p.execute()

lock.close()