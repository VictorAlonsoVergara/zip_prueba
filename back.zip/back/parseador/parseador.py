import time
import shutil
import os

class Parseador:
    def __init__(self,src_route,dest_route):
        self.active = True
        self.timer = 0
        self.src_route = src_route
        self.dest_route = dest_route

    def execute(self):
        while self.active is True:
            now = time.time()
            if now - self.timer >= 20:
                self.timer = time.time()
                lista = []
                lista = os.listdir(self.src_route)
                if len(lista)>0:
                    print("Se ejecuta parseador")
                    self.__move_files(lista)

    def __move_files(self,lista):
        for filename in lista:
            file_src = self.src_route + filename
            file_dest = self.dest_route + filename
            shutil.move(file_src,file_dest)