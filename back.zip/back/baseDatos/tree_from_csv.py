import csv
import os,sys
import psycopg2

tipo = ''
arbol = ''
while tipo !='F' and tipo != 'L':
    tipo = input('Ingrese el tipo de árbol a llenar (F: fisico, L: logico): ')
    tipo = tipo.upper()
    if tipo !='F' and tipo != 'L':
        print('Tipo incorrecto intente nuevamente')
    
filename = input('ingrese el nombre del archivo a importar(ejm: archivo.csv): ')
try:
    conn = psycopg2.connect(database = 'cotener',user = 'cotener',password = 'cotener')
    curs = conn.cursor()
    list_levels = []
    #excel = Reader(filename)
    with open(filename) as csv_file:
        csv_data = csv.reader(csv_file,delimiter=',')
        headers = csv_data.__next__()
        if len(headers)%2 != 0:
            raise Exception('El archivo no tiene el numero de cabeceras correctas')
        for ind,head in enumerate(headers):
            if ind%2 == 0:
                if head.lower() != 'codigo':
                    raise Exception('El archivo no tiene las cabeceras correctas')
        count = 0
        for row in csv_data:
            if len(row)!=len(headers):
                raise Exception('Fila %s tiene un error'%count)
            count+=1
        
        for ind in range(int(len(headers)/2)):
            list_levels.append({})

    with open(filename) as csv_file:
        lists = []
        csv_data = csv.reader(csv_file,delimiter=',')
        csv_data.__next__()
        num_level = 0
        for row in csv_data:
            index = ''
            num_level = 0
            for ind,val in enumerate(row):
                #print("index %s"%ind)
                if ind%2==0:
                    index = str(val)
                    if val not in list_levels[num_level].keys():
                        #print(num_level)
                        list_levels[num_level][index] = {}
                    list_levels[num_level][index]['fis_orden'] = str(val)
                else:
                    #print(list_levels[num_level])
                    list_levels[num_level][index]['fis_desc'] = val
                    list_levels[num_level][index]['fis_id_padre'] = None
                    num_level+=1
    list_datas = []
    list_ids = []
    for item in list_levels:
        list_datas.append(list(item.values()))

    id_node = 0
    sql_fis = ('INSERT INTO "ARB_FISICO" (fis_orden,fis_desc,fis_id_padre) VALUES (%s,%s,%s) RETURNING fis_id')
    sql_log = ('INSERT INTO "ARB_LOGICO" (log_orden,log_desc,log_id_padre) VALUES (%s,%s,%s) RETURNING log_id')

    if tipo == 'F':
        sql_insert = sql_fis
    else:
        sql_insert = sql_log
    for index,item in enumerate(list_datas):
        ids_level = []
        father_pos = 0
        for dicts in item:
            if index!=0:
                arr_orden = dicts['fis_orden'].split('.')
                if arr_orden[index-1] not in list_datas[index-1][father_pos]['fis_orden']:
                    father_pos+=1
                dicts['fis_id_padre'] = list_ids[index-1][father_pos]
            curs.execute(sql_insert,tuple(dicts.values()))
            conn.commit()
            res_ins = curs.fetchall()
            id_node = res_ins[0][0]
            #id_node += 1
            ids_level.append(id_node)
        list_ids.append(ids_level)
    print('Se terminó el insert sin errores')
except Exception as e:
    exc_type, _, exc_tb = sys.exc_info()
    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
    print(str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno))
finally:
    if conn:
        conn.close()