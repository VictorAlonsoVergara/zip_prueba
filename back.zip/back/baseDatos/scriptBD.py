
import psycopg2
from hashlib import blake2b

con = psycopg2.connect(database='cotener',user='cotener',password='cotener')

cur = con.cursor()

# PRIMER NIVEL
cur.execute('CREATE TABLE "MAT_TIPO_OBJ2" (tobj_id serial NOT NULL,	tobj_desc varchar(200),tobj_estado char(1),tobj_consulta char(1),tobj_ldesc text,tobj_padre_id integer,tobj_arb_fisico boolean,tobj_arb_logico boolean,tobj_pasivo boolean,PRIMARY KEY (tobj_id),FOREIGN KEY (tobj_padre_id) REFERENCES "MAT_TIPO_OBJ2" (tobj_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_MARCAS2" (marca_id serial NOT NULL,marca_desc varchar(100),marca_estado char(1),PRIMARY KEY (marca_id))')
con.commit()
cur.execute('CREATE TABLE "TAB_PROTOCOLO2" (prot_id serial NOT NULL,prot_desc varchar(10),prot_abreviacion char(1),PRIMARY KEY (prot_id))')
con.commit()
cur.execute('CREATE TABLE "ARB_LOGICO2" (log_id integer NOT NULL,log_id_padre integer,log_desc varchar(200),log_orden varchar(30),PRIMARY KEY (log_id),FOREIGN KEY (log_id_padre) REFERENCES "ARB_LOGICO2" (log_id))')
con.commit()
cur.execute('CREATE TABLE "ARB_FISICO2" (fis_id integer NOT NULL,fis_id_padre integer,fis_desc varchar(200),fis_orden varchar(30),PRIMARY KEY (fis_id),FOREIGN KEY (fis_id_padre) REFERENCES "ARB_FISICO2" (fis_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_TIPO_USU2" (tusu_id serial NOT NULL,tusu_desc varchar(200),tusu_estado char(1),PRIMARY KEY (tusu_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_IDIOMAS2" (idi_id serial NOT NULL,idi_desc varchar(100),idi_estado char(1),PRIMARY KEY (idi_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_AREA2" (area_id serial NOT NULL,area_desc varchar(100),area_ldesc varchar(200),area_estado char(1),PRIMARY KEY (area_id))')
con.commit()
cur.execute('CREATE TABLE "PARAM_GRUPO2" (grupo_codigo varchar(30) NOT NULL,grupo_nombre varchar(100) NOT NULL,PRIMARY KEY (grupo_codigo))')
con.commit()
cur.execute('CREATE TABLE "TAB_MENU2" (	menu_id smallint NOT NULL,menu_desc varchar(500),menu_name varchar(50),PRIMARY KEY (menu_id))')
con.commit()
cur.execute('CREATE TABLE "TAB_ACCIONES2" (acc_id serial NOT NULL,acc_desc varchar(50),PRIMARY KEY (acc_id))')
con.commit()

#SEGUNDO NIVEL
cur.execute('CREATE TABLE "MAE_MODELO2" (mod_id serial NOT NULL,mod_descripcion varchar(100),marca_id integer,tobj_id integer,mod_estado char(1),PRIMARY KEY (mod_id),FOREIGN KEY (marca_id) REFERENCES "MAE_MARCAS2" (marca_id),FOREIGN KEY (tobj_id) REFERENCES "MAT_TIPO_OBJ2" (tobj_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_CRON2" (cron_id serial NOT NULL,tobj_id integer,cron_tipo char(1),cron_periodo varchar(20),cron_estado char(1),cron_desc varchar(200),prot_id integer,PRIMARY KEY (cron_id),FOREIGN KEY (tobj_id) REFERENCES "MAT_TIPO_OBJ2" (tobj_id),FOREIGN KEY (prot_id) REFERENCES "TAB_PROTOCOLO2" (prot_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_USUARIOS2" (usu_id serial NOT NULL,usu_nombre varchar(300),tusu_id integer,usu_estado char(1),usu_correo varchar(100),usu_usuario varchar(50),usu_password varchar(2048),idi_id integer,area_id integer,usu_usuario_creador varchar(100),usu_fecha_creacion timestamp,usu_usuario_modificacion varchar(100),usu_fecha_modificacion timestamp,PRIMARY KEY (usu_id),FOREIGN KEY (tusu_id) REFERENCES "MAE_TIPO_USU2" (tusu_id),FOREIGN KEY (idi_id) REFERENCES "MAE_IDIOMAS2" (idi_id),FOREIGN KEY (area_id) REFERENCES "MAE_AREA2" (area_id))')
con.commit()
cur.execute('CREATE TABLE "PARAM2" (obj_id serial NOT NULL,param_grupo varchar(30) NOT NULL,param_id varchar(30) NOT NULL,param_valor varchar(255) NOT NULL,param_extra varchar(255),PRIMARY KEY (obj_id), FOREIGN KEY (param_grupo) REFERENCES "PARAM_GRUPO2" (grupo_codigo))')
con.commit()

#TERCER NIVEL
cur.execute('CREATE TABLE "MAE_CONSULTAS2" (con_id serial NOT NULL,con_desc varchar(100),con_estado char(1),prot_id integer,con_trama_pregunta varchar(500),marca_id integer,mod_id integer,PRIMARY KEY (con_id),FOREIGN KEY (mod_id) REFERENCES "MAE_MODELO2" (mod_id),FOREIGN KEY (marca_id) REFERENCES "MAE_MARCAS2" (marca_id),FOREIGN KEY (prot_id) REFERENCES "TAB_PROTOCOLO2" (prot_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_OBJETOS2" (obj_id serial NOT NULL,obj_desc varchar(200),tobj_id integer NOT NULL,obj_estado char(1),obj_ldesc text,obj_latitud numeric(11,8),obj_longitud numeric(11,8),obj_ip_address character varying(16),marca_id smallint,prot_id integer,obj_hardware varchar(100),obj_firmware varchar(100),fch_creacion timestamp,fch_actualizacion timestamp,fch_inscripcion timestamp,obj_usuario varchar(50),obj_password varchar(50),mod_id integer,PRIMARY KEY (obj_id),FOREIGN KEY (mod_id) REFERENCES "MAE_MODELO2" (mod_id),FOREIGN KEY (tobj_id) REFERENCES "MAT_TIPO_OBJ2" (tobj_id),FOREIGN KEY (marca_id) REFERENCES "MAE_MARCAS2" (marca_id),FOREIGN KEY (prot_id) REFERENCES "TAB_PROTOCOLO2" (prot_id))')
con.commit()
cur.execute('CREATE TABLE "TAB_EJECUCIONES2" (eje_id serial NOT NULL,eje_fecha char(8),cron_id integer,eje_fecha_ini timestamp with time zone,eje_fecha_fin timestamp with time zone,eje_log varchar(50),eje_fecha_transferencia timestamp with time zone,eje_fecha_parseo timestamp with time zone,PRIMARY KEY (eje_id),FOREIGN KEY (cron_id) REFERENCES "MAE_CRON2" (cron_id))')
con.commit()
cur.execute('CREATE TABLE "TAB_INDICADORES2" (ind_id serial NOT NULL,ind_desc varchar(200),ind_estado smallint,ind_ldesc smallint,ind_alerta char(1),cron_id integer,ind_trap char(1),ind_trap_definicion text,PRIMARY KEY (ind_id),FOREIGN KEY (cron_id) REFERENCES "MAE_CRON2" (cron_id))')
con.commit()
cur.execute('CREATE TABLE "LOG_ACCIONES_USUARIO2" (log_id serial NOT NULL,log_usu_id integer,log_fecha_hora timestamp DEFAULT now(),log_desc varchar(50),log_acc_id integer,PRIMARY KEY (log_id),FOREIGN KEY (log_usu_id) REFERENCES "MAE_USUARIOS2" (usu_id),FOREIGN KEY (log_acc_id) REFERENCES "TAB_ACCIONES2" (acc_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_USUARIOS_MENU2" (umenu_id serial NOT NULL,usu_id integer,menu_id integer,PRIMARY KEY (umenu_id),FOREIGN KEY (usu_id) REFERENCES "MAE_USUARIOS2" (usu_id),FOREIGN KEY (menu_id) REFERENCES "TAB_MENU2" (menu_id))')
con.commit()
cur.execute('CREATE TABLE "LOG_SESIONES2" (ses_id serial,ses_token varchar(200),ses_logeado char(1),ses_data json,ses_activacion timestamp DEFAULT now(),ses_expirado char(1) DEFAULT \'N\',ses_fexpirado timestamp,usu_id integer,FOREIGN KEY (usu_id) REFERENCES "MAE_USUARIOS2" (usu_id))')
con.commit()

#CUARTO NIVEL
cur.execute('CREATE TABLE "MAE_OBJETO_LOGICO2" (obj_id integer NOT NULL,log_id integer NOT NULL,PRIMARY KEY (obj_id,log_id),FOREIGN KEY (obj_id) REFERENCES "MAE_OBJETOS2" (obj_id),FOREIGN KEY (log_id) REFERENCES "ARB_LOGICO2" (log_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_OBJETO_FISICO2" (obj_id integer NOT NULL,fis_id integer NOT NULL,PRIMARY KEY (obj_id,fis_id),FOREIGN KEY (obj_id) REFERENCES "MAE_OBJETOS2" (obj_id),FOREIGN KEY (fis_id) REFERENCES "ARB_FISICO2" (fis_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_USUARIOS_ALERTAS2" (ind_id integer NOT NULL,usu_id integer NOT NULL,PRIMARY KEY (ind_id,usu_id),FOREIGN KEY (ind_id) REFERENCES "TAB_INDICADORES2" (ind_id),FOREIGN KEY (usu_id) REFERENCES "MAE_USUARIOS2" (usu_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_USU_ACCESOS_INDICADORES2" (uind_id serial NOT NULL,ind_id integer,usu_id integer,PRIMARY KEY (uind_id),FOREIGN KEY (ind_id) REFERENCES "TAB_INDICADORES2" (ind_id),FOREIGN KEY (usu_id) REFERENCES "MAE_USUARIOS2" (usu_id))')
con.commit()

#QUINTO NIVEL
cur.execute('CREATE TABLE "MAE_USU_ACCESOS_ARBOLES2" (uarb_id serial NOT NULL,uind_id integer,uarb_tipo char(1),uarb_hijo integer,PRIMARY KEY (uarb_id),FOREIGN KEY (uind_id) REFERENCES "MAE_USU_ACCESOS_INDICADORES2" (uind_id))')
con.commit()


tup = [	(1, "Administrador",1), (2,"Usuario",2)]
sql_stuff = 'INSERT INTO "MAE_TIPO_USU2" (tusu_id,tusu_desc,tusu_estado) VALUES (%s,%s,%s)'
cur.executemany(sql_stuff,tup)
con.commit()

hToken = blake2b(digest_size=32)
clave = "password"
hToken.update(clave.encode())
password = hToken.hexdigest()
tup = (1, "Usuario Administrador",1,"A","correoAdministrador@mail.com","usu_administrador",password)
sql_stuff = 'INSERT INTO "MAE_USUARIOS2" (usu_id,usu_nombre,tusu_id,usu_estado,usu_correo,usu_usuario,usu_password) VALUES (%s,%s,%s,%s,%s,%s,%s)'
cur.execute(sql_stuff,tup)
con.commit()

tup = [	("estado_usuario", "Estados de usuario del sistema"),("estado_documento", "Estados de documento"), ]
sql_stuff = 'INSERT INTO "PARAM_GRUPO2" (grupo_codigo,grupo_nombre) VALUES (%s,%s)'
cur.executemany(sql_stuff,tup)
con.commit()

tup = [	("estado_usuario", "A", "Activo"),("estado_usuario", "D", "Desactivado"),("estado_usuario", "E", "Eliminado"), ]
sql_stuff = 'INSERT INTO "PARAM2" (param_grupo,param_id,param_valor) VALUES (%s,%s,%s)'
cur.executemany(sql_stuff,tup)
con.commit()

tup = [	("Borrar tipo objeto"),("Borrar todo tipo objeto"),("Buscar hermano tipo objeto"),
		("Buscar hijo tipo objeto"),("Buscar padres tipo objeto"),("Crear tipo objeto"),
		("Lista tipo objeto"),("Modificar tipo objeto"),("Ver tipo objeto"),
		("Borrar marcas"),("Crear marcas"),("Lista marcas"),
		("Modificar marcas"),("Ver marcas"),("Borrar arbol logico"),
		("Borrar todo arbol logico"),("Buscar hermanos arbol logico"),("Buscar hijos arbol logico"),
		("Buscar padres arbol logico"),("Crear arbol logico"),("listar arbol logico"),
		("Modificar arbol logico"),("Ver arbol logico"),("Borrar arbol fisico"),
		("Borrar todo arbol fisico"),("Buscar hermanos arbol fisico"),("Buscar hijos arbol fisico"),
		("Buscar padres arbol fisico"),("Crear arbol fisico"),("Lista arbol fisico"),
		("Modificar arbol fisico"),("Ver arbol fisico"),("Borrar tipo usuario"),
		("Crear tipo usuario"),("Lista tipo usuario"),("Modificar tipo usuario"),
		("Ver tipo usuario"),("Borrar idiomas"),("Crear idiomas"),
		("Lista idiomas"),("Modificar idiomas"),("Ver idiomas"),
		("Borrar area"),("Crear area"),("Lista area"),
		("Modificar area"),("Ver area"),("Borrar modelo"),
		("Crear modelo"),("Lista modelo"),("Modificar modelo"),
		("Ver modelo"),("Borrar cron"),("Crear cron"),
		("Lista cron"),("Modificar cron"),("Ver cron"),
		("Activar usuario"),("Autentica usuario"),("Borrar usuario"),
		("Cerrar usuario"),("Crear usuario"),("Desactivar usuario"),
		("Eliminar usuario"),("Lista usuario"),("Modificar usuario"),
		("Ver usuario"),("Borrar consultas"),("Crear consultas"),
		("Lista consultas"),("Modificar consultas"),("Ver consultas"),
		("Borrar objeto"),("Crear objeto"),("Lista objeto"),
		("Modificar objeto"),("Ver objeto"),("Borrar usuario alertas"),
		("Crear usuario alertas"),("Lista usuario alertas"),("Modificar usuario alertas"),
		("Ver usuario alertas"),("Borrar usuario accesos indicadores"),("Crear usuario accesos indicadores"),
		("Listar usuario accesos indicadores"),("Modificar usuario accesos indicadores"),("Ver usuario accesos indicadores"),
		("Borrar usuario accesos arboles"),("Crear usuario accesos arboles"),("Lista usuario accesos arboles"),
		("Modificar usuario accesos arboles"),("Ver usuario accesos arboles") ]
sql_stuff = 'INSERT INTO "TAB_ACCIONES2" (acc_desc) VALUES (%s)' # INTEGER , VARCHAR(50)
cur.executemany(sql_stuff,tup)
con.commit()
con.close()
#import psycopg2
#from hashlib import blake2b

#con = psycopg2.connect(database='cotener',user='cotener',password='cotener')

#cur = con.cursor()

'''
#*************************************************************
cur.execute('CREATE TABLE "PARAM_GRUPO" (grupo_codigo varchar(30) ,grupo_nombre varchar(100) NOT NULL,PRIMARY KEY (grupo_codigo))')
con.commit()
cur.execute('CREATE TABLE "MAE_CONSULTAS" (con_id serial ,con_desc varchar(100) ,con_estado char(1) ,con_protocolo char(1) ,con_trama_pregunta varchar(500),PRIMARY KEY (con_id))')
con.commit()
cur.execute('CREATE TABLE "MAT_TIPO_OBJ" (tobj_id serial ,tobj_desc varchar(200) ,tobj_estado char(1) ,tobj_consulta char(1) ,tobj_ldesc text,PRIMARY KEY (tobj_id))')
con.commit()
cur.execute('CREATE TABLE "TAB_MENU" (menu_id smallint ,menu_desc varchar(500) ,menu_name varchar(50) ,PRIMARY KEY (menu_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_TIPO_USU" (tusu_id serial ,tusu_desc varchar(200) ,tusu_estado smallint ,PRIMARY KEY (tusu_id))')
con.commit()
#*************************************************************
cur.execute('CREATE TABLE "MAE_USUARIOS" (usu_id serial ,usu_nombre varchar(300) ,tusu_id integer NOT NULL,usu_estado char(1),usu_correo varchar(100),usu_usuario varchar(50),usu_password varchar(2048),PRIMARY KEY (usu_id),FOREIGN KEY (tusu_id) REFERENCES "MAE_TIPO_USU" (tusu_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_CRON" (cron_id serial ,tobj_id integer ,cron_tipo char(1) ,cron_periodo varchar(20),cron_estado char(1),PRIMARY KEY (cron_id),FOREIGN KEY (tobj_id) REFERENCES "MAT_TIPO_OBJ" (tobj_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_OBJETOS" (obj_id serial ,obj_desc varchar(200) ,tobj_id integer NOT NULL ,obj_estado char(1),obj_ldesc text,PRIMARY KEY (obj_id),FOREIGN KEY (tobj_id) REFERENCES "MAT_TIPO_OBJ" (tobj_id))')
con.commit()
cur.execute('CREATE TABLE "PARAM" (obj_id serial ,param_grupo varchar(30) NOT NULL,param_id varchar(30) NOT NULL ,param_valor varchar(255) NOT NULL,param_extra varchar(255),PRIMARY KEY (obj_id),FOREIGN KEY (param_grupo) REFERENCES "PARAM_GRUPO" (grupo_codigo))')
con.commit()
#*************************************************************
cur.execute('CREATE TABLE "MAE_USUARIOS_MENU" (umenu_id serial ,usu_id integer NOT NULL,menu_id integer NOT NULL ,PRIMARY KEY (umenu_id),FOREIGN KEY (usu_id) REFERENCES "MAE_USUARIOS" (usu_id),FOREIGN KEY (menu_id) REFERENCES "TAB_MENU" (menu_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_OBJETOS_CONSULTAS" (obj_id integer ,con_id integer NOT NULL,objc_estado char(1),objc_protocolo char(1),objc_trama varchar(500),PRIMARY KEY (obj_id,con_id),FOREIGN KEY (obj_id) REFERENCES "MAE_OBJETOS" (obj_id),FOREIGN KEY (con_id) REFERENCES "MAE_CONSULTAS" (con_id))')
con.commit()
cur.execute('CREATE TABLE "LOG_SESIONES" (ses_id serial ,ses_token varchar(200) ,ses_logeado char(1),ses_data json,ses_activacion timestamp,ses_expirado char(1),ses_fexpirado timestamp,usu_id integer,PRIMARY KEY (ses_id),FOREIGN KEY (usu_id) REFERENCES "MAE_USUARIOS" (usu_id))')
con.commit()
cur.execute('CREATE TABLE "ARB_LOGICO" (id_obj_hijo integer ,id_obj_padre integer,PRIMARY KEY (id_obj_hijo),FOREIGN KEY (id_obj_padre) REFERENCES "ARB_LOGICO" (id_obj_hijo))')
con.commit()
cur.execute('CREATE TABLE "ARB_FISICO" (id_obj_hijo integer ,id_obj_padre integer,PRIMARY KEY (id_obj_hijo),FOREIGN KEY (id_obj_padre) REFERENCES "ARB_FISICO" (id_obj_hijo))')
con.commit()
cur.execute('CREATE TABLE "TAB_EJECUCIONES" (eje_id serial ,eje_fecha char(8) ,cron_id integer,eje_fecha_ini timestamp with time zone,eje_fecha_fin timestamp with time zone,eje_log varchar(50),eje_fecha_transferencia timestamp with time zone,eje_fecha_parseo timestamp with time zone,PRIMARY KEY (eje_id),FOREIGN KEY (cron_id) REFERENCES "MAE_CRON" (cron_id))')
con.commit()
cur.execute('CREATE TABLE "TAB_INDICADORES" (ind_id serial ,ind_desc varchar(200),ind_estado smallint,ind_ldesc smallint,ind_alerta char(1),cron_id integer,ind_trap char(1),ind_trap_definicion text,PRIMARY KEY (ind_id),FOREIGN KEY (cron_id) REFERENCES "MAE_CRON" (cron_id))')
con.commit()
#*************************************************************
cur.execute('CREATE TABLE "MAE_USUARIOS_ALERTAS" (ind_id integer ,usu_id integer ,PRIMARY KEY (ind_id),PRIMARY KEY (usu_id),FOREIGN KEY (ind_id) REFERENCES "TAB_INDICADORES" (ind_id),FOREIGN KEY (usu_id) REFERENCES "MAE_USUARIOS" (usu_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_USU_ACCESOS_INDICADORES" (uind_id serial ,ind_id integer ,usu_id integer,PRIMARY KEY (uind_id),FOREIGN KEY (ind_id) REFERENCES "TAB_INDICADORES" (ind_id),FOREIGN KEY (usu_id) REFERENCES "MAE_USUARIOS" (usu_id))')
con.commit()
#*************************************************************
cur.execute('CREATE TABLE "MAE_USU_ACCESOS_ARBOLES" (uarb_id serial ,uind_id integer ,uarb_tipo char(1) ,uarb_hijo integer,PRIMARY KEY (uarb_id),FOREIGN KEY (uind_id) REFERENCES "MAE_USU_ACCESOS_INDICADORES" (uind_id))')
con.commit()

#*************************************************************

tup = [	(1, "Administrador",1), ]
sql_stuff = 'INSERT INTO "MAE_TIPO_USU" (tusu_id,tusu_desc,tusu_estado) VALUES (%s,%s,%s)'
cur.executemany(sql_stuff,tup)
con.commit()

hToken = blake2b(digest_size=32)
hToken.update("password")
password = hToken.hexdigest()
tup = [	(1, "Usuario Administrador",1,"A","correoAdministrador@mail.com","usu_administrador",password), ]
sql_stuff = 'INSERT INTO "MAE_USUARIOS" (usu_id,usu_nombre,tusu_id,usu_estado,usu_correo,usu_usuario,usu_password) VALUES (%s,%s,%s)'
cur.executemany(sql_stuff,tup)
con.commit()

tup = [	("estado_usuario", "Estados de usuario del sistema"),("estado_documento", "Estados de documento"), ]
sql_stuff = 'INSERT INTO "PARAM_GRUPO" (grupo_codigo,grupo_nombre) VALUES (%s,%s)'
cur.executemany(sql_stuff,tup)
con.commit()

tup = [	("estado_usuario", "A", "Activo"),("estado_usuario", "D", "Desactivado"),("estado_usuario", "E", "Eliminado"), ]
sql_stuff = 'INSERT INTO "PARAM" (param_grupo,param_id,param_valor) VALUES (%s,%s,%s)'
cur.executemany(sql_stuff,tup)
con.commit()
'''
'''
#*************************************************************
cur.execute('CREATE TABLE "PARAM_GRUPO2" (grupo_codigo varchar(30) ,grupo_nombre varchar(100) NOT NULL,PRIMARY KEY (grupo_codigo))')
con.commit()
cur.execute('CREATE TABLE "MAE_CONSULTAS2" (con_id serial ,con_desc varchar(100) ,con_estado char(1) ,con_protocolo char(1) ,con_trama_pregunta varchar(500),PRIMARY KEY (con_id))')
con.commit()
#cur.execute('CREATE TABLE "MAT_TIPO_OBJ2" (tobj_id serial ,tobj_desc varchar(200) ,tobj_estado char(1) ,tobj_consulta char(1) ,tobj_ldesc text,PRIMARY KEY (tobj_id))')
cur.execute('CREATE TABLE "MAT_TIPO_OBJ2" (tobj_id serial ,tobj_desc varchar(200) ,tobj_estado char(1) ,tobj_consulta char(1) ,tobj_ldesc text,tobj_padre_id integer,tobj_arb_fisico boolean,tobj_arb_logico boolean,tobj_pasivo boolean, PRIMARY KEY (tobj_id))')
con.commit()
cur.execute('CREATE TABLE "TAB_MENU2" (menu_id smallint ,menu_desc varchar(500) ,menu_name varchar(50) ,PRIMARY KEY (menu_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_TIPO_USU2" (tusu_id serial ,tusu_desc varchar(200) ,tusu_estado smallint ,PRIMARY KEY (tusu_id))')
con.commit()
#*************************************************************
cur.execute('CREATE TABLE "MAE_USUARIOS2" (usu_id serial ,usu_nombre varchar(300) ,tusu_id integer NOT NULL,usu_estado char(1),usu_correo varchar(100),usu_usuario varchar(50),usu_password varchar(2048),PRIMARY KEY (usu_id),FOREIGN KEY (tusu_id) REFERENCES "MAE_TIPO_USU2" (tusu_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_CRON2" (cron_id serial ,tobj_id integer ,cron_tipo char(1) ,cron_periodo varchar(20),cron_estado char(1),PRIMARY KEY (cron_id),FOREIGN KEY (tobj_id) REFERENCES "MAT_TIPO_OBJ2" (tobj_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_OBJETOS2" (obj_id serial ,obj_desc varchar(200) ,tobj_id integer NOT NULL ,obj_estado char(1),obj_ldesc text,PRIMARY KEY (obj_id),FOREIGN KEY (tobj_id) REFERENCES "MAT_TIPO_OBJ2" (tobj_id))')
con.commit()
cur.execute('CREATE TABLE "PARAM2" (obj_id serial ,param_grupo varchar(30) NOT NULL,param_id varchar(30) NOT NULL ,param_valor varchar(255) NOT NULL,param_extra varchar(255),PRIMARY KEY (obj_id),FOREIGN KEY (param_grupo) REFERENCES "PARAM_GRUPO2" (grupo_codigo))')
con.commit()
#*************************************************************
cur.execute('CREATE TABLE "MAE_USUARIOS_MENU2" (umenu_id serial ,usu_id integer NOT NULL,menu_id integer NOT NULL ,PRIMARY KEY (umenu_id),FOREIGN KEY (usu_id) REFERENCES "MAE_USUARIOS2" (usu_id),FOREIGN KEY (menu_id) REFERENCES "TAB_MENU2" (menu_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_OBJETOS_CONSULTAS2" (obj_id integer ,con_id integer NOT NULL,objc_estado char(1),objc_protocolo char(1),objc_trama varchar(500),PRIMARY KEY (obj_id,con_id),FOREIGN KEY (obj_id) REFERENCES "MAE_OBJETOS2" (obj_id),FOREIGN KEY (con_id) REFERENCES "MAE_CONSULTAS2" (con_id))')
con.commit()
cur.execute('CREATE TABLE "LOG_SESIONES2" (ses_id serial ,ses_token varchar(200) ,ses_logeado char(1),ses_data json,ses_activacion timestamp,ses_expirado char(1),ses_fexpirado timestamp,usu_id integer,PRIMARY KEY (ses_id),FOREIGN KEY (usu_id) REFERENCES "MAE_USUARIOS2" (usu_id))')
con.commit()
cur.execute('CREATE TABLE "ARB_LOGICO2" (id_obj_hijo integer ,id_obj_padre integer,PRIMARY KEY (id_obj_hijo),FOREIGN KEY (id_obj_padre) REFERENCES "ARB_LOGICO2" (id_obj_hijo))')
con.commit()
cur.execute('CREATE TABLE "ARB_FISICO2" (id_obj_hijo integer ,id_obj_padre integer,PRIMARY KEY (id_obj_hijo),FOREIGN KEY (id_obj_padre) REFERENCES "ARB_FISICO2" (id_obj_hijo))')
con.commit()
cur.execute('CREATE TABLE "TAB_EJECUCIONES2" (eje_id serial ,eje_fecha char(8) ,cron_id integer,eje_fecha_ini timestamp with time zone,eje_fecha_fin timestamp with time zone,eje_log varchar(50),eje_fecha_transferencia timestamp with time zone,eje_fecha_parseo timestamp with time zone,PRIMARY KEY (eje_id),FOREIGN KEY (cron_id) REFERENCES "MAE_CRON2" (cron_id))')
con.commit()
cur.execute('CREATE TABLE "TAB_INDICADORES2" (ind_id serial ,ind_desc varchar(200),ind_estado smallint,ind_ldesc smallint,ind_alerta char(1),cron_id integer,ind_trap char(1),ind_trap_definicion text,PRIMARY KEY (ind_id),FOREIGN KEY (cron_id) REFERENCES "MAE_CRON2" (cron_id))')
con.commit()
#*************************************************************
cur.execute('CREATE TABLE "MAE_USUARIOS_ALERTAS2" (ind_id integer ,usu_id integer ,PRIMARY KEY (ind_id,usu_id),FOREIGN KEY (ind_id) REFERENCES "TAB_INDICADORES2" (ind_id),FOREIGN KEY (usu_id) REFERENCES "MAE_USUARIOS2" (usu_id))')
con.commit()
cur.execute('CREATE TABLE "MAE_USU_ACCESOS_INDICADORES2" (uind_id serial ,ind_id integer ,usu_id integer,PRIMARY KEY (uind_id),FOREIGN KEY (ind_id) REFERENCES "TAB_INDICADORES2" (ind_id),FOREIGN KEY (usu_id) REFERENCES "MAE_USUARIOS2" (usu_id))')
con.commit()
#*************************************************************
cur.execute('CREATE TABLE "MAE_USU_ACCESOS_ARBOLES2" (uarb_id serial ,uind_id integer ,uarb_tipo char(1) ,uarb_hijo integer,PRIMARY KEY (uarb_id),FOREIGN KEY (uind_id) REFERENCES "MAE_USU_ACCESOS_INDICADORES2" (uind_id))')
con.commit()
#*************************************************************
tup = [	(1, "Administrador",1), ]
sql_stuff = 'INSERT INTO "MAE_TIPO_USU2" (tusu_id,tusu_desc,tusu_estado) VALUES (%s,%s,%s)'
cur.executemany(sql_stuff,tup)
con.commit()

hToken = blake2b(digest_size=32)
clave = "password"
hToken.update(clave.encode())
password = hToken.hexdigest()
tup = (1, "Usuario Administrador",1,"A","correoAdministrador@mail.com","usu_administrador",password)
sql_stuff = 'INSERT INTO "MAE_USUARIOS2" (usu_id,usu_nombre,tusu_id,usu_estado,usu_correo,usu_usuario,usu_password) VALUES (%s,%s,%s,%s,%s,%s,%s)'
cur.execute(sql_stuff,tup)
con.commit()

tup = [	("estado_usuario", "Estados de usuario del sistema"),("estado_documento", "Estados de documento"), ]
sql_stuff = 'INSERT INTO "PARAM_GRUPO2" (grupo_codigo,grupo_nombre) VALUES (%s,%s)'
cur.executemany(sql_stuff,tup)
con.commit()

tup = [	("estado_usuario", "A", "Activo"),("estado_usuario", "D", "Desactivado"),("estado_usuario", "E", "Eliminado"), ]
sql_stuff = 'INSERT INTO "PARAM2" (param_grupo,param_id,param_valor) VALUES (%s,%s,%s)'
cur.executemany(sql_stuff,tup)
con.commit()

tup = [	("", "", "", "", "", "", "", ""),("", "", "", "", "", "", "", ""),("", "", "", "", "", "", "", ""), ]
sql_stuff = 'INSERT INTO "TAB_INDICADORES2" (ind_id,ind_desc,ind_estado,ind_ldesc,ind_alerta,cron_id,ind_trap,ind_trap_definicion) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)'
cur.executemany(sql_stuff,tup)
con.commit()

###################################################################
'''
'''
import psycopg2
from hashlib import blake2b

con = psycopg2.connect(database='cotener',user='cotener',password='cotener')
cur = con.cursor()

hToken = blake2b(digest_size=32)
clave = "password"
hToken.update(clave.encode())
password = hToken.hexdigest()
print('password:')
print(password)
print(type(password))
tup = (1, "Usuario Administrador",1,"A","correoAdministrador@mail.com","usu_administrador",password)
sql_stuff = 'INSERT INTO "MAE_USUARIOS2" (usu_id,usu_nombre,tusu_id,usu_estado,usu_correo,usu_usuario,usu_password) VALUES (%s,%s,%s,%s,%s,%s,%s)'
cur.execute(sql_stuff,tup)
con.commit()

tup = [	("estado_usuario", "Estados de usuario del sistema"),("estado_documento", "Estados de documento"), ]
sql_stuff = 'INSERT INTO "PARAM_GRUPO2" (grupo_codigo,grupo_nombre) VALUES (%s,%s)'
cur.executemany(sql_stuff,tup)
con.commit()

tup = [	("estado_usuario", "A", "Activo"),("estado_usuario", "D", "Desactivado"),("estado_usuario", "E", "Eliminado"), ]
sql_stuff = 'INSERT INTO "PARAM2" (param_grupo,param_id,param_valor) VALUES (%s,%s,%s)'
cur.executemany(sql_stuff,tup)
con.commit()'''
#-----------------------------------------------------------------------------------------------------------------------



#tup = [	("", "", "", "", "", "", "", ""),("", "", "", "", "", "", "", ""),("", "", "", "", "", "", "", ""), ]
#sql_stuff = 'INSERT INTO "TAB_INDICADORES2" (ind_id,ind_desc,ind_estado,ind_ldesc,ind_alerta,cron_id,ind_trap,ind_trap_definicion) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)'
#cur.executemany(sql_stuff,tup)
#con.commit()