import sys,os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_USUARIOS import MAE_USUARIOS
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
from clsSession import Session
import validations
import generico

def application(environ, start_response):
    try:
        coo = ""
        jsdato = ""
        
        status = "200 OK"  # se crea la respuesta de estado
        if environ['REQUEST_METHOD'] != 'PUT' and environ['REQUEST_METHOD'] != 'POST':
            #status = "405 Method Not Allowed"
            raise validations.HttpException(405)
        lendata = int(environ.get("CONTENT_LENGTH", 0))
        bydata = environ["wsgi.input"].read(lendata)
        jsdata = json.loads(bydata.decode("utf-8"))
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
            # data
            # IP = environ['HTTP_X_FORWARDED_FOR']
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)  # se obtiene la informacion del cookie
        tk = s.getCookie(cookie, "token")  # se escoge la informacion guardada en la variable token


        if s.valToken(tk) and s.valIp(tk, str(dataIP)):  # se valida si el token esta validado
            jsdato = s.get_Datos_Usu(str(tk))  # se busca los datos del usuario vinculados con el token
            datos_usu = json.loads(jsdato)#Se transforma los datos del usuario en diccionario
            try:
                extra = {}
                diccionario_respu = {}
                pass_flag = True
                diccionario_respu['min_token'] = validations.validate_int(jsdata['min_token'])
                for key,value in jsdata.items():
                    value_empty = validations.validate_empty(value)
                    if value_empty[0] is True :
                        diccionario_respu[key] = value_empty

                for _,value in diccionario_respu.items():
                    if value[0] is False:
                        pass_flag = False
                        break

                if pass_flag is True:
                    resp = Session.update_conf_token(jsdata)
                else:
                    resp = ["error", ""]
                    num = 0
                    for key,respu in diccionario_respu.items():
                        if respu[0] == False:
                            extra[key] = respu[1]
                        num = num + 1
                linea = {}
                if resp[0] == "ok":
                    linea["result"] = "ok"
                    usu_id = s.get_id_Usu(str(tk))
                    filename = os.path.basename(__file__).split('.')[0]
                    obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se cambia la configuracion del tiempo activacion del token',log_acc_id = 526)
                    resp_log = obj_log.guardar_dato()
                    if resp_log[0] == 'error':
                        linea['result'] = "failed"
                        linea['error'] = "Sucedio un error"
                        linea['error_cod'] = 411
                        status = "400 Bad Request"

                        linea['val_errors'] = "No se pudo guardar en el log"
                else:
                    linea["result"] = "failed"
                    linea["error"] = "Sucedio un error"
                    linea["error_cod"] = 411
                    status = "400 Bad Request"

                    if bool(extra):
                        linea["val_errors"] = extra
                        #linea["tipo"] = 'extra'
                    else:
                        linea["val_errors"] = resp[1]
                        #linea["tipo"] = 'resp'
            except Exception as e:
                linea = {}
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
                resp = ["error", str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)]
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 411
                linea["val_errors"] = resp
                status = "400 Bad Request"
        else:
            #resp = ["error", "token no validado"]
            raise validations.HttpException(401,"token no validado")
            status = "401 Unauthorized"

    except validations.HttpException as e:
        linea = {}
        linea.update(e.get_error_dict())
        status = e.status_code

    except Exception as e:
        linea = {}
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        resp = [
            "error",
            "token no validado"
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)]
        linea["result"] = "failed"
        linea["error"] = "Sucedio un error"
        linea["error_cod"] = 411
        linea["val_errors"] = resp
        status = "500 Internal Server Error"  

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
