import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_TIPO_USU import MAE_TIPO_USU
from clsSession import Session
import validations


def application(environ, start_response):
    try:
        coo = ""
        jsdato = ""
        status = "200 OK"  # se crea la respuesta de estado
        if environ["REQUEST_METHOD"] != "GET":
            # status = "405 Method Not Allowed"
            raise validations.HttpException(405)
        bdata = environ["PATH_INFO"]  # se busca el dato en el url
        respuest = validations.validate_int(
            bdata.split("/")[1]
        )  # se valida el tipo de dato integer
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
            # dataIP = environ['HTTP_X_FORWARDED_FOR']
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]
        s = Session()  # creacion de dato
        cookie = environ.get(
            "HTTP_COOKIE", 0
        )  # se obtiene los datos guardados del cookie
        tk = s.getCookie(cookie, "token")  # se busca el dato del token
        s.setToken(tk)
        if s.valToken(tk) and s.valIp(
            tk, str(dataIP)
        ):  # se valida si el token esta activado
            jsdato = s.get_Datos_Usu(
                str(tk)
            )  # se busca los datos del usuario vinculado con el token
            if respuest[0] == True:
                obj = MAE_TIPO_USU(
                    " ", " ", int(bdata.split("/")[1])
                )  # se verifica si existe el tipo de usuario
                dato = obj.buscar_dato()  # se buscan los datos con el id tipo objeto
                if dato[0] == "ok":
                    data = {}
                    data["tusu_id"] = int(bdata.split("/")[1])
                    data["tusu_desc"] = obj.tusu_desc
                    data["tusu_estado"] = obj.tusu_estado
                else:
                    data = {}
                    data["result"] = "failed"
                    data["error"] = "Sucedio un error"
                    data["error_cod"] = 412
                    data["val_errors"] = dato[1]
                    status = "400 Bad Request"
            else:
                data = {}
                data["result"] = "failed"
                data["error"] = "Sucedio un error"
                data["error_cod"] = 412
                data["val_errors"] = respuest[1]
                status = "400 Bad Request"
        else:
            data = {}
            data["result"] = "failed"
            data["error"] = "Sucedio un error con el token:" + str(tk)
            data["error_cod"] = 412
            data["val_errors"] = "token no validado"
            status = "401 Unauthorized"
    except validations.HttpException as e:
        data = {}
        data["result"] = "failed"
        data["error_cod"] = e.code
        data["error"] = e.message
        data["val_errors"] = e.message
        status = e.status_code
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        data = {}
        data["result"] = "failed"
        data["error"] = "Sucedio un error" + str(
            e
        )  # -cookie: "+str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)#+str(cookie)
        data["error_cod"] = 412
        data["val_errors"] = "token no validado"
        status = "500 Internal Server Error"

    preoutput = json.dumps(data)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ("Content-Type", "application/json"),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
