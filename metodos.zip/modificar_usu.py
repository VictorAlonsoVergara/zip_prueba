import sys,os
import logging,datetime
rutalog="/home/sistema/log/Traxium"
sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_USUARIOS import MAE_USUARIOS
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
from clsSession import Session
import validations
import generico

def application(environ, start_response):
    try:
        coo = ""
        jsdato = ""
        
        status = "200 OK"  # se crea la respuesta de estado

        lendata = int(environ.get("CONTENT_LENGTH", 0))
        bydata = environ["wsgi.input"].read(lendata)
        jsdata = json.loads(bydata.decode("utf-8"))
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
            # data
            # IP = environ['HTTP_X_FORWARDED_FOR']
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)  # se obtiene la informacion del cookie
        tk = s.getCookie(cookie, "token")  # se escoge la informacion guardada en la variable token
        datosB = s.getCookie(cookie, "dato")
        len_datosB = len(datosB)
        datosC = json.loads(datosB[1:(len_datosB-1)])
        if environ['REQUEST_METHOD'] != 'PUT' and environ['REQUEST_METHOD'] != 'POST':
            #status = "405 Method Not Allowed"
            raise validations.HttpException(405)
        if s.valToken(tk) and s.valIp(tk, str(dataIP)):  # se valida si el token esta validado
            jsdato = s.get_Datos_Usu(str(tk))  # se busca los datos del usuario vinculados con el token
            datos_usu = json.loads(jsdato)#Se transforma los datos del usuario en diccionario
            try:
                extra = {}
                diccionario_respu = {}
                pass_flag = True
                #se valida que todos los datos recibidos sean correctos
                diccionario_respu['usu_id'] = validations.validate_int(jsdata['usu_id'])
                diccionario_respu['usu_nombre'] = validations.validate_varchar(jsdata["usu_nombre"], 300) 
                diccionario_respu['tusu_id'] = validations.validate_int(jsdata["tusu_id"])
                diccionario_respu['usu_estado'] = validations.validate_char(jsdata["usu_estado"])
                diccionario_respu['usu_correo'] = validations.validate_varchar(jsdata["usu_correo"], 100)
                diccionario_respu['usu_usuario'] = validations.validate_varchar(jsdata["usu_usuario"], 50)
                #diccionario_respu['usu_password'] = validations.validate_varchar(jsdata["usu_password"], 2048)
                diccionario_respu['usu_password'] = validations.validate_clave(jsdata["usu_password"])
                diccionario_respu['idi_id'] = validations.validate_int(jsdata["idi_id"])
                diccionario_respu['area_id'] = validations.validate_int(jsdata["area_id"])
                #diccionario_respu['usu_usuario_modificacion'] = validations.validate_varchar(jsdata["usu_usuario_modificacion"],100)
                #jsdata["usu_usuario_modificacion"] = s.getCookie(cookie,"")
                jsdata["usu_usuario_modificacion"] = datos_usu['usu_nombre']

                if diccionario_respu['usu_nombre'][0]  is True:
                    diccionario_respu['usu_nombre'] = validations.usu_nombre(jsdata["usu_nombre"])
                if diccionario_respu['usu_usuario'][0]  is True:
                    diccionario_respu['usu_usuario'] = validations.usu_usuario(jsdata["usu_usuario"])
                if diccionario_respu['usu_correo'][0]  is True:
                    diccionario_respu['usu_correo'] = validations.usu_correo(jsdata["usu_correo"])
                if diccionario_respu['usu_id'][0] is True:
                    diccionario_respu['usu_id'] = validations.id_Mae_Usu(int(jsdata["usu_id"]))
                if diccionario_respu['tusu_id'][0]  is True:
                    diccionario_respu['tusu_id'] = validations.id_Tipo_Usu(int(jsdata["tusu_id"]))
                if diccionario_respu['idi_id'][0]  is True:
                    diccionario_respu['idi_id'] = validations.id_Mae_Idiomas(int(jsdata["idi_id"]))
                if diccionario_respu['area_id'][0]  is True:
                    diccionario_respu['area_id'] = validations.id_Mae_Area(int(jsdata["area_id"]))
                if diccionario_respu['usu_estado'][0] is True:
                    diccionario_respu['usu_estado'] = validations.validate_parametro('estado_usuario',jsdata['usu_estado'])

                for key,value in jsdata.items():
                    value_empty = validations.validate_empty(value)
                    if value_empty[0] is True and key != 'usu_id':
                        diccionario_respu[key] = value_empty

                usu_id = s.get_id_Usu(str(tk))
                if usu_id == jsdata['usu_id']:
                    temporal = ['ok','Es el mismo usuario']
                else:
                    temporal = MAE_USUARIOS.verifica_admin(jsdata['usu_id'])

                if temporal[0] == "ok" :
                    if temporal[1] == "Es administrador" :
                        diccionario_respu['tusu_id_admin'] = [False," tusu_id_admin "]
                    else :
                        diccionario_respu['tusu_id_admin'] = [True,"ok "]
                else:
                    diccionario_respu['tusu_id_admin'] = [False,temporal[1]]

                for _,value in diccionario_respu.items():
                    if value[0] is False:
                        pass_flag = False
                        break

                #en caso de que no exista ningun error se realiza la accion
                if pass_flag is True:
                    obj = MAE_USUARIOS.from_json(jsdata)
                    resp = obj.modificar()
                    obj.buscar_dato()

                else:
                    resp = ["error1", ""]
                    num = 0
                    for key,respu in diccionario_respu.items():
                        if respu[0] == False:
                            if len(respu) == 3 :
                                mensaje1 = s.mensaje_error(datosC['idioma'],respu[2])
                                extra[key] = str(mensaje1[1][0][0]) + respu[1]
                            else :
                                mensaje1 = s.mensaje_error(datosC['idioma'],104)
                                extra[key] = str(mensaje1[1][0][0]) + respu[1]
                        num = num + 1

                linea = {}
                if resp[0] == "ok":
                    linea["result"] = "ok"
                    linea['temporal'] = temporal
                    linea["data"] = obj.get_diccionario()
                    '''linea["usu_id"] = obj.usu_id
                    linea["usu_nombre"] = obj.usu_nombre
                    linea["tusu_id"] = obj.tusu_id
                    linea["usu_estado"] = obj.usu_estado
                    linea["usu_correo"] = obj.usu_correo
                    linea["usu_usuario"] = obj.usu_usuario
                    linea["usu_password"] = obj.usu_password
                    linea["idi_id"] = obj.idi_id
                    linea["area_id"] = obj.area_id'''
                    #Como la respuesta es correcta se guarda en el log de acciones
                    usu_id = s.get_id_Usu(str(tk))
                    filename = os.path.basename(__file__).split('.')[0]
                    obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se modifica el usuario con el siguiente PK usu_id: '+str(jsdata['usu_id']),log_acc_id = 396)
                    resp_log = obj_log.guardar_dato()
                    if resp_log[0] == 'error':
                        mensaje = s.mensaje_error(datosC['idioma'],103)
                        linea['result'] = "failed"
                        linea['error'] = "Sucedio un error"
                        linea['error_cod'] = 103
                        linea["val_errors"] = str(mensaje[1][0][0])  
                        status = "400 Bad Request"

                        linea['val_errors'] = "No se pudo guardar en el log"

                elif resp[0] == "error1":
                    linea["result"] = "failed"
                    linea["error"] = "Sucedio un error"
                    linea["error_cod"] = 104
                    status = "400 Bad Request"
                    if bool(extra):
                        linea["val_errors"] = extra
                    else:
                        linea["val_errors"] = resp[1]
                else :
                    mensaje = s.mensaje_error(datosC['idioma'],60)
                    linea["result"] = "failed"
                    linea["error"] = resp[1]
                    linea["error_cod"] = 60
                    status = "400 Bad Request"
                    linea["val_errors"] = str(mensaje[1][0][0])                    
               
                        #linea["tipo"] = 'resp'
            #en caso exista algun error entra al exception
            except Exception as e:
                linea = {}
                exc_type, exc_obj, exc_tb = sys.exc_info()
                mensaje = s.mensaje_error(datosC['idioma'],50)
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
                resp = ["error", str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)]
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 50
                linea["val_errors"] = str(mensaje[1][0][0])#resp[1]
                status = "500 Internal Server Error"
        else:
            #resp = ["error", "token no validado"]
            if s.valToken(tk) :
                cod_error = 100
            else :
                cod_error = 101
            mensaje = s.mensaje_error(datosC['idioma'],cod_error)
            data = {}
            data["result"] = "failed"
            data["error"] = "Sucedio un error"
            data["error_cod"] = cod_error
            data["val_errors"] = str(mensaje[1][0][0])
            status = "401 Unauthorized"

    except validations.HttpException as e:
        linea = {}
        mensaje = s.mensaje_error(datosC['idioma'],51)
        linea["result"] = "failed"
        linea["error_cod"] = "Sucedio un error"
        linea["error"] = 51
        linea["val_errors"] = str(mensaje[1][0][0])
        status = e.status_code

    except Exception as e:
        linea = {}
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea["result"] = "failed"
        linea["error"] = "Sucedio un error"
        linea["error_cod"] = 50
        try :
            mensaje = s.mensaje_error(datosC['idioma'],50)
            linea["val_errors"] = str(mensaje[1][0][0])
        except:
            linea["val_errors"] = 'error de python' 
        status = "500 Internal Server Error"
        datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
        now = datetime.datetime.now()
        fecha= datetime.date.today()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")
        logger = logging.getLogger('__name__')
        logger.setLevel(logging.ERROR)
        nombre_log= rutalog+'_'+str(fecha)+'.log'
        fh = logging.FileHandler(nombre_log)
        fh.setLevel(logging.ERROR)
        logger.addHandler(fh)
        logger.error("Error: "+str(current_time) + datoError)

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
