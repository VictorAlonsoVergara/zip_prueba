import sys
import os

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_USU_ACCESOS_INDICADORES import MAE_USU_ACCESOS_INDICADORES
import validations


def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""
        status = "200 OK"

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):

            jsdato = s.get_Datos_Usu(str(tk))
            diccionario = MAE_USU_ACCESOS_INDICADORES.consultar_lista()
        else:
            diccionario = {}
            diccionario["result"] = "failed"
            diccionario["error"] = "Sucedio un error -cookie:" + str(cookie)
            diccionario["error_cod"] = 412
            diccionario["val_errors"] = "token no valido"

    except Exception as e:
        diccionario = {}
        diccionario["result"] = "failed"
        diccionario["error"] = "Sucedio un error -cookie:" + str(cookie)
        diccionario["error_cod"] = 412
        diccionario["val_errors"] = "token no valido"

    preoutput = json.dumps(diccionario)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
