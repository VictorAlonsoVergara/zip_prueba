import sys,os

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
from MAE_CRON import MAE_CRON
import validations


def application(environ, start_response):

	try:
		coo = ""
		jsdato = ""
		status = "200 OK"
		if environ['REQUEST_METHOD'] != 'POST':
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)
		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]

		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)
		tk = s.getCookie(cookie, "token")
		s.setToken(tk)

		if s.valToken(tk) and s.valIp(tk, str(dataIP)):
			jsdato = s.get_Datos_Usu(str(tk))

			lendata = int(environ.get("CONTENT_LENGTH", 0))
			bydata = environ["wsgi.input"].read(lendata)
			jsdata = json.loads(bydata.decode("utf-8"))

			try:
				if (jsdata["cron_tipo"] == None or jsdata["cron_tipo"]=='' or jsdata["cron_periodo"] == None or jsdata["cron_periodo"]=='' or jsdata["cron_estado"] == None or jsdata["cron_estado"]=='' ):
					respu0 = [False,'Hay dato vacio']
				else:
					respu0 = [True, 'ok']
				extra = {}
				#respu1 = validations.validate_int(jsdata["tobj_id"])
				respu2 = validations.validate_char(jsdata["cron_tipo"])
				respu3 = validations.validate_varchar(jsdata["cron_periodo"], 20)
				respu4 = validations.validate_char(jsdata["cron_estado"])
				respu5 = validations.validate_varchar(jsdata["cron_desc"],200)
				#respu7 = validations.validate_int(jsdata["prot_id"])
				#if respu1[0] == True:
				#	respu8 = validations.id_Tipo_Obj(int(jsdata["tobj_id"]))
				#else:
				#	respu8 = [False, "No se tiene un tobj_id correcto"]
				#if respu4[0] == True:
				#	respu9 = validations.id_Tab_Prot(int(jsdata["prot_id"]))
				#else:
				#	respu9 = [False, "No se tiene un prot_id correcto"]

				list_respu = [respu0, respu2, respu3, respu4, respu5]
				nombres = [
					"espacio vacio",
					"cron_tipo",
					"cron_periodo",
					"cron_estado",
					"cron_desc"
				]

				if respu0[0] and respu2[0] and respu3[0] and respu4[0] and respu5[0] :
					obj = MAE_CRON.from_json(jsdata)
					resp = obj.guardar_dato()
					obj.buscar_dato()
								   
				else:
					resp = ["error", ""]
					num = 0

					for respu in list_respu:
						if respu[0] == False:
							# resp[1] = resp[1]+'-'+nombres[num]+': '+respu[1]+' \n'
							extra[nombres[num]] = respu[1]
						num = num + 1

			except Exception as e:
				resp = ["error", str(e)]
			linea = {}

			if resp[0] == "ok":
				linea["result"] = "ok"
				#data.update(obj.get_diccionario())
				linea["data"] = obj.get_diccionario()

				#Como la respuesta es correcta se guarda en el log de acciones
				usu_id = s.get_id_Usu(str(tk))
				filename = os.path.basename(__file__).split('.')[0]
				obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se creo el cron con el siguiente PK cron_id: '+str(obj.cron_id),log_acc_id = 410)
				resp_log = obj_log.guardar_dato()
				if resp_log[0] == 'error':
					linea['result'] = "failed"
					linea['error'] = "Sucedio un error"
					linea['error_cod'] = 411
					status = "400 Bad Request"
					linea['val_errors'] = "No se pudo guardar en el log"

			else:
				linea["result"] = "failed"
				linea["error"] = "Sucedio un error"
				linea["error_cod"] = 412
				#linea["cron_desc"] = str(jsdata["cron_desc"])
							  
				status = "400 Bad Request"
				if bool(extra):
					linea["val_errors"] = extra
				else:
					linea["val_errors"] = resp[1]
		else:
			linea = {}
			linea["result"] = "failed"
			linea["error"] = "Sucedio un error -cookie:" + str(cookie)
			linea["error_cod"] = 413
			linea["val_errors"] = "token no valido"
			status = "401 Unauthorized"

	except validations.HttpException as e:
		linea = {}
		linea["result"] = "failed"
		linea["error_cod"] = e.code
		linea["error"] = e.message
		linea["val_errors"] = e.message
		status = e.status_code

	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		linea = {}
		linea["result"] = "failed"
		linea["error"] = (
			"Sucedio un error -cookie: "
			+ str(e)
			+ " - "
			+ str(exc_type)
			+ " - "
			+ str(fname)
			+ " - "
			+ str(exc_tb.tb_lineno)
		)  # +str(cookie)
		linea["error_cod"] = 412
		linea["val_errors"] = "token no validado"
		status = "500 Internal Server Error"
	
	preoutput = json.dumps(linea)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]
