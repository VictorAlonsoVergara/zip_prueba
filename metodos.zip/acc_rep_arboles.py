import sys, os
import logging,datetime
rutalog="/home/sistema/log/Traxium"
from urllib.parse import parse_qs
from html import escape
sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_USU_ACCESOS_ARBOLES import MAE_USU_ACCESOS_ARBOLES
import validations


def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""
        status = "200 OK"

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        datosB = s.getCookie(cookie, "dato")
        len_datosB = len(datosB)
        datosC = json.loads(datosB[1:(len_datosB-1)])          
        s.setToken(tk)
        if environ['REQUEST_METHOD'] != 'GET':
            #status = "405 Method Not Allowed"
            raise validations.HttpException(405)
        if s.valToken(tk) and s.valIp(tk, str(dataIP)):
            jsdato = s.get_Datos_Usu(str(tk))
            bdata = environ["PATH_INFO"]
            diccionario_resp = {}
            extra = {}
            pass_flag = True
            estado_val = None
            try:
                qs = parse_qs(qs = environ['QUERY_STRING'],max_num_fields = 1)
            except Exception as e:
                raise validations.HttpException(400,'Error al parsear query string',str(e))

            diccionario_resp['urep_id'] = validations.validate_int(bdata.split("/")[1])
            if diccionario_resp['urep_id'][0] is True:
                diccionario_resp['urep_id'] = validations.id_Mae_Usu_Accesos_Reportes(bdata.split("/")[1])
            if len(qs.keys()) > 0:
                if 'estado' in qs.keys():
                    estado_val = escape(qs['estado'][0])
                    diccionario_resp['uarb_estado'] = validations.validate_boolean(estado_val)
                    if diccionario_resp['uarb_estado'][0] is False:
                        is_string_bool = (estado_val == 'true')+(estado_val == 'false')
                        diccionario_resp['uarb_estado'] = [is_string_bool,(is_string_bool*(' uarb_estado'))]
                else:
                    diccionario_resp['uarb_estado'] = [False,' uarb_estado']
            else:
                diccionario_resp['uarb_estado'] = [True,'Ok']

            for _,value in diccionario_resp.items():
                if value[0] is False:
                    pass_flag = False
            # type_valid = validations.validate_int(bdata.split("/")[1])
            # if type_valid[0] == True:
            #     id_valid = validations.id_Mae_Usu_Accesos_Reportes(bdata.split("/")[1])
            #     try:
            #         qs = parse_qs(qs = environ['QUERY_STRING'],max_num_fields = 1)
            #     except ValueError as e:
            #         raise validations.HttpException(400,'Error al parsear query string',str(e))
            #     estado_query = None
            #     estado_is_bool = [True,'None value']
            #     if 'estado' in qs.keys():
            #         estado_query = escape(qs['estado'][0])
            #         is_bool = (estado_query == 'true')+(estado_query == 'false')
            #         if is_bool is True:
            #             estado_is_bool[is_bool,'Valor de boolean']
            #         else:
            #             estado_is_bool[is_bool,'No se ha ingresado un valor true o false']
            #     elif len(qs.keys()) > 0:
            #         estado_is_bool[False,'Se ha ingresado un parametro equivocado']
            #     if id_valid[0] is True and estado_is_bool[0] is True:
                if pass_flag is True:
                    urep_id = bdata.split("/")[1]
                    uarb_estado = estado_val
                    resp = MAE_USU_ACCESOS_ARBOLES.listar_accesos_arboles(urep_id,uarb_estado)
                    if resp['result'] != 'ok' and resp['result'] != 'nodata':
                        mensaje1 = s.mensaje_error(datosC['idioma'],60)
                        resp["result"] = "failed"
                        resp["error"] = resp["val_errors"]
                        resp["error_cod"] = 60
                        resp["val_errors"] = str(mensaje1[1][0][0])
                        status = "400 Bad Request"
                else:
                    for key,value in diccionario_resp.items():
                        if value[0] is False:
                            if len(respu) == 3 :
                                mensaje1 = s.mensaje_error(datosC['idioma'],respu[2])
                                extra[key] = str(mensaje1[1][0][0]) + respu[1]
                            else :
                                mensaje1 = s.mensaje_error(datosC['idioma'],104)
                                extra[key] = str(mensaje1[1][0][0]) + respu[1]
                    resp = {}
                    resp["result"] = "failed"
                    resp["error"] = "Sucedio un error"
                    resp["error_cod"] = 51
                    resp["val_errors"] = extra
                    status = "400 Bad Request"
            # else:
            #     resp = {}
            #     resp["result"] = "failed"
            #     resp["error"] = "Sucedio un error"
            #     resp["error_cod"] = 412
            #     resp["val_errors"] = type_valid[1]
            #     status = "400 Bad Request"
        else:
            if s.valToken(tk) :
                cod_error = 100
            else :
                cod_error = 101
            mensaje = s.mensaje_error(datosC['idioma'],cod_error)            
            resp = {}
            resp["result"] = "failed"
            resp["error"] = "Sucedio un error"
            resp["error_cod"] = cod_error
            resp["val_errors"] = str(mensaje[1][0][0])
            status = "401 Unauthorized"

    except validations.HttpException as e:
        resp = {}
        mensaje = s.mensaje_error(datosC['idioma'],51)
        resp["result"] = "failed"
        resp["error_cod"] = "Sucedio un error"
        resp["error"] = 51
        resp["val_errors"] = str(mensaje[1][0][0])
        status = e.status_code

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        resp = {}
        resp["result"] = "failed"
        resp["error"] = "Sucedio un error"
        resp["error_cod"] = 50
        try :
            mensaje = s.mensaje_error(datosC['idioma'],50)
            resp["val_errors"] = str(mensaje[1][0][0])
        except:
            resp["val_errors"] = 'error de python' 
        status = "500 Internal Server Error"
        datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
        now = datetime.datetime.now()
        fecha= datetime.date.today()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")
        logger = logging.getLogger('__name__')
        logger.setLevel(logging.ERROR)
        nombre_log= rutalog+'_'+str(fecha)+'.log'
        fh = logging.FileHandler(nombre_log)
        fh.setLevel(logging.ERROR)
        logger.addHandler(fh)
        logger.error("Error: "+str(current_time) + datoError)

    
    preoutput = json.dumps(resp)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
