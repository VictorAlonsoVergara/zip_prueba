import sys, os
import logging,datetime
rutalog="/home/sistema/log/Traxium"
sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_USU_ACCESOS_REPORTES import MAE_USU_ACCESOS_REPORTES
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations


def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""
        status = "200 OK"

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        datosB = s.getCookie(cookie, "dato")
        len_datosB = len(datosB)
        datosC = json.loads(datosB[1:(len_datosB-1)])          
        s.setToken(tk)
        if environ['REQUEST_METHOD'] != 'PUT' and environ['REQUEST_METHOD'] != 'POST':
            #status = "405 Method Not Allowed"
            raise validations.HttpException(405)
        if s.valToken(tk) and s.valIp(tk, str(dataIP)):

            jsdato = s.get_Datos_Usu(str(tk))
            lendata = int(environ.get("CONTENT_LENGTH", 0))
            bydata = environ["wsgi.input"].read(lendata)
            jsdata = json.loads(bydata.decode("utf-8"))
            try:
                pass_flag = True
                extra = {}
                diccionario_respu = {}

                diccionario_respu['rep_id'] = validations.validate_int(jsdata["rep_id"])
                diccionario_respu['usu_id'] = validations.validate_int(jsdata["usu_id"])
                diccionario_respu['urep_id'] = validations.validate_int(jsdata["urep_id"])
                #diccionario_respu['urep_estado'] = validations.validate_boolean(jsdata["urep_estado"])

                if diccionario_respu['rep_id'][0] is True:
                    diccionario_respu['rep_id'] = validations.id_Tab_Rep(int(jsdata["rep_id"]))
                if diccionario_respu['usu_id'][0] is True:
                    diccionario_respu['usu_id'] = validations.id_Mae_Usu(int(jsdata["usu_id"]))
                if diccionario_respu['urep_id'][0] is True:
                    diccionario_respu['urep_id'] = validations.id_Mae_Usu_Accesos_Reportes(int(jsdata["urep_id"]))

                for key,value in jsdata.items():
                    value_empty = validations.validate_empty(value)
                    if key != 'urep_id': #Este Valor no puede ser vacio
                        if value_empty[0] is True:
                            diccionario_respu[key] = value_empty
                
                for _,value in diccionario_respu.items():
                    if value[0] is False:
                        pass_flag = False
                        break

                if pass_flag:
                    obj = MAE_USU_ACCESOS_REPORTES.from_json(jsdata)
                    resp = obj.modificar()
                    obj.buscar_dato()
                else:
                    resp = ["error1", ""]

                    for key,respu in diccionario_respu.items():
                        if respu[0] is False:
                            if len(respu) == 3 :
                                mensaje1 = s.mensaje_error(datosC['idioma'],respu[2])
                                extra[key] = str(mensaje1[1][0][0]) + respu[1]
                            else :
                                mensaje1 = s.mensaje_error(datosC['idioma'],104)
                                extra[key] = str(mensaje1[1][0][0]) + respu[1]

            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
                resp = ["error", str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)]
            
            linea = {}
            if resp[0] == "ok":
                linea["result"] = "ok"
                linea["data"] = obj.get_diccionario()
                #Como la respuesta es correcta se guarda en el log de acciones
                usu_id = s.get_id_Usu(str(tk))
                #filename = os.path.basename(__file__).split('.')[0]
                obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se modifico el usuario_acceso_reportes con el siguiente PK urep_id: '+str(jsdata["urep_id"]),log_acc_id = 447)
                resp_log = obj_log.guardar_dato()

            elif resp[0] == "error1":
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 104
                status = "400 Bad Request"
                if bool(extra):
                    linea["val_errors"] = extra
                else:
                    linea["val_errors"] = resp[1]
            else :
                mensaje = s.mensaje_error(datosC['idioma'],60)
                linea["result"] = "failed"
                linea["error"] = resp[1]
                linea["error_cod"] = 60
                status = "400 Bad Request"
                linea["val_errors"] = str(mensaje[1][0][0])
        else:
            if s.valToken(tk) :
                cod_error = 100
            else :
                cod_error = 101
            mensaje = s.mensaje_error(datosC['idioma'],cod_error)            
            linea = {}
            linea["result"] = "failed"
            linea["error"] = "Sucedio un error"
            linea["error_cod"] = cod_error
            linea["val_errors"] = str(mensaje[1][0][0])
            status = "401 Unauthorized"

    except validations.HttpException as e:
        linea = {}
        mensaje = s.mensaje_error(datosC['idioma'],51)
        linea["result"] = "failed"
        linea["error_cod"] = "Sucedio un error"
        linea["error"] = 51
        linea["val_errors"] = str(mensaje[1][0][0])
        status = e.status_code

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea = {}
        linea["result"] = "failed"
        linea["error"] = "Sucedio un error"
        linea["error_cod"] = 50
        try :
            mensaje = s.mensaje_error(datosC['idioma'],50)
            linea["val_errors"] = str(mensaje[1][0][0])
        except:
            linea["val_errors"] = 'error de python' 
        status = "500 Internal Server Error"
        datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
        now = datetime.datetime.now()
        fecha= datetime.date.today()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")
        logger = logging.getLogger('__name__')
        logger.setLevel(logging.ERROR)
        nombre_log= rutalog+'_'+str(fecha)+'.log'
        fh = logging.FileHandler(nombre_log)
        fh.setLevel(logging.ERROR)
        logger.addHandler(fh)
        logger.error("Error: "+str(current_time) + datoError)

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
