import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAT_TIPO_OBJ import MAT_TIPO_OBJ
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
from clsSession import Session
import validations


def application(environ, start_response):
    try:
        coo = ""
        jsdato = ""
        extra = {}
        status = "500 Internal Server Error"
        if environ['REQUEST_METHOD'] != 'POST':
            #status = "405 Method Not Allowed"
            raise validations.HttpException(405)

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        lendata = int(environ.get("CONTENT_LENGTH", 0))  # se guarda los datos enviados
        bydata = environ["wsgi.input"].read(lendata)
        jsdata = json.loads(bydata.decode("utf-8"))  # se convierte los datos y json
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)  # se obtiene la informacion del cookie
        tk = s.getCookie(cookie, "token")  # se escoge la informacion guardada en la variable token
        if s.valToken(tk) and s.valIp(tk, str(dataIP)):  # se valida si el token esta validado
            jsdato = s.get_Datos_Usu(str(tk))  # se busca los datos del usuario vinculados con el token
            try:
                if (jsdata["tobj_desc"] == None or jsdata["tobj_desc"]=='' 
                    or jsdata["tobj_estado"] == None or jsdata["tobj_estado"]=='' 
                    or jsdata["tobj_consulta"] == None or jsdata["tobj_consulta"]=='' 
                    or jsdata["tobj_ldesc"] == None or jsdata["tobj_ldesc"]==''
                    #or jsdata["tobj_padre_id"] == None or jsdata["tobj_padre_id"]==''
                    or jsdata["tobj_arb_fisico"] == None or jsdata["tobj_arb_fisico"]==''
                    or jsdata["tobj_arb_logico"] == None or jsdata["tobj_arb_logico"]==''
                    or jsdata["tobj_pasivo"] == None or jsdata["tobj_pasivo"]==''
                    or jsdata["tobj_key"] == None or jsdata["tobj_key"]==''
                    ):
                    respu0 = [False,'Hay dato vacio']
                else:
                    respu0 = [True, 'ok']                
                extra = {}
                respu1 = validations.validate_varchar(jsdata["tobj_desc"], 200)  
                respu2 = validations.validate_char(jsdata["tobj_estado"]) 
                respu3 = validations.validate_char(jsdata["tobj_consulta"])  
                respu4 = validations.validate_string(jsdata["tobj_ldesc"])  
                if jsdata["tobj_padre_id"] == "NULL":
                    respu5 = [True, "ok"]
                else:
                    respu5 = validations.validate_int(jsdata["tobj_padre_id"]) 
                respu6 = validations.validate_boolean(jsdata["tobj_arb_fisico"])  
                respu7 = validations.validate_boolean(jsdata["tobj_arb_logico"])  
                respu8 = validations.validate_boolean(jsdata["tobj_pasivo"])
                respu10 = validations.validate_varchar(jsdata["tobj_key"],10)
                if (respu5[0]):
                    respu9 = MAT_TIPO_OBJ.validations_crear(jsdata["tobj_padre_id"])
                else:
                    respu9 = [False,"error en tobj_padre_id" ]
                list_respu = [respu0, respu1, respu2, respu3, respu4,respu5,respu6,respu7,respu8,respu9,respu10]
                nombres = ["espacio vacio","tobj_desc", "tobj_estado", "tobj_consulta", "tobj_ldesc", "tobj_padre_id", "tobj_arb_fisico", "tobj_arb_logico", "tobj_pasivo","tobj_padre_id","tobj_key"]

                if (respu0[0] and respu1[0] and respu2[0] and respu3[0] and respu4[0]
                    and respu5[0] and respu6[0] and respu7[0] and respu8[0] and respu9[0] and respu10[0]):
                    jsdata["tobj_arb_fisico"] = bool(jsdata["tobj_arb_fisico"])
                    jsdata["tobj_arb_logico"] = bool(jsdata["tobj_arb_logico"])
                    jsdata["tobj_pasivo"] = bool(jsdata["tobj_pasivo"])
                    obj = MAT_TIPO_OBJ.from_json(jsdata)
                    resp = obj.guardar_dato()  # se guarda los datos de la clase creada
                    obj.buscar_dato()
                else:
                    resp = ["error", ""]
                    num = 0
                    for respu in list_respu:
                        if respu[0] == False:
                            extra[nombres[num]] = respu[1]
                        num = num + 1
                linea = {}
                if resp[0] == "ok":
                    linea["result"] = "ok"
                    linea["data"] = obj.get_diccionario()
                    '''linea["tobj_id"] = obj.tobj_id
                    linea["tobj_desc"] = obj.tobj_desc
                    linea["tobj_estado"] = obj.tobj_estado
                    linea["tobj_consulta"] = obj.tobj_consulta
                    linea["tobj_ldesc"] = obj.tobj_ldesc
                    linea["tobj_padre_id"] = obj.tobj_padre_id
                    linea["tobj_arb_fisico"] = obj.tobj_arb_fisico
                    linea["tobj_arb_logico"] = obj.tobj_arb_logico
                    linea["tobj_pasivo"] = obj.tobj_pasivo'''
                    
                    #Como la respuesta es correcta se guarda en el log de acciones
                    usu_id = s.get_id_Usu(str(tk))
                    filename = os.path.basename(__file__).split('.')[0]
                    obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se creo el tipo de objeto con el siguiente PK tobj_id: '+str(obj.tobj_id),log_acc_id = 415)
                    resp_log = obj_log.guardar_dato()
                    status = "200 OK"
                    if resp_log[0] == 'error':
                        linea['result'] = "failed"
                        linea['error'] = "Sucedio un error"
                        linea['error_cod'] = 500
                        status = "400 Bad Request"
                        linea['val_errors'] = "No se pudo guardar en el log"
                else:
                    linea["result"] = "failed"
                    linea["error"] = "Sucedio un error"
                    linea["error_cod"] = 400
                    status = "400 Bad Request"
                    if bool(extra):
                        linea["val_errors"] = extra
                    else:
                        linea["val_errors"] = resp[1]

            except Exception as e:
                linea = {}
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
                resp = ["error", str(e)+' '+str(exc_type)+" "+str(fname)+" "+str(exc_tb.tb_lineno)]
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 400
                linea["val_errors"] = resp[1]
                status = "400 Bad Request"
        else:
            resp = ["error", "Token no validado"]#+str(tk)+" "+str(dataIP)]
            raise validations.HttpException(401,"Token no validado")

    except validations.HttpException as e:
        linea = {}
        linea.update(e.get_error_dict())
        status = e.status_code

    except Exception as e:
        linea = {}
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        resp = ["error", str(e)+' '+str(exc_type)+" "+str(fname)+" "+str(exc_tb.tb_lineno)]
        linea["result"] = "failed"
        linea["error"] = "Sucedio un error"
        linea["error_cod"] = 500
        linea["val_errors"] = resp[1]
        status = "500 Internal Server Error"

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
