import sys, os

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from ARB_FISICO import ARB_FISICO
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations


def application(environ, start_response):

	try:
		coo = ""
		jsdato = ""
		status = "200 OK"
		if environ['REQUEST_METHOD'] != 'PUT' and environ['REQUEST_METHOD'] != 'POST':
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)

		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]

		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)
		tk = s.getCookie(cookie, "token")
		s.setToken(tk)

		if s.valToken(tk) and s.valIp(tk, str(dataIP)):
			jsdato = s.get_Datos_Usu(str(tk))
			lendata = int(environ.get("CONTENT_LENGTH", 0))
			bydata = environ["wsgi.input"].read(lendata)
			jsdata = json.loads(bydata.decode("utf-8"))
			try:
				extra = {}
				pass_flag = True
				diccionario_respu = {}
				diccionario_respu['fis_id'] = validations.validate_int(jsdata["fis_id"])
				diccionario_respu['fis_desc'] = validations.validate_varchar(jsdata["fis_desc"],200)
				diccionario_respu['fis_orden'] = validations.validate_varchar(jsdata["fis_orden"],30)
				diccionario_respu['fis_id_padre'] = validations.validate_int(jsdata["fis_id_padre"])

				if diccionario_respu['fis_id_padre'][0] is True:
					diccionario_respu['fis_id_padre'] = validations.id_Arb_Fis(int(jsdata["fis_id_padre"]))

				if diccionario_respu['fis_id'][0] is True:
					diccionario_respu['fis_id'] = validations.id_Arb_Fis(jsdata["fis_id"])
				
				if diccionario_respu['fis_id'][0] is True and diccionario_respu['fis_id_padre'][0] is True:
					if jsdata["fis_id"] == jsdata["fis_id_padre"]:
						diccionario_respu['fis_id_padre'] = [False, "El nuevo padre no puede ser el mismo nodo"]

				if jsdata["fis_id_padre"] == "NULL":
					diccionario_respu['fis_id_padre'][0] = True
				
				for key,value in jsdata.items():
					value_empty = validations.validate_empty(value)
					if value_empty[0] is True and key != 'fis_id':
						diccionario_respu[key][0] = True

				for _,value in diccionario_respu.items():
					if value[0] is False:
						pass_flag = False
						break
				
				if pass_flag is True:
					obj = ARB_FISICO.from_json(jsdata)
					resp = obj.modificar()
				else:
					resp = ["error", ""]
					#num = 0
					for key,respu in diccionario_respu.items():
						if respu[0] == False:
							# resp[1] = resp[1]+'-'+nombres[num]+': '+respu[1]+' \n'
							extra[key] = respu[1]
						#num = num + 1

			except Exception as e:
				status = "400 Bad Request"
				resp = ["error", str(e)]
			linea = {}

			if resp[0] == "ok":
				linea["result"] = "ok"
				linea["data"] = obj.get_diccionario()
				'''linea["fis_id"] = obj.fis_id
				linea["fis_id_padre"] = obj.fis_id_padre
				linea["fis_desc"] = obj.fis_desc
				linea["fis_orden"] = obj.fis_orden'''
				#Como la respuesta es correcta se guarda en el log de acciones
				usu_id = s.get_id_Usu(str(tk))
				filename = os.path.basename(__file__).split('.')[0]
				obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se modifico el arb_fisico con el siguiente PK fis_id: '+str(jsdata["fis_id"]),log_acc_id = 462)
				resp_log = obj_log.guardar_dato()
				if resp_log[0] == 'error':
					linea['result'] = "failed"
					linea['error'] = "Sucedio un error"
					linea['error_cod'] = 411
					status = "400 Bad Request"
					linea['val_errors'] = "No se pudo guardar en el log"
			else:
				status = "400 Bad Request"
				linea["result"] = "failed"
				linea["error"] = "Sucedio un error"
				linea["error_cod"] = 411
				if bool(extra):
					linea["val_errors"] = extra
				else:
					linea["val_errors"] = resp[1]
		else:
			status = "401 Unauthorized"
			linea = {}
			linea["result"] = "failed"
			linea["error"] = "Sucedio un error -cookie:" + str(cookie)
			linea["error_cod"] = 412
			linea["val_errors"] = "token no valido"
	except validations.HttpException as e:
		linea = {}
		linea["result"] = "failed"
		linea["error_cod"] = e.code
		linea["error"] = e.message
		linea["val_errors"] = e.message
		status = e.status_code
	except Exception as e:
		status = "500 Internal Server Error"
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		linea = {}
		linea["result"] = "failed"
		linea["error"] = (
			"Sucedio un error -cookie: "
			+ str(e)
			+ " - "
			+ str(exc_type)
			+ " - "
			+ str(fname)
			+ " - "
			+ str(exc_tb.tb_lineno)
		)  # +str(cookie)
		linea["error_cod"] = 413
		linea["val_errors"] = "token no validado"

	preoutput = json.dumps(linea)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]
