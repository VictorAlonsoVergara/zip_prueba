import sys, os

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from ARB_FISICO import ARB_FISICO
import validations


def application(environ, start_response):

	try:
		coo = ""
		jsdato = ""
		status = "200 OK"
		if environ['REQUEST_METHOD'] != 'GET':
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)

		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]

		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)
		tk = s.getCookie(cookie, "token")
		s.setToken(tk)

		if s.valToken(tk) and s.valIp(tk, str(dataIP)):
			jsdato = s.get_Datos_Usu(str(tk))
			bdata = environ["PATH_INFO"]
			respuest = validations.validate_int(bdata.split("/")[1])
			if respuest[0] == True:
				respu = validations.id_Arb_Fis(bdata.split("/")[1])
				if respu[0]:
					obj = ARB_FISICO(int(bdata.split("/")[1]))
					resp = obj.buscar_hermanos()
					if 'error' in resp :
						status = "400 Bad Request"
					else:
						usu_id = s.get_id_Usu(str(tk))
						filename = os.path.basename(__file__).split('.')[0]
						obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se busco el hermano de arb_fisico con el siguiente PK fis_id: '+str(bdata.split("/")[1]),log_acc_id = 467)
						resp_log = obj_log.guardar_dato()
						if resp_log[0] == 'error':
							resp = {}
							status = "400 Bad Request"
							resp['result'] = "failed"
							resp['error'] = "Sucedio un error"
							resp['error_cod'] = 411
							status = "500 Internal Server Error"
							resp['val_errors'] = "No se pudo guardar en el log"

				else:
					status = "400 Bad Request"
					resp = {}
					resp["result"] = "failed"
					resp["error"] = "Sucedio un error"
					resp["error_cod"] = 412
					resp["val_errors"] = respu[1]
			else:
				status = "400 Bad Request"
				resp = {}
				resp["result"] = "failed"
				resp["error"] = "Sucedio un error"
				resp["error_cod"] = 412
				resp["val_errors"] = respuest[1]
		else:
			status = "401 Unauthorized"
			resp = {}
			resp["result"] = "failed"
			resp["error"] = "Sucedio un error -cookie:" + str(cookie)
			resp["error_cod"] = 412
			resp["val_errors"] = "token no valido"
	except validations.HttpException as e:
		resp = {}
		resp["result"] = "failed"
		resp["error_cod"] = e.code
		resp["error"] = e.message
		resp["val_errors"] = e.message
		status = e.status_code

	except Exception as e:
		status = "500 Internal Server Error"
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		resp = {}
		resp["result"] = "failed"
		resp["error"] = (
			"Sucedio un error -cookie: "
			+ str(e)
			+ " - "
			+ str(exc_type)
			+ " - "
			+ str(fname)
			+ " - "
			+ str(exc_tb.tb_lineno)
		)  # +str(cookie)
		resp["error_cod"] = 412
		resp["val_errors"] = "token no validado"

	preoutput = json.dumps(resp)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]
