import sys, os

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from TAB_EJECUCIONES import TAB_EJECUCIONES
import validations


def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""
        status = "200 OK"

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):

            jsdato = s.get_Datos_Usu(str(tk))
            lendata = int(environ.get("CONTENT_LENGTH", 0))
            bydata = environ["wsgi.input"].read(lendata)
            jsdata = json.loads(bydata.decode("utf-8"))

            try:
                if (jsdata["cron_id"] == None or jsdata["cron_id"]=='' or jsdata["eje_fecha_ini"] == None or jsdata["eje_fecha_ini"]=='' or jsdata["eje_fecha_fin"] == None or jsdata["eje_fecha_fin"]=='' or jsdata["eje_log"] == None or jsdata["eje_log"]=='' or jsdata["eje_fecha_transferencia"] == None or jsdata["eje_fecha_transferencia"]=='' or jsdata["eje_fecha_parseo"] == None or jsdata["eje_fecha_parseo"]==''):
                    respu0 = [False,'Hay dato vacio']
                else:
                    respu0 = [True, 'ok']
                extra = {}
                respu1 = validations.validate_int(jsdata["cron_id"])
                respu2 = validations.validate_date_time(
                    jsdata["eje_fecha_ini"]
                )  # validar tipo timestamp
                respu3 = validations.validate_date_time(
                    jsdata["eje_fecha_fin"]
                )  # validar tipo timestamp
                respu4 = validations.validate_varchar(jsdata["eje_log"], 50)
                respu5 = validations.validate_date_time(
                    jsdata["eje_fecha_transferencia"]
                )  # validar tipo timestamp
                respu6 = validations.validate_date_time(
                    jsdata["eje_fecha_parseo"]
                )  # validar tipo timestamp

                if respu1[0] == True:
                    respu7 = validations.id_Mae_Cron(int(jsdata["cron_id"]))
                else:
                    respu7 = [False, "No se tiene un cron_id correcto"]
                list_respu = [respu0, respu1, respu2, respu3, respu4, respu5, respu6, respu7]
                nombres = [
                    "espacio vacio",
                    "cron_id",
                    "eje_fecha_ini",
                    "eje_fecha_fin",
                    "eje_log",
                    "eje_fecha_transferencia",
                    "eje_fecha_parseo",
                    "cron_id",
                ]

                if (
                    respu0[0]
                    and respu1[0]
                    and respu2[0]
                    and respu3[0]
                    and respu4[0]
                    and respu5[0]
                    and respu6[0]
                    and respu7[0]
                ):
                    obj = TAB_EJECUCIONES(
                        int(jsdata["cron_id"]),
                        jsdata["eje_fecha_ini"],
                        jsdata["eje_fecha_fin"],
                        jsdata["eje_log"],
                        jsdata["eje_fecha_transferencia"],
                        jsdata["eje_fecha_parseo"],
                    )
                    resp = obj.guardar_dato()
                else:
                    resp = ["error", ""]
                    num = 0

                    for respu in list_respu:
                        if respu[0] == False:
                            # resp[1] = resp[1]+'-'+nombres[num]+': '+respu[1]+' \n'
                            extra[nombres[num]] = respu[1]
                        num = num + 1

            except Exception as e:
                resp = ["error", str(e)]
            linea = {}

            if resp[0] == "ok":
                linea["result"] = "ok"
                linea["data"] = obj.get_diccionario()
                #linea["eje_id"] = obj.eje_id
            else:
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 412
                if bool(extra):
                    linea["val_errors"] = extra
                else:
                    linea["val_errors"] = resp[1]

        else:
            linea = {}
            linea["result"] = "failed"
            linea["error"] = "Sucedio un error -cookie:" + str(cookie)
            linea["error_cod"] = 412
            linea["val_errors"] = "token no valido"

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea = {}
        linea["result"] = "failed"
        linea["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        linea["error_cod"] = 412
        linea["val_errors"] = "token no validado"

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
