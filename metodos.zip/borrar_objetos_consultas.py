import sys
import datetime, logging
sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_OBJETOS_CONSULTAS import MAE_OBJETOS_CONSULTAS
import validations
import os
rutalog="/home/sistema/log/Traxium"

def application(environ, start_response):

    try:

        status = "200 OK"
        jsdato = ""
        extra = {}
        lendata = int(environ.get("CONTENT_LENGTH", 0))
        bydata = environ["wsgi.input"].read(lendata)
        jsdata = json.loads(bydata.decode("utf-8"))        

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):
            jsdato = s.get_Datos_Usu(str(tk))
            try:
                respu1 = validations.validate_int(jsdata["obj_id"])
                respu2 = validations.validate_int(jsdata["con_id"])
                if respu1[0] and respu2 [0] == True:
                    respu3 = validations.id_Mae_Obj_Con(int(jsdata["obj_id"]),int(jsdata["con_id"]))
                else:
                    respu3 = [False, "No se tiene un obj_id y con_id correctos"]
                
                list_respu = [respu1, respu2, respu3]
                nombres = ["obj_id", "con_id", "obj_id & con_id"]

                if respu1[0] and respu2[0] and respu3[0] :
                    obj = MAE_OBJETOS_CONSULTAS("","","",int(jsdata["obj_id"]), int(jsdata["con_id"]))
                    lista = obj.borrar()
                    if lista['result'] == "ok":
                        resp = ["ok", " "]
                    else:
                        resp = ["error", lista['val_errors']]
                else:
                    resp = ["error", ""]
                    num = 0
                    for respu in list_respu:
                        if respu[0] == False:
                            # resp[1] = resp[1]+'-'+respu[1]+'\n'
                            extra[nombres[num]] = respu[1]
                        num = num + 1

            except Exception as e:
                resp = ["error", str(e)]
        else:
            resp = ["error", "token no validado"]
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        resp = [
            "error",
            "token no validado"
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno),
        ]                
        datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
        now = datetime.datetime.now()
        fecha= datetime.date.today()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")
        logger = logging.getLogger('__name__')
        logger.setLevel(logging.ERROR)
        nombre_log= rutalog+'_'+str(fecha)+'.log'
        fh = logging.FileHandler(nombre_log)
        fh.setLevel(logging.ERROR)
        logger.addHandler(fh)
        logger.error("Error: "+str(current_time) + datoError)

    linea = {}
    if resp[0] == "ok":
        linea = {}
        linea["result"] = "ok"
        linea["descripcion"] = "Se borro correctamente"

    else:
        linea["result"] = "failed"
        linea["error"] = "Sucedio un error"
        linea["error_cod"] = 412
        if bool(extra):
            linea["val_errors"] = extra
        else:
            linea["val_errors"] = resp[1]

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
