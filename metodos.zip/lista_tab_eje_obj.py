import sys, os

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from TAB_EJECUCIONES_OBJETO import TAB_EJECUCIONES_OBJETO
import validations


def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""
        status = "500 Internal Server Error"
        if environ['REQUEST_METHOD'] != 'GET':
            #status = "405 Method Not Allowed"
            raise validations.HttpException(405)
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):
            jsdato = s.get_Datos_Usu(str(tk))
            diccionario = TAB_EJECUCIONES_OBJETO.consultar_lista()
            status = "200 OK"
            if "error" in diccionario :
                status = "400 Bad Request"

        else:
            diccionario = {}
            diccionario["result"] = "failed"
            diccionario["error"] = "Sucedio un error -cookie:" + str(cookie)
            diccionario["error_cod"] = 401
            diccionario["val_errors"] = "token no valido"
            status = "401 Unauthorized"

    except validations.HttpException as e:
        diccionario = {}
        diccionario["result"] = "failed"
        diccionario["error_cod"] = e.code
        diccionario["error"] = e.message
        diccionario["val_errors"] = e.message
        status = e.status_code

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        diccionario = {}
        diccionario["result"] = "failed"
        diccionario["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        diccionario["error_cod"] = 500
        status = "500 Internal Server Error"

    preoutput = json.dumps(diccionario)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
