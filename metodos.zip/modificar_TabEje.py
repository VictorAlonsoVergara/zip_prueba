import sys, os
import logging,datetime
rutalog="/home/sistema/log/Traxium_"
sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from TAB_EJECUCIONES import TAB_EJECUCIONES
import validations

def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""
        status = "200 OK"
        flag : "1"

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        datosB = s.getCookie(cookie, "dato")
        len_datosB = len(datosB)
        datosC = json.loads(datosB[1:(len_datosB-1)])           
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):

            flag = "2"
            jsdato = s.get_Datos_Usu(str(tk))                      
            lendata = int(environ.get("CONTENT_LENGTH", 0))
            bydata = environ["wsgi.input"].read(lendata)
            jsdata = json.loads(bydata.decode("utf-8"))

            try:
                flag ="3"
                extra = {}
                respu1 = validations.validate_int(jsdata["cron_id"])
                respu2 = validations.validate_date_time(
                    jsdata["eje_fecha_ini"]
                )  # validar tipo de dato date time
                respu3 = validations.validate_date_time(
                    jsdata["eje_fecha_fin"]
                )  # validar tipo de dato date time
                respu4 = validations.validate_varchar(jsdata["eje_log"], 50)
                respu5 = validations.validate_date_time(
                    jsdata["eje_fecha_transferencia"]
                )  # validar tipo de dato date time
                respu6 = validations.validate_date_time(
                    jsdata["eje_fecha_parseo"]
                )  # validar tipo de dato date time
                respu7 = validations.validate_int(jsdata["eje_id"])

                if respu1[0] == True:
                    respu8 = validations.id_Mae_Cron(int(jsdata["cron_id"]))
                else:
                    respu8 = [False, " id_Mae_Cron"]

                if respu7[0] == True:
                    respu9 = validations.id_Tab_Eje(int(jsdata["eje_id"]))
                else:
                    respu9 = [False, " id_Tab_Eje"]

                list_respu = [
                    respu1,
                    respu2,
                    respu3,
                    respu4,
                    respu5,
                    respu6,
                    respu7,
                    respu8,
                    respu9,
                ]
                nombres = [
                    "cron_id",
                    "eje_fecha_ini",
                    "eje_fecha_fin",
                    "eje_log",
                    "eje_fecha_transferencia",
                    "eje_fecha_parseo",
                    "eje_id",
                    "cron_id",
                    "eje_id",
                ]

                if (
                    respu1[0]
                    and respu2[0]
                    and respu3[0]
                    and respu4[0]
                    and respu5[0]
                    and respu6[0]
                    and respu7[0]
                    and respu8[0]
                    and respu9[0]
                ):
                    obj = TAB_EJECUCIONES(
                        int(jsdata["cron_id"]),
                        jsdata["eje_fecha_ini"],
                        jsdata["eje_fecha_fin"],
                        jsdata["eje_log"],
                        jsdata["eje_fecha_transferencia"],
                        jsdata["eje_fecha_parseo"],
                        int(jsdata["eje_id"]),
                    )
                    resp = obj.modificar()
                else:
                    resp = ["error1", ""]
                    num = 0

                    for respu in list_respu:
                        if respu[0] == False:                            
                            if len(respu) == 3 :
                                mensaje1 = s.mensaje_error(datosC['idioma'],respu[2])
                                extra[key] = str(mensaje1[1][0][0]) + respu[1]
                            else :
                                mensaje1 = s.mensaje_error(datosC['idioma'],104)
                                extra[key] = str(mensaje1[1][0][0]) + respu[1]
                        num = num + 1

            except Exception as e:
                resp = ["error", str(e)]
            linea = {}

            if resp[0] == "ok":
                linea["result"] = "ok"
                linea["data"] = obj.get_diccionario()
            elif resp[0] == "error1":
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 104
                status = "400 Bad Request"
                if bool(extra):
                    linea["val_errors"] = extra
                else:
                    linea["val_errors"] = resp[1]
            else :
                mensaje = s.mensaje_error(datosC['idioma'],60)
                linea["result"] = "failed"
                linea["error"] = resp[1]
                linea["error_cod"] = 60
                status = "400 Bad Request"
                linea["val_errors"] = str(mensaje[1][0][0])

        else:
            if s.valToken(tk) :
                cod_error = 100
            else :
                cod_error = 101
            mensaje = s.mensaje_error(datosC['idioma'],cod_error)            
            linea = {}
            linea["result"] = "failed"
            linea["error"] = "Sucedio un error"
            linea["error_cod"] = cod_error
            linea["val_errors"] = str(mensaje[1][0][0])

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea = {}
        linea["result"] = "failed"
        linea["error"] = "Sucedio un error"
        linea["error_cod"] = 50
        try :
            mensaje = s.mensaje_error(datosC['idioma'],50)
            linea["val_errors"] = str(mensaje[1][0][0])
        except:
            linea["val_errors"] = 'error de python' 
        #linea["flag"] = flag   
        datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
        now = datetime.datetime.now()
        fecha= datetime.date.today()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")
        logger = logging.getLogger('__name__')
        logger.setLevel(logging.ERROR)
        nombre_log=rutalog+str(fecha)+'.log'
        fh = logging.FileHandler(nombre_log)
        fh.setLevel(logging.ERROR)
        logger.addHandler(fh)
        logger.error("Error: "+str(current_time) + datoError)   

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
