import sys, os
import datetime, logging
sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_INDICADORES import MAE_INDICADORES
import validations
rutalog="/home/sistema/log/Traxium"

def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        status = "200 OK"
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):
            jsdato = s.get_Datos_Usu(str(tk))
            status = "200 OK"
            bdata = environ["PATH_INFO"]

            respuest = validations.validate_int(bdata.split("/")[1])
            if respuest[0] == True:
                obj = MAE_INDICADORES(
                    " ", " ", " ", " ", 1, " ", " ", int(bdata.split("/")[1])
                )
                dato = obj.buscar_dato()
                if dato[0] == "ok":
                    data = {}
                    data["ind_id"] = int(bdata.split("/")[1])
                    data["ind_desc"] = obj.ind_desc
                    data["ind_estado"] = obj.ind_estado
                    data["ind_ldesc"] = obj.ind_ldesc
                    data["ind_alerta"] = obj.ind_alerta
                    data["ind_trap"] = obj.ind_trap
                    data["ind_trap_definicion"] = obj.ind_trap_definicion
                    data["cron_id"] = obj.cron_id
                    data["cron_tipo"] = obj.mae_cron.cron_tipo
                    data["cron_periodo"] = obj.mae_cron.cron_periodo
                    data["cron_estado"] = obj.mae_cron.cron_estado
                    data["tobj_id"] = obj.mae_cron.tobj_id
                    data["tobj_desc"] = obj.mae_cron.mat_tipo_obj.tobj_desc
                    data["tobj_estado"] = obj.mae_cron.mat_tipo_obj.tobj_estado
                    data["tobj_consulta"] = obj.mae_cron.mat_tipo_obj.tobj_consulta
                    data["tobj_ldesc"] = obj.mae_cron.mat_tipo_obj.tobj_ldesc
                else:
                    data = {}
                    data["result"] = "failed"
                    data["error"] = "Sucedio un error"
                    data["error_cod"] = 412
                    data["val_errors"] = dato[1]
            else:
                data = {}
                data["result"] = "failed"
                data["error"] = "Sucedio un error"
                data["error_cod"] = 412
                data["val_errors"] = respuest[1]
        else:
            data = {}
            data["result"] = "failed"
            data["error"] = "Sucedio un error -cookie:" + str(cookie)
            data["error_cod"] = 412
            data["val_errors"] = "token no valido"
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        data = {}
        data["result"] = "failed"
        data["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        data["error_cod"] = 412
        data["val_errors"] = "token no validado"
        datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
        now = datetime.datetime.now()
        fecha= datetime.date.today()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")
        logger = logging.getLogger('__name__')
        logger.setLevel(logging.ERROR)
        nombre_log= rutalog+'_'+str(fecha)+'.log'
        fh = logging.FileHandler(nombre_log)
        fh.setLevel(logging.ERROR)
        logger.addHandler(fh)
        logger.error("Error: "+str(current_time) + datoError)
    preoutput = json.dumps(data)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
