import sys, os
import logging,datetime
rutalog="/home/sistema/log/Traxium"
sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_USUARIOS import MAE_USUARIOS
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
from clsSession import Session
import validations


def application(environ, start_response):
	try:
		coo = ""
		jsdato = ""
		status = "200 OK"  # se crea la respuesta de estado

		bdata = environ["PATH_INFO"]  
		respuest = validations.validate_int(bdata.split("/")[1])  
		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
			
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]
		s = Session()  
		cookie = environ.get("HTTP_COOKIE", 0) 
		tk = s.getCookie(cookie, "token")  
		datosB = s.getCookie(cookie, "dato")
		len_datosB = len(datosB)
		datosC = json.loads(datosB[1:(len_datosB-1)])           
		if environ['REQUEST_METHOD'] != 'PUT' and environ['REQUEST_METHOD'] != 'POST':
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)   
		if s.valToken(tk) and s.valIp(tk, str(dataIP)):
			jsdato = s.get_Datos_Usu(str(tk))
			if respuest[0] == True:
				#se valida que el id que se recibe exista
				respu = validations.id_Mae_Usu(bdata.split("/")[1])
				if respu[0]:
					obj = MAE_USUARIOS(usu_id = int(bdata.split("/")[1]),usu_estado = 'D') 
					resp2 = obj.modificar()
					resp = {}
					resp["result"] = resp2[0]
					if resp2[0] == 'ok':
						usu_id = s.get_id_Usu(str(tk))
						filename = os.path.basename(__file__).split('.')[0]
						obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se desactivo el usuario con el siguiente PK usu_id: '+str(bdata.split("/")[1]),log_acc_id = 400)
						resp_log = obj_log.guardar_dato()
						if resp_log[0] != 'ok':
							mensaje = s.mensaje_error(datosC['idioma'],103)
							resp['result'] = 'failed'
							resp['error'] = 'Sucedio un error'
							resp['error_cod'] = 103
							resp['val_errors'] = str(mensaje[1][0][0])
							status = "400 Bad Request"
					else:
						mensaje = s.mensaje_error(datosC['idioma'],60)
						resp = {}
						resp["result"] = "failed"
						resp["error"] = resp2[1]
						resp["error_cod"] = 60
						resp["val_errors"] = str(mensaje[1][0][0])
						status = "400 Bad Request"                              
				else:
					mensaje = s.mensaje_error(datosC['idioma'],105)
					resp = {}
					resp["result"] = "failed"
					resp["error"] = "Sucedio un error"
					resp["error_cod"] = 105
					status = "400 Bad Request"
					resp["val_errors"] = str(mensaje[1][0][0]) + ' id_mae_usu'
			else:
				resp = {}
				mensaje = s.mensaje_error(datosC['idioma'],102)
				resp["result"] = "failed"
				resp["error"] = "Sucedio un error"
				resp["error_cod"] = 102
				status = "400 Bad Request"
				resp["val_errors"] = str(mensaje[1][0][0])
		else:
			if s.valToken(tk) :
				cod_error = 100
			else :
				cod_error = 101
			mensaje = s.mensaje_error(datosC['idioma'],cod_error)
			resp = {}
			resp["result"] = "failed"
			resp["error"] = "Sucedio un error"
			resp["error_cod"] = cod_error
			resp["val_errors"] = str(mensaje[1][0][0])
			status = "401 Unauthorized"

	except validations.HttpException as e:
		resp = {}
		mensaje = s.mensaje_error(datosC['idioma'],51)
		resp["result"] = "failed"
		resp["error_cod"] = "Sucedio un error"
		resp["error"] = 51
		resp["val_errors"] = str(mensaje[1][0][0])
		status = e.status_code
	#en caso de algun error entra al exception
	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		resp = {}
		resp["result"] = "failed"
		resp["error"] = "Sucedio un error"
		resp["error_cod"] = 50
		try :
			mensaje = s.mensaje_error(datosC['idioma'],50)
			resp["val_errors"] = str(mensaje[1][0][0])
		except:
			resp["val_errors"] = 'error de python' 
		status = "500 Internal Server Error"
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)

	preoutput = json.dumps(resp)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	# se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]
