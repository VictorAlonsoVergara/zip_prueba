import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from ARB_LOGICO import ARB_LOGICO
from clsSession import Session
import validations
#import generico


def application(environ, start_response):
	try:
		coo = ""
		jsdato = ""
		status = "200 OK"
		if environ['REQUEST_METHOD'] != 'GET':
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)
		bdata = environ["PATH_INFO"]
		respuest = validations.validate_int(bdata.split("/")[1])

		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]

		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)
		tk = s.getCookie(cookie, "token")
		s.setToken(tk)

		if s.valToken(tk) and s.valIp(tk, str(dataIP)):

			jsdato = s.get_Datos_Usu(str(tk))
			if respuest[0] == True:
				obj = ARB_LOGICO(int(bdata.split("/")[1]))
				dato = obj.buscar_dato()
				if dato[0] == "ok":
					data = {}
					data.update(obj.get_diccionario())
					usu_id = s.get_id_Usu(str(tk))
					filename = os.path.basename(__file__).split('.')[0]
					obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se ve el arb_logico con el siguiente PK log_id: '+str(bdata.split("/")[1]),log_acc_id = 468)
					resp_log = obj_log.guardar_dato()
					if resp_log[0] != 'ok':
						status = "400 Bad Request"
						resp['result'] = 'failed'
						resp['error'] = 'Sucedio un error'
						resp['error_cod'] = 411
						resp['val_errors'] = resp_log[1]	
				else:
					status = "400 Bad Request"
					data = {}
					data["result"] = "failed"
					data["error"] = "Sucedio un error"
					data["error_cod"] = 412
					data["val_errors"] = dato[1]
			else:
				status = "400 Bad Request"
				data = {}
				data["result"] = "failed"
				data["error"] = "Sucedio un error"
				data["error_cod"] = 412
				data["val_errors"] = respuest[1]
		else:
			status = "401 Unauthorized"
			data = {}
			data["result"] = "failed"
			data["error"] = "Sucedio un error con el token:" + str(tk)
			data["error_cod"] = 412
			data["val_errors"] = "token no validado"

	except validations.HttpException as e:
		data = {}
		data["result"] = "failed"
		data["error_cod"] = e.code
		data["error"] = e.message
		data["val_errors"] = e.message
		status = e.status_code

	except Exception as e:
		status = "500 Internal Server Error"
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		data = {}
		data["result"] = "failed"
		data["error"] = "Sucedio un error" + str(
			e
		)  # -cookie: "+str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)#+str(cookie)
		data["error_cod"] = 412
		data["val_errors"] = "token no validado"

	preoutput = json.dumps(data)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]
