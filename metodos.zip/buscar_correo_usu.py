import sys,os
import logging,datetime
rutalog="/home/sistema/log/Traxium"
sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_USUARIOS import MAE_USUARIOS
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
from clsSession import Session
import validations
import generico

def application(environ, start_response):
	try:
		coo = ""
		jsdato = ""
		
		status = "200 OK"  # se crea la respuesta de estado

		lendata = int(environ.get("CONTENT_LENGTH", 0))
		bydata = environ["wsgi.input"].read(lendata)
		jsdata = json.loads(bydata.decode("utf-8"))
		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
			# data
			# IP = environ['HTTP_X_FORWARDED_FOR']
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]
		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)  # se obtiene la informacion del cookie
		tk = s.getCookie(cookie, "token")  # se escoge la informacion guardada en la variable token
		datosB = s.getCookie(cookie, "dato")
		len_datosB = len(datosB)
		datosC = json.loads(datosB[1:(len_datosB-1)])   
		if environ['REQUEST_METHOD'] != 'PUT' and environ['REQUEST_METHOD'] != 'POST':
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)
		if s.valToken(tk) and s.valIp(tk, str(dataIP)):  # se valida si el token esta validado
			jsdato = s.get_Datos_Usu(str(tk))  # se busca los datos del usuario vinculados con el token
			datos_usu = json.loads(jsdato)#Se transforma los datos del usuario en diccionario
			try:
				extra = {}
				diccionario_respu = {}
				pass_flag = True

				diccionario_respu['data'] = validations.validate_varchar(jsdata['data'],100)
				#diccionario_respu['usu_usuario_modificacion'] = validations.validate_varchar(jsdata["usu_usuario_modificacion"],100)
				#jsdata["usu_usuario_modificacion"] = s.getCookie(cookie,"")


				for key,value in jsdata.items():
					value_empty = validations.validate_empty(value)
					if value_empty[0] is True :
						diccionario_respu[key] = value_empty

				for _,value in diccionario_respu.items():
					if value[0] is False:
						pass_flag = False
						break

				if pass_flag is True:
					resp = MAE_USUARIOS.buscar_correo(jsdata)

				else:
					resp = ["error1", ""]
					num = 0
					for key,respu in diccionario_respu.items():
						if respu[0] == False:
							if len(respu) == 3 :
								mensaje1 = s.mensaje_error(datosC['idioma'],respu[2])
								extra[key] = str(mensaje1[1][0][0]) + respu[1]
							else :
								mensaje1 = s.mensaje_error(datosC['idioma'],104)
								extra[key] = str(mensaje1[1][0][0]) + respu[1]
						num = num + 1

				linea = {}
				if resp[0] == "ok":
					linea["result"] = "ok"
					linea["correo"] = resp[1][0]
					usu_id = s.get_id_Usu(str(tk))
					filename = os.path.basename(__file__).split('.')[0]
					obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se busco el correo de usuario PK usu_id: '+str(jsdata['data']),log_acc_id = 396)
					resp_log = obj_log.guardar_dato()
					if resp_log[0] == 'error':
						mensaje = s.mensaje_error(datosC['idioma'],103)
						linea['result'] = "failed"
						linea['error'] = "Sucedio un error"
						linea['error_cod'] = 103
						status = "400 Bad Request"
						linea['val_errors'] = str(mensaje[1][0][0])
				elif resp[0] == "error1":
					linea["result"] = "failed"
					linea["error"] = "Sucedio un error"
					linea["error_cod"] = 104
					status = "400 Bad Request"
					if bool(extra):
						linea["val_errors"] = extra
					else:
						linea["val_errors"] = resp[1]
				else :
					mensaje = s.mensaje_error(datosC['idioma'],60)
					linea["result"] = "failed"
					linea["error"] = resp[1]
					linea["error_cod"] = 60
					status = "400 Bad Request"
					linea["val_errors"] = str(mensaje[1][0][0])
						#linea["tipo"] = 'resp'
			#en caso de error en el codigo se entra al exception
			except Exception as e:
				linea = {}
				mensaje = s.mensaje_error(datosC['idioma'],50)
				exc_type, exc_obj, exc_tb = sys.exc_info()
				fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
				resp = ["error", str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)]
				linea["result"] = "failed"
				linea["error"] = "Sucedio un error"
				linea["error_cod"] = 50
				linea["val_errors"] = str(mensaje[1][0][0])
				status = "400 Internal Server Error"
		else:
			if s.valToken(tk) :
				cod_error = 100
			else :
				cod_error = 101
			mensaje = s.mensaje_error(datosC['idioma'],cod_error)
			linea = {}
			linea["result"] = "failed"
			linea["error"] = "Sucedio un error"
			linea["error_cod"] = cod_error
			linea["val_errors"] = str(mensaje[1][0][0])
			status = "401 Unauthorized" 

	except validations.HttpException as e:
		linea = {}
		mensaje = s.mensaje_error(datosC['idioma'],51)
		linea["result"] = "failed"
		linea["error_cod"] = "Sucedio un error"
		linea["error"] = 51
		linea["val_errors"] = str(mensaje[1][0][0])
		status = e.status_code

	except Exception as e:
		linea = {}
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		resp = [
			"error",
			"token no validado"
			+ str(e)
			+ " - "
			+ str(exc_type)
			+ " - "
			+ str(fname)
			+ " - "
			+ str(exc_tb.tb_lineno)]
		linea["result"] = "failed"
		linea["error"] = "Sucedio un error"
		linea["error_cod"] = 50
		try :
			mensaje = s.mensaje_error(datosC['idioma'],50)
			linea["val_errors"] = str(mensaje[1][0][0])
		except:
			linea["val_errors"] = 'error de python' 
		status = "500 Internal Server Error" 
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError) 

	preoutput = json.dumps(linea)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	# se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]

