import sys, os

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_USUARIOS_MENU import MAE_USUARIOS_MENU
import validations


def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""
        status = "200 OK"
        if environ["REQUEST_METHOD"] != "GET":
            # status = "405 Method Not Allowed"
            raise validations.HttpException(405)
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):
            jsdato = s.get_Datos_Usu(str(tk))
            bdata = environ["PATH_INFO"]
            respuest = validations.validate_int(bdata.split("/")[1])

            if respuest[0] == True:
                respu = validations.id_Mae_Usu(bdata.split("/")[1])
                if respu[0]:
                    resp = MAE_USUARIOS_MENU.devol_menu(bdata.split("/")[1])
                else:
                    resp = {}
                    resp["result"] = "failed"
                    resp["error"] = "Sucedio un error"
                    resp["error_cod"] = 412
                    resp["val_errors"] = respu[1]
                    status = "400 Bad Request"
            else:
                resp = {}
                resp["result"] = "failed"
                resp["error"] = "Sucedio un error"
                resp["error_cod"] = 412
                resp["val_errors"] = respuest[1]
                status = "400 Bad Request"
        else:
            resp = {}
            resp["result"] = "failed"
            resp["error"] = "Sucedio un error " + str(cookie)
            resp["error_cod"] = 412
            resp["val_errors"] = "token no valido"
            status = "401 Unauthorized"

    except validations.HttpException as e:
        linea = {}
        resp["result"] = "failed"
        resp["error_cod"] = e.code
        resp["error"] = e.message
        resp["val_errors"] = e.message
        status = e.status_code

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        resp = {}
        resp["result"] = "failed"
        resp["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        resp["error_cod"] = 412
        resp["val_errors"] = "token no validado"
        status = "500 Internal Server Error"

    preoutput = json.dumps(resp)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
