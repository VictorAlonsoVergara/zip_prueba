import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_USU_ACCESOS_INDICADORES import MAE_USU_ACCESOS_INDICADORES
from clsSession import Session
import validations
from MyDB import MyDB
#import generico


def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""
        status = "200 OK"

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        bdata = environ["PATH_INFO"]
        respuest = validations.validate_int(bdata.split("/")[1])
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):

            jsdato = s.get_Datos_Usu(str(tk))
            # coo = 'datos={"usu_nombre"="'+jsdato['usu_nombre']+'","usu_estado"="'+jsdato['usu_estado']+'","tusu_id"="'+jsdato['tusu_id']+'","usu_id"="'+jsdato['usu_id']+'"}'
            if respuest[0] == True:
                obj = MAE_USU_ACCESOS_INDICADORES(1, 1, int(bdata.split("/")[1]))
                dato = obj.buscar_dato()
                if dato[0] == "ok":
                    data = {}
                    data["uind_id"] = int(bdata.split("/")[1])
                    data["ind_id"] = obj.ind_id
                    data["ind_desc"] = obj.mae_indicadores.ind_desc
                    data["ind_estado"] = obj.mae_indicadores.ind_estado
                    data["ind_ldesc"] = obj.mae_indicadores.ind_ldesc
                    data["ind_alerta"] = obj.mae_indicadores.ind_alerta
                    data["ind_trap"] = obj.mae_indicadores.ind_trap
                    data[
                        "ind_trap_definicion"
                    ] = obj.mae_indicadores.ind_trap_definicion
                    data["cron_id"] = obj.mae_indicadores.cron_id
                    data["cron_tipo"] = obj.mae_indicadores.mae_cron.cron_tipo
                    data["cron_periodo"] = obj.mae_indicadores.mae_cron.cron_periodo
                    data["cron_estado"] = obj.mae_indicadores.mae_cron.cron_estado
                    data["tobj_id"] = obj.mae_indicadores.mae_cron.tobj_id
                    data[
                        "tobj_desc"
                    ] = obj.mae_indicadores.mae_cron.mat_tipo_obj.tobj_desc
                    data[
                        "tobj_estado"
                    ] = obj.mae_indicadores.mae_cron.mat_tipo_obj.tobj_estado
                    data[
                        "tobj_consulta"
                    ] = obj.mae_indicadores.mae_cron.mat_tipo_obj.tobj_consulta
                    data[
                        "tobj_ldesc"
                    ] = obj.mae_indicadores.mae_cron.mat_tipo_obj.tobj_ldesc

                    data["usu_id"] = obj.usu_id
                    data["usu_nombre"] = obj.mae_usuarios.usu_nombre
                    data["usu_correo"] = obj.mae_usuarios.usu_correo
                    data["usu_usario"] = obj.mae_usuarios.usu_usuario
                    data["usu_estado"] = obj.mae_usuarios.usu_estado
                    clase_MyDB = MyDB()
                    query = 'SELECT param_valor FROM "PARAM" WHERE param_grupo = %s AND param_id = %s '
                    datos = ("estado_usuario",obj.mae_usuarios.usu_estado)
                    respuest2 = clase_MyDB.conectar(query,datos,True)                    
#'SELECT param_valor FROM "PARAM" WHERE param_grupo =\''+grupo_codigo+'\' AND param_id = \''+param_id+'\'')                    
                    #respuest2 = generico.buscaParametro("estado_usuario", obj.mae_usuarios.usu_estado)
                    data["usu_estado_desc"] = respuest2[1][0][0]
                    data["tusu_id"] = obj.mae_usuarios.tusu_id
                    data["tusu_desc"] = obj.mae_usuarios.mae_tipo_usu.tusu_desc

                else:
                    data = {}
                    data["result"] = "failed"
                    data["error"] = "Sucedio un error -cookie:" + str(tk)
                    data["error_cod"] = 412
                    data["val_errors"] = dato[1]
            else:
                data = {}
                data["result"] = "failed"
                data["error"] = "Sucedio un error -cookie:" + str(tk)
                data["error_cod"] = 412
                data["val_errors"] = respuest[1]
        else:
            data = {}
            data["result"] = "failed"
            data["error"] = "Sucedio un error -cookie:" + str(cookie)
            data["error_cod"] = 412
            data["val_errors"] = "token no validado"
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        data = {}
        data["result"] = "failed"
        data["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        data["error_cod"] = 412
        data["val_errors"] = "token no validado"

    preoutput = json.dumps(data)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
