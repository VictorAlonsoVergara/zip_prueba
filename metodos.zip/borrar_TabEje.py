import sys, os
import logging,datetime
rutalog="/home/sistema/log/Traxium_"
sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from TAB_EJECUCIONES import TAB_EJECUCIONES
import validations


def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""
        status = "200 OK"

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        datosB = s.getCookie(cookie, "dato")
        len_datosB = len(datosB)
        datosC = json.loads(datosB[1:(len_datosB-1)])           
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):

            jsdato = s.get_Datos_Usu(str(tk))
            bdata = environ["PATH_INFO"]
            respuest = validations.validate_int(bdata.split("/")[1])
            if respuest[0] == True:
                respu = validations.id_Tab_Eje(bdata.split("/")[1])

                if respu[0]:
                    obj = TAB_EJECUCIONES(
                        1, " ", " ", " ", " ", " ", int(bdata.split("/")[1])
                    )
                    resp = obj.borrar()
                else:
                    resp = {}
                    mensaje = s.mensaje_error(datosC['idioma'],105)
                    resp["result"] = "failed"
                    resp["error"] = "Sucedio un error"
                    resp["error_cod"] = 105
                    resp["val_errors"] = str(mensaje[1][0][0])
            else:
                mensaje = s.mensaje_error(datosC['idioma'],102)
                resp = {}
                resp["result"] = "failed"
                resp["error"] = "Sucedio un error"
                resp["error_cod"] = 102
                resp["val_errors"] = str(mensaje[1][0][0])
        else:
            if s.valToken(tk) :
                cod_error = 100
            else :
                cod_error = 101
            mensaje = s.mensaje_error(datosC['idioma'],cod_error)            
            resp = {}
            resp["result"] = "failed"
            resp["error"] = "Sucedio un error"
            resp["error_cod"] = cod_error
            resp["val_errors"] = str(mensaje[1][0][0])

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        resp = {}
        resp["result"] = "failed"
        resp["error"] = "Sucedio un error "
        resp["error_cod"] = 50
        try :
            mensaje = s.mensaje_error(datosC['idioma'],50)
            resp["val_errors"] = str(mensaje[1][0][0])
        except:
            resp["val_errors"] = 'error de python' 
        datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
        now = datetime.datetime.now()
        fecha= datetime.date.today()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")
        logger = logging.getLogger('__name__')
        logger.setLevel(logging.ERROR)
        nombre_log=rutalog+str(fecha)+'.log'
        fh = logging.FileHandler(nombre_log)
        fh.setLevel(logging.ERROR)
        logger.addHandler(fh)
        logger.error("Error: "+str(current_time) + datoError)

    preoutput = json.dumps(resp)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
