import sys

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_IDIOMAS import MAE_IDIOMAS
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations
import os


def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""

        if environ["REQUEST_METHOD"] != "POST":
            # status = "405 Method Not Allowed"
            raise validations.HttpException(405)

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):
            jsdato = s.get_Datos_Usu(str(tk))
            lendata = int(environ.get("CONTENT_LENGTH", 0))
            bydata = environ["wsgi.input"].read(lendata)
            jsdata = json.loads(bydata.decode("utf-8"))

            try:

                # ----------------------------------------------------------------

                extra = {}
                respu1 = validations.validate_varchar(jsdata["idi_desc"], 100)
                respu2 = validations.validate_varchar(jsdata["idi_key"], 5)
                respu3 = validations.validate_char(jsdata["idi_estado"])

                list_respu = [respu1, respu2, respu3]
                nombres = ["idi_desc", "idi_key", "idi_estado"]

                if respu1[0] and respu2[0] and respu3[0]:
                    val1 = validations.validate_empty(jsdata["idi_desc"])
                    val2 = validations.validate_empty(jsdata["idi_key"])
                    val3 = validations.validate_empty(jsdata["idi_estado"])

                    if val1[0]:
                        desc = None
                    else:
                        desc = jsdata["idi_desc"]

                    if val2[0]:
                        key = None
                    else:
                        key = jsdata["idi_key"]

                    if val3[0]:
                        estado = None
                    else:
                        estado = jsdata["idi_estado"]

                    obj = MAE_IDIOMAS(idi_desc=desc, idi_key=key, idi_estado=estado)

                    resp = obj.guardar_dato()

                else:
                    resp = ["error", ""]
                    num = 0

                    for respu in list_respu:
                        if respu[0] == False:
                            # resp[1] = resp[1]+'-'+nombres[num]+': '+respu[1]+' \n'
                            extra[nombres[num]] = respu[1]
                        num = num + 1

            except Exception as e:
                resp = ["error", str(e)]
            linea = {}

            if resp[0] == "ok":
                linea["result"] = "ok"
                linea["data"] = obj.get_diccionario()
                #linea["idi_id"] = obj.idi_id
                #Como la respuesta es correcta se guarda en el log de acciones
                usu_id = s.get_id_Usu(str(tk))
                filename = os.path.basename(__file__).split('.')[0]
                obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se creo el idioma con el siguiente PK idi_id: '+str(obj.idi_id),log_acc_id = 499)
                resp_log = obj_log.guardar_dato()
                if resp_log[0] == 'error':
                    linea['result'] = "failed"
                    linea['error'] = "Sucedio un error"
                    linea['error_cod'] = 411
                    status = "400 Internal Server Error"
                    linea['error_val'] = "No se pudo guardar en el log"
            else:
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 412
                if bool(extra):
                    linea["val_errors"] = extra
                else:
                    linea["val_errors"] = resp[1]

                status = "400 Internal Server Error"
        else:
            linea = {}
            linea["result"] = "failed"
            linea["error"] = "Sucedio un error -cookie:" + str(cookie)
            linea["error_cod"] = 412
            linea["val_errors"] = "token no valido"
            status = "401 Unauthorized"

    except validations.HttpException as e:
        linea = {}
        linea["result"] = "failed"
        linea["error_cod"] = e.code
        linea["error"] = e.message
        linea["val_errors"] = e.message
        status = e.status_code

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea = {}
        linea["result"] = "failed"
        linea["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        linea["error_cod"] = 412
        linea["val_errors"] = "token no validado"

    status = "200 OK"
    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
