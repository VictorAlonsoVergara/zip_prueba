import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_USU_ACCESOS_INDICADORES import MAE_USU_ACCESOS_INDICADORES
from clsSession import Session
import validations


def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""
        extra = {}
        status = "200 OK"

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):

            jsdato = s.get_Datos_Usu(str(tk))
            bdata = environ["PATH_INFO"]
            respuest = validations.validate_int(bdata.split("/")[1])
            if respuest[0] == True:
                respu = validations.id_Mae_Usu_Accesos_Indicadores(bdata.split("/")[1])

                if respu[0]:
                    obj = MAE_USU_ACCESOS_INDICADORES(1, 1, int(bdata.split("/")[1]))
                    resp = obj.borrar()
                else:
                    resp = {}
                    resp["result"] = "failed"
                    resp["error"] = "Sucedio un error1 error no encontro el "
                    resp["error_cod"] = 412
                    resp["val_errors"] = respu[1]
            else:
                resp = {}
                resp["result"] = "failed"
                resp["error"] = "Sucedio un error2 error de validacion"
                resp["error_cod"] = 412
                resp["val_errors"] = respuest[1]
        else:
            resp = {}
            resp["result"] = "failed"
            resp["error"] = "Sucedio un error3 -cookie:" + str(cookie)
            resp["error_cod"] = 412
            resp["val_errors"] = "token no valido"

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        resp = {}
        resp["result"] = "failed"
        resp["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        resp["error_cod"] = 412
        resp["val_errors"] = "token no validado"

    status = "200 OK"
    preoutput = json.dumps(resp)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
