import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_OBJETO_LOGICO import MAE_OBJETO_LOGICO
from clsSession import Session
import validations
from MyDB import MyDB
#import generico


def application(environ, start_response):

	try:
		jsdato = ""
		coo = ""
		extra = {}
		status = "200 OK"
		if environ['REQUEST_METHOD'] != 'POST':
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)
		lendata = int(environ.get("CONTENT_LENGTH", 0))
		bydata = environ["wsgi.input"].read(lendata)
		jsdata = json.loads(bydata.decode("utf-8"))
		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
			# dataIP = environ['HTTP_X_FORWARDED_FOR']
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]
		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)
		tk = s.getCookie(cookie, "token")
		s.setToken(tk)

		if s.valToken(tk) and s.valIp(tk, str(dataIP)):

			jsdato = s.get_Datos_Usu(str(tk))
			try:
				respu1 = validations.validate_int(jsdata["obj_id"])
				respu2 = validations.validate_int(jsdata["log_id"])
				if respu1[0] == True:
					respu3 = validations.id_Mae_Obj(int(jsdata["obj_id"]))
				else:
					respu3 = [False, "No se tiene un obj_id correcto"]
				if respu2[0] == True:
					respu4 = validations.id_Arb_Log(int(jsdata["log_id"]))
				else:
					respu4 = [False, "No se tiene un log_id correcto"]
				list_respu = [respu1, respu2, respu3, respu4]
				nombres = ["obj_id", "log_id", "obj_id", "log_id"]
				# se busca si todos los datos son correctos
				if respu1[0] and respu2[0] and respu3[0] and respu4[0]:
					obj = MAE_OBJETO_LOGICO(
						int(jsdata["obj_id"]), int(jsdata["log_id"])
					)
					dato = obj.buscar_dato()
					if dato[0] == "ok":
						resp = ["ok", " "]
					else:
						resp = ["error", dato[1]]
				else:
					status = "400 Bad Request"
					resp = ["error", ""]
					num = 0
					for respu in list_respu:
						if respu[0] == False:
							# resp[1] = resp[1]+'-'+respu[1]+'\n'
							extra[nombres[num]] = respu[1]
						num = num + 1

			except Exception as e:
				resp = ["error", str(e)]
				status = "400 Bad Request"

		else:
			resp = ["error", "token no validado"]
			status = "401 Unauthorized"

		linea = {}
		if resp[0] == "ok":
			linea = {}          
			linea.update(obj.get_diccionario())          
			
		else:
			linea["result"] = "failed"
			linea["error"] = "Sucedio un error"
			linea["error_cod"] = 412
			if bool(extra):
				linea["val_errors"] = extra
			else:
				linea["val_errors"] = resp[1]
	except validations.HttpException as e:
		linea = {}
		linea["result"] = "failed"
		linea["error_cod"] = e.code
		linea["error"] = e.message
		linea["val_errors"] = e.message
	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		linea = {}
		linea["result"] = "failed"
		linea["error"] = (
			"Sucedio un error -cookie: "
			+ str(e)
			+ " - "
			+ str(exc_type)
			+ " - "
			+ str(fname)
			+ " - "
			+ str(exc_tb.tb_lineno)
		)  # +str(cookie)
		linea["error_cod"] = 412
		linea["val_errors"] = "token no validado"
		status = "500 Internal Server Error"

	

	preoutput = json.dumps(linea)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	# se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]
