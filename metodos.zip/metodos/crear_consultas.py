import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_CONSULTAS import MAE_CONSULTAS
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations
from clsSession import Session


def application(environ, start_response):
    try:
        coo = ""
        jsdato = ""
        status = "500 Internal Server Error"
        if environ['REQUEST_METHOD'] != 'POST':
            #status = "405 Method Not Allowed"
            raise validations.HttpException(405)
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):

            jsdato = s.get_Datos_Usu(str(tk))
            lendata = int(environ.get("CONTENT_LENGTH", 0))
            bydata = environ["wsgi.input"].read(lendata)
            jsdata = json.loads(bydata.decode("utf-8"))
            try:
                diccio_respu = {}
                pass_flag = True
                extra = {}

                diccio_respu['con_desc'] = validations.validate_varchar(jsdata["con_desc"], 100)
                diccio_respu['con_estado'] = validations.validate_char(jsdata["con_estado"])
                diccio_respu['prot_id'] = validations.validate_int(jsdata["prot_id"])
                diccio_respu['con_trama_pregunta'] = validations.validate_varchar(jsdata["con_trama_pregunta"], 500)
                diccio_respu['marca_id'] = validations.validate_int(jsdata["marca_id"])
                diccio_respu['mod_id'] = validations.validate_int(jsdata["mod_id"])
                diccio_respu['con_respuesta'] = validations.validate_varchar(jsdata["con_respuesta"], 500)

                if diccio_respu['prot_id'][0] is True:
                    diccio_respu['prot_id'] = validations.id_Tab_Prot(int(jsdata["prot_id"]))
                if diccio_respu['marca_id'][0] is True:
                    diccio_respu['marca_id'] = validations.id_Mae_Marcas(int(jsdata["marca_id"]))
                if diccio_respu['mod_id'][0] is True:
                    diccio_respu['mod_id'] = validations.id_Mae_Modelo(int(jsdata["mod_id"]))
                
                for key, value in jsdata.items():
                    value_empty = validations.validate_empty(value)
                    if value_empty[0] is True:
                        diccio_respu[key] = value_empty
                        diccio_respu[key][0] = False
                
                for _,value in diccio_respu.items():
                    if value[0] is False:
                        pass_flag = False
                        break
                if pass_flag is True:
                    obj = MAE_CONSULTAS.from_json(jsdata)
                    resp = obj.guardar_dato()
                    obj.buscar_dato()
                else:
                    resp = ["error", ""]
                    #num = 0
                    status = "400 Bad Request"
                    for key,respu in diccio_respu.items():
                        if respu[0] == False:
                            extra[key] = respu[1]
                        #num = num + 1

            except Exception as e:
                resp = ["error", str(e)]
                status = "400 Bad Request"
            linea = {}

            if resp[0] == "ok":
                linea["result"] = "ok"
                linea["data"] = obj.get_diccionario()
                #linea["con_id"] = obj.con_id
                status = "200 OK"
                #Como la respuesta es correcta se guarda en el log de acciones
                usu_id = s.get_id_Usu(str(tk))
                filename = os.path.basename(__file__).split('.')[0]
                obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se creo la consulta con el siguiente PK con_id: '+str(obj.con_id),log_acc_id = 426)
                resp_log = obj_log.guardar_dato()
                if resp_log[0] == 'error':
                    linea['result'] = "failed"
                    linea['error'] = "Sucedio un error"
                    linea['error_cod'] = 500
                    status = "500 Internal Server Error"
                    linea['error_val'] = "No se pudo guardar en el log"
            else:
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 400
                status = "400 Bad Request"
                if bool(extra):
                    linea["val_errors"] = extra
                else:
                    linea["val_errors"] = resp[1]
        else:
            linea = {}
            linea["result"] = "failed"
            linea["error"] = "Sucedio un error -cookie:" + str(cookie)
            linea["error_cod"] = 401
            linea["val_errors"] = "token no valido"
            status = "401 Unauthorized"

    except validations.HttpException as e:
        linea = {}
        linea["result"] = "failed"
        linea["error_cod"] = e.code
        linea["error"] = e.message
        linea["val_errors"] = e.message
        status = e.status_code

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea = {}
        linea["result"] = "failed"
        linea["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        linea["error_cod"] = 500
        linea["val_errors"] = "token no validado"
        status = "500 Internal Server Error"

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
