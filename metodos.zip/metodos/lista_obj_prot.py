import sys

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_OBJETOS import MAE_OBJETOS
from clsSession import Session
import sys, os
import validations


def application(environ, start_response):

	try:
		jsdato = ""
		status = "200 OK"  # se crea la respuesta de estado
		lendata = int(environ.get("CONTENT_LENGTH", 0))
		bydata = environ["wsgi.input"].read(lendata)
		jsdata = json.loads(bydata.decode("utf-8"))
		if environ['REQUEST_METHOD'] != 'POST':#Verifica el metodo usado
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)
		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]

		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)  # se obtiene la informacion del cookie
		tk = s.getCookie(cookie, "token")  
		if s.valToken(tk) and s.valIp(tk, str(dataIP)): 
			jsdato = s.get_Datos_Usu(str(tk))
			extra = {}
			diccionario_respu = {}
			pass_flag = True

			diccionario_respu['numero_pag'] = validations.validate_int(jsdata['numero_pag'])
			diccionario_respu['cantidad_pag'] = validations.validate_int(jsdata["cantidad_pag"])
			diccionario_respu['prot_id'] = validations.validate_int(jsdata["prot_id"])  

			for key,value in jsdata.items():
				value_empty = validations.validate_empty(value)
				if value_empty[0] is True and key != 'usu_id':
					diccionario_respu[key] = value_empty

			for _,value in diccionario_respu.items():
				if value[0] is False:
					pass_flag = False
					break

			if pass_flag is True:
				status = "200 OK"
				resp = MAE_OBJETOS.consultar_lista_prot(jsdata["numero_pag"],jsdata["cantidad_pag"],jsdata["prot_id"])

			else:
				resp = ["error", ""]
				for key,respu in diccionario_respu.items():
					if respu[0] == False:
						extra[key] = respu[1]

			diccionario = {}
			if "error" in resp:

				diccionario["result"] = "failed"
				diccionario["error"] = "Sucedio un error"
				diccionario["error_cod"] = 411
				status = "400 Bad Request"

				if bool(extra):
					diccionario["val_errors"] = extra
					#linea["tipo"] = 'extra'
				else:
					diccionario["val_errors"] = resp["val_errors"] 
			else:
				diccionario= resp

		else:
			diccionario = {}
			diccionario["result"] = "failed"
			diccionario["error"] = "Sucedio un error -cookie:" + str(cookie)
			diccionario["error_cod"] = 412
			diccionario["val_errors"] = "token no valido"
			status = "401 Unauthorized"

	except validations.HttpException as e:
		diccionario = {}
		diccionario["result"] = "failed"
		diccionario["error_cod"] = e.code
		diccionario["error"] = e.message
		diccionario["val_errors"] = e.message
		status = e.status_code
	
	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		diccionario = {}
		diccionario["result"] = "failed"
		diccionario[
			"error"
		] = "Sucedio un error "  
		diccionario["error_cod"] = 412
		diccionario["val_errors"] = str(e)
		status = "500 Internal Server Error"

	preoutput = json.dumps(diccionario)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	# se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]

	start_response(status, headers)
	return [output]
