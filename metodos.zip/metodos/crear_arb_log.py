import sys,os

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from ARB_LOGICO import ARB_LOGICO
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations


def application(environ, start_response):

	try:
		coo = ""
		jsdato = ""
		status = "200 OK"
		if environ['REQUEST_METHOD'] != 'POST':
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)

		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]

		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)
		tk = s.getCookie(cookie, "token")
		s.setToken(tk)

		if s.valToken(tk) and s.valIp(tk, str(dataIP)):

			jsdato = s.get_Datos_Usu(str(tk))
			lendata = int(environ.get("CONTENT_LENGTH", 0))
			bydata = environ["wsgi.input"].read(lendata)
			jsdata = json.loads(bydata.decode("utf-8"))

			try:
				# diccionario = {}
				extra = {}
				respu2 = validations.validate_varchar(jsdata["log_desc"],200)
				respu3 = validations.validate_varchar(jsdata["log_orden"],30)

				if jsdata["log_id_padre"] == "":
					respu1 = [True, "ok"]
				else:
					respu1 = validations.validate_int(jsdata["log_id_padre"])

				if respu1[0] == True :
					respu4 = ARB_LOGICO.validations_crear(jsdata["log_id_padre"])
				else:
					respu4 = [False, "No se ingreso un log_id_padre valido"]

				list_respu = [respu1, respu2, respu3, respu4]
				nombres = [
					"log_id_padre",
					"log_desc",
					"log_orden",
					"log_id_padre",
				]

				if respu1[0] and respu2[0] and respu3[0] and respu4[0] :
				   
					obj = ARB_LOGICO.from_json(jsdata)
					resp = obj.guardar_dato()
				else:
					resp = ["error", ""]
					num = 0

					for respu in list_respu:
						if respu[0] == False:
							# resp[1] = resp[1]+'-'+nombres[num]+': '+respu[1]+' \n'
							extra[nombres[num]] = respu[1]
						num = num + 1

			except Exception as e:
				status = "400 Bad Request"
				resp = ["error", str(e)]
			linea = {}

			if resp[0] == "ok":
				status = "200 OK"
				linea["result"] = "ok"
				linea["data"] = obj.get_diccionario()
				'''linea["log_id"] = obj.log_id
				linea["log_id_padre"] = obj.log_id_padre
				linea["log_desc"] = obj.log_desc
				linea["log_orden"] = obj.log_orden    '''               
				#Como la respuesta es correcta se guarda en el log de acciones
				usu_id = s.get_id_Usu(str(tk))
				filename = os.path.basename(__file__).split('.')[0]
				obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se creo el arb_logico con el siguiente PK log_id: '+str(obj.log_id),log_acc_id = 470)
				resp_log = obj_log.guardar_dato()
				if resp_log[0] == 'error':
					status = "400 Bad Request"
					linea['result'] = "failed"
					linea['error'] = "Sucedio un error"
					linea['error_cod'] = 411
					linea['val_errors'] =resp_log[1]
			else:
				status = "400 Bad Request"
				linea["result"] = "failed"
				linea["error"] = "Sucedio un error"
				linea["error_cod"] = 412
				if bool(extra):
					linea["val_errors"] = extra
				else:
					linea["val_errors"] = resp[1]
		else:
			status = "401 Unauthorized"
			linea = {}
			linea["result"] = "failed"
			linea["error"] = "Sucedio un error -cookie:" + str(cookie)
			linea["error_cod"] = 412
			linea["val_errors"] = "token no valido"
	except validations.HttpException as e:
		linea = {}
		linea["result"] = "failed"
		linea["error_cod"] = e.code
		linea["error"] = e.message
		linea["val_errors"] = e.message
		status = e.status_code

	except Exception as e:
		status = "500 Internal Server Error"
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		linea = {}
		linea["result"] = "failed"
		linea["error"] = (
			"Sucedio un error -cookie: "
			+ str(e)
			+ " - "
			+ str(exc_type)
			+ " - "
			+ str(fname)
			+ " - "
			+ str(exc_tb.tb_lineno)
		)  # +str(cookie)
		linea["error_cod"] = 412
		linea["val_errors"] = "token no validado"

	preoutput = json.dumps(linea)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]
