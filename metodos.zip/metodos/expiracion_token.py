import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_USUARIOS import MAE_USUARIOS
from clsSession import Session


def application(environ, start_response):
    try:
        status = "200 OK"  # se crea la respuesta de estado
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)  # se obtiene la informacion del cookie
        tk = s.getCookie(
            cookie, "token"
        )  # se escoge la informacion guardada en la variable token
        if s.valToken(tk):  # se valida si el token esta validado
            data = {}
            data["result"] = "ok"
            data["desciption"] = "token se mantiene activado"
        else:
            data = {}
            data["result"] = "failed"
            data["error"] = "token expirado"
            data["error_cod"] = 412
            data["val_errors"] = "token expirado"
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        data = {}
        data["result"] = "failed"
        data[
            "error"
        ] = "Sucedio un error "  # -cookie: "+str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)#+str(cookie)
        data["error_cod"] = 412
        data["val_errors"] = "error con el token"

    preoutput = json.dumps(data)
    output = bytes(preoutput, "utf-8")
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
    ]

    start_response(status, headers)
    return [output]
