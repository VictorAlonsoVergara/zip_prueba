import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_TIPO_USU import MAE_TIPO_USU
from clsSession import Session
import validations


def application(environ, start_response):
    try:
        coo = ""
        jsdato = ""
        status = "200 OK"  # se crea la respuesta de estado
        s = Session()  # se crea la sesion con el token
        cookie = environ.get("HTTP_COOKIE", 0)  # se busca la informacion en el cookie
        tk = s.getCookie(cookie, "token")
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
            
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]
        # respuesta = s.valToken(tk)
        if (s.valToken(tk) and s.valIp(tk, str(dataIP))):
            temp = (s.CerrarSesiones())
            jsdato = s.get_Datos_Usu(str(tk))
        else:
            temp = [
                "ok",
                "Sesion cerrada previamente",
            ]
            status = "401 Unauthorized"  
        resp = {}
        resp["result"] = temp[0]  # se busca el mensaje del estado de la sesion
        resp["mensaje"] = temp[1]


    except Exception as e:  # en caso de error por exception
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        status = "500 Internal Server Error"
        resp = {}
        resp["result"] = "failed"
        resp["error"] = "Sucedio un error" + str(
            e
        )  # +' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)#+str(cookie)
        resp["error_cod"] = 412
        resp["val_errors"] = "token no validado"

    preoutput = json.dumps(resp)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
