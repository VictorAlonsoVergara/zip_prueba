import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_USUARIOS import MAE_USUARIOS
from clsSession import Session
import validations

def application(environ, start_response):
    try:
        coo = ""
        jsdato = ""
        status = "200 OK"  # se crea la respuesta de estado
        if environ['REQUEST_METHOD'] != 'GET':
            #status = "405 Method Not Allowed"
            raise validations.HttpException(405)
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
            # dataIP = environ['HTTP_X_FORWARDED_FOR']
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)  # se obtiene la informacion del cookie
        tk = s.getCookie(
            cookie, "token"
        )  # se escoge la informacion guardada en la variable token
        if s.valToken(tk) and s.valIp(
            tk, str(dataIP)
        ):  # se valida si el token esta validado
            jsdato = s.get_Datos_Usu(
                str(tk)
            )  # se busca los datos del usuario vinculados con el token
            data = (
                MAE_USUARIOS.consultar_lista()
            )  # se consulta la lista de todos los usuarios guardados en la base de datos
            if 'Error' in data :
                status = "400 Bad Request"

        else:
            data = {}
            data["result"] = "failed"
            data["error"] = "Sucedio un error "  
            data["error_cod"] = 412
            data["val_errors"] = "token no validado"
            status = "401 Unauthorized"

    except validations.HttpException as e:
        data = {}
        data.update(e.get_error_dict())
        status = e.status_code

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        data = {}
        data["result"] = "failed"
        data["error"] = "Sucedio un error " +" -cookie: "+str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)#+str(cookie)
        data["error_cod"] = 412
        data["val_errors"] = "token no validado"
        status = "500 Internal Server Error"

    preoutput = json.dumps(data)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]

    start_response(status, headers)
    return [output]
