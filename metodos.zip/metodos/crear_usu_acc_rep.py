import sys, os

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_USU_ACCESOS_REPORTES import MAE_USU_ACCESOS_REPORTES
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations


def application(environ, start_response):
    
    try:
        
        coo = ""
        jsdato = ""
        status = "200 OK"
        if environ['REQUEST_METHOD'] != 'POST':
            #status = "405 Method Not Allowed"
            raise validations.HttpException(405)
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if (s.valToken(tk) and s.valIp(tk, str(dataIP))):

            jsdato = s.get_Datos_Usu(str(tk))
            lendata = int(environ.get("CONTENT_LENGTH", 0))
            bydata = environ["wsgi.input"].read(lendata)
            jsdata = json.loads(bydata.decode("utf-8"))

            try:
                if (jsdata["rep_id"] == None or jsdata["rep_id"]=='' or jsdata["usu_id"] == None or jsdata["usu_id"]=='' ):
                    respu0 = [False,'Hay dato vacio']
                else:
                    respu0 = [True, 'ok']                
                # diccionario = {}
                extra = {}
                respu1 = validations.validate_int(jsdata["rep_id"])
                respu2 = validations.validate_int(jsdata["usu_id"])

                if respu1[0] == True:
                    respu3 = validations.id_Tab_Rep(int(jsdata["rep_id"]))
                else:
                    respu3 = [False, "No se tiene un rep_id correcto"]
                if respu2[0] == True:
                    respu4 = validations.id_Mae_Usu(int(jsdata["usu_id"]))
                else:
                    respu4 = [False, "No se tiene un usu_id correcto"]
                list_respu = [
                    respu0,
                    respu1,
                    respu2,
                    respu3,
                    respu4,
                ]
                nombres = ["espacio vacio","rep_id", "usu_id", "rep_id", "usu_id"]

                if respu0[0] and respu1[0] and respu2[0] and respu3[0] and respu4[0]:
                    obj = MAE_USU_ACCESOS_REPORTES.from_json(jsdata)
                    resp = obj.guardar_dato()
                    obj.buscar_dato()

                else:
                    resp = ["error", ""]
                    num = 0

                    for respu in list_respu:
                        if respu[0] == False:
                            # resp[1] = resp[1]+'-'+nombres[num]+': '+respu[1]+' \n'
                            extra[nombres[num]] = respu[1]
                        num = num + 1

            except Exception as e:
                resp = ["error", str(e)]
            linea = {}

            if resp[0] == "ok":
                linea["result"] = "ok"
                linea["data"] = obj.get_diccionario()
                #linea["urep_id"] = obj.urep_id
                #Como la respuesta es correcta se guarda en el log de acciones
                usu_id = s.get_id_Usu(str(tk))
                filename = os.path.basename(__file__).split('.')[0]
                obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se creo el usuario_acceso_reportes con el siguiente PK urep_id: '+str(obj.urep_id),log_acc_id = 446)
                resp_log = obj_log.guardar_dato()
                if resp_log[0] == 'error':
                    linea['result'] = "failed"
                    linea['error'] = "Sucedio un error"
                    linea['error_cod'] = 411
                    status = "400 Internal Server Error"
                    linea['error_val'] = "No se pudo guardar en el log"

            else:
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 412
                status = "400 Internal Server Error"
                if bool(extra):
                    linea["val_errors"] = extra
                else:
                    linea["val_errors"] = resp[1]
        else:
            linea = {}
            linea["result"] = "failed"
            linea["error"] = "Sucedio un error -cookie:" + str(cookie)
            linea["error_cod"] = 412
            linea["val_errors"] = "token no valido"
            status = "401 Unauthorized"

    except validations.HttpException as e:
        linea = {}
        linea["result"] = "failed"
        linea["error_cod"] = e.code
        linea["error"] = e.message
        linea["val_errors"] = e.message
        status = e.status_code

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea = {}
        linea["result"] = "failed"
        linea["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        linea["error_cod"] = 412
        status = "412"
        linea["val_errors"] = "token no validado"
        status = "500 Internal Server Error"

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
