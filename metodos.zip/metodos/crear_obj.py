import sys , os

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_OBJETOS import MAE_OBJETOS
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations

def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""
        extra = {}
        status = "200 OK"  # se crea la respuesta de estado
        if environ['REQUEST_METHOD'] != 'POST':#Verifica el metodo usado
            #status = "405 Method Not Allowed"
            raise validations.HttpException(405)
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        lendata = int(environ.get("CONTENT_LENGTH", 0))  # se guarda los datos enviados
        bydata = environ["wsgi.input"].read(lendata)
        jsdata = json.loads(bydata.decode("utf-8"))  # se convierte los datos y json
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)  
        tk = s.getCookie(cookie, "token") 
        if s.valToken(tk) and s.valIp(tk, str(dataIP)):  
            jsdato = s.get_Datos_Usu(str(tk))  
            try:
                pass_flag = True
                extra = {}
                respuestas_dict = {}
                #Validaciones de Tipo de Dato
                respuestas_dict["obj_desc"] = (validations.validate_varchar(jsdata["obj_desc"], 200))
                respuestas_dict["tobj_id"] = (validations.validate_int(jsdata["tobj_id"]))
                respuestas_dict["obj_estado"] = (validations.validate_char(jsdata["obj_estado"]))
                respuestas_dict["obj_ldesc"] = (validations.validate_string(jsdata["obj_ldesc"]))
                respuestas_dict["obj_latitud"] = (validations.validate_numeric(jsdata["obj_latitud"],11,8))
                respuestas_dict["obj_longitud"] = (validations.validate_numeric(jsdata["obj_longitud"],11,8))
                respuestas_dict["obj_ip_address"] = (validations.validate_varchar(jsdata["obj_ip_address"],16))
                respuestas_dict["marca_id"] = (validations.validate_int(jsdata["marca_id"]))
                respuestas_dict["prot_id"] = (validations.validate_int(jsdata["prot_id"]))
                respuestas_dict["obj_firmware"] = (validations.validate_varchar(jsdata["obj_firmware"], 200))
                respuestas_dict["obj_hardware"] = (validations.validate_varchar(jsdata["obj_hardware"], 200))
                respuestas_dict["obj_usuario"] = (validations.validate_varchar(jsdata["obj_usuario"], 50))
                respuestas_dict["obj_password"] = (validations.validate_varchar(jsdata["obj_password"], 50))
                respuestas_dict["mod_id"] = (validations.validate_int(jsdata["mod_id"]))
                respuestas_dict["obj_respuesta"] = (validations.validate_varchar(jsdata["obj_respuesta"],500))
                respuestas_dict["obj_respuesta_flag"] = (validations.validate_boolean(jsdata["obj_respuesta_flag"]))
                #Validaciones de Foreign keys
                if respuestas_dict["marca_id"][0] is True:
                    respuestas_dict["marca_id"] = (validations.id_Mae_Marcas(int(jsdata["marca_id"])))
                if respuestas_dict["prot_id"][0] is True:
                    respuestas_dict["prot_id"] = (validations.id_Tab_Prot(int(jsdata["prot_id"])))
                if respuestas_dict["mod_id"][0] is True:
                    respuestas_dict["mod_id"] = (validations.id_Mae_Modelo(int(jsdata["mod_id"])))
                #Validaciones de campo vacio
                for key,value in jsdata.items():
                    value_empty = validations.validate_empty(value)
                    if value_empty[0] is True:
                        respuestas_dict[key] = value_empty
                        if (key != 'obj_usuario' and key != 'obj_password' and key != 'obj_ip_address'):#estos valores pueden ser nulos
                            respuestas_dict[key][0] = False
                #Verificar si existe algun error
                for _,respu in respuestas_dict.items():
                    if respu[0] is False:
                        pass_flag = False
                        break
                #Ejecutar el guardado si no se encontro ningun error
                if pass_flag is True:
                    obj = MAE_OBJETOS.from_json(jsdata)
                    resp = obj.guardar_dato()
                    obj.buscar_dato()
                else:
                    resp = ["error", ""]
                    for key,respu in respuestas_dict.items():
                        if respu[0] == False:
                            # resp[1] = resp[1]+'-'+nombres[num]+': '+respu[1]+' \n'
                            extra[key] = respu[1]
                linea = {}
                if resp[0] == "ok":
                    linea["result"] = "ok"
                    linea["data"] = obj.get_diccionario()
                    #linea["obj_id"] = obj.obj_id
                    #Como la respuesta es correcta se guarda en el log de acciones
                    usu_id = s.get_id_Usu(str(tk))
                    filename = os.path.basename(__file__).split('.')[0]
                    obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se creo el objeto con el siguiente PK obj_id: '+str(obj.obj_id),log_acc_id = 436)
                    resp_log = obj_log.guardar_dato()
                    if resp_log[0] == 'error':
                        linea['result'] = "failed"
                        linea['error'] = "Sucedio un error"
                        linea['error_cod'] = 411
                        status = "500 Internal Server Error"
                        linea['error_val'] = "No se pudo guardar en el log"
                else:
                    linea["result"] = "failed"
                    linea["error"] = "Sucedio un error"
                    linea["error_cod"] = 412
                    status = "400 Bad Request"
                    if bool(extra):
                        linea["val_errors"] = extra
                        linea["tipo"] = "extra"
                    else:
                        linea["val_errors"] = resp[1]                            
            except Exception as e:
                
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                resp = ["error", (
                    "Sucedio un error -cookie: "
                    + str(e)
                    + " - "
                    + str(exc_type)
                    + " - "
                    + str(fname)
                    + " - "
                    + str(exc_tb.tb_lineno)
                )]

            linea = {}
            if resp[0] == "ok":
                linea["result"] = "ok"
                linea["data"] = obj.get_diccionario()
            else:
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 412
                status = "400 Bad Request"
                if bool(extra):
                    linea["val_errors"] = extra
                else:
                    linea["val_errors"] = resp[1]
        else:
            resp = ["error", "Token no validado"]
            status = "401 Unauthorized"
    
    except validations.HttpException as e:
        linea = {}
        linea["result"] = "failed"
        linea["error_cod"] = e.code
        linea["error"] = e.message
        linea["val_errors"] = e.message
        status = e.status_code
    
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea = {}
        linea["result"] = "failed"
        linea["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        linea["error_cod"] = 412
        linea["val_errors"] = "token no validado"
        status = "500 Internal Server Error"

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
