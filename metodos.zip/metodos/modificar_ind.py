import sys, os

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_INDICADORES import MAE_INDICADORES
import validations


def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        status = "200 OK"
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):
            jsdato = s.get_Datos_Usu(str(tk))
            status = "200 OK"
            lendata = int(environ.get("CONTENT_LENGTH", 0))
            bydata = environ["wsgi.input"].read(lendata)
            jsdata = json.loads(bydata.decode("utf-8"))

            try:
                extra = {}
                flag = 0
                respu2 = [False, "error validacion ind_estado"]
                respu3 = [False, "error validacion int_ldesc"]
                respu5 = [False, "error en cron_id"]
                respu9 = [False, "No se tiene un cron_id correcto"]
                answer2 = [False, "cadena llena"]
                answer3 = [False, "cadema llena"]
                answer5 = [False, "cadena llena"]

                respu1 = validations.validate_varchar(jsdata["ind_desc"], 200)
                respu4 = validations.validate_char(jsdata["ind_alerta"])
                respu6 = validations.validate_char(jsdata["ind_trap"])
                respu7 = validations.validate_string(jsdata["ind_trap_definicion"])

                # valido si las entradas son vacias
                respuEmpty2 = validations.validate_empty(jsdata["ind_estado"])
                respuEmpty3 = validations.validate_empty(jsdata["ind_ldesc"])
                respuEmpty5 = validations.validate_empty(jsdata["cron_id"])

                # validacion para el ind_estado
                if respuEmpty2[0]:
                    answer2 = [True, "cadena vacia"]
                else:
                    respu2 = validations.validate_int(jsdata["ind_estado"])  # smallint

                # validacion para el ldesc
                if respuEmpty3[0]:
                    answer3 = [True, "cadena vacia"]
                else:
                    respu3 = validations.validate_int(jsdata["ind_ldesc"])  # smallint

                # validacion para el cron_id
                if respuEmpty5[0]:
                    answer5 = [True, "cadena vacia"]
                else:
                    respu5 = validations.validate_int(jsdata["cron_id"])  # integer

                    if respu5[0] == True:
                        respu9 = validations.id_Mae_Cron(int(jsdata["cron_id"]))
                    else:
                        respu9 = [False, "No se tiene un cron_id correcto"]

                # validacion para el ind_id
                respu8 = validations.validate_int(jsdata["ind_id"])  # serial
                if respu8[0] == True:
                    respu10 = validations.id_Mae_Ind(int(jsdata["ind_id"]))
                else:
                    respu10 = [False, "No se tiene ind_id correcto"]

                list_respu = [
                    respu1,
                    respu2,
                    respu3,
                    respu4,
                    respu5,
                    respu6,
                    respu7,
                    respu8,
                    respu9,
                    respu10,
                ]
                nombres = [
                    "ind_desc",
                    "ind_estado",
                    "ind_ldesc",
                    "ind_alerta",
                    "cron_id",
                    "ind_trap",
                    "ind_trap_definicion",
                    "ind_id",
                    "cron_id",
                    "ind_id",
                ]

                if (
                    respu1[0]  # ind_desc
                    and respu2[0]  ## int_estado
                    and respu3[0]  ## int_ldesc
                    and respu4[0]  # ind_alerta
                    and respu5[0]  ## int cron_id
                    and respu6[0]  # ind_trap
                    and respu7[0]  # ind_trap_definition
                    and respu8[0]  ## int ind_id
                    and respu9[0]  ## rigth cron_id
                    and respu10[0]  ## exists ind_id
                ):
                    obj = MAE_INDICADORES(
                        jsdata["ind_desc"],
                        int(jsdata["ind_estado"]),
                        int(jsdata["ind_ldesc"]),
                        jsdata["ind_alerta"],
                        int(jsdata["cron_id"]),
                        jsdata["ind_trap"],
                        jsdata["ind_trap_definicion"],
                        int(jsdata["ind_id"]),
                    )

                    resp = obj.modificar()
                    flag = 1

                # we use or to analize ind_estado,ind_ldesc and cron_id

                elif (
                    respu1[0]  # ind_desc
                    and respu4[0]  # ind_alerta
                    and respu6[0]  # ind_trap
                    and respu7[0]  # ind_trap_definition
                    and respu8[0]  # ind_id int
                    and respu10[0]  # ind_id exist
                    and (answer2 or answer3 or answer5)
                ):
                    # si es cadena vacia
                    if answer2[0]:
                        data2 = ""
                    else:
                        data2 = int(jsdata["ind_estado"])

                    if answer3[0]:
                        data3 = ""
                    else:
                        data3 = int(jsdata["ind_ldesc"])

                    if answer5[0]:
                        data5 = ""
                    else:
                        data5 = int(jsdata["cron_id"])

                    obj = MAE_INDICADORES(
                        jsdata["ind_desc"],
                        data2,
                        data3,
                        jsdata["ind_alerta"],
                        data5,
                        jsdata["ind_trap"],
                        jsdata["ind_trap_definicion"],
                        int(jsdata["ind_id"]),
                    )

                    resp = obj.modificar()
                    flag = 2

                else:
                    resp = ["error", ""]
                    num = 0

                    for respu in list_respu:
                        if respu[0] == False:
                            # resp[1] = resp[1]+'-'+respu[1]+'\n'
                            extra[nombres[num]] = respu[1]
                        num = num + 1

            except Exception as e:
                resp = ["error", str(e)]
            linea = {}

            if resp[0] == "ok":
                linea["result"] = "ok"
                linea["data"] = obj.get_diccionario()
                '''linea["ind_id"] = obj.ind_id
                linea["ind_desc"] = obj.ind_desc
                linea["ind_estado"] = obj.ind_estado
                linea["ind_ldesc"] = obj.ind_ldesc
                linea["ind_alerta"] = obj.ind_alerta
                linea["cron_id"] = obj.cron_id
                linea["ind_trap"] = obj.ind_trap
                linea["ind_trap_definicion"] = obj.ind_trap_definicion   '''             
            else:
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 411
                linea['query'] = resp
                if bool(extra):
                    linea["val_errors"] = extra
                else:
                    linea["val_errors"] = resp[1]

        else:
            linea = {}
            linea["result"] = "failed"
            linea["error"] = "Sucedio un error -cookie:" + str(cookie)
            linea["error_cod"] = 412
            linea["val_errors"] = "token no valido"
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea = {}
        linea["result"] = "failed"
        linea["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        linea["error_cod"] = 413
        linea["val_errors"] = "token no validado"

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
