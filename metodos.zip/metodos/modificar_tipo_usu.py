import sys, os

sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_TIPO_USU import MAE_TIPO_USU
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
from clsSession import Session
import validations


def application(environ, start_response):
    try:
        coo = ""
        jsdato = ""
        extra = {}
        status = "200 OK"  # se crea la respuesta de estado

        s = Session()
        if environ["REQUEST_METHOD"] != "PUT" and environ['REQUEST_METHOD'] != 'POST':
            raise validations.HttpException(405)

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):
            jsdato = s.get_Datos_Usu(str(tk))
            lendata = int(environ.get("CONTENT_LENGTH", 0))
            bydata = environ["wsgi.input"].read(lendata)
            jsdata = json.loads(bydata.decode("utf-8"))

            try:
                respu1 = validations.validate_varchar(jsdata["tusu_desc"], 300)
                respu2 = validations.validate_int(jsdata["tusu_id"])
                respu3 = validations.validate_char(jsdata["tusu_estado"])

                if respu2[0] == True:
                    respu4 = validations.id_Tipo_Usu(int(jsdata["tusu_id"]))
                else:
                    respu4 = [False, "No existe tusu_id con el numero dado"]

                list_respu = [respu1, respu2, respu3, respu4]
                nombres = ["tusu_desc", "tusu_id", "tusu_estado", "tusu_id"]

                if respu1[0] and respu2[0] and respu3[0] and respu4[0]:

                    obj = MAE_TIPO_USU.from_json(jsdata)
                    resp = obj.modificar()
                else:
                    resp = ["error", ""]
                    num = 0
                    status = "400 Internal Server Error"
                    for respu in list_respu:

                        if respu[0] == False:
                            extra[nombres[num]] = respu[1]
                        num = num + 1

            except Exception as e:
                resp = ["error", str(e)]
                status = "400 Internal Server Error"
        else:
            resp = ["error", "token no validado"]
            status = "401 Unauthorized"

        linea = {}

        if resp[0] == "ok":
            linea["result"] = "ok"
            linea["data"] = obj.get_diccionario()
            '''linea["tusu_id"] = obj.tusu_id
            linea["tusu_desc"] = obj.tusu_desc
            linea["tusu_estado"] = obj.tusu_estado'''
            # Como la respuesta es correcta se guarda en el log de acciones
            usu_id = s.get_id_Usu(str(tk))
            filename = os.path.basename(__file__).split(".")[0]
            obj_log = LOG_ACCIONES_USUARIO(
                log_usu_id=usu_id,
                log_desc="Se modifico el tipo de usuario con el siguiente PK tusu_id: "
                + str(jsdata["tusu_id"]),
                log_acc_id=406,
            )
            resp_log = obj_log.guardar_dato()
            if resp_log[0] == "error":
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 411
                status = "400 Internal Server Error"
                linea["error_val"] = "No se pudo guardar en el log"
        else:
            linea["result"] = "failed"
            linea["error"] = "Sucedio un error"
            linea["error_cod"] = 412
            if bool(extra):
                linea["val_errors"] = extra
            else:
                linea["val_errors"] = resp[1]

    except validations.HttpException as e:
        linea = {}
        linea["result"] = "failed"
        linea["error_cod"] = e.code
        linea["error"] = e.message
        linea["val_errors"] = e.message
        status = e.status_code

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea = {}
        linea["result"] = "failed"
        linea["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        linea["error_cod"] = 412
        linea["val_errors"] = "token no validado"
        status = "500 Internal Server Error"

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ("Content-Type", "application/json"),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
