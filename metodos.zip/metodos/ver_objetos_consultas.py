import sys

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_OBJETOS_CONSULTAS import MAE_OBJETOS_CONSULTAS
import validations
import os


def application(environ, start_response):

    try:
        coo = ""
        extra = {}
        jsdato = ""
        status = "200 OK"
        lendata = int(environ.get("CONTENT_LENGTH", 0))
        bydata = environ["wsgi.input"].read(lendata)
        jsdata = json.loads(bydata.decode("utf-8"))

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        #bdata = environ["PATH_INFO"]
        #bdata2 = bdata.split("/")[1]
        #respuest1 = validations.validate_int(bdata2.split("-")[0])
        #respuest2 = validations.validate_int(bdata2.split("-")[1])

        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):
            jsdato = s.get_Datos_Usu(str(tk))
            try:
                respu1 = validations.validate_int(jsdata["obj_id"]) #integer
                respu2 = validations.validate_int(jsdata["con_id"]) #integer
                if respu1[0] == True:
                    respu3 = validations.id_Mae_Obj(int(jsdata["obj_id"]))
                else:
                    respu3 = [False, "No se tiene un obj_id correcto"]
                if respu2[0] == True:
                    respu4 = validations.id_Consultas(int(jsdata["con_id"]))
                else :
                    respu4 = [False, "No se tiene un con_id correcto"]

                list_respu = [respu1, respu2, respu3, respu4]
                nombres = ["obj_id", "con_id", "obj_id", "con_id"]

                if respu1[0] and respu2[0] and respu3[0] and respu4[0]:

                    obj = MAE_OBJETOS_CONSULTAS(" ", " ", " ", int(jsdata["obj_id"]), int(jsdata["con_id"]))
                    dato = obj.buscar_dato()
                    if dato[0] == "ok":
                        resp = ["ok", " "]
                    else:
                        resp = ["error", dato[1]]
                else:
                    resp = ["error", ""]
                    num = 0
                    for respu in list_respu:
                        if respu[0] == False:
                            # resp[1] = resp[1]+'-'+respu[1]+'\n'
                            extra[nombres[num]] = respu[1]
                        num = num + 1
            except Exception as e:
                resp = ["error", str(e)]
        else:
            resp = ["error", "token no validado"]
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        resp = ["error","token no validado"+ str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)]

    linea = {}
    if resp[0] == "ok":
        linea = {}
        linea["obj_id"] = jsdata["obj_id"]
        linea["con_id"] = jsdata["con_id"]
        linea["objc_estado"] = obj.objc_estado
        linea["objc_protocolo"] = obj.objc_protocolo
        linea["objc_trama"] = obj.objc_trama
    else:
        linea["result"] = "failed"
        linea["error"] = "Sucedio un error"
        linea["error_cod"] = 412
        if bool(extra):
            linea["val_errors"] = extra
        else:
            linea["val_errors"] = resp[1]



    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
