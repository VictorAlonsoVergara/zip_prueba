import sys,os

sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_AREA import MAE_AREA
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations


def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""
        status = "500 Internal Server Error"
        if environ['REQUEST_METHOD'] != 'POST':
            #status = "405 Method Not Allowed"
            raise validations.HttpException(405)

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):
            jsdato = s.get_Datos_Usu(str(tk))

            lendata = int(environ.get("CONTENT_LENGTH", 0))
            bydata = environ["wsgi.input"].read(lendata)
            jsdata = json.loads(bydata.decode("utf-8"))

            try:
                extra = {}
                diccionario_respu = {}
                pass_flag = True

                diccionario_respu['area_desc'] = validations.validate_varchar(jsdata["area_desc"], 100)
                diccionario_respu['area_ldesc'] = validations.validate_varchar(jsdata["area_ldesc"], 200)
                diccionario_respu['area_estado'] = validations.validate_char(jsdata["area_estado"])

                for key,value in jsdata.items():
                    value_empty = validations.validate_empty(value)
                    if value_empty[0] is True:
                        diccionario_respu[key] = value_empty
                        diccionario_respu[key][0] = False

                for _,value in diccionario_respu.items():
                    if value[0] is False:
                        pass_flag = False
                        break
                if pass_flag is True:
                    obj = MAE_AREA.from_json(jsdata)
                    resp = obj.guardar_dato()
                else:
                    resp = ["error", ""]
                    for key,respu in diccionario_respu.items():
                        if respu[0] == False:
                            # resp[1] = resp[1]+'-'+nombres[num]+': '+respu[1]+' \n'
                            extra[key] = respu[1]
                    status = "400 Bad Request"

            except Exception as e:
                resp = ["error", str(e)]
                status = "400 Bad Request"
            linea = {}

            if resp[0] == "ok":
                linea["result"] = "ok"
                linea["data"] = obj.get_diccionario()
                '''linea["area_id"] = obj.area_id
                linea["area_desc"] = obj.area_desc
                linea["area_ldesc"] = obj.area_ldesc
                linea["area_estado"] = obj.area_estado'''
                #Como la respuesta es correcta se guarda en el log de acciones
                usu_id = s.get_id_Usu(str(tk))
                filename = os.path.basename(__file__).split('.')[0]
                obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se creo el area con el siguiente PK area_id: '+str(obj.area_id),log_acc_id = 494)
                resp_log = obj_log.guardar_dato()
                status = "200 OK"
                if resp_log[0] == 'error':
                    linea['result'] = "failed"
                    linea['error'] = "Sucedio un error"
                    linea['error_cod'] = 411
                    status = "500 Internal Server Error"
                    linea['error_val'] = "No se pudo guardar en el log"
            else:
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 412
                status = "400 Bad Request"
                if bool(extra):
                    linea["val_errors"] = extra
                else:
                    linea["val_errors"] = resp[1]
        else:
            linea = {}
            linea["result"] = "failed"
            linea["error"] = "Sucedio un error -cookie:" + str(cookie)
            linea["error_cod"] = 412
            linea["val_errors"] = "token no valido"
            status = "401 Unauthorized"

    except validations.HttpException as e:
        linea = {}
        linea["result"] = "failed"
        linea["error_cod"] = e.code
        linea["error"] = e.message
        linea["val_errors"] = e.message
        status = e.status_code

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea = {}
        linea["result"] = "failed"
        linea["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        linea["error_cod"] = 412
        linea["val_errors"] = "token no validado"
        status = "500 Internal Server Error"

    
    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
