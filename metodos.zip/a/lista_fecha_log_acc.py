import sys, os
import datetime, logging
sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations
rutalog="/home/sistema/log/Traxium"
def application(environ, start_response):

	try:
		coo = ""
		jsdato = ""
		status = "500 Internal Server Error"
		lendata = int(environ.get("CONTENT_LENGTH", 0))
		bydata = environ["wsgi.input"].read(lendata)
		jsdata = json.loads(bydata.decode("utf-8"))
		
		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]
		
		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)
		tk = s.getCookie(cookie, "token")
		s.setToken(tk)
		datosB = s.getCookie(cookie, "dato")
		len_datosB = len(datosB)
		datosC = json.loads(datosB[1:(len_datosB-1)])  
		if environ['REQUEST_METHOD'] != 'POST':
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)
		if s.valToken(tk) and s.valIp(tk, str(dataIP)):
			jsdato = s.get_Datos_Usu(str(tk))
			extra = {}
			diccionario_respu = {}
			pass_flag = True

			diccionario_respu['numero_pag'] = validations.validate_int(jsdata['numero_pag'])
			diccionario_respu['cantidad_pag'] = validations.validate_int(jsdata["cantidad_pag"])
			diccionario_respu['fecha_ini'] = validations.validate_date_time(jsdata["fecha_ini"])
			diccionario_respu['fecha_fin'] = validations.validate_date_time(jsdata["fecha_fin"])

			for key,value in jsdata.items():
				value_empty = validations.validate_empty(value)
				if value_empty[0] is True and key != 'usu_id':
					diccionario_respu[key] = value_empty

			for _,value in diccionario_respu.items():
				if value[0] is False:
					pass_flag = False
					break

			if pass_flag is True:
				status = "200 OK"
				resp = LOG_ACCIONES_USUARIO.consultar_lista_fecha(jsdata["numero_pag"],jsdata["cantidad_pag"],jsdata["fecha_ini"],jsdata["fecha_fin"])

			else:
				resp = {}
				resp["error1"] = "Sucedio un error"
				for key,respu in diccionario_respu.items():
					if respu[0] == False:
						if len(respu) == 3 :
							mensaje1 = s.mensaje_error(datosC['idioma'],respu[2])
							extra[key] = str(mensaje1[1][0][0]) + respu[1]
						else :
							mensaje1 = s.mensaje_error(datosC['idioma'],104)
							extra[key] = str(mensaje1[1][0][0]) + respu[1]



			diccionario = {}
			if "error" in resp:
				mensaje = s.mensaje_error(datosC['idioma'],60)
				diccionario["result"] = "failed"
				diccionario["error"] = resp[1]
				diccionario["error_cod"] = 60
				status = "400 Bad Request"
				diccionario["val_errors"] = str(mensaje[1][0][0])
			elif "error1" in resp:

				diccionario["result"] = "failed"
				diccionario["error"] = "Sucedio un error"
				diccionario["error_cod"] = 104
				status = "400 Bad Request"
				if bool(extra):
					diccionario["val_errors"] = extra
				else:
					diccionario["val_errors"] = resp[1]
			else :
				diccionario= resp
		else:
			if s.valToken(tk) :
				cod_error = 100
			else :
				cod_error = 101
			mensaje = s.mensaje_error(datosC['idioma'],cod_error)
			diccionario = {}
			diccionario["result"] = "failed"
			diccionario["error"] = "Sucedio un error"
			diccionario["error_cod"] = cod_error
			diccionario["val_errors"] = str(mensaje[1][0][0])
			status = "401 Unauthorized"	
	except validations.HttpException as e:
		diccionario = {}
		mensaje = s.mensaje_error(datosC['idioma'],51)
		diccionario["result"] = "failed"
		diccionario["error_cod"] = "Sucedio un error"
		diccionario["error"] = 51
		diccionario["val_errors"] = str(mensaje[1][0][0])
		status = e.status_code
	except Exception as e:
		diccionario = {}
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		diccionario["result"] = "failed"
		diccionario["error"] = "Sucedio un error"
		diccionario["error_cod"] = 50
		try :
			mensaje = s.mensaje_error(datosC['idioma'],50)
			diccionario["val_errors"] = str(mensaje[1][0][0])
		except:
			diccionario["val_errors"] = 'error de python' 
		status = "500 Internal Server Error"
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)

	preoutput = json.dumps(diccionario)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]
