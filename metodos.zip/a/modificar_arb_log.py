import sys, os
import datetime, logging
sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from ARB_LOGICO import ARB_LOGICO
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations
rutalog="/home/sistema/log/Traxium"

def application(environ, start_response):

	try:
		coo = ""
		jsdato = ""
		status = "200 OK"
		

		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]

		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)
		tk = s.getCookie(cookie, "token")
		s.setToken(tk)
		datosB = s.getCookie(cookie, "dato")
		len_datosB = len(datosB)
		datosC = json.loads(datosB[1:(len_datosB-1)]) 
		if environ['REQUEST_METHOD'] != 'PUT' and environ['REQUEST_METHOD'] != 'POST':
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)
		if s.valToken(tk) and s.valIp(tk, str(dataIP)):

			jsdato = s.get_Datos_Usu(str(tk))
			lendata = int(environ.get("CONTENT_LENGTH", 0))
			bydata = environ["wsgi.input"].read(lendata)
			jsdata = json.loads(bydata.decode("utf-8"))
			try:

				extra = {}
				pass_flag = True
				diccionario_respu = {}
				diccionario_respu['log_id'] = validations.validate_int(jsdata["log_id"])
				diccionario_respu['log_desc'] = validations.validate_varchar(jsdata["log_desc"],200)
				diccionario_respu['log_orden'] = validations.validate_varchar(jsdata["log_orden"],30)
				diccionario_respu['log_id_padre'] = validations.validate_int(jsdata["log_id_padre"])

				if diccionario_respu['log_id_padre'][0] is True:
					diccionario_respu['log_id_padre'] = validations.id_Arb_Log(int(jsdata["log_id_padre"]))
				

				if diccionario_respu['log_id'][0] is True:
					diccionario_respu['log_id'] = validations.id_Arb_Log(int(jsdata["log_id"]))
				
				if diccionario_respu['log_id'][0] is True and diccionario_respu['log_id_padre'][0] is True:
					if jsdata["log_id"] == jsdata["log_id_padre"]:
						diccionario_respu['log_id_padre'] = [False, "El nuevo padre no puede ser el mismo nodo"]
				
				if jsdata["log_id_padre"] == "NULL":
						diccionario_respu['log_id_padre'][0] = True
				
				for key,value in jsdata.items():
					value_empty = validations.validate_empty(value)
					if value_empty[0] is True and key != 'log_id':
						diccionario_respu[key][0] = True

				for _,value in diccionario_respu.items():
					if value[0] is False:
						pass_flag = False
						break
				
				if pass_flag is True:
					obj = ARB_LOGICO.from_json(jsdata)
					resp = obj.modificar()
				else:
					resp = ["error1", ""]
					num = 0

					for key,respu in diccionario_respu.items():
						if respu[0] == False:
							if len(respu) == 3 :
								mensaje1 = s.mensaje_error(datosC['idioma'],respu[2])
								extra[key] = str(mensaje1[1][0][0]) + respu[1]
							else :
								mensaje1 = s.mensaje_error(datosC['idioma'],104)
								extra[key] = str(mensaje1[1][0][0]) + respu[1]
						num = num + 1

			except Exception as e:
				status = "400 Bad Request"
				resp = ["error1", str(e)]
			linea = {}

			if resp[0] == "ok":
				linea["result"] = "ok"
				linea["data"] = obj.get_diccionario()
				'''linea["log_id"] = obj.log_id
				linea["log_id_padre"] = obj.log_id_padre
				linea["log_desc"] = obj.log_desc
				linea["log_orden"] = obj.log_orden      '''          
				#Como la respuesta es correcta se guarda en el log de acciones
				usu_id = s.get_id_Usu(str(tk))
				filename = os.path.basename(__file__).split('.')[0]
				obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se modifico el arb_logico con el siguiente PK log_id: '+str(jsdata["log_id"]),log_acc_id = 471)
				resp_log = obj_log.guardar_dato()
				if resp_log[0] == 'error':
					mensaje = s.mensaje_error(datosC['idioma'],103)
					linea['result'] = "failed"
					linea['error'] = "Sucedio un error"
					linea['error_cod'] = 103
					status = "400 Bad Request"
					linea['val_errors'] = str(mensaje[1][0][0])
			elif resp[0] == "error1":
				linea["result"] = "failed"
				linea["error"] = "Sucedio un error"
				linea["error_cod"] = 104
				status = "400 Bad Request"
				if bool(extra):
					linea["val_errors"] = extra
				else:
					linea["val_errors"] = resp[1]
			else :
				mensaje = s.mensaje_error(datosC['idioma'],60)
				linea["result"] = "failed"
				linea["error"] = resp[1]
				linea["error_cod"] = 60
				status = "400 Bad Request"
				linea["val_errors"] = str(mensaje[1][0][0])
		else:
			if s.valToken(tk) :
				cod_error = 100
			else :
				cod_error = 101
			mensaje = s.mensaje_error(datosC['idioma'],cod_error)
			linea = {}
			linea["result"] = "failed"
			linea["error"] = "Sucedio un error"
			linea["error_cod"] = cod_error
			linea["val_errors"] = str(mensaje[1][0][0])
			status = "401 Unauthorized"	
	except validations.HttpException as e:
		linea = {}
		mensaje = s.mensaje_error(datosC['idioma'],51)
		linea["result"] = "failed"
		linea["error_cod"] = "Sucedio un error"
		linea["error"] = 51
		linea["val_errors"] = str(mensaje[1][0][0])
		status = e.status_code
	except Exception as e:
		linea = {}
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		linea["result"] = "failed"
		linea["error"] = "Sucedio un error"
		linea["error_cod"] = 50
		try :
			mensaje = s.mensaje_error(datosC['idioma'],50)
			linea["val_errors"] = str(mensaje[1][0][0])
		except:
			linea["val_errors"] = 'error de python' 
		status = "500 Internal Server Error"     
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)

	preoutput = json.dumps(linea)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]
