import sys , os
import datetime, logging
sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_OBJETOS import MAE_OBJETOS
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations
rutalog="/home/sistema/log/Traxium"
def application(environ, start_response):

	try:
		coo = ""
		jsdato = ""
		extra = {}
		status = "200 OK"  # se crea la respuesta de estado

		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]

		lendata = int(environ.get("CONTENT_LENGTH", 0))  # se guarda los datos enviados
		bydata = environ["wsgi.input"].read(lendata)
		jsdata = json.loads(bydata.decode("utf-8"))  # se convierte los datos y json
		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)  
		tk = s.getCookie(cookie, "token") 
		datosB = s.getCookie(cookie, "dato")
		len_datosB = len(datosB)
		datosC = json.loads(datosB[1:(len_datosB-1)])   
		if environ['REQUEST_METHOD'] != 'POST':#Verifica el metodo usado
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)				
		if s.valToken(tk) and s.valIp(tk, str(dataIP)):  
			jsdato = s.get_Datos_Usu(str(tk))  
			try:
				pass_flag = True
				extra = {}
				respuestas_dict = {}
				#Validaciones de Tipo de Dato
				respuestas_dict["obj_desc"] = (validations.validate_varchar(jsdata["obj_desc"], 200))
				respuestas_dict["tobj_id"] = (validations.validate_int(jsdata["tobj_id"]))
				respuestas_dict["obj_estado"] = (validations.validate_char(jsdata["obj_estado"]))
				respuestas_dict["obj_ldesc"] = (validations.validate_string(jsdata["obj_ldesc"]))
				respuestas_dict["obj_latitud"] = (validations.validate_numeric(jsdata["obj_latitud"],11,8))
				respuestas_dict["obj_longitud"] = (validations.validate_numeric(jsdata["obj_longitud"],11,8))
				respuestas_dict["obj_ip_address"] = (validations.validate_varchar(jsdata["obj_ip_address"],16))
				respuestas_dict["marca_id"] = (validations.validate_int(jsdata["marca_id"]))
				respuestas_dict["prot_id"] = (validations.validate_int(jsdata["prot_id"]))
				respuestas_dict["obj_firmware"] = (validations.validate_varchar(jsdata["obj_firmware"], 200))
				respuestas_dict["obj_hardware"] = (validations.validate_varchar(jsdata["obj_hardware"], 200))
				respuestas_dict["obj_usuario"] = (validations.validate_varchar(jsdata["obj_usuario"], 50))
				respuestas_dict["obj_password"] = (validations.validate_varchar(jsdata["obj_password"], 50))
				respuestas_dict["mod_id"] = (validations.validate_int(jsdata["mod_id"]))
				respuestas_dict["obj_respuesta"] = (validations.validate_varchar(jsdata["obj_respuesta"],500))
				respuestas_dict["obj_respuesta_flag"] = (validations.validate_boolean(jsdata["obj_respuesta_flag"]))
				#Validaciones de Foreign keys
				if respuestas_dict["marca_id"][0] is True:
					respuestas_dict["marca_id"] = (validations.id_Mae_Marcas(int(jsdata["marca_id"])))
				if respuestas_dict["prot_id"][0] is True:
					respuestas_dict["prot_id"] = (validations.id_Tab_Prot(int(jsdata["prot_id"])))
				if respuestas_dict["mod_id"][0] is True:
					respuestas_dict["mod_id"] = (validations.id_Mae_Modelo(int(jsdata["mod_id"])))
				#Validaciones de campo vacio
				for key,value in jsdata.items():
					value_empty = validations.validate_empty(value)
					if value_empty[0] is True:
						respuestas_dict[key] = value_empty
						if (key != 'obj_usuario' and key != 'obj_password' and key != 'obj_ip_address'):#estos valores pueden ser nulos
							respuestas_dict[key][0] = False
				#Verificar si existe algun error
				for _,respu in respuestas_dict.items():
					if respu[0] is False:
						pass_flag = False
						break
				#Ejecutar el guardado si no se encontro ningun error
				if pass_flag is True:
					obj = MAE_OBJETOS.from_json(jsdata)
					resp = obj.guardar_dato()
					obj.buscar_dato()
				else:
					resp = ["error1", ""]
					for key,respu in respuestas_dict.items():
						if respu[0] == False:
							# resp[1] = resp[1]+'-'+nombres[num]+': '+respu[1]+' \n'
							if len(respu) == 3 :
								mensaje1 = s.mensaje_error(datosC['idioma'],respu[2])
								extra[key] = str(mensaje1[1][0][0]) + respu[1]
							else :
								mensaje1 = s.mensaje_error(datosC['idioma'],104)
								extra[key] = str(mensaje1[1][0][0]) + respu[1]
				linea = {}
				if resp[0] == "ok":
					linea["result"] = "ok"
					linea["data"] = obj.get_diccionario()
					#linea["obj_id"] = obj.obj_id
					#Como la respuesta es correcta se guarda en el log de acciones
					usu_id = s.get_id_Usu(str(tk))
					filename = os.path.basename(__file__).split('.')[0]
					obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se creo el objeto con el siguiente PK obj_id: '+str(obj.obj_id),log_acc_id = 436)
					resp_log = obj_log.guardar_dato()
					if resp_log[0] == 'error':
						mensaje = s.mensaje_error(datosC['idioma'],103)
						linea['result'] = "failed"
						linea['error'] = "Sucedio un error"
						linea['error_cod'] = 103
						status = "500 Internal Server Error"
						linea['error_val'] = str(mensaje[1][0][0]) 
				elif resp[0] == "error1":
					linea["result"] = "failed"
					linea["error"] = "Sucedio un error"
					linea["error_cod"] = 104
					status = "400 Bad Request"
					if bool(extra):
						linea["val_errors"] = extra
					else:
						linea["val_errors"] = resp[1]
				else :
					mensaje = s.mensaje_error(datosC['idioma'],60)
					linea["result"] = "failed"
					linea["error"] = resp[1]
					linea["error_cod"] = 60
					status = "400 Bad Request"
					linea["val_errors"] = str(mensaje[1][0][0])                          
			except Exception as e:
				
				exc_type, exc_obj, exc_tb = sys.exc_info()
				fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
				resp = ["error", (
					"Sucedio un error -cookie: "
					+ str(e)
					+ " - "
					+ str(exc_type)
					+ " - "
					+ str(fname)
					+ " - "
					+ str(exc_tb.tb_lineno)
				)]

			linea = {}
			if resp[0] == "ok":
				linea["result"] = "ok"
				linea["data"] = obj.get_diccionario()
			else:
				mensaje = s.mensaje_error(datosC['idioma'],cod_error)
				linea["result"] = "failed"
				linea["error"] = "Sucedio un error"
				linea["error_cod"] = 412
				status = "400 Bad Request"
				if bool(extra):
					linea["val_errors"] = extra
				else:
					linea["val_errors"] = resp[1]
		else:
			if s.valToken(tk) :
				cod_error = 100
			else :
				cod_error = 101
			mensaje = s.mensaje_error(datosC['idioma'],cod_error)			
			linea = {}
			linea["result"] = "failed"
			linea["error"] = "Sucedio un error" 
			linea["error_cod"] = error_cod
			linea["val_errors"] =  str(mensaje[1][0][0])
			status = "401 Unauthorized"
	
	except validations.HttpException as e:
		linea = {}
		mensaje = s.mensaje_error(datosC['idioma'],51)
		linea["result"] = "failed"
		linea["error_cod"] = "Sucedio un error"
		linea["error"] = 51
		linea["val_errors"] = str(mensaje[1][0][0])
		status = e.status_code
	
	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		linea = {}
		linea["result"] = "failed"
		linea["error"] = "Sucedio un error"
		linea["error_cod"] = 50
		try :
			mensaje = s.mensaje_error(datosC['idioma'],50)
			linea["val_errors"] = str(mensaje[1][0][0])
		except:
			linea["val_errors"] = 'error de python' 
		status = "500 Internal Server Error"
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)

	preoutput = json.dumps(linea)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	# se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]
