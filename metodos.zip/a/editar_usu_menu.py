import sys, os
import logging,datetime
rutalog="/home/sistema/log/Traxium"
sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_USUARIOS_MENU import MAE_USUARIOS_MENU
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
from clsSession import Session
import validations
import generico


def application(environ, start_response):
    try:
        jsdato = ""
        linea = {}
        status = "200 OK"  # se crea la respuesta de estado
        lendata = int(environ.get("CONTENT_LENGTH", 0))
        bydata = environ["wsgi.input"].read(lendata)
        jsdata = json.loads(bydata.decode("utf-8"))
        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)  # se obtiene la informacion del cookie
        datosB = s.getCookie(cookie, "dato")
        len_datosB = len(datosB)
        datosC = json.loads(datosB[1:(len_datosB-1)])   
        tk = s.getCookie(
            cookie, "token"
        )  # se escoge la informacion guardada en la variable token

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):  # se valida si el token esta validado

            answer1 = validations.id_Mae_Usu(jsdata["usu_id"])
            if answer1[0]:
                jsdato = s.get_Datos_Usu(str(tk))
                usu_id = s.get_id_Usu(str(tk))
                linea = MAE_USUARIOS_MENU.editar_menu(jsdata["usu_id"], jsdata["datos"])
                if linea['result'] == 'ok':
                    obj_log = LOG_ACCIONES_USUARIO(
                        log_usu_id=usu_id,
                        log_desc="Se edito el usuario_menu con el siguiente PK umenu_id: "
                        + str(jsdata["datos"]),
                        log_acc_id=513,
                    )
                    resp_log = obj_log.guardar_dato()

                if resp_log[0] == "error":
                    mensaje = s.mensaje_error(datosC['idioma'],103)
                    linea["result"] = "failed"
                    linea["error"] = "Sucedio un error"
                    linea["error_cod"] = 103
                    status = "500 Internal Server Error"
                    linea["val_errors"] = str(mensaje[1][0][0])

            else:
                mensaje = s.mensaje_error(datosC['idioma'],105)
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 105
                linea["val_errors"] = str(mensaje[1][0][0]) + " usu_id"
                status = "400 Bad Request"
        else:
            if s.valToken(tk) :
                cod_error = 100
            else :
                cod_error = 101
            mensaje = s.mensaje_error(datosC['idioma'],cod_error)              
            linea["result"] = "failed"
            linea["error"] = "Sucedio un error"
            linea["error_cod"] = cod_error
            linea["val_errors"] = str(mensaje[1][0][0])
            status = "401 Unauthorized"
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea["result"] = "failed"
        linea["error"] = "Sucedio un error"
        linea["error_cod"] = 50
        try :
            mensaje = s.mensaje_error(datosC['idioma'],50)
            linea["val_errors"] = str(mensaje[1][0][0])
        except:
            linea["val_errors"] = 'error de python'

        status = "500 Internal Server Error"
        datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
        now = datetime.datetime.now()
        fecha= datetime.date.today()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")
        logger = logging.getLogger('__name__')
        logger.setLevel(logging.ERROR)
        nombre_log= rutalog+'_'+str(fecha)+'.log'
        fh = logging.FileHandler(nombre_log)
        fh.setLevel(logging.ERROR)
        logger.addHandler(fh)
        logger.error("Error: "+str(current_time) + datoError)

    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ('Content-Type', 'application/json'),
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
