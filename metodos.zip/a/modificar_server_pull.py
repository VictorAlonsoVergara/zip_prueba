import sys, os
import datetime, logging
sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_SERVERS_PULL import MAE_SERVERS_PULL
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations
rutalog="/home/sistema/log/Traxium"

def application(environ, start_response):

	try:
		coo = ""
		jsdato = ""
		status = "200 OK"
		extra = {}

		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]
		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)
		tk = s.getCookie(cookie, "token")
		datosB = s.getCookie(cookie, "dato")
		len_datosB = len(datosB)
		datosC = json.loads(datosB[1:(len_datosB-1)]) 		
		s.setToken(tk)
		if environ['REQUEST_METHOD'] != 'PUT' and environ['REQUEST_METHOD'] != 'POST':
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)
		if s.valToken(tk) and s.valIp(tk, str(dataIP)):
			jsdato = s.get_Datos_Usu(str(tk))
			lendata = int(environ.get("CONTENT_LENGTH", 0))
			bydata = environ["wsgi.input"].read(lendata)
			jsdata = json.loads(bydata.decode("utf-8"))
			try:

				diccionario_respu = {}
				pass_flag = True
				diccionario_respu["serv_id"] = validations.validate_int(jsdata["serv_id"])
				diccionario_respu["serv_ip"] = validations.validate_varchar(jsdata["serv_ip"],20)
				diccionario_respu["serv_hostname"] = validations.validate_varchar(jsdata["serv_hostname"],50)
				diccionario_respu["log_id"] = validations.validate_int(jsdata["log_id"])
				if diccionario_respu["serv_id"][0] is True:
					diccionario_respu["serv_id"] = validations.id_Mae_Servers_Pull(int(jsdata["serv_id"]))
				if diccionario_respu["log_id"][0] is True:
					diccionario_respu["log_id"] = validations.id_Arb_Log(int(jsdata["log_id"]))
				
				for key,value in jsdata.items():
					val_empty = validations.validate_empty(value)
					if val_empty[0] is True:
						diccionario_respu[key][0] = True
				
				for _,value in diccionario_respu.items():
					if value[0] is False:
						pass_flag = False
						break
				if pass_flag is True:
					obj = MAE_SERVERS_PULL.from_json(jsdata)
					resp = obj.modificar()
					obj.buscar_dato()

				else:
					resp = ["error1", ""]
					for key,respu in diccionario_respu.items():
						if respu[0] == False:
							# resp[1] = resp[1]+'-'+nombres[num]+': '+respu[1]+' \n'
							if len(respu) == 3 :
								mensaje1 = s.mensaje_error(datosC['idioma'],respu[2])
								extra[key] = str(mensaje1[1][0][0]) + respu[1]
							else :
								mensaje1 = s.mensaje_error(datosC['idioma'],104)
								extra[key] = str(mensaje1[1][0][0]) + respu[1]

			except Exception as e:
				resp = ["error", str(e)]
			linea = {}

			if resp[0] == "ok":
				linea["result"] = "ok"
				linea["data"] = obj.get_diccionario()
				'''linea["serv_id"] = obj.serv_id
				linea["serv_ip"] = obj.serv_ip
				linea["serv_hostname"] = obj.serv_hostname
				linea["log_id"] = obj.log_id'''             
				usu_id = s.get_id_Usu(str(tk))
				filename = os.path.basename(__file__).split('.')[0]
				obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc='Se modifico el modelo con el siguiente PK serv_id: '+str(jsdata["serv_id"]),log_acc_id = 505)
				resp_log = obj_log.guardar_dato()
				if resp_log[0] == 'error':
					mensaje1 = s.mensaje_error(datosC['idioma'],103)
					linea['result'] = "failed"
					linea['error'] = "Sucedio un error"
					linea['error_cod'] = 103
					status = "400 Bad Request"
					linea['val_errors'] = str(mensaje[1][0][0])
			elif resp[0] == "error1":
				linea["result"] = "failed"
				linea["error"] = "Sucedio un error"
				linea["error_cod"] = 104
				status = "400 Bad Request"
				if bool(extra):
					linea["val_errors"] = extra
				else:
					linea["val_errors"] = resp[1]
			else :
				mensaje = s.mensaje_error(datosC['idioma'],60)
				linea["result"] = "failed"
				linea["error"] = resp[1]
				linea["error_cod"] = 60
				status = "400 Bad Request"
				linea["val_errors"] = str(mensaje[1][0][0])
		else:
			if s.valToken(tk) :
				cod_error = 100
			else :
				cod_error = 101
			mensaje = s.mensaje_error(datosC['idioma'],cod_error)			
			linea = {}
			linea["result"] = "failed"
			linea["error"] = "Sucedio un error"
			linea["error_cod"] = 410
			linea["val_errors"] = str(mensaje[1][0][0])
			status = "401 Unauthorized"

	except validations.HttpException as e:
		linea = {}
		mensaje = s.mensaje_error(datosC['idioma'],51)
		linea["result"] = "failed"
		linea["error_cod"] = "Sucedio un error"
		linea["error"] = 51
		linea["val_errors"] = str(mensaje[1][0][0])
		status = e.status_code

	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		linea = {}
		linea["result"] = "failed"
		linea["error"] = "Sucedio un error"
		linea["error_cod"] = 50
		try :
			mensaje = s.mensaje_error(datosC['idioma'],50)
			linea["val_errors"] = str(mensaje[1][0][0])
		except:
			linea["val_errors"] = 'error de python' 
		status = "500 Internal Server Error"
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)

	preoutput = json.dumps(linea)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]
