import sys, os
import datetime, logging
sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_INDICADORES import MAE_INDICADORES
import validations
rutalog="/home/sistema/log/Traxium"

def application(environ, start_response):

    try:
        coo = ""
        jsdato = ""

        try:
            dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
        except KeyError:
            dataIP = environ["REMOTE_ADDR"]

        status = "200 OK"
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)
        tk = s.getCookie(cookie, "token")
        s.setToken(tk)

        if s.valToken(tk) and s.valIp(tk, str(dataIP)):
            jsdato = s.get_Datos_Usu(str(tk))
            status = "200 OK"
            lendata = int(environ.get("CONTENT_LENGTH", 0))
            bydata = environ["wsgi.input"].read(lendata)
            jsdata = json.loads(bydata.decode("utf-8"))
            try:
                if (jsdata["ind_desc"] == None or jsdata["ind_desc"]=='' or jsdata["ind_estado"] == None or jsdata["ind_estado"]=='' or jsdata["ind_ldesc"] == None or jsdata["ind_ldesc"]=='' or jsdata["ind_alerta"] == None or jsdata["ind_alerta"]=='' or jsdata["cron_id"] == None or jsdata["cron_id"]=='' or jsdata["ind_trap"] == None or jsdata["ind_trap"]=='' or jsdata["ind_trap_definicion"] == None or jsdata["ind_trap_definicion"]==''):
                    respu0 = [False,'Hay dato vacio']
                else:
                    respu0 = [True, 'ok']                      
                extra = {}
                respu1 = validations.validate_varchar(jsdata["ind_desc"], 200)
                respu2 = validations.validate_int(jsdata["ind_estado"])
                respu3 = validations.validate_int(jsdata["ind_ldesc"])
                respu4 = validations.validate_char(jsdata["ind_alerta"])
                respu5 = validations.validate_int(jsdata["cron_id"])
                respu6 = validations.validate_char(jsdata["ind_trap"])
                respu7 = validations.validate_string(jsdata["ind_trap_definicion"])
                if respu5[0] == True:
                    respu8 = validations.id_Mae_Cron(int(jsdata["cron_id"]))
                else:
                    respu8 = [False, "No se tiene un cron_id correcto"]
                list_respu = [
                    respu0,                
                    respu1,
                    respu2,
                    respu3,
                    respu4,
                    respu5,
                    respu6,
                    respu7,
                    respu8,
                ]
                nombres = [
                    "espacio vacio",                
                    "ind_desc",
                    "ind_estado",
                    "ind_ldesc",
                    "ind_alerta",
                    "cron_id",
                    "ind_trap",
                    "ind_trap_definicion",
                    "cron_id",
                ]

                if (
                    respu0[0]                    
                    and respu1[0]
                    and respu2[0]
                    and respu3[0]
                    and respu4[0]
                    and respu5[0]
                    and respu6[0]
                    and respu7[0]
                    and respu8[0]
                ):
                    obj = MAE_INDICADORES(
                        jsdata["ind_desc"],
                        int(jsdata["ind_estado"]),
                        int(jsdata["ind_ldesc"]),
                        jsdata["ind_alerta"],
                        int(jsdata["cron_id"]),
                        jsdata["ind_trap"],
                        jsdata["ind_trap_definicion"],
                    )
                    resp = obj.guardar_dato()
                else:
                    resp = ["error", ""]
                    num = 0

                    for respu in list_respu:
                        if respu[0] == False:
                            # resp[1] = resp[1]+'-'+nombres[num]+': '+respu[1]+' \n'
                            extra[nombres[num]] = respu[1]
                        num = num + 1

            except Exception as e:
                resp = ["error", str(e)]
            linea = {}

            if resp[0] == "ok":
                linea["result"] = "ok"
                linea["data"] = obj.get_diccionario()
                '''linea["ind_id"] = obj.ind_id
                linea["ind_desc"] = obj.ind_desc
                linea["ind_estado"] = obj.ind_estado
                linea["ind_ldesc"] = obj.ind_ldesc
                linea["ind_alerta"] = obj.ind_alerta
                linea["cron_id"] = obj.cron_id
                linea["ind_trap"] = obj.ind_trap
                linea["ind_trap_definicion"] = obj.ind_trap_definicion'''
            else:
                linea["result"] = "failed"
                linea["error"] = "Sucedio un error"
                linea["error_cod"] = 412
                if bool(extra):
                    linea["val_errors"] = extra
                else:
                    linea["val_errors"] = resp[1]
        else:
            linea = {}
            linea["result"] = "failed"
            linea["error"] = "Sucedio un error -cookie:" + str(cookie)
            linea["error_cod"] = 412
            linea["val_errors"] = "token no valido"

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        linea = {}
        linea["result"] = "failed"
        linea["error"] = (
            "Sucedio un error -cookie: "
            + str(e)
            + " - "
            + str(exc_type)
            + " - "
            + str(fname)
            + " - "
            + str(exc_tb.tb_lineno)
        )  # +str(cookie)
        linea["error_cod"] = 412
        linea["val_errors"] = "token no validado"
        datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
        now = datetime.datetime.now()
        fecha= datetime.date.today()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")
        logger = logging.getLogger('__name__')
        logger.setLevel(logging.ERROR)
        nombre_log= rutalog+'_'+str(fecha)+'.log'
        fh = logging.FileHandler(nombre_log)
        fh.setLevel(logging.ERROR)
        logger.addHandler(fh)
        logger.error("Error: "+str(current_time) + datoError)
    preoutput = json.dumps(linea)
    output = bytes(preoutput, "utf-8")
    cook = 'dato="' + str(jsdato) + '" ;path=/'
    headers = [
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
        ("set-cookie", cook),
    ]
    start_response(status, headers)
    return [output]
