import sys, os
import datetime, logging
sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_OBJETO_LOGICO import MAE_OBJETO_LOGICO
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations
rutalog="/home/sistema/log/Traxium"

def application(environ, start_response):

	try:
		coo = ""
		jsdato = ""
		status = "200 OK"

		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
			# dataIP = environ['HTTP_X_FORWARDED_FOR']
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]
		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)
		tk = s.getCookie(cookie, "token")
		datosB = s.getCookie(cookie, "dato")
		len_datosB = len(datosB)
		datosC = json.loads(datosB[1:(len_datosB-1)]) 		
		s.setToken(tk)
		if environ['REQUEST_METHOD'] != 'POST':
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)
		if s.valToken(tk) and s.valIp(tk, str(dataIP)):
			jsdato = s.get_Datos_Usu(str(tk))

			lendata = int(environ.get("CONTENT_LENGTH", 0))
			bydata = environ["wsgi.input"].read(lendata)
			jsdata = json.loads(bydata.decode("utf-8"))

			try:
				# diccionario = {}
				if (jsdata["obj_id"] == None or jsdata["obj_id"]=='' or jsdata["log_id"] == None or jsdata["log_id"]=='' ):
					respu0 = [False,'Hay dato vacio']
				else:
					respu0 = [True, 'ok']                
				extra = {}
				respu1 = validations.validate_int(jsdata["obj_id"])
				respu2 = validations.validate_int(jsdata["log_id"])

				if respu1[0] == True:
					respu3 = validations.id_Mae_Obj(int(jsdata["obj_id"]))
				else:
					respu3 = [False, "No se tiene un obj_id correcto"]
				if respu2[0] == True:
					respu4 = validations.id_Arb_Log(int(jsdata["log_id"]))
				else:
					respu4 = [False, "No se tiene un log_id correcto"]
				if respu3[0] == True and respu4[0] == True:
					respu5 = MAE_OBJETO_LOGICO.validations_crear(
						int(jsdata["obj_id"]), int(jsdata["log_id"])
					)
				else:
					respu5 = [False, "No se tiene un obj_id & log_id correcto"]
				list_respu = [respu0, respu1, respu2, respu3, respu4, respu5]
				nombres = ["espacio vacio","obj_id", "log_id", "obj_id", "log_id", "obj_id & log_id"]

				if respu0[0] and respu1[0] and respu2[0] and respu3[0] and respu4[0] and respu5[0]:
					obj = MAE_OBJETO_LOGICO(
						int(jsdata["obj_id"]), int(jsdata["log_id"])
					)
					resp = obj.guardar_dato()
					obj.buscar_dato()
				else:
					resp = ["error1", ""]
					num = 0
					status = "400 Bad Request"
					for respu in list_respu:
						if respu[0] == False:
							# resp[1] = resp[1]+'-'+nombres[num]+': '+respu[1]+' \n'
							if len(respu) == 3 :
								mensaje1 = s.mensaje_error(datosC['idioma'],respu[2])
								extra[key] = str(mensaje1[1][0][0]) + respu[1]
							else :
								mensaje1 = s.mensaje_error(datosC['idioma'],104)
								extra[key] = str(mensaje1[1][0][0]) + respu[1]
						num = num + 1

			except Exception as e:
				resp = ["error", str(e)]
				status = "400 Bad Request"
			linea = {}

			if resp[0] == "ok":
				linea["result"] = "ok"
				linea["data"] = obj.get_diccionario()
				#linea["obj_id"] = obj.obj_id
				#linea["log_id"] = obj.log_id
				#Como la respuesta es correcta se guarda en el log de acciones
				usu_id = s.get_id_Usu(str(tk))
				filename = os.path.basename(__file__).split('.')[0]
				obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se crear el objeto logico con el siguiente PK log_id: '+str(obj.log_id)+'  obj_id: '+str(obj.obj_id),log_acc_id = 484)
				resp_log = obj_log.guardar_dato()
				if resp_log[0] == 'error':
					mensaje = s.mensaje_error(datosC['idioma'],103)
					linea['result'] = "failed"
					linea['error'] = "Sucedio un error"
					linea['error_cod'] = 103
					linea['val_errors'] = str(mensaje[1][0][0])
					status = "400 Bad Request"

			elif resp[0] == "error1":
				linea["result"] = "failed"
				linea["error"] = "Sucedio un error"
				linea["error_cod"] = 104
				status = "400 Bad Request"
				if bool(extra):
					linea["val_errors"] = extra
				else:
					linea["val_errors"] = resp[1]
			else :
				mensaje = s.mensaje_error(datosC['idioma'],60)
				linea["result"] = "failed"
				linea["error"] = resp[1]
				linea["error_cod"] = 60
				status = "400 Bad Request"
				linea["val_errors"] = str(mensaje[1][0][0])
		else:
			if s.valToken(tk) :
				cod_error = 100
			else :
				cod_error = 101
			mensaje = s.mensaje_error(datosC['idioma'],cod_error)			
			linea = {}
			linea["result"] = "failed"
			linea["error"] = "Sucedio un error"
			linea["error_cod"] = cod_error
			linea["val_errors"] = str(mensaje[1][0][0])
			status = "401 Unauthorized"

	except validations.HttpException as e:
		linea = {}
		mensaje = s.mensaje_error(datosC['idioma'],51)
		linea["result"] = "failed"
		linea["error_cod"] = "Sucedio un error"
		linea["error"] = 51
		linea["val_errors"] = str(mensaje[1][0][0])
		status = e.status_code

	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		linea = {}
		linea["result"] = "failed"
		linea["error"] = "Sucedio un error"
		linea["error_cod"] = 50
		try :
			mensaje = s.mensaje_error(datosC['idioma'],50)
			linea["val_errors"] = str(mensaje[1][0][0])
		except:
			linea["val_errors"] = 'error de python' 
		status = "500 Internal Server Error"
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)


	
	preoutput = json.dumps(linea)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]
