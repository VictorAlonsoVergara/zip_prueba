import sys
import datetime, logging
sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
import parameters
import validations
import os
rutalog="/home/sistema/log/Traxium"
def application(environ, start_response):

	try:
		coo = ""
		jsdato = ""
		extra = {}
		status = "200 OK"  # se crea la respuesta de estado

		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]

		lendata = int(
			environ.get("CONTENT_LENGTH", 0)
		)  # se guarda el dato puesto en el url
		bydata = environ["wsgi.input"].read(lendata)
		jsdata = json.loads(bydata.decode("utf-8"))

		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)
		tk = s.getCookie(cookie, "token")
		datosB = s.getCookie(cookie, "dato")
		len_datosB = len(datosB)
		datosC = json.loads(datosB[1:(len_datosB-1)]) 		
		s.setToken(tk)

		if s.valToken(tk) and s.valIp(tk, str(dataIP)):
			jsdato = s.get_Datos_Usu(str(tk))

			try:
				extra = {}
				respu1 = validations.validate_varchar(jsdata["grupo_codigo"], 30)
				# respu2 = validations.validate_varchar(jsdata['param_id'],30)

				list_respu = [respu1]
				nombres = ["grupo_codigo"]

				# verificar si todos los datos son correctos
				if respu1[0]:

					resp = parameters.buscar_param_grupo(jsdata["grupo_codigo"])

				else:
					status = "400 Bad Request"
					resp = ["error", ""]
					num = 0

					for respu in list_respu:

						if respu[0] == False:
							extra[nombres[num]] = respu[1]

						num = num + 1

			except Exception as e:
				resp = ["errore", str(e)]
				status = "400 Bad Request"

		else:
			resp = ["errort", "Token no validado"]
			status = "401 Unauthorized"

	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]

		resp = [
			"errore",
			str(e)
			+ " - "
			+ str(exc_type)
			+ " - "
			+ str(fname)
			+ " - "
			+ str(exc_tb.tb_lineno),
		]
		status = "500 Internal Server Error"
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)

	linea = {}

	if resp[0] == "ok":
		linea["result"] = "ok"
		linea["grupo_nombre"] = resp[1]
	# linea['param_extra'] = resp[2]
	elif resp[0] == "errore":
		linea = {}
		linea["result"] = "failed"
		linea["error"] = "Sucedio un error"
		linea["error_cod"] = 50
		try :
			mensaje = s.mensaje_error(datosC['idioma'],50)
			linea["val_errors"] = str(mensaje[1][0][0])
		except:
			linea["val_errors"] = 'error de python' 
	elif resp[0] == "errort":
		if s.valToken(tk) :
			cod_error = 100
		else :
			cod_error = 101
		mensaje = s.mensaje_error(datosC['idioma'],cod_error)
		linea = {}
		linea["result"] = "failed"
		linea["error"] = "Sucedio un error"
		linea["error_cod"] = cod_error
		linea["val_errors"] = str(mensaje[1][0][0])
		status = "401 Unauthorized" 					
	else:
		linea["result"] = "failed"
		linea["error"] = "Sucedio un error"
		linea["error_cod"] = 415
		# linea['jsdato'] = jsdato
		# linea['lendata'] = lendata
		# linea['bydata'] = bydata

		if bool(extra):
			linea["val_error"] = extra
		else:
			linea["val_errors"] = resp[1]

	preoutput = json.dumps(linea)
	output = bytes(preoutput, "utf-8")
	cook = '"dato"="' + str(jsdato) + '" ;path=/'
	# se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
	headers = [
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]