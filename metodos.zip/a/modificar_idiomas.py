import sys, os
import datetime,logging
sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_IDIOMAS import MAE_IDIOMAS
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations
rutalog="/home/sistema/log/Traxium"

def application(environ, start_response):

	try:
		coo = ""
		jsdato = ""
		extra = {}
		status = "200 OK"

		s = Session()
		
		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]

		cookie = environ.get("HTTP_COOKIE", 0)
		tk = s.getCookie(cookie, "token")
		s.setToken(tk)
		datosB = s.getCookie(cookie, "dato")
		len_datosB = len(datosB)
		datosC = json.loads(datosB[1:(len_datosB-1)])
		if environ["REQUEST_METHOD"] != "PUT" and environ['REQUEST_METHOD'] != 'POST':
			# status = "405 Method Not Allowed"
			raise validations.HttpException(405)
		if s.valToken(tk) and s.valIp(tk, str(dataIP)):
			jsdato = s.get_Datos_Usu(str(tk))
			lendata = int(environ.get("CONTENT_LENGTH", 0))
			bydata = environ["wsgi.input"].read(lendata)
			jsdata = json.loads(bydata.decode("utf-8"))

			try:
				respu1 = validations.validate_int(jsdata["idi_id"])
				respu2 = validations.validate_varchar(jsdata["idi_desc"], 100)
				respu3 = validations.validate_varchar(jsdata["idi_key"], 5)
				respu4 = validations.validate_char(jsdata["idi_estado"])

				if respu1[0] == True:
					respu5 = validations.id_Mae_Idiomas(int(jsdata["idi_id"]))
				else:
					respu5 = [False, "No se tiene un idioma correcto"]

				list_respu = [respu1, respu2, respu3, respu4, respu5]
				nombres = ["idi_id", "idi_desc", "idi_key", "idi_estado", "idi_id"]

				if respu1[0] and respu2[0] and respu3[0] and respu4[0] and respu5[0]:

					val1 = validations.validate_empty(jsdata["idi_desc"])
					val2 = validations.validate_empty(jsdata["idi_key"])
					val3 = validations.validate_empty(jsdata["idi_estado"])

					if val1[0]:
						desc = None
					else:
						desc = jsdata["idi_desc"]

					if val2[0]:
						key = None
					else:
						key = jsdata["idi_key"]

					if val3[0]:
						estado = None
					else:
						estado = jsdata["idi_estado"]

					obj = MAE_IDIOMAS(
						idi_desc=desc,
						idi_key=key,
						idi_estado=estado,
						idi_id=int(jsdata["idi_id"]),
					)
					resp = obj.modificar()

				else:
					resp = ["error1", ""]
					num = 0

					for respu in list_respu:
						if respu[0] == False:
							if len(respu) == 3 :
								mensaje1 = s.mensaje_error(datosC['idioma'],respu[2])
								extra[nombres[num]] = str(mensaje1[1][0][0]) + respu[1]
							else :
								mensaje1 = s.mensaje_error(datosC['idioma'],104)
								extra[nombres[num]] = str(mensaje1[1][0][0]) + respu[1]
							
						num = num + 1

			except Exception as e:
				resp = ["error1", str(e)]
			linea = {}

			if resp[0] == "ok":
				linea["result"] = "ok"
				status = "200 OK"
				linea["data"] = obj.get_diccionario()
				#Como la respuesta es correcta se guarda en el log de acciones
				usu_id = s.get_id_Usu(str(tk))
				filename = os.path.basename(__file__).split('.')[0]
				obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se modifico el idioma con el siguiente PK idi_id: '+str(jsdata["idi_id"]),log_acc_id = 500)
				resp_log = obj_log.guardar_dato()
				if resp_log[0] == 'error':
					mensaje = s.mensaje_error(datosC['idioma'],103)
					linea['result'] = "failed"
					linea['error'] = "Sucedio un error"
					linea['error_cod'] = 103
					status = "400 Bad Request"
					linea['val_errors'] = str(mensaje[1][0][0])

			elif resp[0] == "error1":
				linea["result"] = "failed"
				linea["error"] = "Sucedio un error"
				linea["error_cod"] = 104
				status = "400 Bad Request"
				if bool(extra):
					linea["val_errors"] = extra
				else:
					linea["val_errors"] = resp[1]
			else :
				mensaje = s.mensaje_error(datosC['idioma'],60)
				linea["result"] = "failed"
				linea["error"] = resp[1]
				linea["error_cod"] = 60
				status = "400 Bad Request"
				linea["val_errors"] = str(mensaje[1][0][0])
		else:
			if s.valToken(tk) :
				cod_error = 100
			else :
				cod_error = 101
			mensaje = s.mensaje_error(datosC['idioma'],cod_error)
			linea = {}
			linea["result"] = "failed"
			linea["error"] = "Sucedio un error"
			linea["error_cod"] = cod_error
			linea["val_errors"] = str(mensaje[1][0][0])
			status = "401 Unauthorized"	

	except validations.HttpException as e:
		linea = {}
		mensaje = s.mensaje_error(datosC['idioma'],51)
		linea["result"] = "failed"
		linea["error_cod"] = "Sucedio un error"
		linea["error"] = 51
		linea["val_errors"] = str(mensaje[1][0][0])
		status = e.status_code

	except Exception as e:
		linea = {}
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		linea["result"] = "failed"
		linea["error"] = "Sucedio un error"
		linea["error_cod"] = 50
		try :
			mensaje = s.mensaje_error(datosC['idioma'],50)
			linea["val_errors"] = str(mensaje[1][0][0])
		except:
			linea["val_errors"] = 'error de python' 
		status = "500 Internal Server Error" 
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)

	preoutput = json.dumps(linea)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]
