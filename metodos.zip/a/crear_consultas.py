import sys, os
import datetime, logging
sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_CONSULTAS import MAE_CONSULTAS
from LOG_ACCIONES_USUARIO import LOG_ACCIONES_USUARIO
import validations
from clsSession import Session

rutalog="/home/sistema/log/Traxium"
def application(environ, start_response):
	try:
		coo = ""
		jsdato = ""
		status = "500 Internal Server Error"
		
		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]

		
		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)
		tk = s.getCookie(cookie, "token")
		s.setToken(tk)
		datosB = s.getCookie(cookie, "dato")
		len_datosB = len(datosB)
		datosC = json.loads(datosB[1:(len_datosB-1)])
		if environ['REQUEST_METHOD'] != 'POST':
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)
		if s.valToken(tk) and s.valIp(tk, str(dataIP)):

			jsdato = s.get_Datos_Usu(str(tk))
			lendata = int(environ.get("CONTENT_LENGTH", 0))
			bydata = environ["wsgi.input"].read(lendata)
			jsdata = json.loads(bydata.decode("utf-8"))
			try:
				diccio_respu = {}
				pass_flag = True
				extra = {}

				diccio_respu['con_desc'] = validations.validate_varchar(jsdata["con_desc"], 100)
				diccio_respu['con_estado'] = validations.validate_char(jsdata["con_estado"])
				diccio_respu['prot_id'] = validations.validate_int(jsdata["prot_id"])
				diccio_respu['con_trama_pregunta'] = validations.validate_varchar(jsdata["con_trama_pregunta"], 500)
				diccio_respu['marca_id'] = validations.validate_int(jsdata["marca_id"])
				diccio_respu['mod_id'] = validations.validate_int(jsdata["mod_id"])
				diccio_respu['con_respuesta'] = validations.validate_varchar(jsdata["con_respuesta"], 500)
				diccio_respu['tobj_id'] = validations.validate_int(jsdata["tobj_id"])
				diccio_respu['cron_id'] = validations.validate_int(jsdata["cron_id"])

				if diccio_respu['prot_id'][0] is True:
					diccio_respu['prot_id'] = validations.id_Tab_Prot(int(jsdata["prot_id"]))
				if diccio_respu['marca_id'][0] is True:
					diccio_respu['marca_id'] = validations.id_Mae_Marcas(int(jsdata["marca_id"]))
				if diccio_respu['mod_id'][0] is True:
					diccio_respu['mod_id'] = validations.id_Mae_Modelo(int(jsdata["mod_id"]))
				if diccio_respu['tobj_id'][0] is True:
					diccio_respu['tobj_id'] = validations.id_Tipo_Obj(int(jsdata["tobj_id"]))
				if diccio_respu['cron_id'][0] is True:
					diccio_respu['cron_id'] = validations.id_Mae_Cron(int(jsdata["cron_id"]))
				
				for key, value in jsdata.items():
					value_empty = validations.validate_empty(value)
					if value_empty[0] is True:
						diccio_respu[key] = value_empty
						diccio_respu[key][0] = False
				
				for _,value in diccio_respu.items():
					if value[0] is False:
						pass_flag = False
						break
				if pass_flag is True:
					obj = MAE_CONSULTAS.from_json(jsdata)
					resp = obj.guardar_dato()
					obj.buscar_dato()
				else:
					resp = ["error1", ""]
					#num = 0
					status = "400 Bad Request"
					for key,respu in diccio_respu.items():
						if respu[0] == False:
							if len(respu) == 3 :
								mensaje1 = s.mensaje_error(datosC['idioma'],respu[2])
								extra[key] = str(mensaje1[1][0][0]) + respu[1]
							else :
								mensaje1 = s.mensaje_error(datosC['idioma'],104)
								extra[key] = str(mensaje1[1][0][0]) + respu[1]
						#num = num + 1

			except Exception as e:
				resp = ["error1", str(e)]
				status = "400 Bad Request"
			linea = {}

			if resp[0] == "ok":
				linea["result"] = "ok"
				linea["data"] = obj.get_diccionario()
				#linea["con_id"] = obj.con_id
				status = "200 OK"
				#Como la respuesta es correcta se guarda en el log de acciones
				usu_id = s.get_id_Usu(str(tk))
				#filename = os.path.basename(__file__).split('.')[0]
				obj_log = LOG_ACCIONES_USUARIO(log_usu_id=usu_id,log_desc ='Se creo la consulta con el siguiente PK con_id: '+str(obj.con_id),log_acc_id = 426)
				resp_log = obj_log.guardar_dato()
				if resp_log[0] == 'error':
					mensaje = s.mensaje_error(datosC['idioma'],103)
					linea['result'] = "failed"
					linea['error'] = "Sucedio un error"
					linea['error_cod'] = 103
					status = "400 Bad Request"
					linea['val_errors'] = str(mensaje[1][0][0])
			elif resp[0] == "error1":
				linea["result"] = "failed"
				linea["error"] = "Sucedio un error"
				linea["error_cod"] = 104
				status = "400 Bad Request"
				if bool(extra):
					linea["val_errors"] = extra
				else:
					linea["val_errors"] = resp[1]
			else :
				mensaje = s.mensaje_error(datosC['idioma'],60)
				linea["result"] = "failed"
				linea["error"] = resp[1]
				linea["error_cod"] = 60
				status = "400 Bad Request"
				linea["val_errors"] = str(mensaje[1][0][0])
		else:
			if s.valToken(tk) :
				cod_error = 100
			else :
				cod_error = 101
			mensaje = s.mensaje_error(datosC['idioma'],cod_error)
			linea = {}
			linea["result"] = "failed"
			linea["error"] = "Sucedio un error"
			linea["error_cod"] = cod_error
			linea["val_errors"] = str(mensaje[1][0][0])
			status = "401 Unauthorized"	

	except validations.HttpException as e:
		linea = {}
		mensaje = s.mensaje_error(datosC['idioma'],51)
		linea["result"] = "failed"
		linea["error_cod"] = "Sucedio un error"
		linea["error"] = 51
		linea["val_errors"] = str(mensaje[1][0][0])
		status = e.status_code

	except Exception as e:
		linea = {}
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		linea["result"] = "failed"
		linea["error"] = "Sucedio un error"
		linea["error_cod"] = 50
		try :
			mensaje = s.mensaje_error(datosC['idioma'],50)
			linea["val_errors"] = str(mensaje[1][0][0])
		except:
			linea["val_errors"] = 'error de python' 
		status = "500 Internal Server Error"
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)

	preoutput = json.dumps(linea)
	output = bytes(preoutput, "utf-8")
	cook = 'dato="' + str(jsdato) + '" ;path=/'
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]
