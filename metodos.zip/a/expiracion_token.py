import sys, os
import logging,datetime
rutalog="/home/sistema/log/Traxium"
sys.path.insert(0, "/home/sistema/clases")

import json
from MAE_USUARIOS import MAE_USUARIOS
from clsSession import Session


def application(environ, start_response):
    try:
        status = "200 OK"  # se crea la respuesta de estado
        s = Session()
        cookie = environ.get("HTTP_COOKIE", 0)  # se obtiene la informacion del cookie
        #cookie = environ.get("HTTP_COOKIE")  # se obtiene la informacion del cookie
        tk = s.getCookie(cookie, "token")    # se escoge la informacion guardada en la variable token
        datosB = s.getCookie(cookie, "dato")
        len_datosB = len(datosB)
        datosC = json.loads(datosB[1:(len_datosB-1)])
        if s.valToken(tk):  # se valida si el token esta validado
            data = {}
            data["result"] = "ok"
            data["desciption"] = "token se mantiene activado"
        else:
            mensaje = s.mensaje_error(datosC['idioma'],100)#idi , error
            data = {}
            data["result"] = "failed"
            data["error"] = "Sucedio un error"
            data["error_cod"] = 100
            data["val_errors"] = str(mensaje[1][0][0])
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        data = {}
        data["result"] = "failed"
        data["error"] = "Sucedio un error"  # -cookie: "+str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)#+str(cookie)
        data["error_cod"] = 50
        try :
            mensaje = s.mensaje_error(datosC['idioma'],50)
            data["val_errors"] = str(mensaje[1][0][0])
        except:
            data["val_errors"] = 'error de python'
        datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
        now = datetime.datetime.now()
        fecha= datetime.date.today()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")
        logger = logging.getLogger('__name__')
        logger.setLevel(logging.ERROR)
        nombre_log= rutalog+'_'+str(fecha)+'.log'
        fh = logging.FileHandler(nombre_log)
        fh.setLevel(logging.ERROR)
        logger.addHandler(fh)
        logger.error("Error: "+str(current_time) + datoError)

    preoutput = json.dumps(data)
    output = bytes(preoutput, "utf-8")
    # se coloca la configuracion de las cabeceras y los datos a devolver en los cookies
    headers = [
        ("Access-Control-Allow-Origin", "http://localhost:4200"),
        ("Access-Control-Allow-Credentials", "true"),
    ]

    start_response(status, headers)
    return [output]
