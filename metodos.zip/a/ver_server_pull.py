import sys, os
import datetime, logging
sys.path.insert(0, "/home/sistema/clases")

from clsSession import Session
import json
from MAE_SERVERS_PULL import MAE_SERVERS_PULL
import validations
rutalog="/home/sistema/log/Traxium"

def application(environ, start_response):

	coo = ""
	jsdato = ""
	data = {}
	try:
		coo = ""
		jsdato = ""
		status = "200 OK"

		try:
			dataIP = environ["HTTP_X_FORWARDED_FOR"].split(",")[-1].strip()
		except KeyError:
			dataIP = environ["REMOTE_ADDR"]

		s = Session()
		cookie = environ.get("HTTP_COOKIE", 0)
		tk = s.getCookie(cookie, "token")
		datosB = s.getCookie(cookie, "dato")
		len_datosB = len(datosB)
		datosC = json.loads(datosB[1:(len_datosB-1)]) 		
		s.setToken(tk)
		if environ['REQUEST_METHOD'] != 'GET':
			#status = "405 Method Not Allowed"
			raise validations.HttpException(405)
		if s.valToken(tk) and s.valIp(tk, str(dataIP)):
			jsdato = s.get_Datos_Usu(str(tk))

			bdata = environ["PATH_INFO"]

			respuest = validations.validate_int(bdata.split("/")[1])
			if respuest[0] == True:
				obj = MAE_SERVERS_PULL(serv_id=int(bdata.split("/")[1]))
				dato = obj.buscar_dato()
				if dato[0] == "ok":
					data = {}
					data.update(obj.get_diccionario())
					
				else:
					mensaje = s.mensaje_error(datosC['idioma'],60)
					data = {}
					data["result"] = "failed"
					data["error"] = dato[1]
					data["error_cod"] = 60
					status = "400 Bad Request"
					data["val_errors"] = str(mensaje[1][0][0])
			else:
				mensaje = s.mensaje_error(datosC['idioma'],102)
				data = {}
				data["result"] = "failed"
				data["error"] = "Sucedio un error"
				data["error_cod"] = 102
				status = "400 Bad Request"
				data["val_errors"] = str(mensaje[1][0][0])
		else:
			if s.valToken(tk) :
				cod_error = 100
			else :
				cod_error = 101
			mensaje = s.mensaje_error(datosC['idioma'],cod_error)			
			data = {}
			data["result"] = "failed"
			data["error"] = "Sucedio un error"
			data["error_cod"] = cod_error
			data["val_errors"] = str(mensaje[1][0][0])
			status = "401 Unauthorized"
			coo = ""

	except validations.HttpException as e:
		data = {}
		mensaje = s.mensaje_error(datosC['idioma'],51)
		data["result"] = "failed"
		data["error_cod"] = "Sucedio un error"
		data["error"] = 51
		data["val_errors"] = str(mensaje[1][0][0])
		status = e.status_code

	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
		data = {}
		data["result"] = "failed"
		data["error"] = "Sucedio un error"
		data["error_cod"] = 50
		try :
			mensaje = s.mensaje_error(datosC['idioma'],50)
			data["val_errors"] = str(mensaje[1][0][0])
		except:
			data["val_errors"] = 'error de python' 
		status = "500 Internal Server Error"
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)

	
	preoutput = json.dumps(data)
	output = bytes(preoutput, "utf-8")

	cook = 'dato="' + str(jsdato) + '" ;path=/'
	headers = [
		('Content-Type', 'application/json'),
		("Access-Control-Allow-Origin", "http://localhost:4200"),
		("Access-Control-Allow-Credentials", "true"),
		("set-cookie", cook),
	]
	start_response(status, headers)
	return [output]
