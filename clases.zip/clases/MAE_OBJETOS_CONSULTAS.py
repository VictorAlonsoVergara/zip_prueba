import psycopg2
import sys
from MAE_OBJETOS import MAE_OBJETOS
from MAE_CONSULTAS import MAE_CONSULTAS
import logging
import datetime
import os
from MyDB import MyDB


class MAE_OBJETOS_CONSULTAS:
    def __init__(
        self, objc_estado, objc_protocolo, objc_trama, obj_id=None, con_id=None
    ):

        self.obj_id = obj_id  # integer
        self.con_id = con_id  # integer
        self.objc_estado = objc_estado  # char(1)
        self.objc_protocolo = objc_protocolo  # char(1)
        self.objc_trama = objc_trama  # varchar(500)

        self.mae_consultas = MAE_CONSULTAS("", "", "", "", con_id)
        self.mae_consultas.buscar_dato()
        self.mae_objetos = MAE_OBJETOS("", "", "", "", obj_id)
        self.mae_objetos.buscar_dato()

        # si bSelect es False delete,update,insert si es True select
        self.clase_MyDB = MyDB()

    def guardar_dato(self):
        try:
            query = 'INSERT INTO "MAE_OBJETOS_CONSULTAS" (obj_id,con_id,objc_estado,objc_protocolo,objc_trama) VALUES (%s,%s,%s,%s,%s)'
            datos = (
                self.obj_id,
                self.con_id,
                self.objc_estado,
                self.objc_protocolo,
                self.objc_trama,
            )
            version = self.clase_MyDB.conectar(query, datos, False)

            if version[0] == "ok":
                dato = ["ok", " "]
            else:
                dato = ["error", "Error en la base de datos"]

        except psycopg2.DatabaseError as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            dato = ["error", str(e)]
            print(f"Error {e}")
            print(exc_type, fname, exc_tb.tb_lineno)

        except Exception as e:
            dato = ["error", str(e)]
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, fname, exc_tb.tb_lineno)

        finally:
            return dato

    def buscar_dato(self):
        try:
            query = (
                'SELECT * FROM "MAE_OBJETOS_CONSULTAS" WHERE obj_id = %s AND con_id= %s'
            )
            datos = (self.obj_id, self.con_id)
            version = self.clase_MyDB.conectar(query, datos, True)

            if version[0] == "ok":
                if version[1] != False:
                    self.objc_estado = version[1][0][2]  # char(1)
                    self.objc_protocolo = version[1][0][3]  # char(1)
                    self.objc_trama = version[1][0][4]  # varchar(500)
                    dato = ["ok", " "]
                else:
                    dato = ["error", "No se encontro el objeto consulta con ese ID"]
            else:
                dato = ["error", "Error con la base de datos"]
        except psycopg2.DatabaseError as e:
            dato = ["error", str(e)]
            print(f"Error {e}")
        except Exception as e:
            dato = ["error", str(e)]
        finally:
            return dato

    @staticmethod
    def validations_crear(obj_id, con_id):
        try:
            query = 'SELECT * FROM "MAE_OBJETOS_CONSULTAS" WHERE obj_id = %s AND con_id = %s'
            datos = (obj_id, con_id)
            clase_MyDB = MyDB()
            version = clase_MyDB.conectar(query, datos, True)

            if version[1] != False:
                dato = [False, "ya existe MAE_OBJETOS_CONSULTAS con esos ID"]
            else:
                dato = [True, "ok"]
        except psycopg2.DatabaseError as e:
            dato = ["error", str(e)]
            print(f"Error {e}")
        except Exception as e:
            dato = ["error", str(e)]
        finally:
            return dato

    @staticmethod
    def consultar_lista():
        try:
            query = 'SELECT * FROM "MAE_OBJETOS_CONSULTAS"'
            datos = ()
            clase_MyDB = MyDB()
            version = clase_MyDB.conectar(query, datos, True)

            if (version[0] == 'ok'):
                lista = []
                for usu in version[1]:
                    data = {}
                    data["obj_id"] = usu[0]
                    obj1 = MAE_OBJETOS(" ", "", " ", " ", int(usu[0]))
                    obj1.buscar_dato()                    
                    data["obj_desc"] = obj1.obj_desc
                    data["tobj_id"] = obj1.tobj_id
                    data["obj_estado"] = obj1.obj_estado
                    data["obj_ldesc"] = obj1.obj_ldesc
                    data["tobj_desc"] = obj1.mat_tipo_obj.tobj_desc
                    data["tobj_estado"] = obj1.mat_tipo_obj.tobj_estado
                    data["tobj_consulta"] = obj1.mat_tipo_obj.tobj_consulta
                    data["tobj_ldesc"] = obj1.mat_tipo_obj.tobj_ldesc                    
                    
                    data["con_id"] = usu[1]
                    obj2 = MAE_CONSULTAS("", "", "", "", int(usu[1]))
                    obj2.buscar_dato()                    
                    data["con_desc"] = obj2.con_desc
                    data["con_estado"] = obj2.con_estado
                    data["con_protocolo"] = obj2.con_protocolo
                    data["con_trama_pregunta"] = obj2.con_trama_pregunta

                    data["objc_estado"] = usu[2]
                    data["objc_protocolo"] = usu[3]
                    data["objc_trama"] = usu[4]

                    lista.append(data)
            else:
                lista = {}
                lista["Error"] = "Error en la base de datos"
        except psycopg2.DatabaseError as e:
            lista = {}
            lista["Error"] = "1"
            print(f"Error {e}")
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]            
            lista = {}
            lista["Error"] =  str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
            print(e)
        finally:
            return lista

    def modificar_info(self):
        try:
            query = 'SELECT * FROM "MAE_OBJETOS_CONSULTAS" WHERE obj_id = %s AND con_id = %s '
            datos = (self.obj_id, self.con_id)
            version = self.clase_MyDB.conectar(query, datos, True)
            if version[0] == "ok":
                if version[1] != False:
                    objc_estado = version[1][0][2]  # char(1)
                    objc_protocolo = version[1][0][3]  # char(1)
                    objc_trama = version[1][0][4]  # varchar(500)
                    dato = ["ok", ""]
                else:
                    dato = ["error", "No se encontro el objeto_consulta con esos ID"]
            else:
                dato = ["error", "Error en la base de datos"]

            if dato[0] == "ok":
                if self.objc_estado == "":
                    self.objc_estado = objc_estado
                if self.objc_protocolo == "":
                    self.objc_protocolo = objc_protocolo
                if self.objc_trama == "":
                    self.objc_trama = objc_trama
                query = 'UPDATE "MAE_OBJETOS_CONSULTAS" SET objc_estado = %s , objc_protocolo= %s , objc_trama= %s WHERE obj_id = %s and con_id = %s'
                datos = (
                    self.objc_estado,
                    self.objc_protocolo,
                    self.objc_trama,
                    self.obj_id,
                    self.con_id,
                )
                respu = self.clase_MyDB.conectar(query, datos, False)
                lista = ["ok", " "]
            else:
                lista = ["error", "Error en la base de datos"]

        except Exception as e:
            lista = ["error", str(e)]
        finally:
            return lista

    def borrar(self):
        try:
            query = (
                'DELETE FROM "MAE_OBJETOS_CONSULTAS" WHERE obj_id = %s and con_id = %s'
            )
            datos = (self.obj_id, self.con_id)
            respu = self.clase_MyDB.conectar(query, datos, False)
            if respu[0] == "ok":
                lista = {}
                lista["result"] = "ok"  # +str(respu)
            else:
                lista = {}
                lista["result"] = "failed"
                lista["error"] = "Sucedio un error"
                lista["error_cod"] = 505
                lista["val_errors"] = "Error en la base de datos"
        except psycopg2.DatabaseError as e:
            lista = {}
            lista["result"] = "failed"
            lista["error"] = "Sucedio un error"
            lista["error_cod"] = 505
            lista["val_errors"] = str(e)
        except Exception as e:
            lista = {}
            lista["result"] = "failed"
            lista["error"] = "Sucedio un error"
            lista["error_cod"] = 505
            lista["val_errors"] = str(e)
        else:
            lista = {}
            lista["result"] = "ok"
        finally:
            return lista
