import psycopg2
import sys
import logging
import datetime
import os
from MyDB import MyDB
#Clase que gestiona la tabla areas de los usuarios
class MAE_AREA:
	#Inicializa la clase Area
	def __init__(self, area_desc=None, area_ldesc=None,area_estado = None,area_id=None):
		self.area_id = area_id  # serial
		self.area_desc = area_desc  # varchar(20)
		self.area_ldesc = area_ldesc  # varchar(20)
		self.area_estado = area_estado
		self.clase_MyDB = MyDB()

	#devuelve datos importantes de la clase area
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		diccionario.pop('clase_MyDB')
		return diccionario

	#guarda datos en la tabla de area
	def guardar_dato(self):
		try:
			datos = (
				self.area_desc,
				self.area_ldesc,
				self.area_estado
			)
			query = 'INSERT INTO "MAE_AREA" (area_desc,area_ldesc,area_estado) VALUES (%s,%s,%s) RETURNING area_id'
			version = self.clase_MyDB.conectar(query, datos, False)
			if version[0] == "ok":
				self.area_id = version[1][0][0]  
				dato = ["ok", " "]
			else:
				dato = ["error", "Error en la base de datos"]
		except Exception as e:
			dato = ["error", str(e)]
		finally:
			return dato

	#busca un dato activado segun su id
	def buscar_dato(self):
		try:
			datos = (self.area_id,)
			query = """SELECT * FROM "MAE_AREA" WHERE area_id = %s AND area_estado='A'"""
			version = self.clase_MyDB.conectar(query, datos, True)
			if version[0] == "ok":
				if version[1] != False:
					self.area_desc = version[1][0][1]  # varchar(200)
					self.area_ldesc = version[1][0][2]  # varchar(200)
					self.area_estado = version[1][0][3]  # char(1)
					dato = ["ok", " "]
				else:
					dato = ["error", "No se encontro el area con ese ID"]
			else:
				dato = ["error", "Error con la base de datos"]
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			dato = [
				"error",
				str(e)
				+ " - "
				+ str(exc_type)
				+ " - "
				+ str(fname)
				+ " - "
				+ str(exc_tb.tb_lineno),
			]
		finally:            
			return dato

	#consulta la lista completa de las areas registradas en la base de datos
	@staticmethod
	def consultar_lista():
		try:
			query = """SELECT * FROM "MAE_AREA" WHERE area_estado='A' ORDER BY area_id"""
			datos = ()
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query, datos, True)
			if version[0] == "ok":
				if version[1]!=False:
					lista = []
					for area in version[1]:
						data = {}
						obj_area = MAE_AREA.from_list(area)
						data.update(obj_area.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista["result"] = "failed"
					lista["error"] = "Sucedio un error "
					lista["error_cod"] = 412
					lista["val_errors"] = "Lista vacia"
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error "
				lista["error_cod"] = 412
				lista["val_errors"] = version[1]
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error "
			lista["error_cod"] = 412
			lista["val_errors"] = str(e)
		finally:
			return lista

	#modifica el area seleccionada 
	def modificar(self):
		try:
			query = 'UPDATE "MAE_AREA" SET area_desc = COALESCE(%s,area_desc), area_ldesc= COALESCE(%s,area_ldesc),area_estado = COALESCE(%s,area_estado) WHERE area_id = %s'
			datos = (
				self.area_desc,
				self.area_ldesc,
				self.area_estado,
				self.area_id,
			)
			respu = self.clase_MyDB.conectar(query, datos, False)
			if respu[0] == "ok":
				lista = ["ok", " "]
			else:
				lista = ["error", respu[1]]
		except Exception as e:
			lista = ["error", str(e)]
		finally:
			return lista

	#borra el area seleccionada
	def borrar(self):
		try:
			query = 'DELETE FROM "MAE_AREA" WHERE area_id= %s'
			datos = (self.area_id,)
			respu = self.clase_MyDB.conectar(query, datos, False)
			if respu[0] == "ok":
				lista = {}
				lista["result"] = "ok"  # +str(respu)
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 505
				lista["val_errors"] = str(respu[1])
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 505
			lista["val_errors"] = str(e)
		finally:
			return lista

	#inicializa la clase de area con un array
	@staticmethod
	def from_list(lista):
		area = MAE_AREA(
			area_id = lista[0],
			area_desc = lista[1],
			area_ldesc = lista[2],
			area_estado = lista[3]
		)
		return area

	#incializa la clase con un json
	@staticmethod
	def from_json(json):
		area = MAE_AREA()
		diccio = vars(area)
		for key,value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			diccio[key] = value
		return area