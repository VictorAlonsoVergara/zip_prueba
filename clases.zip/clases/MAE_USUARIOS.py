import psycopg2
import sys, os
import generico
from MAE_TIPO_USU import MAE_TIPO_USU
from MAE_IDIOMAS import MAE_IDIOMAS
from MAE_AREA import MAE_AREA
import logging
import datetime
from hashlib import blake2b
from MyDB import MyDB
#clase que gstiona a los usuarios
class MAE_USUARIOS:
	def __init__(
		self,
		usu_nombre = None,
		tusu_id = None,
		usu_estado = None,
		usu_correo = None,
		usu_usuario = None,
		usu_password = None,
		idi_id = None,
		area_id = None,
		usu_usuario_creador = None,
		usu_fecha_creacion = None,
		usu_usuario_modificacion = None,
		usu_fecha_modificacion = None,
		usu_id=None
	):
		self.usu_id = usu_id  # serial
		self.usu_nombre = usu_nombre  # varchar(300)
		self.tusu_id = tusu_id  # integer
		self.usu_estado = usu_estado  # char(1)
		self.usu_correo = usu_correo  # varchar(100)
		self.usu_usuario = usu_usuario  # varchar(50)
		self.usu_password = usu_password  # varchar(2048)
		self.idi_id = idi_id 
		self.area_id = area_id
		self.mae_tipo_usu = MAE_TIPO_USU(tusu_id= tusu_id)  # clase tipo usuario
		self.mae_idioma = MAE_IDIOMAS(idi_id=idi_id)
		self.mae_area = MAE_AREA(area_id=area_id)
		self.mae_tipo_usu.buscar_dato()
		self.mae_idioma.buscar_dato()
		self.mae_area.buscar_dato()
		self.usu_usuario_creador = usu_usuario_creador
		self.usu_fecha_creacion = usu_fecha_creacion
		self.usu_usuario_modificacion = usu_usuario_modificacion
		self.usu_fecha_modificacion = usu_fecha_modificacion
		self.clase_MyDB = MyDB()

	#devuelve datos importantes de la clase
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		if self.usu_fecha_creacion is not None:
			diccionario['usu_fecha_creacion'] = self.usu_fecha_creacion.strftime("%Y-%m-%d %H:%M:%S")#convierto a string para que pueda convertirlo a JSON
		if self.usu_fecha_modificacion is not None:
			diccionario['usu_fecha_modificacion'] = self.usu_fecha_modificacion.strftime("%Y-%m-%d %H:%M:%S")#convierto a string para que pueda convertirlo a JSON
		diccionario['tipo_usuario'] = {}
		diccionario['tipo_usuario'].update(self.mae_tipo_usu.get_diccionario())
		diccionario['idioma'] = {}
		diccionario['idioma'].update(self.mae_idioma.get_diccionario())
		diccionario['area'] = {}
		diccionario['area'].update(self.mae_area.get_diccionario())
		diccionario.pop('usu_password')
		diccionario.pop('mae_tipo_usu')
		diccionario.pop('clase_MyDB')
		diccionario.pop('mae_idioma')
		diccionario.pop('mae_area')
		return diccionario

	def guardar_dato(self):  # guarda los datos de la clase en al base de datos
		try:
			query = ('INSERT INTO "MAE_USUARIOS" ('
						'usu_nombre,tusu_id,usu_estado,'
						'usu_correo,usu_usuario,'
						'usu_password,idi_id,area_id,'
						'usu_usuario_creador,'
						'usu_usuario_modificacion,'
						'usu_fecha_modificacion) '
						'VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING usu_id')
			datos = (self.usu_nombre,self.tusu_id,self.usu_estado,
					self.usu_correo,self.usu_usuario,
					str(self.__tokenizer(self.usu_password)),
					self.idi_id,self.area_id,
					self.usu_usuario_creador,
					None,
					None)
			version = self.clase_MyDB.conectar(query,datos,False)

			if version[0] == 'ok':
				self.usu_id = version[1][0][0]#version[len(version)-1][0]
				dato = ['ok',' ']
			else:
				dato = ['error',str (version[1])]
				#dato = ['error',version]
		except psycopg2.DatabaseError as e:
			dato = ["error", str(e)]
		except Exception as e:
			dato = ["error", str(e)]
		finally:
			return dato

	def buscar_dato(self):  # busca los datos de la clase , con el ID
		try:
			query = 'SELECT * FROM "MAE_USUARIOS" WHERE usu_id = %s'
			datos = (self.usu_id,)
			version = self.clase_MyDB.conectar(query,datos,True)

			if (version[0] == 'ok'):
				if (version[1] != False):
					self.usu_nombre = version[1][0][1]  # varchar(300)
					self.tusu_id = version[1][0][2]  # integer
					self.usu_estado = version[1][0][3]  # char(1)
					self.usu_correo = version[1][0][4]  # varchar(100)
					self.usu_usuario = version[1][0][5]  # varchar(50)
					self.mae_tipo_usu = MAE_TIPO_USU(tusu_id = self.tusu_id)
					self.mae_tipo_usu.buscar_dato()
					self.usu_password = ""  # version[1][0][6] #varchar(2048)
					self.idi_id = version[1][0][7]
					self.area_id = version[1][0][8]
					self.usu_usuario_creador = version[1][0][9]
					self.usu_fecha_creacion = version[1][0][10]
					self.usu_usuario_modificacion = version[1][0][11]
					self.usu_fecha_modificacion = version[1][0][12]
					self.mae_area = MAE_AREA(area_id=self.area_id)
					self.mae_area.buscar_dato()
					self.mae_idioma = MAE_IDIOMAS(idi_id=self.idi_id)
					self.mae_idioma.buscar_dato()
					dato = ["ok", ""]
				else:
					dato = ["error", "No se encontro el usuario con ese ID"]
			else:
				dato = ['error', str(version[1])]
		except psycopg2.DatabaseError as e:
			dato = ["error", str(e)]
		except Exception as e:
			dato = ["error", str(e)]
		finally:
			return dato

	@staticmethod
	def consultar_lista():  # regresa la lista con los datos en la base de datos
		try:
			query = 'SELECT * FROM "MAE_USUARIOS"WHERE usu_estado != \'E\' ORDER BY usu_id'
			datos = ( )
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)
			# se selecciona todos los datos de la tabla mae usuarios
			if (version[0]=='ok'):
				if (version[1]!=False):
					lista = []
					for usu in version[1]:
						data = {}
						obj_usuario = MAE_USUARIOS.from_lista(usu)
						obj_usuario.buscar_dato()
						data.update(obj_usuario.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista["result"] = "failed"
					lista["error"] = "Sucedio un error "
					lista["error_cod"] = 412
					lista["val_errors"] = "Lista vacia"

			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error en la base de datos"
				lista["error_cod"] = 412
				lista["val_errors"] = str (version[1])
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error "
			lista["error_cod"] = 412
			lista["val_errors"] = str (e)
		finally:
		   return lista

	def modificar(self):  # modifica el valor de los datos en la base de datos
		try:
			if self.usu_password is not None:
				hToken = blake2b(digest_size=32)  # se crea token para difuminar el otro dato
				hToken.update(self.usu_password.encode())# se difumina el dato
				temp = hToken.hexdigest()# se obtiene el dato despues de difuminar
				self.usu_password = temp
			query = ('UPDATE "MAE_USUARIOS" SET usu_nombre = COALESCE(%s,usu_nombre),'
						'tusu_id = COALESCE(%s,tusu_id),usu_estado = COALESCE(%s,usu_estado),'
						'usu_correo = COALESCE(%s,usu_correo),usu_usuario = COALESCE(%s,usu_usuario),'
						'usu_password = COALESCE(%s,usu_password),idi_id = COALESCE(%s,idi_id),'
						'area_id = COALESCE(%s,area_id),'
						'usu_usuario_modificacion = COALESCE(%s,usu_usuario_modificacion),'
						'usu_fecha_modificacion = COALESCE(%s,usu_fecha_modificacion) '
						'WHERE usu_id = %s')
			datos = (self.usu_nombre,self.tusu_id,
						self.usu_estado,self.usu_correo,
						self.usu_usuario,self.usu_password,
						self.idi_id,self.area_id,
						self.usu_usuario_modificacion,
						datetime.datetime.now(),self.usu_id)
			version = self.clase_MyDB.conectar(query,datos,False)
			if(version[0] == "ok"):
				lista = ["ok", " "]
				self.mae_tipo_usu = MAE_TIPO_USU(tusu_id= self.tusu_id)  # clase tipo usuario
				self.mae_idioma = MAE_IDIOMAS(idi_id=self.idi_id)
				self.mae_area = MAE_AREA(area_id=self.area_id)
				self.mae_tipo_usu.buscar_dato()
				self.mae_idioma.buscar_dato()
				self.mae_area.buscar_dato()
			else:
				lista = ['error',str(version[1])]
		except Exception as e:
			lista = ["error", str(e)]
		finally:
			return lista

	def borrar(self):  # borra los datos de la clase en al base de datos
		try:
			query = 'DELETE FROM "MAE_USUARIOS" WHERE usu_id = %s'
			datos = (self.usu_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)
			if (respu[0] == 'ok'):
				lista = {}
				lista['result']='ok'#+str(respu)
				lista['dato']=respu
			else:
				lista = {}
				lista['result']='failed'
				lista['error']='Sucedio un error'
				lista['error_cod']=505
				lista['val_errors']=str(respu[1])
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 505
			lista["val_errors"] = str(e)
		finally:
			return lista

	# ofuzca el token numerico
	def __tokenizer(self, sNum):  # difumina el valor de cualquier string
		hToken = blake2b(digest_size=32)
		hToken.update(sNum.encode())
		return hToken.hexdigest()

	@staticmethod
	def verificar_usuario(usu_usuario, usu_password):  # verifica si el usuario y password son correctos segun los datos guardados en la base de datos
		try:
			clase_MyDB = MyDB()
			hToken = blake2b(digest_size=32)
			hToken.update(usu_password.encode())
			temp = hToken.hexdigest()  # valor difuminado
			query = 'SELECT usu_id,tusu_id FROM "MAE_USUARIOS" WHERE (usu_usuario= %s AND usu_password= %s AND usu_estado = %s) OR (usu_correo= %s AND usu_password= %s AND usu_estado = %s)'
			datos = (usu_usuario,str(temp),'A',usu_usuario,str(temp),'A',)
			version = clase_MyDB.conectar(query,datos,True)

			if (version[0]=='ok'):
				if version[1] != False:  # si se obtiene algun dato
					rsp = ["ok", " ", version[1][len(version[1]) - 1][0], version[1][len(version[1]) - 1][1]]
				else:
					#query = 'SELECT COUNT(usu_id) FROM "MAE_USUARIOS" WHERE usu_usuario= %s AND usu_estado =%s'
					query = 'SELECT usu_estado FROM "MAE_USUARIOS" WHERE usu_usuario= %s OR usu_correo =%s'
					#datos = (usu_usuario,'A')
					datos = (usu_usuario,usu_usuario)
					version2 = clase_MyDB.conectar(query,datos,True)
					if (version2[0] == 'ok'):
						#if version2[1][0][0] < 1:
						if version2[1] == False:
							#rsp = ["error", "error usuario no existe o no esta activado", -1]
							rsp = ["error", "error usuario o correo no existe", -1]
						elif version2[1][0][0] != "A":
							rsp = ["error", "error usuario o correo no esta activado", -1]
						else:
							rsp = ["error", "clave incorrecta", -1]
					else:
						rsp = ["error", "Error en la base de datos "+version2[1], -1]
			else:
				rsp = ["error", "Error en la base de datos "+version[1], -1]
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			# print(exc_type, fname, exc_tb.tb_lineno)
			rsp = ["error", "error en el verificar usuario "+' '+str(e)+' '+str(exc_type)+" "+str(fname)+" "+str(exc_tb.tb_lineno), -1]
		finally:
			return rsp


	#obtiene el id del usuario
	@staticmethod
	def obtener_id(datos_usu):
		try:
			db = MyDB()
			query = 'SELECT * FROM "MAE_USUARIOS" WHERE usu_nombre = %s and tusu_id = %s'
			datos = (datos_usu['usu_nombre'],datos_usu['tusu_id'])
			result = db.conectar(query,datos,True)
			if result[0] == 'ok':
				if result[1] != False:
					usu_id = result[1][0][0]
					resp = [True,usu_id]
				else:
					resp = [False, "No se encontro el usuario con ese ID"]
			else:
				resp = [False,str(result[1])]
		except psycopg2.DatabaseError as e:
			resp = [False, str(e)]
		except Exception as e:
			resp = [False, str(e)]
		finally:
			return resp

	# crea la clase con un array
	@staticmethod
	def from_lista(lista):
		usuario = MAE_USUARIOS(
			usu_id = lista[0],
			usu_nombre = lista[1],
			tusu_id = lista[2],
			usu_estado = lista[3],
			usu_correo = lista[4],
			usu_usuario = lista[5],
			usu_password= lista[6],
			idi_id = lista[7],
			area_id = lista[8],
			usu_usuario_creador = lista[9],
			usu_fecha_creacion = lista[10],
			usu_usuario_modificacion = lista[11],
			usu_fecha_modificacion = lista[12]
		)
		return usuario

	# crea la clase con un json
	@staticmethod
	def from_json(json):
		usuario = MAE_USUARIOS()
		diccio = vars(usuario)
		for key,value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			diccio[key] = value
		return usuario
	
	# sevuelve la informacion de la configuracion del password
	@staticmethod
	def devol_info_password():  # borra los datos de la clase en al base de datos
		try:
			clase_MyDB = MyDB()
			respu1 = clase_MyDB.conectar('SELECT param_id FROM "PARAM" WHERE param_grupo = %s ',('estado_password_mayus',),True)
			if respu1[0] == 'ok' and respu1[1] != False :
				respu1 = respu1[1][0][0].split('+')
				if respu1[0] == "A" :
					respu1[0] = True
				else:
					respu1[0] = False
			else:
				respu1 = ['error','error']
			respu2 = clase_MyDB.conectar('SELECT param_id FROM "PARAM" WHERE param_grupo = %s ',('estado_password_num',),True)
			if respu2[0] == 'ok' and respu2[1] != False :
				respu2 = respu2[1][0][0].split('+')
				if respu2[0] == "A" :
					respu2[0] = True
				else:
					respu2[0] = False             
			else:
				respu2 = ['error','error']
			respu3 = clase_MyDB.conectar('SELECT param_id FROM "PARAM" WHERE param_grupo = %s ',('estado_password_carac',),True)
			if respu3[0] == 'ok' and respu3[1] != False :
				respu3 = respu3[1][0][0].split('+')
				if respu3[0] == "A" :
					respu3[0] = True
				else:
					respu3[0] = False
			else:
				respu3 = ['error','error']
			respu4 = clase_MyDB.conectar('SELECT param_id FROM "PARAM" WHERE param_grupo = %s ',('longitud_pass',),True)
			if respu4[0] == 'ok' and respu4[1] != False :
				respu4 = respu4[1][0][0]
			else:
				respu4 = ['error','error']

			ejem = {}
			ejem2 = {}
			ejem2["estado"] = respu1[0]
			ejem2["cantidad"] = respu1[1]
			ejem["valida_mayuscula"]= ejem2

			ejem2 = {}
			ejem2["estado"] = respu2[0]
			ejem2["cantidad"] = respu2[1]            
			ejem["valida_digitos"]= ejem2

			ejem2 = {}
			ejem2["estado"] = respu3[0]
			ejem2["cantidad"] = respu3[1]            
			ejem["valida_caracteres_especiales"]= ejem2

			ejem2 = {}
			ejem["longitud_minima"]= respu4

		except Exception as e:
			lista = {}
			ejem["result"] = "failed"
			ejem["error"] = "Sucedio un error"
			ejem["error_cod"] = 505
			ejem["val_errors"] = str(e)
		finally:
			return ejem

	#edita la configuracion del password
	@staticmethod
	def update_conf_password(json):
		try:
			if (json["mayus_estd"] != "" and json["mayus_estd"]!= None and json["mayus_num"] != "" and json["mayus_num"]!= None and json["digi_estd"] != "" and json["digi_estd"]!= None and json["digi_num"] != "" and json["digi_num"]!= None and json["carac_estd"] != "" and json["carac_estd"]!= None and json["carac_num"] != "" and json["carac_num"]!= None and json["long_num"] != "" and json["long_num"]!= None):
				clase_MyDB = MyDB()
				if json["mayus_estd"] :
					cadena1 = "A+"+str(json["mayus_num"])
				else:
					cadena1 = "D+"+str(json["mayus_num"])

				if json["digi_estd"] :
					cadena2 = "A+"+str(json["digi_num"])
				else:
					cadena2 = "D+"+str(json["digi_num"])

				if json["carac_estd"] :
					cadena3 = "A+"+str(json["carac_num"])
				else:
					cadena3 = "D+"+str(json["carac_num"])

				#json["long_num"]
				respu1 = clase_MyDB.conectar('UPDATE "PARAM" SET param_id = %s WHERE param_grupo = %s ',(cadena1,'estado_password_mayus'),False)
				respu2 = clase_MyDB.conectar('UPDATE "PARAM" SET param_id = %s WHERE param_grupo = %s ',(cadena2,'estado_password_num'),False)
				respu3 = clase_MyDB.conectar('UPDATE "PARAM" SET param_id = %s WHERE param_grupo = %s ',(cadena3,'estado_password_carac'),False)
				respu4 = clase_MyDB.conectar('UPDATE "PARAM" SET param_id = %s WHERE param_grupo = %s ',(str(json["long_num"]),'longitud_pass'),False)
				if (respu1[0] == "ok" and respu2[0] == "ok" and respu3[0] == "ok" and respu4[0] == "ok"):
					mnsj = ["ok",""]
				else:
					mnsj = ["error","Hay dato vacio"]
			else:
				mnsj = ["error","Hay dato vacio"]
		except Exception as e :
			mnsj = ["error",str(e)]
		finally :
			return mnsj


	#busca el correo con un username o otro correo
	@staticmethod
	def buscar_correo(json):
		try:
			if (json["data"] != "" and json["data"]!= None ):
				clase_MyDB = MyDB()
					
				query = 'SELECT usu_correo FROM "MAE_USUARIOS" WHERE usu_usuario = %s or usu_correo = %s'
				datos = (json["data"],json["data"])
				version = clase_MyDB.conectar(query,datos,True)

				if version[0] == "ok" :
					if version[1] != False :
						mnsj = ["ok",version[1][0]]
					else :
						mnsj = ["error","No exite un usuario con es usuario/correo"]
				else :
					mnsj = ["error",version[1]]
			else:
				mnsj = ["error","el dato enviado es vacio"]
		except Exception as e :
			mnsj = ["error",str(e)]
		finally :
			return mnsj

	#verifica si el usuario es de tipo administrador
	@staticmethod
	def verifica_admin(str_id):
		try:
			clase_MyDB = MyDB()
			query = 'SELECT tusu_id FROM "MAE_USUARIOS" WHERE usu_id = %s'
			datos = (str_id,)
			version = clase_MyDB.conectar(query,datos,True)

			if version[0] == "ok" :
				if version[1] != False and version[1][0][0] == 1:
					mnsj = ["ok","Es administrador"]
				else :
					mnsj = ["ok","No es administrador"]
			else :
				mnsj = ["error",version[1]]
		except Exception as e :
			mnsj = ["error",str(e)]
		finally :
			return mnsj
	