import psycopg2
import sys , os
import logging
import datetime
from MyDB import MyDB
from ARB_FISICO import ARB_FISICO
from MAE_OBJETOS import MAE_OBJETOS

class MAE_OBJETO_FISICO :

	def __init__(self,obj_id=None,fis_id=None):
	
		self.obj_id = obj_id #integer
		self.fis_id = fis_id #integer
		self.arb_fisico=ARB_FISICO(fis_id=fis_id)
		self.mae_objetos = MAE_OBJETOS(obj_id=obj_id)
		self.arb_fisico.buscar_dato()
		self.mae_objetos.buscar_dato()
								
		self.clase_MyDB = MyDB()
	def get_diccionario(self):
		diccionario = vars(self)
		diccionario['arbol_fisico'] = {}
		diccionario['arbol_fisico'].update(self.arb_fisico.get_diccionario())
		#modificar el metodo ver cuando objeto tenga la funcion get_diccionario
		diccionario['objeto'] = {}
		diccionario['objeto'].update(self.mae_objetos.get_diccionario())
		diccionario['objeto'].pop('marca')
		diccionario['objeto'].pop('modelo')
		diccionario['objeto'].pop('protocolo')
		diccionario['objeto'].pop('tipo_obj')
		diccionario.pop('clase_MyDB')
		diccionario.pop('arb_fisico')
		diccionario.pop('mae_objetos')
		return diccionario

	# Metodo para obtener la tupla que se usara en el metodo guardar
	def _get_insert_tuple(self):
		return (self.obj_id, self.fis_id,)

  
	def guardar_dato(self):
		try:
			datos = self._get_insert_tuple()
			query='INSERT INTO "MAE_OBJETO_FISICO" (obj_id,fis_id) VALUES (%s,%s)'
			version = self.clase_MyDB.conectar(query,datos,False)
			if version[0] == 'ok':
				dato = ['ok',' ']
			else:
				dato = ['error','Error en la base de datos']
			
		except Exception as e:
			dato = ['error',str(e)]
		finally:
			return dato


	def buscar_dato(self):
		try:
			datos = (self.obj_id,self.fis_id,)
			query='SELECT * FROM "MAE_OBJETO_FISICO" WHERE obj_id = %s AND fis_id= %s'
			version = self.clase_MyDB.conectar(query,datos,True)
			if (version[0] == 'ok'):
				if (version[1]!=False):
					self.arb_fisico=ARB_FISICO(fis_id=self.fis_id)
					self.mae_objetos = MAE_OBJETOS(obj_id=self.obj_id)
					self.arb_fisico.buscar_dato()
					self.mae_objetos.buscar_dato()
					dato = ['ok',' ']
				else:
					dato = ['error', 'No se encontro un elemento en ARB_FISICO con ese ID']
			else:
				dato = ['error', 'Error con la base de datos']
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]				
			dato = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
		finally:
			return dato

	@staticmethod
	def validations_crear(obj_id,fis_id):
		try:
			query='SELECT * FROM "MAE_OBJETO_FISICO" WHERE obj_id =%s AND fis_id = %s'
			datos=(obj_id,fis_id,)
			clase_MyDB = MyDB()  
			version = clase_MyDB.conectar(query,datos,True)
			if (version[0] == 'ok'):
				if (version[1]!=False): #ya existe 
					dato = [False,'ya existe MAE_OBJETO_FISICO con esos ID']
				else:
					dato = [True,'ok']
			else:
				dato = ['error', 'Error con la base de datos']
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]				
			dato = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
		finally:
			return dato

	@staticmethod
	def consultar_lista():
		try:
			query='SELECT * FROM "MAE_OBJETO_FISICO"'
			datos=()
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)
			if (version[0]=='ok'):
				if (version[1]!=False):
					lista=[]
					for obj in version[1]:
						data = {}
						obj_fisico = MAE_OBJETO_FISICO.from_list(obj)
						data.update(obj_fisico.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista['MAE_OBJETO_FISICO'] = 'Lista vacia'
			else:
				lista = {}
				lista['Error']='Error en la base de datos'

		except Exception as e:
			lista = {}
			lista['Error'] =str(e)
		finally:
			return lista

	def modificar(self,obj_id,fis_id):
		try:
			query = 'UPDATE "MAE_OBJETO_FISICO" SET obj_id = %s , fis_id = %s WHERE obj_id = %s and fis_id= %s'
			datos=(obj_id,fis_id,self.obj_id,self.fis_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)
			if (respu[0]=='ok'):
				lista = ['ok',' ']
				self.obj_id = obj_id
				self.fis_id = fis_id
				self.arb_fisico=ARB_FISICO(fis_id=fis_id)
				self.mae_objetos = MAE_OBJETOS(obj_id=obj_id)
				self.arb_fisico.buscar_dato()
				self.mae_objetos.buscar_dato()
			else:
				lista = ['error','Error en la base de datos']
		except Exception as e:
			lista = ['error',str(e)]
		finally:
			return lista

	def borrar(self):
		try:
			query = 'DELETE FROM "MAE_OBJETO_FISICO" WHERE obj_id= %s and fis_id = %s'
			datos = (self.obj_id, self.fis_id,)
			respu = self.clase_MyDB.conectar(query, datos, False)
			if respu[0] == "ok":
				lista = {}
				lista["result"] = "ok"  # +str(respu)
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 505
				lista["val_errors"] = "Error en la base de datos"
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 505
			lista["val_errors"] = str(e)
		finally:
			return lista

	def consultar(self):
		print("consulta")

	@staticmethod
	def from_list(lista):
		obj_fisico = MAE_OBJETO_FISICO(
			obj_id = lista[0],
			fis_id = lista[1]
		)
		return obj_fisico

	#Crea un objeto de MAE_OBJETO_FISICO a partir de un diccionario json, los datos del json
	#deben tener los mismos nombres que en la clase objeto_fisico
	@staticmethod
	def from_json(json):
		obj_fisico = MAE_OBJETO_FISICO()
		diccio_obj_fisico = vars(obj_fisico)
		for key,value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			diccio_obj_fisico[key] = value
		return obj_fisico
