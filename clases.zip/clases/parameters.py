import psycopg2
import sys
import logging
import datetime
import os
from MyDB import MyDB



def buscar_param_grupo(grupo_codigo):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT * FROM "PARAM_GRUPO" WHERE grupo_codigo = %s'
		datos=(str(grupo_codigo),)
		version = clase_MyDB.conectar(query,datos,True)
		if (version[0] == 'ok'):
			if(version[1]!=False):
				grupo_codigo = version[1][0][1]
				dato = ['ok',grupo_codigo]
			
			else:
				dato = ['error','No se encontro el grupo con ese codigo']
		else:
				dato = ['error','error en la BD']

	except Exception as e:
		dato = ["error",str(e)]
	finally:

		return dato


def buscar_param(param_grupo,param_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT * FROM "PARAM" WHERE param_grupo = %s  AND param_id = %s'
		datos=(param_grupo,param_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if (version[0] == 'ok'):
			if(version[1]!=False):

				obj_id = version[1][0][0]
				param_extra = version[1][0][3]

				dato = ['ok',obj_id,param_extra]

			else:

				dato = ['error','No se encontro el param con ese codigo']
		else:
				dato = ['error','error en la BD']


	except Exception as e:
		dato = ["error",str(e)]
	finally:
		return dato

if __name__ == "__main__":

	#dato = buscar_dato('estado_usuario')
	dato = buscar_param('estado_usuario','A')

	print(dato)
