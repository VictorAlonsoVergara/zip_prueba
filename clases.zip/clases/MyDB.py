import psycopg2
#from psycopg2 import pool
import sys , os
import configuracionParametros

# class MyDB:

# 	instance = None
# 	class __DB_Single:
# 		def __init__(self):
# 			self.database = configuracionParametros.NombreDataBase()
# 			self.user = configuracionParametros.UsuarioDataBase()
# 			self.clave = configuracionParametros.ClaveDataBase()
# 			self.ps_pool = pool.ThreadedConnectionPool(1,20,user = self.user,database = self.database,password = self.clave)
# 			#self.db = psycopg2.connect(database=self.database,user=self.user,password=self.clave)
			
    
# 	def __init__(self):
# 		if not MyDB.instance:
# 			MyDB.instance = MyDB.__DB_Single()
# 		else:
# 			#print("Already instanced")
# 			pass
# 	def conectar(self, sQry, tData, bSelect = False):
# 		try:
# 			db = MyDB.instance.ps_pool.getconn()
# 			cur = db.cursor()

# 			#si es un select no necesitamos hacer commits
# 			# if bSelect == True:
# 			# 	MyDB.instance.db.autocommit = True
# 			# else:
# 			# 	MyDB.instance.db.autocommit = False
# 			cur.execute(sQry,tData)
# 			db.commit()
# 			if bSelect == False:
# 				db.commit()
# 				if (sQry.find('returning')>=0 or sQry.find('RETURNING')>=0):
# 					rRpt = cur.fetchall()
# 					respuesta = ['ok',rRpt]
# 				else:
# 					respuesta = ['ok',True]
# 			else:
# 				rRpt = cur.fetchall()
# 				if len(rRpt) == 0:
# 					respuesta = ['ok',False]
# 				else:
# 					respuesta = ['ok',rRpt]

# 		except Exception as e :
# 			exc_type, _, exc_tb = sys.exc_info()
# 			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
# 			respuesta = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
# 		finally:
# 			cur.close()
# 			MyDB.instance.ps_pool.putconn(db)
# 			return respuesta


class MyDB:
	def __init__(self):
		self.database = configuracionParametros.NombreDataBase()
		self.user = configuracionParametros.UsuarioDataBase()
		self.clave = configuracionParametros.ClaveDataBase()

	#si bSelect es False delete,update,insert si es True select
	def conectar(self, sQry, tData, bSelect = False):
		try:
			con = psycopg2.connect(database=self.database,user=self.user,password=self.clave)
			#si es un select no necesitamos hacer commits
			# if bSelect == True:
			# 	con.autocommit = True
			# else:
			# 	con.autocommit = False
			mycursor = con.cursor()
			mycursor.execute(sQry,tData)
			con.commit()
			if bSelect == False:
				#con.commit()
				if (sQry.find('returning')>=0 or sQry.find('RETURNING')>=0):
					rRpt = mycursor.fetchall()
					respuesta = ['ok',rRpt]
				else:
					respuesta = ['ok',True]
				mycursor.close()	
			else:
				rRpt = mycursor.fetchall()
				if len(rRpt) == 0:
					respuesta = ['ok',False]
				else:
					respuesta = ['ok',rRpt]
				mycursor.close()	

		except Exception as e :
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			respuesta = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
			if mycursor:
				mycursor.close()
			if con:
				con.close()
		finally:
			if con:
				con.close()
			return respuesta
		
	def execute_procedure(self,query,datos):
		try:
			con = psycopg2.connect(database=self.database,user=self.user,password=self.clave)
			mycursor = con.cursor()
			mycursor.callproc(query,datos)
			con.commit()
			rRpt = mycursor.fetchall()
			if len(rRpt) == 0:
				respuesta = ['ok',False]
			else:
				respuesta = ['ok',rRpt]
			mycursor.close()	

		except Exception as e :
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			respuesta = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
		finally:
			if mycursor:
				mycursor.close()
			if con:
				con.close()
			return respuesta