import psycopg2
#from psycopg2 import pool
import sys , os
import configuracionParametros

#clase que interactua directamente con la base de datos
class MyDB:
	#se inicializa
	def __init__(self):
		self.database = configuracionParametros.NombreDataBase()
		self.user = configuracionParametros.UsuarioDataBase()
		self.clave = configuracionParametros.ClaveDataBase()

	#si bSelect es False delete,update,insert si es True select
	def conectar(self, sQry, tData, bSelect = False):
		try:
			con = psycopg2.connect(database=self.database,user=self.user,password=self.clave)
			#si es un select no necesitamos hacer commits
			# if bSelect == True:
			# 	con.autocommit = True
			# else:
			# 	con.autocommit = False
			mycursor = con.cursor()
			mycursor.execute(sQry,tData)
			con.commit()
			if bSelect == False:
				#con.commit()
				if (sQry.find('returning')>=0 or sQry.find('RETURNING')>=0):
					rRpt = mycursor.fetchall()
					respuesta = ['ok',rRpt]
				else:
					respuesta = ['ok',True]
				mycursor.close()	
			else:
				rRpt = mycursor.fetchall()
				if len(rRpt) == 0:
					respuesta = ['ok',False]
				else:
					respuesta = ['ok',rRpt]
				mycursor.close()	

		except psycopg2.IntegrityError as err :
			cadena = str(err).split("DETAIL: ")
			cadena2 = cadena[1].split("CONTEXT")[0]
			respuesta = ['error',"error dato es foreign key de otro dato - " +str(cadena2)]
		except Exception as e :
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			respuesta = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
			if mycursor:
				mycursor.close()
			if con:
				con.close()
		finally:
			if con:
				con.close()
			return respuesta
		
	# funcion que sirve para realizar un procedure en la base de datos
	def execute_procedure(self,query,datos):
		try:
			con = psycopg2.connect(database=self.database,user=self.user,password=self.clave)
			mycursor = con.cursor()
			mycursor.callproc(query,datos)
			con.commit()
			rRpt = mycursor.fetchall()
			if len(rRpt) == 0:
				respuesta = ['ok',False]
			else:
				respuesta = ['ok',rRpt]
			mycursor.close()	

		except Exception as e :
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			respuesta = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
		finally:
			if mycursor:
				mycursor.close()
			if con:
				con.close()
			return respuesta