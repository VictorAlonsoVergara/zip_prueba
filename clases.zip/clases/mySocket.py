import socket
class MySocket:
    def __init__(self,sock = None):
        self.conn = None
        self.addr = None
        self.msglen = 1024
        if sock is None:
            self.sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        else:
            self.sock = sock
        
    def connect(self,port):
        try:
            self.__connect('0.0.0.0',port)
        except:
            self.__bind('0.0.0.0',port)

    def __bind(self,host,port):
        self.sock.bind((host,port))
        self.__accept()

    def __connect(self,host,port):
        self.sock.connect((host,port))
        #self.__accept()

    def __accept(self):
        self.sock.listen(5)
        self.conn,self.addr = self.sock.accept()

    def send(self,msg):
        #totalsent = 0
        msg = msg.encode('utf-8')
        if self.conn is not None:
            self.conn.send(msg)
        else:
            self.sock.send(msg)

    def receive(self):
        if self.conn is not None:
            data = self.conn.recv(self.msglen).decode('utf-8')
        else:
            data = self.sock.recv(self.msglen).decode('utf-8')
        return data
        
    def close(self):
        self.sock.close()