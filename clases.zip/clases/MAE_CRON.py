#import psycopg2
import sys
from MAT_TIPO_OBJ import MAT_TIPO_OBJ
from TAB_PROTOCOLO import TAB_PROTOCOLO
import logging
import datetime
import os
from MyDB import MyDB
from mySocket import MySocket
#clase cron que sirve para poder realizar una actividad en un tiempo determinado
class MAE_CRON:
	#inicializa la clase
	def __init__(self,cron_tipo=None,
					cron_periodo=None,cron_estado=None,
					cron_desc=None,cron_id=None):
		self.cron_id = cron_id  # serial
		#self.tobj_id = tobj_id  # integer
		self.cron_tipo = cron_tipo  # char(1)
		self.cron_periodo = cron_periodo  # varchar(20)
		self.cron_estado = cron_estado  # char(1)
		self.cron_desc = cron_desc # varchar(200)
		#self.prot_id = prot_id # integer
		#self.tab_prot = TAB_PROTOCOLO(prot_id=prot_id)
		#self.tab_prot.buscar_dato()
		#self.mat_tipo_obj = MAT_TIPO_OBJ(tobj_id=tobj_id)
		#self.mat_tipo_obj = MAT_TIPO_OBJ("", "", "", "","", "", "", "", tobj_id)
		#self.mat_tipo_obj.buscar_dato()
		self.clase_MyDB = MyDB()

	#devuelve informacion importante de la consulta
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		diccionario.pop('clase_MyDB')
		return diccionario

	# guarda dato en la tabla de cron 
	def guardar_dato(self):
		try:
			datos = (
				self.cron_tipo,
				self.cron_periodo.upper(),
				self.cron_estado.upper(),
				self.cron_desc,
			)
			query = ('INSERT INTO "MAE_CRON" (cron_tipo,cron_periodo,cron_estado,cron_desc) VALUES (%s,%s,%s,%s) RETURNING cron_id')
			version = self.clase_MyDB.conectar(query, datos, False)
			if version[0] == "ok":
				self.cron_id = version[1][0][0]  
				dato = ["ok", " "]
			else:
				dato = ["error", version[1]]
				#dato = ["error", version[1]]
		except Exception as e:
			dato = ["error", str(e)]
		finally:
			return dato

	#busca dato en la tabla de cron que se encuentre activado
	def buscar_dato(self):
		try:
			datos = (self.cron_id,)
			query = """SELECT * FROM "MAE_CRON" WHERE cron_id = %s AND cron_estado='A'"""
			version = self.clase_MyDB.conectar(query, datos, True)
			if version[0] == "ok":
				if version[1] != False:
					#self.tobj_id = version[1][0][1] # integer
					self.cron_tipo = version[1][0][1] # char(1)
					self.cron_periodo = version[1][0][2] # varchar(20)
					self.cron_estado = version[1][0][3] # char(1)
					self.cron_desc = version[1][0][4] # varchar(200)
					#self.prot_id = version[1][0][6] # integer
					#self.mat_tipo_obj = MAT_TIPO_OBJ(tobj_id = self.tobj_id)
					#self.mat_tipo_obj.buscar_dato()
					#self.tab_prot = TAB_PROTOCOLO(self.prot_id)
					#self.tab_prot.buscar_dato()
					dato = ["ok", " "]
				else:
					dato = ["error", "No se encontro el cron con ese ID"]
			else:
				dato = ["error", version[1]]
		except Exception as e:
			exc_type, _, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			dato = [
				"error",
				str(e)
				+ " - "
				+ str(exc_type)
				+ " - "
				+ str(fname)
				+ " - "
				+ str(exc_tb.tb_lineno),
			]
		finally:            
			return dato

	#consulta la lista de la tabla cron que se encuentren activados
	@staticmethod
	def consultar_lista():
		try:
			query = """SELECT * FROM "MAE_CRON" WHERE cron_estado='A' ORDER BY cron_id"""
			datos = ()
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query, datos, True)
			if version[0] == "ok":
				lista = []
				if version[1] != False:
					for cron in version[1]:
						data = {}
						obj_cron = MAE_CRON.from_list(cron)
						data.update(obj_cron.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista["result"] = "failed"
					lista["error"] = "Sucedio un error "
					lista["error_cod"] = 413
					lista["val_errors"] = "lista vacia"
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error "
				lista["error_cod"] = 413			
				lista["val_errors"] = version[1]
		except Exception as e:
			exc_type, _, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]            
			lista = {}
			lista["Error"] = str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)
		finally:
			return lista

	# modifica el dato de l atabla de cron
	def modificar(self):
		try:
			#query = 'UPDATE "MAE_CRON" SET tobj_id = %s, cron_tipo= %s, cron_periodo= %s, cron_estado=%s, cron_desc=%s,  prot_id=%s WHERE cron_id = %s'
			query = ('UPDATE "MAE_CRON" SET cron_tipo= COALESCE(%s,cron_tipo),'
						'cron_periodo= COALESCE(%s,cron_periodo),'
						'cron_estado=COALESCE(%s,cron_estado),'
						'cron_desc=COALESCE(%s,cron_desc) WHERE cron_id = %s')
			datos = (
				self.cron_tipo,
				self.cron_periodo,
				self.cron_estado,
				self.cron_desc,
				self.cron_id,
			)
			respu = self.clase_MyDB.conectar(query, datos, False)
			if respu[0] == "ok":
				lista = ["ok", " "]
			else:
				lista = ["error", respu[1]]
		except Exception as e:
			lista = ["error", str(e)]
		finally:
			return lista

	#borra un dato de la tabla cron
	def borrar(self):
		try:
			query = 'DELETE FROM "MAE_CRON" WHERE cron_id= %s'
			datos = (self.cron_id,)
			respu = self.clase_MyDB.conectar(query, datos, False)
			if respu[0] == "ok":
				lista = {}
				lista["result"] = "ok"  # +str(respu)
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 505
				lista["val_errors"] = respu[1]
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 505
			lista["val_errors"] = str(e)
		finally:
			return lista

	#busca los datos de la tabla  que se encuentran activados
	@staticmethod
	def buscar_activos():
		try:
			db = MyDB()
			query = 'SELECT * FROM "MAE_CRON" WHERE cron_estado = %s'
			datos = ('A',)
			results = db.conectar(query,datos,True)
			if results[0] == 'ok':
				lista = []
				for cron in results[1]:
					data = {}
					obj_cron = MAE_CRON.from_list(cron)
					data.update(obj_cron.get_diccionario())
					lista.append(data)
			else:
				lista = {}
				lista["error"] = "Error en la base de datos"
		except Exception as e:
			exc_type, _, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]            
			lista = {}
			lista["error"] = str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)
		finally:
			return lista

	#inicializa la clase con un array
	@staticmethod
	def from_list(lista):
		cron = MAE_CRON(
			cron_id = lista[0],
			cron_tipo = lista[1],
			cron_periodo = lista[2],
			cron_estado = lista[3],
			cron_desc = lista[4],
		)
		return cron

	#inicializa la clase con un json
	@staticmethod
	def from_json(json):
		cron = MAE_CRON()
		diccio_objeto = vars(cron)
		for key,value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			diccio_objeto[key] = value
		return cron
	
	def __sendUpdate(self):
		try:
			mySock = MySocket()
			mySock.connect(7777)
			mySock.send("update")
			resp = mySock.receive()
			mySock.close()
		except Exception as e:
			resp = str(e)
		finally: 
			return resp