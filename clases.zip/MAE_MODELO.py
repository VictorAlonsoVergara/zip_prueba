import sys , os
import logging
import datetime
from MyDB import MyDB
from MAE_MARCAS import MAE_MARCAS
from MAT_TIPO_OBJ import MAT_TIPO_OBJ
rutalog="/home/sistema/log/Traxium"
#la clase modelo gestiona los modelos disponibles de los dispositivos
class MAE_MODELO:
	#se inicializa
	def __init__(self,mod_id=None,mod_descripcion = None, marca_id = None,tobj_id=None,mod_estado=None):
		self.mod_id=mod_id
		self.mod_descripcion=mod_descripcion
		self.marca_id = marca_id
		self.tobj_id = tobj_id
		self.mod_estado = mod_estado
		self.mae_marcas = MAE_MARCAS(marca_id=marca_id)
		self.mat_tipo_obj = MAT_TIPO_OBJ(tobj_id=tobj_id)
		self.mae_marcas.buscar_dato()
		self.mat_tipo_obj.buscar_dato()
		self.my_db = MyDB()
	# Metodo para obtener la tupla que se usara en el metodo guardar
	def __get_insert_tuple(self):
		return (self.mod_descripcion,self.marca_id,self.tobj_id,self.mod_estado)
	# Metodo para obtener la tupla que se usara en el metodo modificar
	def __get_update_tuple(self):
		return (self.mod_descripcion,self.marca_id,self.tobj_id,self.mod_estado,self.mod_id)
	
	#devuelve datos importantes de la clase modelo
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		diccionario['marca'] = {}
		diccionario['marca'].update(self.mae_marcas.get_diccionario())
		diccionario['tipo_obj'] = {}
		diccionario['tipo_obj'].update(self.mat_tipo_obj.get_diccionario())
		diccionario.pop('my_db')
		diccionario.pop('mae_marcas')
		diccionario.pop('mat_tipo_obj')
		return diccionario

	#guarda los datos en la tabla modelo
	def guardar_dato(self):
		try:
			datos = self.__get_insert_tuple()
			query = 'INSERT INTO "MAE_MODELO" (mod_descripcion,marca_id,tobj_id,mod_estado) VALUES (%s,%s,%s,%s) RETURNING mod_id'
			version = self.my_db.conectar(query, datos, False)
			if version[0] == "ok":
				self.mod_id = version[1][0][0]
				dato = ["ok", " "]
			else:
				dato = ["error", version[1]]
		except Exception as e:
			dato = ["error", str(e)]
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return dato

	#se busca el dato en la tabla modelo
	def buscar_dato(self):
		try:
			query = """SELECT * FROM "MAE_MODELO" WHERE mod_id = %s AND mod_estado='A'"""
			datos = (self.mod_id,)
			resultado = self.my_db.conectar(query,datos,True)
			if resultado[0] is 'ok':
				if resultado[1] is not False:
					#self.mod_id=resultado[1][0][0]
					self.mod_descripcion = resultado[1][0][1]
					self.marca_id = resultado[1][0][2]
					self.tobj_id = resultado[1][0][3]
					self.mod_estado = resultado[1][0][4]
					self.mae_marcas=MAE_MARCAS(marca_id=resultado[1][0][2])
					self.mat_tipo_obj=MAT_TIPO_OBJ(tobj_id=resultado[1][0][3])
					self.mae_marcas.buscar_dato()
					self.mat_tipo_obj.buscar_dato()

					dato = ["ok", " "]
				else:
					dato = ["error", "No se encontro el modelo con ese ID"]
			else:
				dato = ["error", resultado[1]]
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			dato = [
				"error",
				str(e)
				+ " - "
				+ str(exc_type)
				+ " - "
				+ str(fname)
				+ " - "
				+ str(exc_tb.tb_lineno),
			]            
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:            
			return dato

	#se consulta la lista de la tabla modelo que se encuentre activada
	@staticmethod
	def consultar_lista():
		try:
			query = """SELECT * FROM "MAE_MODELO" WHERE mod_estado='A' ORDER BY mod_id"""
			datos = ()
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query, datos, True)
			if version[0] == "ok":
				if version[1]!= False:
					lista = []
					for modelo in version[1]:
						data = {}
						obj_modelo = MAE_MODELO.from_lista(modelo)
						data.update(obj_modelo.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista['result'] = 'nodata'
					lista['message'] = 'Lista vacia'
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 412
				lista["val_errors"] = version[1]			
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 412
			lista["val_errors"] = str(e)
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	#se modifica los datos de la tabla modelo
	def modificar(self):
		try:
			query = ('UPDATE "MAE_MODELO" SET mod_descripcion = COALESCE(%s,mod_descripcion),'
						'marca_id = COALESCE(%s,marca_id),'
						'tobj_id = COALESCE(%s,tobj_id),'
						'mod_estado= COALESCE(%s,mod_estado) '
						'WHERE mod_id = %s')
			datos = self.__get_update_tuple()
			respu = self.my_db.conectar(query, datos, False)
			if respu[0] == "ok":
				lista = ["ok", " "]
				self.mae_marcas = MAE_MARCAS(marca_id=self.marca_id)
				self.mat_tipo_obj = MAT_TIPO_OBJ(tobj_id=self.tobj_id)
				self.mae_marcas.buscar_dato()
				self.mat_tipo_obj.buscar_dato()
			else:
				lista = ["error", respu[1]]
		except Exception as e:
			lista = ["error", str(e)]
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	#se borra el dato seleccionado de la tabla modelo
	def borrar(self):
		try:
			query = 'DELETE FROM "MAE_MODELO" WHERE mod_id= %s'
			datos = (self.mod_id,)
			respu = self.my_db.conectar(query, datos, False)
			if respu[0] == "ok":
				lista = {}
				lista["result"] = "ok"  # +str(respu)
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 412
				lista["val_errors"] = respu[1]
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 412
			lista["val_errors"] = str(e)
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	#inicializa la clase modelo con un array
	@staticmethod
	def from_lista(lista):
		modelo = MAE_MODELO(
			mod_id = lista[0],
			mod_descripcion = lista[1],
			marca_id = lista[2],
			tobj_id = lista[3],
			mod_estado=lista[4]
		)
		return modelo

	#inicializa la clase modelo con un json
	@staticmethod
	def from_json(json):
		modelo = MAE_MODELO()
		diccio = vars(modelo)
		for key,value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			diccio[key] = value
		return modelo
			