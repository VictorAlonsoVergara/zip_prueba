#import psycopg2
import sys
import logging
import datetime
import os
from MyDB import MyDB
rutalog="/home/sistema/log/Traxium"

#clase que gestiona las marcas de los dispositivos
class MAE_MARCAS:
	#se inicializa
	def __init__(self, marca_desc=None, marca_estado=None,marca_id=None):
		self.marca_id = marca_id  # serial
		self.marca_desc = marca_desc  # varchar (100)
		self.marca_estado = marca_estado  # char(1)
		self.clase_MyDB = MyDB()

	# devuelve datos importnates de la marca
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		diccionario.pop('clase_MyDB')
		return diccionario
	# Metodo para obtener la tupla que se usara en el metodo guardar
	def _get_insert_tuple(self):
		return (self.marca_desc, self.marca_estado,)

	# Metodo para obtener la tupla que se usara en el metodo modificar
	def _get_update_tuple(self):
		return (self.marca_desc, self.marca_estado, self.marca_id,)

	#guarda el dato en la tabla
	def guardar_dato(self):
		try:
			datos = self._get_insert_tuple()
			query = 'INSERT INTO "MAE_MARCAS" (marca_desc,marca_estado) VALUES (%s,%s) RETURNING marca_id'
			version = self.clase_MyDB.conectar(query, datos, False)
			if version[0] == "ok":
				self.marca_id = version[1][0][0]  
				dato = ["ok", " "]
			else:
				dato = ["error", version[1]]
		except Exception as e:
			dato = ["error", str(e)]
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return dato

	#busca el dato seleccionado que se encuentre activado
	def buscar_dato(self):
		try:
			datos = (self.marca_id,)
			query = """SELECT * FROM "MAE_MARCAS" WHERE marca_id = %s and marca_estado='A' """
			version = self.clase_MyDB.conectar(query, datos, True)
			if version[0] == "ok":
				if version[1] != False:
					self.marca_desc = version[1][0][1]  # varchar(100)
					self.marca_estado = version[1][0][2]  # CHAR (1)
					dato = ["ok", " "]
				else:
					dato = ["error", "No se encontro la marca con ese ID"]
			else:
				dato = ["error", version[1]]
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			dato = [
				"error",
				str(e)
				+ " - "
				+ str(exc_type)
				+ " - "
				+ str(fname)
				+ " - "
				+ str(exc_tb.tb_lineno),
			]             
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:            
			return dato

	#consulta la lista de las marcas que se encuentren ativados
	@staticmethod
	def consultar_lista():
		try:
			query = '''SELECT * FROM "MAE_MARCAS" where marca_estado ='A' ORDER BY marca_id'''
			datos = ()
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query, datos, True)
			if version[0] == "ok":
				if version[1] != False:
					lista = []
					for marca in version[1]:
						data = {}
						mae_marca = MAE_MARCAS.from_list(marca)
						data.update(mae_marca.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista['result'] = 'nodata'
					lista['message'] = 'Lista vacia'

			else:
				lista = {}
				linea["result"] = "failed"
				linea["error"] = "Sucedio un error "
				linea["error_cod"] = 412
				lista["val_errors"] = "Error en la base de datos" 
		except Exception as e:
			lista = {}
			linea["result"] = "failed"
			linea["error"] = "Sucedio un error "
			linea["error_cod"] = 412
			lista["val_errors"] = str(e)
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	#se modifica la tabla de marcas
	def modificar(self):
		try:
			query = ('UPDATE "MAE_MARCAS" SET marca_desc = COALESCE(%s,marca_desc),'
				'marca_estado= COALESCE(%s,marca_estado) WHERE marca_id = %s')
			datos = self._get_update_tuple()
			respu = self.clase_MyDB.conectar(query, datos, False)
			if respu[0] == "ok":
				lista = ["ok", " "]
			else:
				lista = ["error", respu[1]]
		except Exception as e:
			lista = ["error", str(e)]
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	#borra la tabla de marcas
	def borrar(self):
		try:
			query = 'DELETE FROM "MAE_MARCAS" WHERE marca_id= %s'
			datos = (self.marca_id,)
			respu = self.clase_MyDB.conectar(query, datos, False)
			if respu[0] == "ok":
				lista = {}
				lista["result"] = "ok"  # +str(respu)
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 505
				lista["val_errors"] = respu[1]
				
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 505
			lista["val_errors"] = str(e)     
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)       
		finally:
			return lista

	# El metodo crea un objeto a partir de una lista mandada por
	# la base de datos
	@staticmethod
	def from_list(lista):
		marca = MAE_MARCAS(
			marca_id=lista[0], marca_desc=lista[1], marca_estado=lista[2]
		)
		return marca

	# Crea una marca de MAE_MARCAS a partir de un diccionario json,
	# los datos del json deben tener los mismos nombres que en la clase de marca
	@staticmethod
	def from_json(json):
		marca = MAE_MARCAS()
		dicc_marca = vars(marca)
		for key, value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			dicc_marca[key] = value
		return marca
