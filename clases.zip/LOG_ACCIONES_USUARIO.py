import sys,os
import psycopg2
import datetime
from MyDB import MyDB
from TAB_ACCIONES import TAB_ACCIONES
from MAE_USUARIOS import MAE_USUARIOS

#clase que interactua con el log de acciones de los usuarios
class LOG_ACCIONES_USUARIO:

	#se inicializa
	def __init__(self,log_id = None,log_usu_id = None, log_fecha_hora=None, log_desc =None, log_acc_id=None):

		self.log_id = log_id
		self.log_usu_id = log_usu_id
		self.log_fecha_hora = log_fecha_hora
		self.log_desc = log_desc
		self.log_acc_id = log_acc_id
		self.tab_acciones=TAB_ACCIONES(acc_id=log_acc_id)
		self.mae_usuarios=MAE_USUARIOS(usu_id=log_usu_id)
		if log_usu_id is not None:
			self.mae_usuarios.buscar_dato()
		if log_acc_id is not None:
			self.tab_acciones.buscar_dato()
		self.clase_MyDB = MyDB()

	#se devuelve los parametros importantes del log del usuario
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		if self.log_fecha_hora is not None:
			diccionario['log_fecha_hora'] = self.log_fecha_hora.strftime("%Y-%m-%d %H:%M:%S")#convierto a string para que pueda convertirlo a JSON
		diccionario['acciones'] = {}
		diccionario['acciones'].update(self.tab_acciones.get_diccionario())
		diccionario['usuario'] = {}
		diccionario['usuario'].update(self.mae_usuarios.get_diccionario())
		diccionario['usuario'].pop('tipo_usuario')
		diccionario['usuario'].pop('idioma')
		diccionario['usuario'].pop('area')
		diccionario.pop('clase_MyDB')
		diccionario.pop('tab_acciones')
		diccionario.pop('mae_usuarios')
		return diccionario

	#buscador de algun dato de la tabla 
	def buscar_dato(self):

		try:
			query = 'SELECT * FROM "LOG_ACCIONES_USUARIO" WHERE  log_id = %s'
			datos = (self.log_id,)
			version = self.clase_MyDB.conectar(query,datos,True)

			if(version[0] == "ok"):
				if(version[1] != False):
					self.log_id = version[1][0][0]
					self.log_usu_id = version[1][0][1]
					self.log_fecha_hora = version[1][0][2]
					self.log_desc = version[1][0][3]
					self.log_acc_id = version[1][0][4]
					self.tab_acciones=TAB_ACCIONES(acc_id=version[1][0][4])
					self.mae_usuarios=MAE_USUARIOS(usu_id=version[1][0][1])
					self.tab_acciones.buscar_dato()
					self.mae_usuarios.buscar_dato()
					dato = ["ok" , " "]
				else:
					dato = ["error" , "No se encontro el LOG_ACCIONES_USUARIO con ese ID"]
			else:
				dato = ["error", version[1]] 
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			dato = [
				"error",
				str(e)
				+ " - "
				+ str(exc_type)
				+ " - "
				+ str(fname)
				+ " - "
				+ str(exc_tb.tb_lineno),
			]
		finally:            
			return dato

	#devuelve la lista segun los datos indicados y el numero de pagina
	@staticmethod
	def consultar_lista(numero_pag,cantidad_pag):

		try:
			query = 'SELECT * FROM "LOG_ACCIONES_USUARIO" order by log_fecha_hora LIMIT %s OFFSET %s'
			datos = (cantidad_pag,(numero_pag-1)*cantidad_pag)
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)

			query = 'SELECT SUM(1) FROM "LOG_ACCIONES_USUARIO" '
			datos = ()
			clase_MyDB = MyDB()
			version2 = clase_MyDB.conectar(query,datos,True)

			if (version[0] == "ok" and version2[0] == "ok"):
				if (version[1]!=False):
					lista = {} 
					lista["num_registros"]=version2[1][0][0]
					lista2 = []
					for accion in version[1]:
						data = {}
						acciones = LOG_ACCIONES_USUARIO.from_list(accion)
						data.update(acciones.get_diccionario())
						lista2.append(data)
					lista["lista"]=lista2
				else:
					lista = {}
					lista["result"] = "failed"
					lista["error"] = "Sucedio un error"
					lista["error_cod"] = 400
					lista["val_errors"] = "Lista vacia"
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 400
				lista["val_errors"] = version[1]
		except Exception as e:
			lista = {}
			lista["Error"] = str(e)
		finally:
			return lista

	#se guarda el dato en la tabla de log acciones usuarios
	def guardar_dato(self):
		try:
			query = 'INSERT INTO "LOG_ACCIONES_USUARIO" (log_usu_id,log_desc,log_acc_id) VALUES (%s,%s,%s) RETURNING log_id'
			datos = (self.log_usu_id,self.log_desc,self.log_acc_id,)
			version = self.clase_MyDB.conectar(query, datos, False)
			if version[0] == "ok":
				self.log_id = version[1][0][0]
				dato = ["ok", " "]
			else:
				dato = ["error", version[1]]#"Error al guardar en el Log"]
		except Exception as e:
			dato = ["error", str(e)]
		finally:
			return dato

	#devuelve la lista segun los datos indicados, numero del id del usuario y el numero de pagina
	@staticmethod
	def consultar_lista_usu_id(numero_pag,cantidad_pag,usu_id):
	#SELECT * FROM "LOG_ACCIONES_USUARIO" WHERE log_usu_id = 1 order by log_fecha_hora LIMIT 10 OFFSET 1;
		try:
			query = 'SELECT * FROM "LOG_ACCIONES_USUARIO" WHERE log_usu_id = %s order by log_fecha_hora LIMIT %s OFFSET %s'
			datos = (usu_id,cantidad_pag,(numero_pag-1)*cantidad_pag)
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)

			query = 'SELECT SUM(1) FROM "LOG_ACCIONES_USUARIO" WHERE log_usu_id = %s'
			datos = (usu_id,)
			clase_MyDB = MyDB()
			version2 = clase_MyDB.conectar(query,datos,True)

			if (version[0] == "ok" and version2[0] == "ok"):
				if (version[1]!=False):
					lista = {} 
					lista["num_registros"]=version2[1][0][0]
					lista2 = []
					for accion in version[1]:
						#if (str(type(accion)) != "<class 'int'>"):

						data = {}
						acciones = LOG_ACCIONES_USUARIO.from_list(accion)
						data.update(acciones.get_diccionario())
						lista2.append(data)
					lista["lista"]=lista2
				else:
					lista = {}
					lista["result"] = "failed"
					lista["error"] = "Sucedio un error"
					lista["error_cod"] = 400
					lista["val_errors"] = "Lista vacia"
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 400
				lista["val_errors"] = str(version) +" ******** "+ str(version2)
		except Exception as e:
			lista = {}
			lista["Error"] = str(e)
		finally:
			return lista

	#devuelve la lista segun los datos indicados, numero del id de la accion y el numero de pagina
	@staticmethod
	def consultar_lista_acc(numero_pag,cantidad_pag,acc_id):
	#SELECT * FROM "LOG_ACCIONES_USUARIO" WHERE log_usu_id = 1 order by log_fecha_hora LIMIT 10 OFFSET 1;
		try:
			query = 'SELECT * FROM "LOG_ACCIONES_USUARIO" WHERE log_acc_id = %s order by log_fecha_hora LIMIT %s OFFSET %s'
			datos = (acc_id,cantidad_pag,(numero_pag-1)*cantidad_pag)
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)

			query = 'SELECT SUM(1) FROM "LOG_ACCIONES_USUARIO" WHERE log_acc_id = %s'
			datos = (acc_id,)
			clase_MyDB = MyDB()
			version2 = clase_MyDB.conectar(query,datos,True)

			if (version[0] == "ok" and version2[0] == "ok"):
				if (version[1]!=False):
					lista = {} 
					lista["num_registros"]=version2[1][0][0]
					lista2 = []
					for accion in version[1]:
						data = {}
						acciones = LOG_ACCIONES_USUARIO.from_list(accion)
						data.update(acciones.get_diccionario())
						lista2.append(data)
					lista["lista"]=lista2
				else:
					lista = {}
					lista["result"] = "failed"
					lista["error"] = "Sucedio un error"
					lista["error_cod"] = 400
					lista["val_errors"] = "Lista vacia"
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 400
				lista["val_errors"] = version[1]
		except Exception as e:
			lista = {}
			lista["Error"] = str(e)
		finally:
			return lista

	#devuelve la lista segun los datos indicados, numero del id de la accion y el numero de pagina
	@staticmethod
	def consultar_lista_fecha(numero_pag,cantidad_pag,fecha_ini,fecha_fin):
	#SELECT * FROM "LOG_ACCIONES_USUARIO" WHERE log_usu_id = 1 order by log_fecha_hora LIMIT 10 OFFSET 1; < y > 
		try:
			query = 'SELECT * FROM "LOG_ACCIONES_USUARIO" WHERE log_fecha_hora >= %s AND log_fecha_hora <= %s order by log_fecha_hora LIMIT %s OFFSET %s'
			datos = (fecha_ini,fecha_fin,cantidad_pag,(numero_pag-1)*cantidad_pag)
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)

			query = 'SELECT SUM(1) FROM "LOG_ACCIONES_USUARIO" WHERE log_acc_id = %s AND log_fecha_hora >= %s AND log_fecha_hora <= %s'
			datos = (fecha_ini,fecha_fin,)
			clase_MyDB = MyDB()
			version2 = clase_MyDB.conectar(query,datos,True)

			if (version[0] == "ok" and version2[0] == "ok"):
				if (version[1]!=False):
					lista = {} 
					lista["num_registros"]=version2[1][0][0]
					lista2 = []
					for accion in version[1]:
						data = {}
						acciones = LOG_ACCIONES_USUARIO.from_list(accion)
						data.update(acciones.get_diccionario())
						lista2.append(data)
					lista["lista"]=lista2
				else:
					lista = {}
					lista["result"] = "failed"
					lista["error"] = "Sucedio un error"
					lista["error_cod"] = 400
					lista["val_errors"] = "Lista vacia"
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 400
				lista["val_errors"] = version[1]
		except Exception as e:
			lista = {}
			lista["Error"] = str(e)
		finally:
			return lista

	@staticmethod
	def consultar_lista_filtro(numero_pag,cantidad_pag,usu_id,acc_id,fecha_ini,fecha_fin):
	#SELECT * FROM "LOG_ACCIONES_USUARIO" WHERE log_usu_id = 1 order by log_fecha_hora LIMIT 10 OFFSET 1; < y > 
		try:	
			if fecha_fin == "" or fecha_fin == None :
				fecha_fin = str(datetime.date.today())
			if fecha_ini == "" or fecha_ini == None :
				fecha_ini = "2000-01-02"
			if acc_id == "" or acc_id == None :
				query = 'SELECT * FROM "LOG_ACCIONES_USUARIO" WHERE log_usu_id = COALESCE(%s,log_usu_id) AND log_fecha_hora >= COALESCE(%s,log_fecha_hora) AND log_fecha_hora <= COALESCE(%s,log_fecha_hora) order by log_fecha_hora LIMIT %s OFFSET %s'
				datos = (usu_id,fecha_ini,fecha_fin,cantidad_pag,(numero_pag-1)*cantidad_pag)
				clase_MyDB = MyDB()
				version = clase_MyDB.conectar(query,datos,True)

				query = 'SELECT SUM(1) FROM "LOG_ACCIONES_USUARIO" WHERE log_usu_id = COALESCE(%s,log_usu_id) AND log_fecha_hora >= %s AND log_fecha_hora <= %s'
				datos = (usu_id,fecha_ini,fecha_fin,)
				clase_MyDB = MyDB()
				version2 = clase_MyDB.conectar(query,datos,True)				
			else:
				query = 'SELECT * FROM "LOG_ACCIONES_USUARIO" WHERE log_usu_id = COALESCE(%s,log_usu_id) AND log_acc_id = COALESCE(%s,log_acc_id) AND log_fecha_hora >= COALESCE(%s,log_fecha_hora) AND log_fecha_hora <= COALESCE(%s,log_fecha_hora) order by log_fecha_hora LIMIT %s OFFSET %s'
				datos = (usu_id,acc_id,fecha_ini,fecha_fin,cantidad_pag,(numero_pag-1)*cantidad_pag)
				clase_MyDB = MyDB()
				version = clase_MyDB.conectar(query,datos,True)

				query = 'SELECT SUM(1) FROM "LOG_ACCIONES_USUARIO" WHERE log_usu_id = COALESCE(%s,log_usu_id) AND log_acc_id = COALESCE(%s,log_acc_id) AND log_fecha_hora >= %s AND log_fecha_hora <= %s'
				datos = (usu_id,acc_id,fecha_ini,fecha_fin,)
				clase_MyDB = MyDB()
				version2 = clase_MyDB.conectar(query,datos,True)

			if (version[0] == "ok" and version2[0] == "ok"):
				if (version[1]!=False):
					lista = {} 
					lista["num_registros"]=version2[1][0][0]
					lista2 = []
					for accion in version[1]:
						data = {}
						acciones = LOG_ACCIONES_USUARIO.from_list(accion)
						data.update(acciones.get_diccionario())
						lista2.append(data)
					lista["lista"]=lista2
				else:
					lista = {}
					lista["result"] = "failed"
					lista["error"] = "Sucedio un error"
					lista["error_cod"] = 400
					lista["val_errors"] = "Lista vacia"
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 400
				lista["val_errors"] = version[1]
		except Exception as e:
			lista = {}
			lista["Error"] = str(e)
		finally:
			return lista

	#iniciza los datos con un array
	@staticmethod
	def from_list(lista):
		acciones = LOG_ACCIONES_USUARIO(
			log_id = lista[0],
			log_usu_id = lista[1], 
			log_fecha_hora = lista[2], 
			log_desc = lista[3], 
			log_acc_id = lista[4]
		)
		return acciones