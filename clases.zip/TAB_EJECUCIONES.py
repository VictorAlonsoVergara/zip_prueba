import psycopg2
import sys
from MAE_CRON import MAE_CRON
from MAT_TIPO_OBJ import MAT_TIPO_OBJ
import logging
import datetime
import os
from MyDB import MyDB
#clase que gestiona las ejecuciones

class TAB_EJECUCIONES:
	#se inicializa
	def __init__(
		self,
		eje_id = None,
		eje_fecha = None,
		cron_id = None,
		eje_fecha_ini = None,
		eje_fecha_fin = None,
		eje_log = None,
		eje_fecha_transferencia = None,
		eje_fecha_parseo = None  
	):

		self.eje_id = eje_id  # serial
		self.eje_fecha = eje_fecha  # datetime timestamp with time zone
		self.cron_id = cron_id  # integer
		self.eje_fecha_ini = eje_fecha_ini  # datetime timestamp with time zone
		self.eje_fecha_fin = eje_fecha_fin  # datetime timestamp with time zone
		self.eje_log = eje_log  # varchar(50)
		self.eje_fecha_transferencia = eje_fecha_transferencia  # datetime timestamp with time zone 
		self.eje_fecha_parseo = eje_fecha_parseo  # datetime timestamp with time zone
		self.mae_cron = MAE_CRON(cron_id= cron_id)
		if cron_id is not None:
			self.mae_cron.buscar_dato()

		# si bSelect es False delete ,update ,insert si es True select
		self.clase_MyDB = MyDB()

	#devuelve datos importantes de las ejecuciones
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		if self.eje_fecha is not None:
			diccionario['eje_fecha'] = self.eje_fecha.strftime("%Y-%m-%d %H:%M:%S")#convierto a string para que pueda convertirlo a JSON
		if self.eje_fecha_ini is not None:
			diccionario['eje_fecha_ini'] = self.eje_fecha_ini.strftime("%Y-%m-%d %H:%M:%S")#convierto a string para que pueda convertirlo a JSON
		if self.eje_fecha_fin is not None:
			diccionario['eje_fecha_fin'] = self.eje_fecha_fin.strftime("%Y-%m-%d %H:%M:%S")#convierto a string para que pueda convertirlo a JSON
		if self.eje_fecha_transferencia is not None:
			diccionario['eje_fecha_transferencia'] = self.eje_fecha_transferencia.strftime("%Y-%m-%d %H:%M:%S")#convierto a string para que pueda convertirlo a JSON
		if self.eje_fecha_parseo is not None:
			diccionario['eje_fecha_parseo'] = self.eje_fecha_parseo.strftime("%Y-%m-%d %H:%M:%S")#convierto a string para que pueda convertirlo a JSON
		diccionario['cron'] = {}
		diccionario['cron'].update(self.mae_cron.get_diccionario())
		diccionario['cron'].pop('protocolo')
		diccionario['cron'].pop('tipo_objeto')
		diccionario.pop('clase_MyDB')
		diccionario.pop('mae_cron')
		return diccionario

	#Metodo para obtener la tupla que se usara en el metodo guardar
	def _get_insert_tuple(self):
		return (self.cron_id,self.eje_fecha_ini,self.eje_fecha_fin,self.eje_log,self.eje_fecha_transferencia,self.eje_fecha_parseo,)
	#Metodo para obtener la tupla que se usara en el metodo modificar
	def _get_update_tuple(self):
		return (self.cron_id,self.eje_fecha_ini,self.eje_fecha_fin,self.eje_log,self.eje_fecha_transferencia,self.eje_fecha_parseo,self.eje_id,)

	# guarda los datos en la tabla de ejecuciones
	def guardar_dato(self):
		try:
			query = 'INSERT INTO "TAB_EJECUCIONES" (cron_id,eje_fecha_ini,eje_fecha_fin,eje_log,eje_fecha_transferencia,eje_fecha_parseo) VALUES (%s,%s,%s,%s,%s,%s) RETURNING eje_id '
			datos = self._get_insert_tuple()
			version = self.clase_MyDB.conectar(query, datos, False)

			if version[0] == "ok":
				self.eje_id = version[1][0][0]
				dato = ["ok", ""]
			else:
				dato = ["error", "Error en la base de datos"]

		except psycopg2.DatabaseError as e:
			dato = ["error", str(e)]
			print(f"Error {e}")
			exc_type, exc_obj, exc_tb = sys.exc_info()
			#print(exc_type, fname, exc_tb.tb_lineno)
		except Exception as e:
			dato = ["error",str(e)]
			#print(exc_type, fname, exc_tb.tb_lineno)
		finally:
			return dato

	#busca los datos de la tabla ejecuciones
	def buscar_dato(self):
		try:
			query = 'SELECT * FROM "TAB_EJECUCIONES" WHERE eje_id = %s'
			datos = (self.eje_id,)
			version = self.clase_MyDB.conectar(query, datos, True)

			if version[0] == "ok":
				if version[1] != False:
					self.eje_fecha = version[1][0][1] # datetime timestamp with time zone
					self.cron_id = version[1][0][2]  # integer
					self.eje_fecha_ini = version[1][0][3] # datetime timestamp with time zone
					self.eje_fecha_fin = version[1][0][4] # datetime timestamp with time zone
					self.eje_log = version[1][0][5]  # varchar(50)
					self.eje_fecha_transferencia = version[1][0][6] # datetime timestamp with time zone
					self.eje_fecha_parseo = version[1][0][7] # datetime timestamp with time zone
					self.mae_cron = MAE_CRON(cron_id=self.cron_id)
					self.mae_cron.buscar_dato()
					dato = ["ok", ""]
				else:
					dato = ["error", "No se encontro la ejecucion con ese ID"]
			else:
				dato = ["error", "Error con la base de datos"]

		except psycopg2.DatabaseError as e:
			dato = ["error", str(e)]
			print(f"Error {e}")
		except:
			dato = ["error", str(e)]
		finally:
			
			return dato

	#consulta la lista de la tabla de ejecuciones
	@staticmethod
	def consultar_lista():
		try:
			query = 'SELECT * FROM "TAB_EJECUCIONES" ORDER BY eje_id'
			datos = ()
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query, datos, True)

			if version[0] == "ok":
				if version[1]!=False:
					lista = []
					for indicadores in version[1]:
						data = {}
						ejecuciones = TAB_EJECUCIONES.from_list(indicadores)
						data.update(ejecuciones.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista['result'] = 'failed'
					lista['error'] = 'Sucedio un error'
					lista['error_cod'] = 411
					lista['val_errors'] = 'Lista vacia'
			else:
				lista = {}
				lista['result'] = 'failed'
				lista['error'] = 'Sucedio un error'
				lista['error_cod'] = 411
				lista['val_errors'] = version[1]

		except Exception as e:
			lista = {}
			lista['result'] = 'failed'
			lista['error'] = 'Sucedio un error'
			lista['error_cod'] = 411
			lista['val_errors'] = e 
		finally:
			return lista

	#modifica los datos de la tabla ejecuciones
	def modificar(self):
		try:
			query = ('UPDATE "TAB_EJECUCIONES" SET  '
						'cron_id=  COALESCE(%s,cron_id),'
						'eje_fecha_ini= COALESCE(%s,eje_fecha_ini),'
						'eje_fecha_fin= COALESCE(%s,eje_fecha_fin),'
						'eje_log = COALESCE(%s,eje_log),'
						'eje_fecha_transferencia = COALESCE(%s,eje_fecha_transferencia),'
						'eje_fecha_parseo = COALESCE(%s,eje_fecha_parseo) '
						'WHERE eje_id = %s ')
			datos = self._get_update_tuple()
			respu = self.clase_MyDB.conectar(query, datos, False)

			if respu[0] == "ok":
				lista = ["ok", " "]
			else:
				lista = ["error", "Error en la base de datos"]
		except psycopg2.DatabaseError as e:

			lista = ["error", str(e)]

		except Exception as e:

			lista = ["error", str(e)]
		else:

			lista = ["ok", " "]
		finally:
			return lista

	#se borra el dato seleccionado de la tabla ejecuciones
	def borrar(self):
		try:
			query = 'DELETE FROM "TAB_EJECUCIONES" WHERE eje_id= %s'
			datos = (self.eje_id,)
			respu = self.clase_MyDB.conectar(query, datos, False)

			if respu[0] == "ok":
				lista = {}
				lista["result"] = "ok"
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 505
				lista["val_errors"] = "Error en la base de datos"

		except psycopg2.DatabaseError as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 505
			lista["val_errors"] = str(e)

		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 505
			lista["val_errors"] = str(e)
		else:
			lista = {}
			lista["result"] = "ok"
		finally:
			return lista

	#crea la clase dcon un array
	@staticmethod
	def from_list(lista):
		ejecuciones = TAB_EJECUCIONES(
			eje_id = lista[0],
			eje_fecha = lista[1],
			cron_id = lista[2],
			eje_fecha_ini = lista[3],
			eje_fecha_fin= lista[4],
			eje_log = lista[5],
			eje_fecha_transferencia = lista[6],
			eje_fecha_parseo =lista[7]
		)
		return ejecuciones

	#crea la clase dcon un json
	@staticmethod
	def from_json(json):
		ejecuciones = TAB_EJECUCIONES()
		diccio = vars(ejecuciones)
		for key,value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			diccio[key] = value
		return ejecuciones
