import pandas
# lector de excel
class Reader:   
    def __init__(self,filename):
        self.__data_excel = pandas.read_excel("data/%s"%filename)

    def get_column(self,column_header):
        return self.__data_excel[column_header].tolist()