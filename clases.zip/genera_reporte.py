import psycopg2
#from psycopg2 import pool
import sys , os
import datetime
import configuracionParametros
from pyreportjasper import JasperPy
import logging

#clase que interactua directamente con la base de datos
class genera_reporte:
	#se inicializa
	#"t.usu_estado = 'A'"
	#"Blank_A4_Landscape."
	def __init__(self,usuario_creador=None,filtro=None,reporte=None,tipo=None,tabla=None):
		self.usuario_creador = usuario_creador
		self.filtro = filtro
		self.reporte = reporte
		self.tipo = tipo
		self.tabla = tabla
		logging.error("*********** "+filtro+" **********")
		if reporte == "usuario general":
			self.template = "formato_usuarios."
		elif reporte == "reporte area":
			self.template = "repo_area."   #condicionador (area_id)
		elif reporte == "reporte consultas":
			if tipo == 'csv' or tipo == 'xlsx' or tipo == 'xml':
				self.template = "repo_consultas_ex." # condicionador (t.con_id)
			else:
				self.template = "repo_consultas." # condicionador (t.con_id)
		elif reporte == "reporte marca":
			self.template = "repo_marca." # condicionador (marca_id)
		elif reporte == "reporte modelo":
			self.template = "repo_modelo." # condicionador (t.mod_id)
		elif reporte == "reporte tipo objeto":
			self.template = "repo_tipo_obj." # condicionador (tobj_id)
		elif reporte == "reporte usuario especifico":
			self.template = "repo_usu_esp." # condicionador (t.usu_id)
		elif reporte == "reporte objeto":
			if tipo == 'csv' or tipo == 'xlsx' or tipo == 'xml':
				self.template = "repo_obj_ex." # condicionador (tobj_id)
			else:
				self.template = "repo_obj." # condicionador (tobj_id)
		elif reporte == "reporte acciones usuarios":
			self.template = "acciones_usuarios."
		elif reporte == "reporte crons":
			self.template = "crons."
		elif reporte == "reporte definiciones reportes":
			self.template = "definiciones_reportes."
		elif reporte == "reporte ejecuciones":
			self.template = "ejecuciones."
		elif reporte == "reporte tipo usuario":######
			self.template = "repo_tipo_usu."
		elif reporte == "reporte usuario menu":
			self.template = "repo_usu_menu."
		elif reporte == "reporte arbol acceso":
			self.template = "repo_arb_acc."
		elif reporte == "reporte usuario alerta":
			self.template = "repo_usu_aler."
		elif reporte == "reporte de reportes":
			self.template = "repo_reportes."
		elif reporte == "reporte idiomas":
			self.template = "repo_idi."
		elif reporte == "reporte objeto fisico":
			self.template = "repo_obj_fis."
		elif reporte == "reporte objeto logico":
			self.template = "repo_obj_log."
		elif reporte == "reporte server pull":
			self.template = "repo_serv_pull."
		elif reporte == "reporte usuario reportes":
			self.template = "repo_usu_rep."
		else:
			self.template = ""


	def compiling(self):
		#input_file = "/home/sistema/report_input/"+str(self.template)+"jrxml"
		input_file = os.path.dirname(os.path.abspath(__file__)) +'/report_input/'+str(self.template)+'jrxml'#str(self.template)+"jrxml"
		jasper = JasperPy()
		jasper.compile(input_file)


	def processing(self):
		#input_file = "/home/sistema/report_input/"+str(self.template)+"jrxml"
		input_file = os.path.dirname(os.path.abspath(__file__)) +'/report_input/'+str(self.template)+'jrxml'#hello_world.jrxml'
		#logging.error("-------------------------"+str(input_file))
		#str(self.template)+"jrxml"

		output="/home/sistema/report_output/"

		con = {
			'driver': 'postgres',
			'username': 'cotener',
			'password': 'cotener',
			'host': '127.0.0.1',
			'database': 'cotener',
			'schema': 'public',
			'port': '35432'
		}


		jasper = JasperPy()
		#rtf es gigantesco
		#pdf OK
		#html lo genera en un solo file todo
		#xhtml lo genera en un solo file todo
		#csv OK
		#ods OK (excel de libreoffice)
		#odt OK (word de libreoffice)
		#docx ok
		#xlsx ok
		#xml ok
		jasper.process(input_file, output_file=output, db_connection=con, format_list=[self.tipo],
			parameters={"Parameter1":self.usuario_creador,
			"Parameter2":self.tabla,
			"Parameter3":"fecha de emision: "+str(datetime.date.today()),
			"Parameter4":str(self.filtro)})
		#jasper.process(input_file, output_file=output, format_list=["pdf"])

	def parametros(self):
		#input_file = "/home/sistema/report_input/"+str(self.template)+"jrxml"
		input_file = os.path.dirname(os.path.abspath(__file__)) +'/report_input/'+str(self.template)+'jrxml'#str(self.template)+"jrxml"
		jasper = JasperPy()
		output = jasper.list_parameters(input_file)
		#print(output)

	def cambio_nombre(self):
		precad = str(datetime.datetime.today()).replace(":","t")
		precad2 = precad.split('.')[0]
		precad1 = ''.join(e for e in str(self.usuario_creador) if e.isalnum())
		precad3 = ''.join(e for e in str(self.reporte) if e.isalnum())
		cadena = precad1+'_'+precad3+str(precad2)+'.'+str(self.tipo)
		cadena2 = cadena.replace(" ","_")
		os.rename(r'home/sistema/report_output/'+str(self.template)+str(self.tipo),r'home/sistema/report_output/'+cadena2)
		return 'home/sistema/report_output/'+cadena2
		#f = open('home/sistema/report_output/'+str(self.usuario_creador)+'_'+str(datetime.datetime.today())+'.'+str(self.tipo),'wb')

