import psycopg2
import sys , os
import datetime
import logging 
from MyDB import MyDB
from TAB_PROTOCOLO import TAB_PROTOCOLO
from MAE_MARCAS import MAE_MARCAS
from MAE_MODELO import MAE_MODELO
from MAT_TIPO_OBJ import MAT_TIPO_OBJ
from MAE_CRON import MAE_CRON
rutalog="/home/sistema/log/Traxium"
#la clase consultas que se realizaran a los dispositivos
class MAE_CONSULTAS :

	#inicializa
	def __init__(self,con_desc=None,con_estado=None,
					prot_id=None,con_trama_pregunta=None,
					marca_id=None,mod_id=None,
					con_id=None,con_respuesta=None,
					tobj_id = None, cron_id = None):
		self.con_id = con_id #serial
		self.con_desc = con_desc #varchar(100)
		self.con_estado = con_estado #char(1)
		self.prot_id = prot_id #char(1)
		self.con_trama_pregunta = con_trama_pregunta #varchar(500)
		self.marca_id = marca_id #varchar(500)
		self.mod_id = mod_id #varchar(500)
		self.con_respuesta = con_respuesta #varchar(500)
		self.tobj_id = tobj_id #integer
		self.cron_id = cron_id #integer
		#si bSelect es False delete,update,insert si es True select
		self.tab_protocolo = TAB_PROTOCOLO(prot_id)
		self.tab_protocolo.buscar_dato()
		self.mae_marcas = MAE_MARCAS(marca_id=marca_id)
		self.mae_marcas.buscar_dato()
		self.mae_modelo = MAE_MODELO(mod_id=mod_id)
		self.mae_modelo.buscar_dato()
		self.mat_tobj = MAT_TIPO_OBJ(tobj_id=tobj_id)
		self.mat_tobj.buscar_dato()
		self.mae_cron = MAE_CRON(cron_id = cron_id)
		self.clase_MyDB = MyDB()

	#devuelve informacion importante de la consulta
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		diccionario['protocolo'] = {}
		diccionario['protocolo'].update(self.tab_protocolo.get_diccionario())
		diccionario['modelo'] = {}
		diccionario['modelo'].update(self.mae_modelo.get_diccionario())
		diccionario['modelo'].pop('tipo_obj')
		diccionario['modelo'].pop('marca')
		diccionario['marca'] = {}
		diccionario['marca'].update(self.mae_marcas.get_diccionario())
		diccionario['tipo_objeto'] = {}
		diccionario['tipo_objeto'].update(self.mat_tobj.get_diccionario())
		diccionario['cron'] = {}
		diccionario['cron'].update(self.mae_cron.get_diccionario())
		diccionario.pop('clase_MyDB')
		diccionario.pop('mae_marcas')
		diccionario.pop('mae_modelo')
		diccionario.pop('tab_protocolo')
		diccionario.pop('mat_tobj')
		diccionario.pop('mae_cron')
		return diccionario

	#guarda los datos en la tabla de la base de datos
	def guardar_dato(self):
		try:
			query = ('INSERT INTO "MAE_CONSULTAS" (con_desc,con_estado,'
						'prot_id,con_trama_pregunta,'
						'marca_id,mod_id,con_respuesta,'
						'tobj_id,cron_id) '
						'VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING con_id')
			datos =(self.con_desc,self.con_estado,
						self.prot_id,self.con_trama_pregunta,
						self.marca_id,self.mod_id,
						self.con_respuesta,self.tobj_id,self.cron_id)
			version = self.clase_MyDB.conectar(query,datos,False)
			if version[0] == 'ok':
				self.con_id = version[1][0][0]
				dato = ['ok',' ']
			else:
				dato = ['error',str(version[1])]
		except psycopg2.DatabaseError as e:
			dato = ['error',str(e)]
		except Exception as e:						
			dato = ['error',str(e)]
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:			
			return dato

	#busca un dato de la tabla consultas
	def buscar_dato(self):
		try:
			query ="""SELECT * FROM "MAE_CONSULTAS" WHERE con_id = %s AND con_estado= 'A'"""
			datos =(self.con_id,)
			version = self.clase_MyDB.conectar(query,datos,True)		
			if (version[0] == 'ok'):
				if (version[1]!= False):
					self.con_desc = version[1][0][1] #varchar(100)
					self.con_estado = version[1][0][2] #char(1)
					self.prot_id = version[1][0][3] #char(1)
					self.con_trama_pregunta = version[1][0][4] #varchar(500)
					self.marca_id = version[1][0][5] #varchar(100)
					self.mod_id = version[1][0][6] #char(1)
					self.con_respuesta = version[1][0][7] #char(1)
					self.tobj_id = version[1][0][8] #integer
					self.cron_id = version[1][0][9] #integer
					self.tab_protocolo = TAB_PROTOCOLO(prot_id=self.prot_id)
					self.tab_protocolo.buscar_dato()
					self.mae_marcas = MAE_MARCAS(marca_id=self.marca_id)
					self.mae_marcas.buscar_dato()
					self.mae_modelo = MAE_MODELO(mod_id=self.mod_id)
					self.mae_modelo.buscar_dato()
					self.mat_tobj = MAT_TIPO_OBJ(tobj_id=self.tobj_id)
					self.mat_tobj.buscar_dato()
					self.mae_cron = MAE_CRON(cron_id = self.cron_id)
					self.mae_cron.buscar_dato()
					dato = ['ok',' ']
				else:
					dato = ['error', 'No se encontro la consulta con ese ID']
			else:
				dato = ['error', str(version[1])]
		
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			dato = [
				"error",
				str(e)
				+ " - "
				+ str(exc_type)
				+ " - "
				+ str(fname)
				+ " - "
				+ str(exc_tb.tb_lineno),
			]           
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:			
			return dato

	#consulta la lista de la tabla consultas que se encuentren activadas
	@staticmethod
	def consultar_lista():
		try:
			query = 'SELECT * FROM "MAE_CONSULTAS" WHERE con_estado= %s ORDER BY con_id'
			datos = ('A',)
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)
			if (version[0]=='ok'):
				if version[1]!=False:
					lista = []
					for usu in version[1]:
						data = {}
						obj_consulta = MAE_CONSULTAS.from_lista(usu)
						data.update(obj_consulta.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista['result'] = 'nodata'
					lista['message'] = 'Lista vacia'
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error "
				lista["error_cod"] = 401
				lista['val_errors']=version[1]
		
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]			
			lista = {}
			lista['Error'] = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)             
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:			
			return lista

	#modifica un dato de la tabla de consultas
	def modificar(self):
		try:
			query = ('UPDATE "MAE_CONSULTAS" SET con_desc = COALESCE(%s,con_desc),'
					'con_estado = COALESCE(%s,con_estado),'
					'prot_id = COALESCE(%s,prot_id),'
					'con_trama_pregunta = COALESCE(%s,con_trama_pregunta),'
					'marca_id = COALESCE(%s,marca_id),'
					'mod_id = COALESCE(%s,mod_id),con_respuesta = COALESCE(%s,con_respuesta), '
					'tobj_id = COALESCE(%s,tobj_id),cron_id = COALESCE(%s,cron_id)'
					'WHERE con_id = %s')
			datos = (self.con_desc,self.con_estado,
						self.prot_id,self.con_trama_pregunta,
						self.marca_id,self.mod_id,
						self.con_respuesta,
						self.tobj_id,self.cron_id,self.con_id)
			respu = self.clase_MyDB.conectar(query,datos,False)
			
			if respu[0] == 'ok':
				lista = ['ok',' ']
				#self.tab_protocolo = TAB_PROTOCOLO(prot_id=self.prot_id)
				self.tab_protocolo.buscar_dato()
				#self.mae_marcas = MAE_MARCAS(marca_id=self.marca_id)
				self.mae_marcas.buscar_dato()
				#self.mae_modelo = MAE_MODELO(mod_id=self.mod_id)
				self.mae_modelo.buscar_dato()
				self.mat_tobj.buscar_dato()
				self.mae_cron.buscar_dato()
			else:
				lista = ['error',str(respu[1])]
		except psycopg2.DatabaseError as e:
			lista = ['error',str(e)]
		except Exception as e:
			lista = ['error',str(e)]
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		else:
			lista = ['ok',' ']
		finally:			
			return lista

	#borra un dato de la tabla consultas
	def borrar(self):
		try:
			query = 'DELETE FROM "MAE_CONSULTAS" WHERE con_id= %s'
			datos = (self.con_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)
			if (respu[0] == 'ok'):
				lista = {}
				lista['result']='ok'#+str(respu)
			else:
				lista = {}
				lista['result']='failed'
				lista['error']='Sucedio un error'
				lista['error_cod']=505
				lista['val_errors']=respu[1]
		except psycopg2.DatabaseError as e:
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]			
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)                 
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		else:
			lista = {}
			lista['result']='ok'
		finally:			
			return lista

	#Metodo para buscar una lista de consultas de acuerdo con cualquier valor que se haya puesto en la clase
	def buscar_lista(self):
		try:
			query = ('SELECT * FROM "MAE_CONSULTAS" WHERE '
						'(con_desc = COALESCE(%s,con_desc) OR con_desc is NULL) AND'
						'(con_estado = COALESCE(%s,con_estado) OR con_estado is NULL) AND'
						'(prot_id = COALESCE(%s,prot_id) OR prot_id is NULL) AND'
						'(con_trama_pregunta = COALESCE(%s,con_trama_pregunta) OR con_trama_pregunta is NULL) AND'
						'(marca_id = COALESCE(%s,marca_id) OR marca_id is NULL) AND'
						'(mod_id = COALESCE(%s,mod_id) OR mod_id is NULL)')
			datos = (self.con_desc,self.con_estado,self.prot_id,self.con_trama_pregunta,self.marca_id,self.mod_id,)
			resultados = self.clase_MyDB.conectar(query,datos,True)
			if (resultados[0]=='ok'):
				lista = []
				for usu in resultados[1]:
					data = {}
					obj_con = MAE_CONSULTAS.from_lista(usu)
					data.update(obj_con.get_diccionario())
					lista.append(data)
			else:
				lista = {}
				lista['error']=str(resultados[1])
		except psycopg2.DatabaseError as e:
			lista = {}
			lista['error']=str(e)
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]			
			lista = {}
			lista['error'] = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)            
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:			
			return lista

	#inicializa la clase con un array
	@staticmethod
	def from_lista(lista):
		consulta = MAE_CONSULTAS(
			con_id=lista[0],
			con_desc= lista[1],
			con_estado= lista[2],
			prot_id= lista[3],
			con_trama_pregunta= lista[4],
			marca_id= lista[5],
			mod_id= lista[6],
			con_respuesta=lista[7],
			tobj_id=lista[8],
			cron_id=lista[9]
		)
		return consulta

	#inicializa la clase con un json
	@staticmethod
	def from_json(json):
		consulta = MAE_CONSULTAS()
		diccio = vars(consulta)
		for key,value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			diccio[key] = value
		return consulta