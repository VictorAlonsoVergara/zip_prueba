import psycopg2
import sys , os
import logging
import datetime
from MyDB import MyDB
from TAB_MENU import TAB_MENU
from MAE_USUARIOS import MAE_USUARIOS
rutalog="/home/sistema/log/Traxium"
#clase que se gestiona el menu de los usuarios
class MAE_USUARIOS_MENU :
	#se inicializa
	def __init__(self,umenu_id=None,usu_id=None,menu_id=None, estado_umenu=None):
		self.umenu_id = umenu_id #integer
		self.usu_id = usu_id #integer
		self.menu_id = menu_id #integer
		self.estado_umenu= estado_umenu # boolean
		self.tab_menu=TAB_MENU(menu_id=menu_id)
		self.mae_usuarios=MAE_USUARIOS(usu_id=usu_id)
		if menu_id is not None:
			self.tab_menu.buscar_dato()
		if usu_id is not None:
			self.mae_usuarios.buscar_dato()
		self.clase_MyDB = MyDB()

	#devuelve datos importantes de la clase
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		diccionario['usuario'] = {}
		diccionario['usuario'].update(self.mae_usuarios.get_diccionario())
		diccionario['usuario'].pop('tipo_usuario')
		diccionario['usuario'].pop('idioma')
		diccionario['usuario'].pop('area')
		diccionario['menu'] = {}
		diccionario['menu'].update(self.tab_menu.get_diccionario())
		diccionario.pop("clase_MyDB")
		diccionario.pop("tab_menu")
		diccionario.pop("mae_usuarios")
		return diccionario

	#devuelve datos importantes de la clase
	def get_diccionario2(self):
		diccionario = {}
		diccionario.update(vars(self))
		#diccionario['usuario'] = {}
		#diccionario['usuario'].update(self.mae_usuarios.get_diccionario())
		#diccionario['usuario'].pop('tipo_usuario')
		#diccionario['usuario'].pop('idioma')
		#diccionario['usuario'].pop('area')
		diccionario['menu'] = {}
		diccionario['menu'].update(self.tab_menu.get_diccionario())
		diccionario.pop("clase_MyDB")
		diccionario.pop("tab_menu")
		diccionario.pop("mae_usuarios")
		diccionario.pop("usu_id")
		return diccionario

	#Metodo para obtener la tupla que se usara en el metodo guardar
	def _get_insert_tuple(self):
		return (self.usu_id,self.menu_id,self.estado_umenu,)

	#Metodo para obtener la tupla que se usara en el metodo modificar
	def _get_update_tuple(self):
		return (self.usu_id,self.menu_id,self.estado_umenu,self.umenu_id,)

	#guarda datos en la tabla de usuarios menu
	def guardar_dato(self):
		try:
			query='INSERT INTO "MAE_USUARIOS_MENU" (usu_id,menu_id,estado_umenu) VALUES (%s,%s,%s) RETURNING umenu_id'
			datos = self._get_insert_tuple()
			version = self.clase_MyDB.conectar(query,datos,False)
			if version[0] == 'ok':
				self.umenu_id = version[1][0][0]
				dato = ['ok',' ']
			else:
				dato = ['error','Error en la base de datos']
		except Exception as e:
			dato = ['error',str(e)]
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return dato

	#busca datos de la tabla de usuarios menu
	def buscar_dato(self):
		try:
			datos=(self.umenu_id,)
			query='SELECT * FROM "MAE_USUARIOS_MENU" WHERE umenu_id = %s'
			version = self.clase_MyDB.conectar(query,datos,True)
			if (version[0] == 'ok'):
				if (version[1]!=False):
					self.usu_id = version[1][0][1] #int
					self.menu_id = version[1][0][2] #int
					self.estado_umenu = version[1][0][3] #boolean
					self.tab_menu=TAB_MENU(menu_id=version[1][0][2])
					self.mae_usuarios=MAE_USUARIOS(usu_id=version[1][0][1])
					self.tab_menu.buscar_dato()
					self.mae_usuarios.buscar_dato()
					dato = ['ok',' ']
				else:
					dato = ['error', 'No se encontro un elemento en MAE_USUARIOS_MENU con ese ID']
			else:
				dato = ['error', 'Error con la base de datos']
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			dato = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]              
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return dato

	#se consulta la lista de usuarios menu
	@staticmethod
	def consultar_lista():
		try:
			query = 'SELECT * FROM "MAE_USUARIOS_MENU" ORDER BY umenu_id'
			datos = ()
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query, datos, True)
			if version[0] == "ok":
				if (version[1]!= False):
					lista = []
					for menu in version[1]:
						data = {}
						obj_umen = MAE_USUARIOS_MENU.from_list(menu)
						data.update(obj_umen.get_diccionario())
						lista.append(data)
				else :
					lista = {}
					lista['result'] = 'nodata'
					lista['message'] = 'Lista vacia'
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 412
				lista["val_errors"] = version[1]
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			lista = {}
			lista["error"] = "Sucedio un error"
			lista["result"] = "failed"
			lista["error_cod"] = 412
			lista["val_errors"] = str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)            
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	#modifica los datos del usuario del menu
	def modificar(self):
		try:
			query = ('UPDATE "MAE_USUARIOS_MENU" SET usu_id = COALESCE(%s,usu_id),'
						'menu_id= COALESCE(%s,menu_id), estado_umenu = COALESCE(%s,estado_umenu) WHERE umenu_id = %s')
			datos = self._get_update_tuple()
			respu = self.clase_MyDB.conectar(query, datos, False)
			if respu[0] == "ok":
				lista = ["ok", " "]
				self.tab_menu=TAB_MENU(menu_id=self.menu_id)
				self.mae_usuarios=MAE_USUARIOS(usu_id=self.usu_id)
				self.tab_menu.buscar_dato()
				self.mae_usuarios.buscar_dato()
			else:
				lista = ["error", respu[1]]
		except Exception as e:
			lista = ["error", str(e)]
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	#devuelve informacion del menu de un usuario
	@staticmethod
	def devol_menu(ID):
		try:
			listas = []
			lista = {}
			clase_MyDB = MyDB()
			#query = 'SELECT * FROM "TAB_MENU" '
			#datos=()
			#respu = clase_MyDB.conectar(query,datos,True)
			query = 'SELECT * FROM "MAE_USUARIOS_MENU" WHERE usu_id = %s ORDER BY umenu_id'
			datos=(ID , )
			version = clase_MyDB.conectar(query,datos,True)
			if version[0] == "ok":
				if (version[1]!= False):
					lista = []
					for menu in version[1]:
						data = {}
						obj_umen = MAE_USUARIOS_MENU.from_list(menu)
						data.update(obj_umen.get_diccionario2())
						lista.append(data)
				else :
					lista = {}
					lista["result"] = "failed"
					lista["error"] = "Sucedio un error"
					lista["error_cod"] = 412
					lista["val_errors"] = "Lista vacia"
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 412
				lista["val_errors"] = version[1]			
			#minlist = []
			#if respu2[1] == False :
			#	minlist = []
			#else:
			#	for dat in respu2[1] :
			#		minlist.append(dat[0])

			#for dato in respu[1] :
			#	if dato[0] in minlist:
			#		cad = {}
			#		cad['id'] = dato[0]
			#		cad['activo'] = True
			#		cad['nombre'] = dato[2]
			#		cad['orden'] = dato[3]
			#	else:
			#		cad = {}
			#		cad['id'] = dato[0]
			#		cad['activo'] = False
			#		cad['nombre'] = dato[2]
			#		cad['orden'] = dato[3]
			#	listas.append(cad)
			#lista['result'] = 'ok'
			#lista['menus'] = listas
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)            
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	#edita la tabla del menu
	@staticmethod
	def editar_menu(usu_ID,lista_menu):
		try:
			extra = {}
			clase_MyDB = MyDB()
			lista_datos = lista_menu
			temp = []
			list_respu = []
			descripcion = []

			query= 'SELECT * FROM "TAB_MENU" '
			datos=()
			respu3 = clase_MyDB.conectar(query,datos,True)
			temp2 = []
			nombre = []
			
			for da in respu3[1]:
				temp2.append(da[0])

			for dat in lista_datos :
				if dat in temp2 :
					numero = temp2.index(dat)
					del temp2[numero]

					query= 'SELECT (umenu_id) FROM "MAE_USUARIOS_MENU" WHERE usu_id = %s AND menu_id = %s '
					datos=(usu_ID,dat)
					respu = clase_MyDB.conectar(query,datos,True)
					if (respu[0] == 'ok' and respu[1] != False):
						query= 'UPDATE "MAE_USUARIOS_MENU" SET estado_umenu= %s WHERE umenu_id = %s'
						datos=(True,respu[1][0])
						version = clase_MyDB.conectar(query,datos,False)
					elif (respu[0] == 'ok' and respu[1] == False):
						datos = (usu_ID,dat,True)
						query='INSERT INTO "MAE_USUARIOS_MENU" (usu_id,menu_id,estado_umenu) VALUES (%s,%s,%s)'
						version = clase_MyDB.conectar(query,datos,False)
					else :
						version = ['error','Error al update mae usuarios menu']
					descripcion.append(version[0])
					list_respu.append(version)
					nombre.append(dat)

				else:
					list_respu.append(['error','No existe el ID del menu'])
					descripcion.append('error')
					nombre.append(dat)

			for dat in temp2 :
				query= 'SELECT (umenu_id) FROM "MAE_USUARIOS_MENU" WHERE usu_id = %s AND menu_id = %s '
				datos=(usu_ID,dat)
				respu = clase_MyDB.conectar(query,datos,True)
				if (respu[0] == 'ok' and respu[1] != False):
					query= 'UPDATE "MAE_USUARIOS_MENU" SET estado_umenu= %s WHERE umenu_id = %s'
					datos=(False,respu[1][0])
					version = clase_MyDB.conectar(query,datos,False)
				elif (respu[0] == 'ok' and respu[1] == False):
					datos = (usu_ID,dat,False)
					query='INSERT INTO "MAE_USUARIOS_MENU" (usu_id,menu_id,estado_umenu) VALUES (%s,%s,%s)'
					version = clase_MyDB.conectar(query,datos,False)
				else :
					version = ['error','Error en mae usuarios menu']
				descripcion.append(version[0])
				list_respu.append(version)
				nombre.append(dat)
			
			if 'error' in descripcion :
				resp = ["error", ""]
				num = 0
				for respu in list_respu:
					if respu[0] == 'error':
						extra[nombre[num]] = respu[1]
					num = num + 1
			else:
				resp = ['ok','']
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			resp = ["error",str(e)+" - "+ str(exc_type)+" - "+ str(fname)+" - "+ str(exc_tb.tb_lineno)]             
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)

		linea = {}
		if resp[0] == "ok":
			linea["result"] = "ok"
		else:
			linea["result"] = "failed"
			linea["error"] = "Sucedio un error"
			linea["error_cod"] = 411
			if bool(extra):
				linea["val_errors"] = extra
			else:
				linea["val_errors"] = resp
		return linea

	#se borra datos de la tabla usuarios menu
	def borrar(self):
		try:
			query = 'DELETE FROM "MAE_USUARIOS_MENU" WHERE umenu_id= %s'
			datos = (self.umenu_id,)
			respu = self.clase_MyDB.conectar(query, datos, False)
			if respu[0] == "ok":
				lista = {}
				lista["result"] = "ok"  # +str(respu)
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 505
				lista["val_errors"] = str (respu[1])
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 505
			lista["val_errors"] = str(e)
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	#se crea la clase con un array
	@staticmethod
	def from_list(lista):
		usumen = MAE_USUARIOS_MENU(
			umenu_id = lista[0],
			usu_id = lista[1],
			menu_id=lista[2],
			estado_umenu=lista[3]
		)
		return usumen

	#se crea la clase con un json
	@staticmethod
	def from_json(json):
		umenu = MAE_USUARIOS_MENU()
		dicc_umenu = vars(umenu)
		for key,value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			dicc_umenu[key] = value
		return umenu