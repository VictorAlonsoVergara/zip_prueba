import sys, os
from MyDB import MyDB
import psycopg2

#clase que gestiona tabla de protocolo
class TAB_PROTOCOLO:
	def __init__(self, prot_id=None, prot_desc=None, prot_abreviacion=None):

		self.prot_id = prot_id
		self.prot_desc = prot_desc
		self.prot_abreviacion = prot_abreviacion
		self.db = MyDB()

	#devuelve datos importantes del diccionario
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		diccionario.pop('db')
		return diccionario

	# Metodo para obtener la tupla que se usara en el metodo guardar
	def _get_insert_tuple(self):
		return (self.prot_desc, self.prot_abreviacion)

	# Metodo para obtener a tupla que se usara en el metodo modificar
	def _get_update_tuple(self):
		return (self.prot_desc, self.prot_abreviacion)

	# Metodo para obtener la tupla que se usara en el metodo buscar_lista
	def _get_params_tuple(self):
		return (self.prot_desc, self.prot_abreviacion)

	#busca los datos de la tabla protocolo
	def buscar_dato(self):
		try:
			query = 'SELECT * FROM "TAB_PROTOCOLO" WHERE prot_id = %s'
			datos = (self.prot_id,)
			resultados = self.db.conectar(query, datos, True)
			if resultados[0] is "ok":
				if resultados[1] is not False:
					self.prot_desc = resultados[1][0][1]
					self.prot_abreviacion = resultados[1][0][2]
					dato = ["ok", " "]
				else:
					dato = ["error", "No se encontro el protocolo con ese ID"]
			else:
				dato = [
					"error",
					"Error con la base de datos - este es el prot id = "
					+ str(self.prot_id)
					+ "otros resultados = "
					+ str(resultados),
				]
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			dato = [
				"error",
				str(e)
				+ " - "
				+ str(exc_type)
				+ " - "
				+ str(fname)
				+ " - "
				+ str(exc_tb.tb_lineno),
			]
		finally:
			return dato

	#consulta la lista de la tabla protocolo
	@staticmethod
	def consultar_lista():  # regresa la lista con los datos en la base de datos
		try:
			query = 'SELECT * FROM "TAB_PROTOCOLO" ORDER BY prot_id'
			datos = ()
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query, datos, True)
			# se selecciona todos los datos de la tabla mae usuarios
			if version[0] == "ok":
				if (version[1]!=False):
					lista = []
					for usu in version[1]:
						data = {}
						data["prot_id"] = usu[0]
						data["prot_desc"] = usu[1]
						data["prot_abreviacion"] = usu[2]
						lista.append(data)
				else:
					lista = {}
					lista["result"] = "failed"
					lista["error"] = "Sucedio un error "
					lista["error_cod"] = 412
					lista["val_errors"] = 'Lista vacia'
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error "
				lista["error_cod"] = 412		
				lista["val_errors"] = version[1]
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error "
			lista["error_cod"] = 412
			lista["val_errors"] = str(e)
		finally:
			return lista

	#genera la clase con un json
	@staticmethod
	def from_json(json):
		protocolo = TAB_PROTOCOLO()
		diccio_protocolo = vars(protocolo)
		for key, value in json.items():
			if (type(value) is str):
				if len(value) <= 0:
					value = None
				else:
					pass
			else:
				pass
			diccio_protocolo[key] = value
		return protocolo
