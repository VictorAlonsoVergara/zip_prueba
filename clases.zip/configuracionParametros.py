import datetime
import os
import logging
import sys
import time

rutalog="/home/sistema/log/Traxium"
# se encarga de captar los datos generales de un bloc de notas
try:
	variable = os.listdir(os.getcwd())
	std = 0
	for var in variable :
		if(var == '/home/sistema/clases/parametros.txt'):
			std = std + 1

	if (std == 0):
		f= open("/home/sistema/clases/parametros.txt","w+")
		f.write("COMENTARIO: Escoje el tipo de separador el cual estara entre los datos->(#)  No cambiar el orden de los parametros\n")
		f.write("1 nombre base de datos:	#traxium#\n")
		f.write("2 usuario base de datos:	#traxium#\n")
		f.write("3 clave base de datos:		#traxium#\n")
		f.write("4 largo minimo de clave:		#12#\n")
		f.write("5 cantidad de mayusculas en clave:		#1#\n")
		f.write("6 cantidad de caracteres especiales en clave:		#1#\n")
		f.write("7 cantidad de digitos en clave:		#1#\n")
		f.close()

except Exception as e:
	exc_type, exc_obj, exc_tb = sys.exc_info()
	fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
	datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
	now = datetime.datetime.now()
	fecha= datetime.date.today()
	current_time = now.strftime("%Y-%m-%d %H:%M:%S")
	logger = logging.getLogger('__name__')
	logger.setLevel(logging.ERROR)
	nombre_log= rutalog+'_'+str(fecha)+'.log'
	fh = logging.FileHandler(nombre_log)
	fh.setLevel(logging.ERROR)
	logger.addHandler(fh)
	logger.error("Error: "+str(current_time) + datoError)
	pass
	
except :
	pass

#capta los separadores existentes en el bloc de notas
def captarSeparador():
	f = open("/home/sistema/clases/parametros.txt","r")
	if f.mode == "r":
		contents = f.read()
		partes = contents.split('\n')
	f.close
	numI = partes[0].find("(")
	numF = partes[0].find(")")
	return partes[0][numI+1:numF]

#Se encarga de verificar el dato segun la linea
def captarDatos(num):
	try:
		int_numero = (num*2)

		f = open("/home/sistema/clases/parametros.txt","r")
		if f.mode == "r":
			contents = f.read()
			#print "captar datos $$$$$$$$$$$"
			separador = captarSeparador()
			#print separador
			partes = contents.split(separador)
		f.close
		string = partes[int_numero]

	except Exception as e:
		string = 'Error404'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return string

#busca el dato en linea puesta
def buscarDatoxLinea(numero_de_linea,string):
	try:
		f = open("/home/sistema/clases/parametros.txt","r")
		if f.mode == "r":
			contents = f.read()
			partes = contents.split('\n')
		f.close
		cadena = partes[numero_de_linea]
		indice = cadena.find(string)
		indice2 = cadena.find(str(numero_de_linea))
		devol = 'ok'	
		if(indice == -1):
			devol = 'hay un error'
		elif (indice2 == -1):
			devol = 'hay un error'
		return devol
	except :
		devol = 'hay un error'
		return devol

#dato del nombre de la base de datos
def NombreDataBase():
	try:
		msg = captarDatos(1)
		feedback = buscarDatoxLinea(1,msg)
		if (feedback == 'hay un error'):
			msg= "Error404"
			#raise Exception('error', 'error')
	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]		
		msg = 'Error404'+' '+str(exc_type)+" "+str(fname)+" "+str(exc_tb.tb_lineno)              
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	except :
		msg = 'Error404'
	finally:
		return msg

#el nombre del usuario de la base de datos
def UsuarioDataBase():
	try:
		msg = captarDatos(2)
		feedback = buscarDatoxLinea(2,msg)
		if (feedback == 'hay un error'):
			msg= "Error404"
			#raise Exception('error', 'error')
	except Exception as e:
		msg = 'Error404'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	except :
		msg = 'Error404'
	finally:
		return msg

# la clave del usuario de la base de datos
def ClaveDataBase():
	try:
		msg = captarDatos(3)
		feedback = buscarDatoxLinea(3,msg)
		if (feedback == 'hay un error'):
			msg= "Error404"
			#raise Exception('error', 'error')
	except Exception as e:
		msg = 'Error404'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	except :
		msg = 'Error404'
	finally:
		return msg

#largo minimo de la clave , ya no se usa este metodo
def largoMin():
	try:
		msg = int(captarDatos(4))
		feedback = buscarDatoxLinea(4,str(msg))
		if (feedback == 'hay un error'):
			msg= "Error404"
			#raise Exception('error', 'error')
	except Exception as e:
		msg = 'Error404'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	except :
		msg = 'Error404'
	finally:
		return msg

#cantidad de mayusculas de la clave , ya no se usa
def cantMayus():
	try:
		msg = int(captarDatos(5))
		feedback = buscarDatoxLinea(5,str(msg))
		if (feedback == 'hay un error'):
			msg= "Error404"
			#raise Exception('error', 'error')
	except Exception as e:
		msg = 'Error404'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	except :
		msg = 'Error404'
	finally:
		return msg

#cantidad de caracteres especiales , ya no se usa
def cantCarac():
	try:
		msg = int(captarDatos(6))
		feedback = buscarDatoxLinea(6,str(msg))
		if (feedback == 'hay un error'):
			msg= "Error404"
			#raise Exception('error', 'error')
	except Exception as e:
		msg = 'Error404'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	except :
		msg = 'Error404'
	finally:
		return msg

#cantidad de digitos en la clave , ya no se usa
def cantDig():
	try:
		msg = int(captarDatos(7))
		feedback = buscarDatoxLinea(7,str(msg))
		if (feedback == 'hay un error'):
			msg= "Error404"
			#raise Exception('error', 'error')
	except Exception as e:
		msg = 'Error404'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	except :
		msg = 'Error404'
	finally:
		return msg

#comprobacion de todos los datos
def comprobarDatos():
	try:
		lista = []
		lista.append(NombreDataBase())
		lista.append(UsuarioDataBase())
		lista.append(ClaveDataBase())
		lista.append(largoMin())
		lista.append(cantMayus())
		lista.append(cantCarac())
		lista.append(cantDig())
		
		flag = 'no hay problema'
		i=0
		for cosa in lista :
			i=i+1
			if (cosa == 'Error404'):
				print(i)
				flag = 'hay problema'
				break
	except :
		flag = 'hay problema'
	finally:
		return flag
