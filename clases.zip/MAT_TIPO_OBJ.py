import psycopg2
import sys,os
import logging
import datetime
from MyDB import MyDB
#Clase para tipos de objeto, verificar los parametros de init

class MAT_TIPO_OBJ :
	#se inicializa
	def __init__(
		self,
		tobj_desc = None,
		tobj_estado = None,
		tobj_consulta = None,
		tobj_ldesc = None,
		tobj_padre_id = None,
		tobj_arb_fisico = None,
		tobj_arb_logico = None,
		tobj_pasivo = None,
		tobj_key = None,
		tobj_id = None 
		):

		self.tobj_id = tobj_id #serial
		self.tobj_desc = tobj_desc #varchar(200)
		self.tobj_estado = tobj_estado #char(1)
		self.tobj_consulta = tobj_consulta #char(1)
		self.tobj_ldesc = tobj_ldesc #text
		self.tobj_padre_id = tobj_padre_id #int
		self.tobj_arb_fisico = tobj_arb_fisico #boolean
		self.tobj_arb_logico = tobj_arb_logico #boolean
		self.tobj_pasivo = tobj_pasivo #boolean
		self.tobj_key = tobj_key
		#si bSelect es False delete ,update ,insert si es True select
		self.clase_MyDB = MyDB()

	#devuelve datos importantes de la clase
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		diccionario.pop('clase_MyDB')
		return diccionario

	#Metodo para obtener la tupla que se usara en el metodo guardar
	def _get_insert_tuple(self):
		return (self.tobj_desc,self.tobj_estado,self.tobj_consulta,self.tobj_ldesc,
					self.tobj_padre_id,self.tobj_arb_fisico,self.tobj_arb_logico,self.tobj_pasivo,self.tobj_key,)

	#metodo para obtener la tupla que se usara en guardar dato
	def _get_insert_tuple_null(self):
		return (self.tobj_desc,self.tobj_estado,self.tobj_consulta,self.tobj_ldesc,
					self.tobj_arb_fisico,self.tobj_arb_logico,self.tobj_pasivo,self.tobj_key,)
	
	#metodo para obtener la tupla que se usara en modificar
	def _get_update_tuple(self):
		return (self.tobj_desc,self.tobj_estado,
				self.tobj_consulta,self.tobj_ldesc,str(self.tobj_arb_fisico),
				str(self.tobj_arb_logico),str(self.tobj_pasivo),self.tobj_key,self.tobj_id,)

	#metodo para obtener la tupla que se usara en modificar
	def _get_update_tuple2(self):
		return (self.tobj_desc,self.tobj_estado,self.tobj_consulta,self.tobj_ldesc,
				self.tobj_padre_id,str(self.tobj_arb_fisico),str(self.tobj_arb_logico),
				str(self.tobj_pasivo),self.tobj_key,self.tobj_id,)

	def _get_params_tuple(self):
		pass 

	#guarda los datos en tabla de tipo objeto
	def guardar_dato(self):
		try:
			if (self.tobj_padre_id!="NULL"):
				query = 'INSERT INTO "MAT_TIPO_OBJ" (tobj_desc,tobj_estado,tobj_consulta,tobj_ldesc, tobj_padre_id,tobj_arb_fisico,tobj_arb_logico,tobj_pasivo,tobj_key) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING tobj_id'
				datos = self._get_insert_tuple()
			else:
				query = 'INSERT INTO "MAT_TIPO_OBJ" (tobj_desc,tobj_estado,tobj_consulta,tobj_ldesc, tobj_padre_id,tobj_arb_fisico,tobj_arb_logico,tobj_pasivo,tobj_key) VALUES (%s,%s,%s,%s,NULL,%s,%s,%s,%s) RETURNING tobj_id'
				datos = self._get_insert_tuple_null()

			version = self.clase_MyDB.conectar(query,datos,False)
			if (version[0] == 'ok'):
				self.tobj_id = version[1][0][0]
				dato = ['ok','']
			else:
				dato = ['error',version[1]] #+ str(version[1])]
		except Exception as e:
			dato = ['error',str(e)]
		finally:
			return dato

	#busca datos con el id del tipo objeto
	def buscar_dato(self):
		try:
			query = """SELECT * FROM "MAT_TIPO_OBJ" WHERE tobj_id = %s AND tobj_estado='A' """
			datos = (self.tobj_id,)
			version = self.clase_MyDB.conectar(query,datos,True)			
			if (version[0] == 'ok'):
				if (version[1] != False):
					self.tobj_desc = version[1][0][1] #varchar(200)
					self.tobj_estado = version[1][0][2] #char(1)
					self.tobj_consulta = version[1][0][3] #char(1)
					self.tobj_ldesc = version[1][0][4] #text
					self.tobj_padre_id = version[1][0][5] #int
					self.tobj_arb_fisico = version[1][0][6] #boolean
					self.tobj_arb_logico = version[1][0][7] #boolean
					self.tobj_pasivo = version[1][0][8] #boolean
					self.tobj_key = version[1][0][9] #varchar de 10
					dato = ['ok', ' ']
				else:
					dato = ['error', 'No se encontro el tipo de objeto con ese ID']
			else:
				dato = ['error', version[1]]
		except psycopg2.DatabaseError as e:
			dato = ['error',str(e)]
		except Exception as e:
			dato = ['error',str(e)]
		finally:			
			return dato

	#validacion antes de crear
	@staticmethod
	def validations_crear(tobj_padre_id):
		try:
			if (tobj_padre_id == "NULL"):
				dato = [True,'ok']
			else:
				datos=(tobj_padre_id,)
				query='SELECT * FROM "MAT_TIPO_OBJ" WHERE tobj_id = %s'
				clase_MyDB = MyDB()
				version = clase_MyDB.conectar(query,datos,True)
				if (version[1]!=False): #ya existe 
					dato = [True,'ok']
				else:
					dato = [False,'No existe un tipo de objeto con ese tobj_padre_id']
		except Exception as e:
			dato = [False,str(e)]
		finally:
			return dato

	#consulta la lista de la tabla de tipo objeto
	@staticmethod
	def consultar_lista():
		try:
			query = """SELECT * FROM "MAT_TIPO_OBJ" WHERE tobj_estado='A' ORDER BY tobj_id """
			datos = ( )
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)
			if (version[0] == 'ok'):
				if (version[1]!=False):
					lista = []
					for tobj in version[1]:
						data = {}
						tipo_obj = MAT_TIPO_OBJ.from_list(tobj)##########
						data.update(tipo_obj.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista["result"] = "failed"
					lista["error"] = "Sucedio un error"
					lista["error_cod"] = 412
					lista["val_errors"] = "Lista vacia"
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 412
				lista["val_errors"] = version[1]	
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 412
			lista["val_errors"] = str(e)
		finally:			
			return lista

	#validacion de antes de borrar
	@staticmethod
	def validations_borrar(tobj_id):
		try:
			query='SELECT * FROM "MAT_TIPO_OBJ" WHERE tobj_padre_id = %s'
			datos= (tobj_id,)
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)
			if (version[0] == 'ok'):
				if (version[1]!=False): #existe 
					dato = [False,'No se puede eliminar un tobj_padre']
				else:
					dato = [True,'ok']
		except Exception as e:
			dato = [False,str(e)]
		finally:
			return dato

	#modifica el dato del tipo objeto
	def modificar(self):
		try:
			if self.tobj_padre_id != 'NULL':
				tobj_aux = MAT_TIPO_OBJ(tobj_id=self.tobj_padre_id)
				dict_padres = tobj_aux.buscar_padres()
				if dict_padres['result'] == 'failed':
					lista = ['error',dict_padres['val_errors']]
					return lista
				lista_padres = dict_padres['listas']
				pass_flag = True
				for objeto in lista_padres:
					try:
						id_padre = objeto['padre']
						if id_padre == self.tobj_id:
							pass_flag = False
							break
					except Exception:
						pass
				if pass_flag is False:
					lista = ['error','Referencia circular encontrada, escoja otro id de padre']
					return lista

			if ((self.tobj_padre_id)!="NULL"):
				query = ('UPDATE "MAT_TIPO_OBJ" SET tobj_desc = COALESCE(%s,tobj_desc),'
						'tobj_estado = COALESCE(%s,tobj_estado),'
						'tobj_consulta = COALESCE(%s,tobj_consulta),'
						'tobj_ldesc = COALESCE(%s,tobj_ldesc),'
						'tobj_padre_id = COALESCE(%s,tobj_padre_id),'
						'tobj_arb_fisico = COALESCE(%s,tobj_arb_fisico),'
						'tobj_arb_logico = COALESCE(%s,tobj_arb_logico),'
						'tobj_pasivo = COALESCE(%s,tobj_pasivo), '
						'tobj_key = COALESCE(%s,tobj_key) '
						'WHERE tobj_id = %s')
				datos = self._get_update_tuple2()			
			else:
				#query = 'UPDATE "MAT_TIPO_OBJ" SET tobj_desc = %s , tobj_estado = %s , tobj_consulta = %s , tobj_ldesc = %s, tobj_padre_id = NULL, tobj_arb_fisico = %s, tobj_arb_logico = %s, tobj_pasivo = %s  WHERE tobj_id = %s'
				query = ('UPDATE "MAT_TIPO_OBJ" SET tobj_desc = COALESCE(%s,tobj_desc),'
						'tobj_estado = COALESCE(%s,tobj_estado),'
						'tobj_consulta = COALESCE(%s,tobj_consulta),'
						'tobj_ldesc = COALESCE(%s,tobj_ldesc),'
						'tobj_padre_id = NULL,'
						'tobj_arb_fisico = COALESCE(%s,tobj_arb_fisico),'
						'tobj_arb_logico = COALESCE(%s,tobj_arb_logico),'
						'tobj_pasivo = COALESCE(%s,tobj_pasivo), '
						'tobj_key = COALESCE(%s,tobj_key) '
						'WHERE tobj_id = %s')
				datos = self._get_update_tuple()
			
			respu = self.clase_MyDB.conectar(query,datos,False)

			if (respu[0] == 'ok'):
				lista = ['ok', str(respu)]
			else:
				lista = ['error', respu[1]]
		except psycopg2.DatabaseError as e:
			lista = ['error',str(e)]
		except Exception as e:
			lista = ['error',str(e)]
		else:
			lista = ['ok',' ']
		finally:
			return lista

	#borra dato de la tabla tipo objeto
	def borrar(self):
		try:
			query = 'DELETE FROM "MAT_TIPO_OBJ" WHERE tobj_id= %s'
			datos = (self.tobj_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)
			if (respu[0] == 'ok'):
				lista = {}
				lista['result'] = 'ok'
			else:
				lista = {}
				lista['result'] = 'failed'
				lista['error'] = 'Sucedio un error'
				lista['error_cod']= 412
				lista['val_errors']=respu[1]
		except psycopg2.DatabaseError as e:
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)
		except Exception as e:
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)      
		finally:			
			return lista

	#borra una rama enterade tipos objetos
	def borrar_rama(self):
		try:
			function = 'call borrar_rama_tipo_objeto(%s,%s)'
			params = (self.tobj_id,[],)
			resultado = self.clase_MyDB.conectar(function,params,True)
			respuesta = {}
			if resultado[0] == 'ok':
				if resultado[1] is not False:
					respuesta['result'] = 'ok'
					respuesta['listas'] = resultado[1][0][0]
				else:
					respuesta['result'] = 'failed'
					respuesta['error'] = 'Sucedio un error'
					respuesta['error_cod'] = 501
					respuesta['val_errors'] = 'No se encontro elementos'
			else:
				respuesta['result'] = 'failed'
				respuesta['error'] = 'Sucedio un error'
				respuesta['error_cod'] = 502
				respuesta['val_errors'] = 'Error en la base de datos ' + str(resultado)
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			respuesta = {}
			respuesta['result']='failed'
			respuesta['error']='Sucedio un error'
			respuesta['error_cod']=505
			respuesta['val_errors']=str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)
		finally:
			return respuesta

	#busca a los hijos del tipo de objeto seleccionado
	def buscar_hijos(self):
		result_buscar = self.__execute_buscar('buscar_hijos_tipo_objeto')
		return result_buscar

	#busca a los padres del tipo de objeto seleccionado
	def buscar_padres(self):
		result_buscar = self.__execute_buscar('buscar_padres_tipo_objeto')
		return result_buscar

	#execution para buscar a un tipo objeto
	def __execute_buscar(self,function):
		try:
			funct = function
			datos = [self.tobj_id]
			resultado = self.clase_MyDB.execute_procedure(funct,datos)
			result_lista = []
			if resultado[0] == 'ok':
				if resultado[1] is not False:
					#if resultado[1][0][1] == None :
					#	respuesta = {}
					#	respuesta['result'] = 'failed'
					#	respuesta['error'] = 'Sucedio un error'
					#	respuesta['cod'] = 502
					#	respuesta['val_errors'] = 'Error en la base de datos '+ str(resultado)						
					for nodos in resultado[1]:
						data = {}
						data['padre'] = nodos[1]
						data['hijo'] = nodos[0]
						if nodos[1] != None :
							result_lista.append(data)
					respuesta = {}
					respuesta['result'] = 'ok'
					respuesta['listas'] = result_lista
					#respuesta['listas completa'] = resultado
				else:
					respuesta = {}
					respuesta['listas'] = ''
					respuesta['result'] = 'failed'
					respuesta['error'] = 'Sucedio un error'
					respuesta['error_cod'] = 501
					respuesta['val_errors'] = 'No se obtuvo resultados'
			else:
				respuesta = {}
				respuesta['result'] = 'failed'
				respuesta['error'] = 'Sucedio un error'
				respuesta['error_cod'] = 502
				respuesta['val_errors'] = 'Error en la base de datos '+ str(resultado)
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			respuesta = {}
			respuesta['result']='failed'
			respuesta['error']='Sucedio un error'
			respuesta['error_cod']=503
			respuesta['val_errors']=str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)
		finally:
			return respuesta

	# busca a los hermanos del tipo objeto
	def buscar_hermanos(self):
		try:
			flag = False
			listas = []
			cad = {}
			cad["hijo"] = self.tobj_id
			
			listas.append(cad)
			temp = self.tobj_id
			query = 'SELECT (tobj_padre_id) FROM "MAT_TIPO_OBJ" WHERE tobj_id = %s'
			datos = (temp,)
			respu3 = self.clase_MyDB.conectar(query,datos,True)
			if (respu3[0]=='ok' and respu3[1] != False ):
				cad = {}
				cad["padre"] = respu3[1][0][0]
				listas.append(cad)
				temp = respu3[1][0][0]
				query = 'SELECT (tobj_id) FROM "MAT_TIPO_OBJ" WHERE tobj_padre_id = %s AND tobj_id != %s'
				datos = (temp,self.tobj_id,)
				respu2 = self.clase_MyDB.conectar(query,datos,True)
				if (respu2[0]=='ok' ):
					if (respu2[1]!=False):
						cad = {}
						temporal = []
						for re in respu2[1] :
							temporal.append(re[0])
						cad["hermanos"] = temporal						
						listas.append(cad)
						#listas = respu2[1]
						respu = ['ok',' ']
					else:
						listas = "No tiene hermanos el Id seleccionado"
						respu = ['ok','error']
				else:
					listas = "Sucedio un error buscando a los hijos"
					respu = ['ok','error']
			else:
				listas = "No existe un hijo con ese Id"
				respu = ['error','No existe un hijo con ese Id']

			if (respu[0] == 'ok'):
				lista = {}

				lista['result']='ok'
				if (respu[1] == 'error'):
					lista['result']='failed'
					lista['error']='Sucedio un error'
					lista['error_cod']=505
					lista['val_errors'] = listas
				else:
					lista['listas'] = listas
			else:
				lista = {}
				lista['result']='failed'
				lista['error']='Sucedio un error'
				lista['error_cod']=505
				lista['val_errors']='Error '+ str(respu[1])	
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)
		finally:
			return lista

	#crea una clase de un array
	@staticmethod
	def from_list(lista):
		tipo_obj = MAT_TIPO_OBJ(
			tobj_id = lista[0],
			tobj_desc = lista[1],
			tobj_estado = lista[2],
			tobj_consulta = lista[3],
			tobj_ldesc = lista[4],
			tobj_padre_id = lista[5],
			tobj_arb_fisico = lista[6],
			tobj_arb_logico = lista[7],
			tobj_pasivo = lista[8],
			tobj_key = lista[9]
		)
		return tipo_obj

	# Crea un tipo objeto de MAT_TIPO_OBJ a partir de un diccionario json,
	# los datos del json deben tener los mismos nombres que en la clase de tipo objeto
	@staticmethod
	def from_json(json):
		tipo_obj = MAT_TIPO_OBJ()
		dicc_tipo_obj = vars(tipo_obj)
		for key, value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			dicc_tipo_obj[key] = value
		return tipo_obj

	