import psycopg2
import configuracionParametros
from MyDB import MyDB
import sys,os 
import logging
import datetime
#clase que gestiona las valdiaciones
rutalog="/home/sistema/log/Traxium"
#valida si existe el id de la tabla mae objetos consultas
def id_Mae_Obj_Con(obj_id,con_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(con_id) FROM "MAE_OBJETOS_CONSULTAS" WHERE con_id = %s and obj_id = %s '
		datos = (con_id,obj_id)
		version = clase_MyDB.conectar(query,datos,True)
		if(version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id
				dato = [True,' '] #'ok'
			else:
				dato = [False,'No existe el objeto - consultas seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#datatype validation
def validate_string(data):
	words  = str(data) 
	try:
		number = int(words)
		#print('Solo esta permitido cadenas y usted ha ingresado un numero')
		return [False ,'ha ingresado un numero']
	except ValueError:
		pass   

	lenght = len(data) 
	for i in range(lenght):
		try:
			character = int(words[i])
			#print('Todos los caracteres de la data deben ser letras y no numeros')
			return [False,'se encontro un numero como caracter']
		except ValueError:
		# print('todo ok con el caracter ')
			continue

	return [True,'ok']

#valida que el dato sea varchar
def validate_varchar(data,maximum_length):
	words = str(data) 
	try:
		number = int(words)
		#print('Solo esta permitido cadenas y usted ha ingresado un numero')
		return [False ,'ha ingresado un numero']
	except ValueError:
		pass

	lenght = len(data) 
	if (lenght > maximum_length ):
		#print('La longitud de la entrada no debe ser mayor a {}'.format(maximum_length))
		return [False,'Sobrepaso longitud maxima de '+str(maximum_length)]

	return [True,'ok']

#valida que el dato sea boolean
def validate_boolean(data):
	words=data
	
	try:
		number = int(words)
		#print('Solo esta permitido cadenas y usted ha ingresado un numero')
		if (number is 0 or number is 1):
			return [True ,'boolean']
		
		return [False ,'ha ingresado un numero']
	except ValueError:
		return [False ,'No es boolean'] 

#valida que el dato sea int
def validate_int(data):
	try:
		number = int(data)  
		return [True,'ok']
	except ValueError:
		return [False,'No es un numero entero']
		#string= str(data)
		#if (len(string)==0):
		#	return [True,"ok"]
		#else:
		#	return[False,"No es doble comilla"]

#valida que el dato sea un char
def validate_char(data):
	words  = str(data) 
	try:
		number = int(words)
		#print('Solo esta permitido cadenas y usted ha ingresado un numero')
		return [False,'Ha ingresado un numero']
	except ValueError:
		pass   
		#print('La entrada {} no se pudo convertir a int'.format(words))
	#largo del input
	lenght = len(data) 
	if (lenght > 1):
		return [False,'Sobrepaso la longitud de 1']
	return [True,'ok']

#valida que el dato tenga el formato correcto de date time
def validate_date_time(data):
	fecha = str(data)
	try:
		int(fecha)
		return [False,'Ha ingresado un numero']
	except ValueError:
		pass
	#1999-01-08 04:05:06-8:00     #formato xxxx-xx-xx xx:xx:xx-x:xx 

	if len(fecha)>=15:
		formato = "-- ::" # 
		a = fecha[4] + fecha[7] + fecha[10] + fecha[13] + fecha[16]
	elif(len(fecha)>=8):
		formato = "--" # 
		a = fecha[4] + fecha[7]
	else:
		formato="a"
		a ="b"
	#utc = fecha[19]
	if (a == formato) :#and (utc == "+" or utc == "-"):

		return [True,'ok']
	else:
		return [False,'Formato no valido']

#valida que el dato sea un dato numerico
def validate_numeric(num,size,decimal):
    try:
        num_str = str(num)
        float(num_str)
        if len(num_str) > (size+1):
            return [False,"Numero demasiado grande"]
        dot_pos = num_str.find('.')
        ent = num_str[:dot_pos]
        if len(ent) > (size-decimal):
            return [False,"Parte entera demasiado grande"]
        if dot_pos != -1:
            dec = num_str[dot_pos+1:]
            if len(dec) > decimal:
                return [False, "Parte decimal demasiado grande"]
        return [True,"ok"]
    except Exception:
        return [False,"No se ingreso un numero decimal"]

#valida si el dato es dato vacio
def validate_empty(data):
	string= str(data)
	if (len(string)==0):
		return [True,"Campo vacio"]
	else:
		return[False,"Campo no vacio"]

#valida que el id de la tabla mae tipo usu exista
def id_Tipo_Usu(tusu_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(tusu_id) FROM "MAE_TIPO_USU" WHERE tusu_id = %s'
		datos = (tusu_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if (version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id 
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el tipo de usuario seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato 

#valida que el id del mae usuarios existe
def id_Mae_Usu(usu_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(usu_id) FROM "MAE_USUARIOS" WHERE usu_id = %s'
		datos = (usu_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if (version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id 
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el usuario seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'			
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato     

#valida que el id del tipo objeto exista
def id_Tipo_Obj(tobj_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(tobj_id) FROM "MAT_TIPO_OBJ" WHERE tobj_id = %s'
		datos = (tobj_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if (version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el tipo de objeto seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'			
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato 

#valida que el id del mae consultas existe
def id_Consultas(con_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(con_id) FROM "MAE_CONSULTAS" WHERE con_id = %s'
		datos = (con_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if (version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el id_consultas seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'	
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que el id del mae objetos exista
def id_Mae_Obj(obj_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(obj_id) FROM "MAE_OBJETOS" WHERE obj_id = %s'
		datos = (obj_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0]=='ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo obj_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el objeto seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
		
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que el id del mae cron exista
def id_Mae_Cron(cron_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(cron_id) FROM "MAE_CRON" WHERE cron_id = %s'
		datos = (cron_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if (version[0]=='ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id 
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el cron seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato     

#valida que el id de tab reportes exista
def id_Tab_Rep(rep_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(rep_id) FROM "TAB_REPORTES" WHERE rep_id = %s'
		datos = (rep_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0] == 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id 
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el reporte seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que el id de tab ejecuciones exista
def id_Tab_Eje (eje_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(eje_id) FROM "TAB_EJECUCIONES" WHERE eje_id = %s'
		datos = (eje_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0] == 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo eje_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe TAB_EJECUCIONES seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que el id del tab protocolo exista
def id_Tab_Prot (prot_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(prot_id) FROM "TAB_PROTOCOLO" WHERE prot_id = %s'
		datos = (prot_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0] == 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo eje_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe TAB_PROTOCOLO seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que id del tab menu exista
def id_Tab_Menu (menu_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(menu_id) FROM "TAB_MENU" WHERE menu_id = %s'
		datos = (menu_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0] == 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo eje_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe TAB_MENU seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valdia que el id de mae usu accesos reportes exista
def id_Mae_Usu_Accesos_Reportes (urep_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(urep_id) FROM "MAE_USU_ACCESOS_REPORTES" WHERE urep_id = %s'
		datos = (urep_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if (version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id 
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el usuario accesos reportes seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'			
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato   

#valida que el id de mae usuarios alertas exista
def id_Mae_Usu_Aler (rep_id,usu_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(rep_id) FROM "MAE_USUARIOS_ALERTAS" WHERE rep_id = %s AND usu_id = %s'
		datos = (rep_id,usu_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0]=='ok':
			if (version[1][0][0]!=0): #ya existe 
				dato = [True,'ok']
			else:
				dato = [False,'No existe MAE_USUARIOS_ALERTAS con esos id']
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)]
	except Exception as e:
		dato = [False,str(e)]
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida  que le id de mae usu accesos arboles
def id_Mae_Usu_Acc_Arb (uarb_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(uarb_id) FROM "MAE_USU_ACCESOS_ARBOLES" WHERE uarb_id = %s'
		datos = (uarb_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0]=='ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo uarb_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,"No existe MAE_USU_ACCESOS_ARBOLES seleccionado"] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que el id de arb fisico exista 
def id_Arb_Fis (fis_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(fis_id) FROM "ARB_FISICO" WHERE fis_id = %s'
		datos = (fis_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if version[0] == 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo uarb_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,"No existe fis_id seleccionado"] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que el id de arbol logico exista
def id_Arb_Log (log_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(log_id) FROM "ARB_LOGICO" WHERE log_id = %s'
		datos = (log_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if version[0]== 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo uarb_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,"No existe log_id seleccionado"] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que el di de mae area exista
def id_Mae_Area (area_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(area_id) FROM "MAE_AREA" WHERE area_id = %s'
		datos = (area_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if version[0]== 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo uarb_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,"No existe  el area seleccionado"] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que el id de mae idiomas exista
def id_Mae_Idiomas (idi_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(idi_id) FROM "MAE_IDIOMAS" WHERE idi_id = %s'
		datos = (idi_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if version[0]== 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo uarb_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,"No existe  el idioma seleccionado"] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que el id de mae servers_pull exista
def id_Mae_Servers_Pull (serv_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(serv_id) FROM "MAE_SERVERS_PULL" WHERE serv_id = %s'
		datos = (serv_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if version[0]== 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo uarb_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,"No existe el servidor seleccionado"] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que el id de mae marcas exista
def id_Mae_Marcas (marca_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(marca_id) FROM "MAE_MARCAS" WHERE marca_id = %s'
		datos = (marca_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if version[0]== 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo uarb_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,"No existe la marca seleccionada"] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que el id de mae modelo exista
def id_Mae_Modelo (mod_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(mod_id) FROM "MAE_MODELO" WHERE mod_id = %s'
		datos = (mod_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if version[0]== 'ok':
			if version[1][0][0]!=0:# sí existe un dato con el codigo uarb_id
				dato = [True,' '] #'ok'
			else: 
				dato = [False,"No existe el modelo seleccionado"] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que el mae objeto fisico exista
def id_Mae_Obj_Fis(obj_id,fis_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(obj_id) FROM "MAE_OBJETO_FISICO" WHERE obj_id = %s and fis_id = %s '
		datos = (obj_id,fis_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if(version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id
				dato = [True,' '] #'ok'
			else:
				dato = [False,'No existe el objeto - fisico seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que el id de mae objeto logico exista
def id_Mae_Obj_Log(obj_id,log_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(obj_id) FROM "MAE_OBJETO_LOGICO" WHERE obj_id = %s and log_id = %s '
		datos = (obj_id,log_id,)
		version = clase_MyDB.conectar(query,datos,True)
		if(version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id
				dato = [True,' '] #'ok'
			else:
				dato = [False,'No existe el objeto - logico seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que el id de mae usuarios menu exista
def id_Mae_Usu_Menu(umenu_id):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(umenu_id) FROM "MAE_USUARIOS_MENU" WHERE umenu_id = %s'
		datos = (umenu_id,)
		version = clase_MyDB.conectar(query,datos,True)		
		if (version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id 
				dato = [True,' '] #'ok'
			else: 
				dato = [False,'No existe el MAE_USUARIOS_MENU seleccionado'] #'error'
		else:
			dato = [False,'Sucedio un error en la BD'] #'error'			
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato

#valida que el id de param exista
def validate_parametro(grupo,param_id):
	try:
		db = MyDB()
		query = 'SELECT COUNT(param_valor) FROM "PARAM" WHERE param_grupo =%s AND param_id = %s'
		datos = (grupo,param_id,)
		results = db.conectar(query,datos,True)
		if results[0] == 'ok':
			if results[1][0][0] > 0:
				dato = [True,'Existe Parametro']
			else:
				dato = [False,'No existe el parametro ingresado']
		else:
			dato = [False,'Error en la BD al buscar parametros']
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)]
	except Exception as e:
		dato = [False,str(e)]
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato
	
#exception del http
class HttpException(Exception):
	def __init__(self,code,error=None,val_errors=None):
		self.result = "failed"
		self.code = code
		self.message = ""
		self.status_code = ""
		self.error = error
		self.val_errors = val_errors
		self.__get_message()

	def __get_message(self):
		if self.code == 401:
			self.message = "Unauthorized"
		elif self.code == 405:
			self.message = "Method Not Allowed"
		elif self.code == 500:
			self.message = "Internal Server Error"
		elif self.code == 400:
			self.message = "400 Bad Request"
		else:
			self.message = "Not a Http Status Code"
		self.status_code = str(self.code) + " " +self.message
		if self.error is None:
			self.error = self.message
		if self.val_errors is None:
			self.val_errors = self.message

	def get_error_dict(self):
		error_dict = {}
		error_dict.update(vars(self))
		error_dict.pop('status_code')
		error_dict.pop('message')
		return error_dict



#datatype validation
def validate_clave(data):
	try:
		words  = str(data)
		clase_MyDB = MyDB()
		flag_countM = clase_MyDB.conectar('SELECT param_id FROM "PARAM" WHERE param_grupo = %s ',('estado_password_mayus',),True)
		if flag_countM[0] == 'ok' and flag_countM[1] != False :
			flag_countM = flag_countM[1][0][0].split('+') 
		else:
			flag_countM = ['error','error']
		flag_digit = clase_MyDB.conectar('SELECT param_id FROM "PARAM" WHERE param_grupo = %s ',('estado_password_num',),True)
		if flag_digit[0] == 'ok' and flag_digit[1] != False :
			flag_digit = flag_digit[1][0][0].split('+') 
		else:
			flag_digit = ['error','error']
		flag_countC = clase_MyDB.conectar('SELECT param_id FROM "PARAM" WHERE param_grupo = %s ',('estado_password_carac',),True)
		if flag_countC[0] == 'ok' and flag_countC[1] != False :
			flag_countC = flag_countC[1][0][0].split('+') 
		else:
			flag_countC = ['error','error']
		longitud_minima = clase_MyDB.conectar('SELECT param_id FROM "PARAM" WHERE param_grupo = %s ',('longitud_pass',),True)
		if longitud_minima[0] == 'ok' and longitud_minima[1] != False :
			longitud_minima = int(longitud_minima[1][0][0])
		else:
			longitud_minima = 0	

		countM = 0
		digit = 0
		countC = 0
		for c in words:
			if c.isupper():
				countM = countM + 1
			elif c.isnumeric():
				digit = digit + 1
			elif (c=="!") or (c=="#") or (c=="$") or (c=="%") or (c=="&") or (c=="*") or (c=="+") or (c==",") or (c=="-") or (c==".") or (c=="/") or (c==":") or (c==";") or (c=="=") or (c=="?") or (c=="@") or (c=="[") or (c=="]") or (c=="^") or (c=="_") or (c=="{") or (c=="|") or (c=="}") :
				countC = countC + 1
		largoW = len(words)
		#  < >
		#if countM >= configuracionParametros.cantMayus() :
		if flag_countM[0] == "A":
			if countM >= int(flag_countM[1]) :
				flag1 = True
			else :
				return [False,'No tiene la cantidad de Letras mayusculas indicadas :' +str(flag_countM[1])]
				flag1 = False
		else :
			flag1 = True

		if flag_digit[0] == "A":
			if digit >= int(flag_digit[1]) :
				flag2 = True
			else :
				return [False,'No tiene la cantidad de Numeros indicados: ' +str(flag_digit[1])]
				flag2 = False
		else:
			flag2 =  True

		if flag_countC[0] == "A":
			if countC >= int(flag_countC[1]) :
				flag3 = True
			else :
				return [False,'No tiene la cantidad de Caracteres Especiales indicados: ' +str(flag_countC[1])]
				flag3 = False
		else:
			flag3 = True

		if largoW >= 8 and largoW >= longitud_minima:
			flag4 = True
		else :
			if longitud_minima > 8 :
				return [False,'No tiene la cantidad de Caracteres minima: ' +str(longitud_minima)]
			else:
				return [False,'No tiene la cantidad de Caracteres minima: 8']
			flag4 = False

		if (flag1 and flag2 and flag3 and flag4):
			msg = [True,'ok']
		else:
			msg = [False,'error']
		return msg

	except Exception as e :
		return [False,str(e)+" "+str(flag_countM)+" - "+str(flag_countM[1])+" - "+str(flag_countM[1][0])+" - "+str(flag_countM[1][0][0])]

#valida si existe un nombre de usuario parecido
def usu_nombre(usu_nombre):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(usu_nombre) FROM "MAE_USUARIOS" WHERE usu_nombre = %s'
		datos = (usu_nombre,)
		version = clase_MyDB.conectar(query,datos,True)
		if (version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id 
				dato = [False,'Ya existe un nombre igual'] #'ok'
			else: 
				dato = [True,'Nombre disponible'] #'error'
		else:
			dato = [False,version[1]] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato
#valdia si existe un usuario parecido
def usu_usuario(usu_usuario):
	try:
		clase_MyDB = MyDB()
		query = 'SELECT COUNT(usu_usuario) FROM "MAE_USUARIOS" WHERE usu_usuario = %s'
		datos = (usu_usuario,)
		version = clase_MyDB.conectar(query,datos,True)
		if (version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id 
				dato = [False,'Ya existe un usuario igual'] #'ok'
			else: 
				dato = [True,'Usuario disponible'] #'error'
		else:
			dato = [False,version[1]] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato
#valida si existe un correo parecido
def usu_correo(usu_correo):
	try:
		clase_MyDB = MyDB()
		query = """SELECT COUNT(usu_correo) FROM "MAE_USUARIOS" WHERE usu_correo = %s AND usu_estado = 'A' """
		datos = (usu_correo,)
		version = clase_MyDB.conectar(query,datos,True)
		if (version[0] == 'ok'):
			if version[1][0][0]!=0:# sí existe un dato con el codigo tusu_id 
				dato = [False,'Ya existe un correo igual'] #'ok'
			else: 
				dato = [True,'Correo disponible'] #'error'
		else:
			dato = [False,version[1]] #'error'
	except psycopg2.DatabaseError as e:
		dato = [False,str(e)] #'error'
		print(f'Error {e}')
	except Exception as e:
		dato = [False,str(e)] #'error'
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
		datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
		now = datetime.datetime.now()
		fecha= datetime.date.today()
		current_time = now.strftime("%Y-%m-%d %H:%M:%S")
		logger = logging.getLogger('__name__')
		logger.setLevel(logging.ERROR)
		nombre_log= rutalog+'_'+str(fecha)+'.log'
		fh = logging.FileHandler(nombre_log)
		fh.setLevel(logging.ERROR)
		logger.addHandler(fh)
		logger.error("Error: "+str(current_time) + datoError)
	finally:
		return dato
