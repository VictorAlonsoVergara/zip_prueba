import psycopg2
import sys, os
import logging
import datetime
from MyDB import MyDB
rutalog="/home/sistema/log/Traxium"
#clase que gestiona tabla menu
class TAB_MENU:
	def __init__(self, menu_id=None, menu_desc=None, menu_name=None,menu_key=None,menu_padre=None,menu_ruta=None,menu_cssclass=None,menu_ord=None):

		self.menu_id = menu_id  # integer
		self.menu_desc = menu_desc  # varchar(500)
		self.menu_name = menu_name  # varchar(50)
		#self.menu_ord = menu_ord #integer
		self.menu_key = menu_key
		self.menu_padre = menu_padre
		self.menu_ruta = menu_ruta
		self.menu_cssclass = menu_cssclass
		self.menu_ord = menu_ord
		self.clase_MyDB = MyDB()

	#devuelve datos importantes de la tabla menu
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		diccionario.pop('clase_MyDB')
		return diccionario

	# Metodo para obtener la tupla que se usara en el metodo guardar
	def _get_insert_tuple(self):
		return (self.menu_desc, self.menu_name)

	# Metodo para obtener la tupla que se usara en el metodo modificar
	def _get_update_tuple(self):
		return (self.menu_desc, self.menu_name,self.menu_id)

	# Metodo para obtener la tupla que se usara en el metodo buscar_lista
	def _get_params_tuple(self):
		return (self.menu_desc, self.menu_name)

	#busca datos de la tabla de menu
	def buscar_dato(self):
		try:
			datos = (self.menu_id,)
			query = 'SELECT * FROM "TAB_MENU" WHERE menu_id = %s'
			version = self.clase_MyDB.conectar(query, datos, True)
			if version[0] == "ok":
				if version[1] != False:
					self.menu_desc = version[1][0][1]  # varchar(500)
					self.menu_name = version[1][0][2]  # varchar(50)
					self.menu_key = version[1][0][3]
					self.menu_padre = version[1][0][4]
					self.menu_ruta = version[1][0][5]
					self.menu_cssclass = version[1][0][6]
					self.menu_ord = version[1][0][7]
					dato = ["ok", " "]
				else:
					dato = [
						"error",
						"No se encontro un elemento en TAB_MENU con ese ID",
					]
			else:
				dato = ["error", "Error con la base de datos"]
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			dato = [
				"error",
				str(e)
				+ " - "
				+ str(exc_type)
				+ " - "
				+ str(fname)
				+ " - "
				+ str(exc_tb.tb_lineno),
			]               
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return dato

	# consulta la lista de tabla menu
	@staticmethod
	def consultar_lista():
		try:
			query = 'SELECT * FROM "TAB_MENU" ORDER BY menu_id'
			datos = ()
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query, datos, True)
			if version[0] == "ok":
				if version[1] != False:
					lista = []
					for menu in version[1]:
						data = {}
						menu_obj = TAB_MENU.from_list(menu)
						data.update(menu_obj.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista['result'] = 'nodata'
					lista['message'] = 'Lista vacia'
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 412
				lista["val_errors"] = version[1]
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 412
			lista["val_errors"] = e
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	#crea la clase con un array
	@staticmethod
	def from_list(lista):
		menu = TAB_MENU(
			menu_id = lista[0],
			menu_desc = lista[1],
			menu_name = lista[2],
			menu_key = lista[3],
			menu_padre = lista[4],
			menu_ruta = lista[5],
			menu_cssclass = lista[6],
			menu_ord = lista[7]
		)
		return menu

	#crea la clase con un json
	@staticmethod
	def from_json(json):
		menu = TAB_MENU()
		dicc_menu = vars(menu)
		for key, value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
				else:
					pass
			else:
				pass
			dicc_menu[key] = value

		return menu
