import sys , os
import configuracionParametros
import logging

import smtplib
from email.mime.base import MIMEBase
from email import encoders 
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

#clase que wnvia correos

class enviar_correo:

	def __init__(self,receptor=None,nombre_archivo=None,asunto=None,texto=None):
		self.nombre_archivo = nombre_archivo
		self.receptor = receptor
		self.asunto = asunto
		self.texto = texto

	def enviar_archivo(self):
		mail = smtplib.SMTP('smtp.gmail.com', 587)
		mail.ehlo()
		mail.starttls()
		mail.login('redmine@eqsoft.net', 'apesol123456')

		msg = MIMEMultipart('alternative')
		msg['From'] = "redmine@eqsoft.net"
		msg['To'] = self.receptor

		if self.asunto == None:
			self.asunto = "Archivo generado correctamente"
		msg['Subject'] = self.asunto

		if self.texto == None:
			self.texto = "Aqui se encuentra su archivo generado."
		msg_text = self.texto
		msg_html = "<b>" + msg_text + "</b>"

		part1 = MIMEText(msg_text, 'plain', 'utf-8')

		msg.attach(part1)

		filename = self.nombre_archivo
		pathname = "/home/sistema/report_output/%s" % filename
		attachment = open(pathname, "rb")

		p = MIMEBase('application', 'octet-stream')
		p.set_payload((attachment).read())
		encoders.encode_base64(p)
		p.add_header('Content-Disposition', "attachment; filename= %s" % filename)
		msg.attach(p)

		mail.sendmail(msg['From'], msg['To'], msg.as_string())
		mail.quit()
		return 'Se envio correctamente el correo'

