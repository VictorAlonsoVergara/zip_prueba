import psycopg2
import sys
import logging
import datetime
import os
from MyDB import MyDB
rutalog="/home/sistema/log/Traxium"

#esta clase gestiona los idiomas del proyecto
class MAE_IDIOMAS:
	def __init__(self, idi_id=None, idi_desc=None, idi_key=None, idi_estado=None):
		self.idi_id = idi_id  # serial
		self.idi_desc = idi_desc  # varchar(100)
		self.idi_key = idi_key
		self.idi_estado = idi_estado

		self.clase_MyDB = MyDB()

	#devuelve los datos importantes de idiomas
	def get_diccionario(self):
		diccionario = {}
		diccionario.update(vars(self))
		diccionario.pop("clase_MyDB")
		return diccionario

	# Metodo para obtener la tupla que se usara en el metodo guardar
	def _get_insert_tuple(self):
		return (self.idi_desc, self.idi_estado, self.idi_key)

	# Metodo para obtener la tupla que se usara en el metodo modificar
	def _get_update_tuple(self):
		return (self.idi_desc, self.idi_estado, self.idi_key, self.idi_id)

	# Metodo para obtener la tupla que se usara en el metodo buscar_lista
	def _get_params_tuple(self):
		return (self.idi_desc, self.idi_estado, self.idi_key)

	#guarda el dato en la tabla
	def guardar_dato(self):
		try:
			query = 'INSERT INTO "MAE_IDIOMAS" (idi_desc,idi_estado,idi_key) VALUES (%s,%s,%s) RETURNING idi_id'
			datos = self._get_insert_tuple()
			version = self.clase_MyDB.conectar(query, datos, False)
			if version[0] == "ok":
				self.idi_id = version[1][0][0]
				dato = ["ok", " "]
			else:
				dato = ["error", version[1]]
		except Exception as e:
			dato = ["error", str(e)]
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return dato

	#Busca el dato en la tabla que se encuentran activados
	def buscar_dato(self):
		try:
			query = """SELECT * FROM "MAE_IDIOMAS" WHERE idi_id = %s AND idi_estado='A'"""
			datos = (self.idi_id,)
			version = self.clase_MyDB.conectar(query, datos, True)

			if version[0] == "ok":
				if version[1] != False:
					self.idi_desc = version[1][0][1]  # varchar(200)
					self.idi_key = version[1][0][2]  # varchar(200)
					self.idi_estado = version[1][0][3]  # varchar(200)
					dato = ["ok", " "]
				else:
					dato = ["error", "No se encontro el idioma con ese ID"]
			else:
				dato = ["error", version[1]]
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			dato = [
				"error",
				str(e)
				+ " - "
				+ str(exc_type)
				+ " - "
				+ str(fname)
				+ " - "
				+ str(exc_tb.tb_lineno),
			]              
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return dato

	# Metodo para consultar todos los idiomas que se encuentren activados
	@staticmethod
	def consultar_lista():
		try:
			query = """SELECT * FROM "MAE_IDIOMAS" WHERE idi_estado='A' ORDER BY idi_id"""
			datos = ()
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query, datos, True)

			if version[0] == "ok":
				lista = []
				if version[1] != False:
					for idioma in version[1]:
						idioma = MAE_IDIOMAS.from_list(idioma)
						lista.append(idioma.get_diccionario())
				else:
					lista = {}
					lista['result'] = 'nodata'
					lista['message'] = 'Lista vacia'
			else:
				lista = {}
				linea['result'] = "failed"
				linea['error'] = "Sucedio un error"
				linea['error_cod'] = 411
				lista["val_errors"] = version[1]
		except Exception as e:
			lista = {}
			linea['result'] = "failed"
			linea['error'] = "Sucedio un error"
			linea['error_cod'] = 411
			lista["val_errors"] = str(e)
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	# Metodo que modifica un idioma con idi_id,los valores en None no seran modificados
	def modificar(self):
		
		try:
			query = (
				'UPDATE "MAE_IDIOMAS" SET idi_desc = COALESCE(%s,idi_desc),'
				"idi_estado = COALESCE(%s,idi_estado),idi_key = COALESCE(%s,idi_key) WHERE idi_id = %s"
			)
			datos = self._get_update_tuple()
			respu = self.clase_MyDB.conectar(query, datos, False)

			if respu[0] == "ok":
				lista = ["ok", " "]
			else:
				lista = ["error", respu[1]]
		except Exception as e:
			lista = ["error", str(e)]
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	# Metodo para borrar un elemento de la base de datos a partir de un ind_id
	def borrar(self):
		try:
			query = 'DELETE FROM "MAE_IDIOMAS" WHERE idi_id= %s'
			datos = (self.idi_id,)
			respu = self.clase_MyDB.conectar(query, datos, False)

			if respu[0] == "ok":
				lista = {}
				lista["result"] = "ok"  # +str(respu)
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 505
				lista["val_errors"] = respu[1]
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 505
			lista["val_errors"] = str(e)
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	# El metodo crea un objeto a partir de una lista mandada por
	# la base de datos
	@staticmethod
	def from_list(lista):
		idioma = MAE_IDIOMAS(
			idi_id=lista[0], idi_desc=lista[1], idi_key=lista[2], idi_estado=lista[3]
		)
		return idioma

	# Crea un idioma de MAE_IDIOMA a partir de un diccionario json,
	# los datos del json deben tener los mismos nombres que en la clase de idioma
	@staticmethod
	def from_json(json):
		idioma = MAE_IDIOMAS()
		dicc_idioma = vars(idioma)
		for key, value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			dicc_idioma[key] = value
		return idioma
