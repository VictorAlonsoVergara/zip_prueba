import sys,os
import datetime
import logging
import psycopg2
from MyDB import MyDB
rutalog="/home/sistema/log/Traxium"
# clase que gesiotna la tabla de acciones
class TAB_ACCIONES:
	#se inicializa
	def __init__(self,acc_id = None,acc_desc = None):

		self.acc_id = acc_id
		self.acc_desc = acc_desc
		self.clase_MyDB = MyDB()

	#devuelve los dato simportantes de la clase
	def get_diccionario(self):
		diccionario = vars(self)
		diccionario.pop('clase_MyDB')
		return diccionario

	#guarda los datos en la tabla de acciones
	def guardar(self):
		try:
			query = 'INSERT INTO "TAB_ACCIONES" (acc_desc) VALUES (%s) RETURNING acc_id '
			datos = (self.acc_desc,)
			version = self.clase_MyDB.conectar(query,datos,False)

			if (version[0] == "ok"):
				self.acc_id = version[1][0][0]
				dato = ["ok"," "]

			else:
				dato = ["error", "Error en la base de datos"]

		except psycopg2.DatabaseError as e:
			dato = ['error',str(e)]
			print(f'Error {e}')
			exc_type, exc_obj, exc_tb = sys.exc_info()
			#print(exc_type, fname, exc_tb.tb_lineno)			
		except:
			dato = 'error'
			#print(exc_type, fname, exc_tb.tb_lineno)			
		finally:			
			return dato

	#busca datos en la tabla de acciones
	def buscar_dato(self):
		try:
			query = 'SELECT * FROM "TAB_ACCIONES" WHERE  acc_id = %s'
			datos = (self.acc_id,)
			version = self.clase_MyDB.conectar(query,datos,True)

			if(version[0] == "ok"):
				if(version[1] != False):
					self.acc_desc = str(version[1][0][1])
					dato = ["ok" , " "]
				else:
					dato = ["error" , "No se encontro el tab_acciones con ese ID"]
			else:
				dato = ["error", "Error con la base de datos"] 
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			dato = [
				"error",
				str(e)
				+ " - "
				+ str(exc_type)
				+ " - "
				+ str(fname)
				+ " - "
				+ str(exc_tb.tb_lineno),
			]               
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:            
			return dato

	#consulta la lista de las acciones
	@staticmethod
	def consultar_lista():
		try:
			query = 'SELECT * FROM "TAB_ACCIONES" ORDER BY acc_id'
			datos = ()
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)

			if (version[0] == "ok"):
				if (version[1]!=False):
					lista = []
					for accion in version[1]:
						data = {}
						acciones = TAB_ACCIONES.from_list(accion)
						data.update(acciones.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista['result'] = 'nodata'
					lista['message'] = 'Lista vacia'
			else:
				lista = {}
				lista['result'] = 'failed'
				lista['error'] = 'Sucedio un error'
				lista['error_cod'] = 411
				lista['val_errors'] = version[1]
		except Exception as e:
			lista = {}
			lista['result'] = 'failed'
			lista['error'] = 'Sucedio un error'
			lista['error_cod'] = 411
			lista['val_errors'] = str(e)
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	#modifica la tabla de acciones
	def modificar(self):

		try:
			query = 'UPDATE "TAB_ACCIONES" SET acc_desc = COALESCE(%s,acc_desc) WHERE acc_id = %s'
			datos = (self.acc_desc,self.acc_id)

			answer = self.clase_MyDB.conectar(query,datos,False)
			if (answer[0] == "ok"):
				lista = ["ok", " "]
			else:
				lista = ["error","Error en la base de datos"]

		except Exception as e:
			lista = ["error", str(e)]
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	#borra los datos de la tabla acciones
	def borrar(self):

		try:
			query = 'DELETE FROM "TAB_ACCIONES" WHERE acc_id = %s'
			datos = (self.acc_id,)
			answer = self.clase_MyDB.conectar(query,datos,False)

			if (answer[0] == "ok"):
				lista = {}
				lista["result"] = "ok"

			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 505
				lista["val_errors"] = "Error en la base de datos"

		except Exception as e:
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		else:
			lista = {}
			lista["result"] = "ok"
		finally:
			return lista

	#se crea la clase con un array
	@staticmethod
	def from_list(lista):
		acciones = TAB_ACCIONES(
			acc_id = lista[0],
			acc_desc = lista[1]
		)
		return acciones