import psycopg2
import sys , os
import logging
import datetime
from MyDB import MyDB
from ARB_LOGICO import ARB_LOGICO
from MAE_OBJETOS import MAE_OBJETOS
rutalog="/home/sistema/log/Traxium"
#clase que gestiona con objeto logico
class MAE_OBJETO_LOGICO :
	#se inicializa
	def __init__(self,obj_id=None,log_id=None):
	
		self.obj_id = obj_id #integer
		self.log_id = log_id #integer
		self.arb_logico=ARB_LOGICO(log_id=log_id)
		self.mae_objetos = MAE_OBJETOS(obj_id=obj_id)
		self.arb_logico.buscar_dato()
		self.mae_objetos.buscar_dato()		
		self.clase_MyDB = MyDB()
	
	#devuelve datos importantes del objeto logico	
	def get_diccionario(self):
		diccionario = vars(self)
		diccionario['arbol_logico'] = {}
		diccionario['arbol_logico'].update(self.arb_logico.get_diccionario())
		diccionario['objeto'] = {}
		diccionario['objeto'].update(self.mae_objetos.get_diccionario())
		diccionario['objeto'].pop('marca')
		diccionario['objeto'].pop('modelo')
		diccionario['objeto'].pop('protocolo')
		diccionario['objeto'].pop('tipo_obj')
		diccionario.pop('clase_MyDB')
		diccionario.pop('arb_logico')
		diccionario.pop('mae_objetos')
		return diccionario

	# Metodo para obtener la tupla que se usara en el metodo guardar
	def _get_insert_tuple(self):
		return (self.obj_id, self.log_id,)

	#se guarda el dato del objeto logico en la tabla de la base de datos
	def guardar_dato(self):
		try:
			datos = self._get_insert_tuple()
			query='INSERT INTO "MAE_OBJETO_LOGICO" (obj_id,log_id) VALUES (%s,%s)'
			version = self.clase_MyDB.conectar(query,datos,False)
			if version[0] == 'ok':
				dato = ['ok',' ']
			else:
				dato = ['error',version[1]]
			
		except Exception as e:
			dato = ['error',str(e)]
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return dato

	#busca el dato del objeto logico 
	def buscar_dato(self):
		try:
			datos = (self.obj_id,self.log_id,)
			query='SELECT * FROM "MAE_OBJETO_LOGICO" WHERE obj_id = %s AND log_id= %s'
			version = self.clase_MyDB.conectar(query,datos,True)
			if (version[0] == 'ok'):
				if (version[1]!=False):
					self.arb_logico=ARB_LOGICO(log_id=self.log_id)
					self.mae_objetos = MAE_OBJETOS(obj_id=self.obj_id)
					self.arb_logico.buscar_dato()
					self.mae_objetos.buscar_dato()
					dato = ['ok',' ']
				else:
					dato = ['error', 'No se encontro un elemento en ARB_LOGICO con ese ID']
			else:
				dato = ['error', version[1]]
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]				
			dato = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]              
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return dato

	#validacion para crear el objeto logico
	@staticmethod
	def validations_crear(obj_id,log_id):
		try:
			query='SELECT * FROM "MAE_OBJETO_LOGICO" WHERE obj_id =%s AND log_id = %s'
			datos=(obj_id,log_id,)
			clase_MyDB = MyDB()  
			version = clase_MyDB.conectar(query,datos,True)
			if (version[0] == 'ok'):
				if (version[1]!=False): #ya existe 
					dato = [False,'ya existe MAE_OBJETO_LOGICO con esos ID']
				else:
					dato = [True,'ok']
			else:
				dato = ['error', 'Error con la base de datos']
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]				
			dato = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]             
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return dato

	#consulta la lista del objeto fisico
	@staticmethod
	def consultar_lista():
		try:
			query='SELECT * FROM "MAE_OBJETO_LOGICO"'
			datos=()
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)
			if (version[0]=='ok'):
				if (version[1]!=False):
					lista=[]
					for obj in version[1]:
						data = {}
						obj_logico = MAE_OBJETO_LOGICO.from_list(obj)
						data.update(obj_logico.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista['result'] = 'nodata'
					lista['message'] = 'Lista vacia'
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error_cod"] = "Sucedio un error"
				lista["error"] = 412
				lista['val_errors']=version[1]
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error_cod"] = "Sucedio un error"
			lista["error"] = 412
			lista['val_errors'] = str(e)
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	#se modifica los datos de la tabla del objeto logico
	def modificar(self,obj_id,log_id):
		try:
			query = 'UPDATE "MAE_OBJETO_LOGICO" SET obj_id = %s , log_id = %s WHERE obj_id = %s and log_id= %s'
			datos=(obj_id,log_id,self.obj_id,self.log_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)
			if (respu[0]=='ok'):
				lista = ['ok',' ']
				self.obj_id = obj_id
				self.log_id = log_id
				self.arb_logico=ARB_LOGICO(log_id=log_id)
				self.mae_objetos = MAE_OBJETOS(obj_id=obj_id)
				self.arb_logico.buscar_dato()
				self.mae_objetos.buscar_dato()
			else:
				lista = ['error',respu[1]]
		except Exception as e:
			lista = ['error',str(e)]
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	#se borra el dato seleccionado en el objeto logico
	def borrar(self):
		try:
			query = 'DELETE FROM "MAE_OBJETO_LOGICO" WHERE obj_id= %s and log_id = %s'
			datos = (self.obj_id, self.log_id,)
			respu = self.clase_MyDB.conectar(query, datos, False)
			if respu[0] == "ok":
				lista = {}
				lista["result"] = "ok"  # +str(respu)
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error"
				lista["error_cod"] = 505
				lista["val_errors"] = respu[1]
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 505
			lista["val_errors"] = str(e)
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]                
			datoError = str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)
			now = datetime.datetime.now()
			fecha= datetime.date.today()
			current_time = now.strftime("%Y-%m-%d %H:%M:%S")
			logger = logging.getLogger('__name__')
			logger.setLevel(logging.ERROR)
			nombre_log= rutalog+'_'+str(fecha)+'.log'
			fh = logging.FileHandler(nombre_log)
			fh.setLevel(logging.ERROR)
			logger.addHandler(fh)
			logger.error("Error: "+str(current_time) + datoError)
		finally:
			return lista

	# se crea la clase con un array
	@staticmethod
	def from_list(lista):
		obj_logico = MAE_OBJETO_LOGICO(
			obj_id = lista[0],
			log_id = lista[1]
		)
		return obj_logico

	#Crea un objeto de MAE_OBJETO_LOGICO a partir de un diccionario json, los datos del json
	#deben tener los mismos nombres que en la clase objeto_fisico
	@staticmethod
	def from_json(json):
		obj_logico = MAE_OBJETO_LOGICO()
		diccio_obj_logico = vars(obj_logico)
		for key,value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			diccio_obj_logico[key] = value
		return obj_logico
