import psycopg2
import sys, os
import logging
import datetime
from MyDB import MyDB

#clase que gestiona tipo de usuario
class MAE_TIPO_USU:
    def __init__(self, tusu_desc=None, tusu_estado=None, tusu_id=None):
        self.tusu_id = tusu_id  # serial
        self.tusu_desc = tusu_desc  # varchar(200)
        self.tusu_estado = tusu_estado  # char
        # si bSelect es False delete,update,insert si es True select
        self.clase_MyDB = MyDB()

    #devuelve datos importantes de la clase
    def get_diccionario(self):
        diccionario = {}
        diccionario.update(vars(self))
        diccionario.pop("clase_MyDB")
        return diccionario

    # Metodo para obtener la tupla que se usara en el metodo guardar
    def _get_insert_tuple(self):
        return (self.tusu_desc, self.tusu_estado)

    # Metodo para obtener la tupla que se usara en el metodo modificar
    def _get_update_tuple(self):
        return (self.tusu_desc, self.tusu_estado, self.tusu_id)

    # Metodo para obtener la tupla que se usara en el metodo buscar_lista
    def _get_params_tuple(self):
        return (self.tusu_desc, self.tusu_estado)

    #guarda el dato en la tabla de tipo usuario
    def guardar_dato(self):
        try:
            query = (
                'INSERT INTO "MAE_TIPO_USU" (tusu_desc,tusu_estado)'
                " VALUES (%s,%s) RETURNING tusu_id"
            )
            datos = self._get_insert_tuple()
            version = self.clase_MyDB.conectar(query, datos, False)

            if version[0] == "ok":
                self.tusu_id = version[1][0][0]  # version[len(version)-1][0]
                dato = ["ok", " "]
            else:
                dato = ["error", str (version[1])]
        except Exception as e:
            dato = ["error", str(e)]
        finally:
            return dato

    # Metodo para buscar un dato especifico en base al tusu_id
    def buscar_dato(self):
        try:
            query = """SELECT * FROM "MAE_TIPO_USU" WHERE tusu_id = %s AND tusu_estado='A' """
            datos = (self.tusu_id,)
            version = self.clase_MyDB.conectar(query, datos, True)

            if version[0] == "ok":
                if version[1] != False:
                    self.tusu_desc = version[1][0][1]  # varchar(200)
                    self.tusu_estado = version[1][0][2]  # smallint
                    dato = ["ok", " "]
                else:
                    dato = ["error", "No se encontro el tipo de usuario con ese ID"]
            else:
                dato = ["error", str(version[1])]
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            dato = [
                "error",
                str(e)
                + " - "
                + str(exc_type)
                + " - "
                + str(fname)
                + " - "
                + str(exc_tb.tb_lineno),
            ]
        finally:
            return dato

    # Metodo para consultar todos los objetos y devolver una lista con todos
    @staticmethod
    def consultar_lista():
        try:
            query = """SELECT * FROM "MAE_TIPO_USU" WHERE tusu_estado='A' ORDER BY tusu_id"""
            datos = ()
            clase_MyDB = MyDB()
            version = clase_MyDB.conectar(query, datos, True)

            if version[0] == "ok":
                if version[1]!=False:
                    lista = []
                    for usu in version[1]:
                        usu = MAE_TIPO_USU.from_list(usu)
                        lista.append(usu.get_diccionario())
                else:
                    lista = {}
                    lista["result"] = "failed"
                    lista["error"] = "Sucedio un error"
                    lista["error_cod"] = 412
                    lista["val_errors"] = "Lista vacia"
            else:
                lista = {}
                lista["result"] = "failed"
                lista["error"] = "Sucedio un error"
                lista["error_cod"] = 412
                lista["val_errors"] = str(version[1])
        except Exception as e:
            lista = {}
            lista["result"] = "failed"
            lista["error"] = "Sucedio un error"
            lista["error_cod"] = 412
            lista["val_errors"] = str(e)
        finally:
            return lista

    #modifica datos de la tabla tipo usuarios
    def modificar(self):
        try:
            query = (
                'UPDATE "MAE_TIPO_USU" SET tusu_desc = COALESCE(%s,tusu_desc),'
                "tusu_estado = COALESCE(%s,tusu_estado) WHERE tusu_id = %s"
            )
            datos = self._get_update_tuple()
            respu = self.clase_MyDB.conectar(query, datos, False)

            if respu[0] == "ok":
                lista = ["ok", " "]
            else:
                lista = ["error", str(respu[1])]
        except psycopg2.DatabaseError as e:
            lista = ["error", str(e)]

        except Exception as e:
            print(str(e))
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            lista = [
                "error",
                str(e)
                + " - "
                + str(exc_type)
                + " - "
                + str(fname)
                + " - "
                + str(exc_tb.tb_lineno),
            ]
        else:
            lista = ["ok", ""]
        finally:
            return lista

    #borra el dato seleccionado en el tipo usuario
    def borrar(self):
        try:
            query = 'DELETE FROM "MAE_TIPO_USU" WHERE tusu_id = %s'
            datos = (self.tusu_id,)
            respu = self.clase_MyDB.conectar(query, datos, False)
            if respu[0] == "ok":
                lista = {}
                lista["result"] = "ok"  # +str(respu)
            else:
                lista = {}
                lista["result"] = "failed"
                lista["error"] = "Sucedio un error"
                lista["error_cod"] = 505
                lista["val_errors"] = str(respu[1])
        except Exception as e:
            lista = {}
            lista["result"] = "failed"
            lista["error"] = "Sucedio un error"
            lista["error_cod"] = 505
            lista["val_errors"] = str(e)
        finally:
            return lista


    # El metodo crea un objeto a partir de una lista mandada por la base de datos
    @staticmethod
    def from_list(lista):
        tusu = MAE_TIPO_USU(tusu_id=lista[0], tusu_desc=lista[1], tusu_estado=lista[2])
        return tusu

    # Crea un tusu de MAE_TIPO_USU a partir de un diccionario json,
    # los datos del json deben tener los mismos nombres que en la clase
    # tipo_usu
    @staticmethod
    def from_json(json):
        tusu = MAE_TIPO_USU()
        dicc_tusu = vars(tusu)
        for key, value in json.items():
            if type(value) is str:
                if len(value) <= 0:
                    value = None
                else:
                    pass
            else:
                pass
            dicc_tusu[key] = value
        return tusu
