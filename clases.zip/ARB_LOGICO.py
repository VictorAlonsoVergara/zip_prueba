import psycopg2
import sys,os 
import logging
import datetime
from MyDB import MyDB

#clase que gestiona la tabla arbol logico
class ARB_LOGICO :
	#se inicializa
	def __init__(self,log_id=None,log_id_padre=None,log_desc=None,log_orden=None):
	
		self.log_id = log_id #integer
		self.log_id_padre = log_id_padre #integer
		self.log_desc = log_desc #varchar(200)
		self.log_orden = log_orden #varchar(30)
		self.clase_MyDB = MyDB()
	
	#devuelve datos importantes de arbol logico
	def get_diccionario(self):
		diccionario = vars(self)
		diccionario.pop('clase_MyDB')
		return diccionario

	#guarda datos en la tabla de arbol logico
	def guardar_dato(self):
		try:
			
			if (self.log_id_padre!="NULL"):
				datos = (self.log_id_padre,self.log_desc,self.log_orden,)
				query='INSERT INTO "ARB_LOGICO" (log_id_padre,log_desc,log_orden) VALUES (%s,%s,%s) RETURNING log_id'
			else :
				datos = (self.log_desc,self.log_orden,)
				query='INSERT INTO "ARB_LOGICO" (log_id_padre,log_desc,log_orden) VALUES (NULL,%s,%s) RETURNING log_id'
			version = self.clase_MyDB.conectar(query,datos,False)
			if version[0] == 'ok':
				self.log_id = version[1][0][0]
				dato = ['ok',' ']
			else:
				dato = ['error',str(version[1])]
			
		except Exception as e:
			dato = ['error',str(e)]
		finally:
			return dato

	#busca datos en la tabla de arbol logico
	def buscar_dato(self):
		try:
			datos=(self.log_id,)
			query='SELECT * FROM "ARB_LOGICO" WHERE log_id = %s'
			version = self.clase_MyDB.conectar(query,datos,True)
			if (version[0] == 'ok'):
				if (version[1]!=False):
					self.log_id_padre = version[1][0][1] #integer
					self.log_desc = version[1][0][2] #integer
					self.log_orden = version[1][0][3] #integer
					
					dato = ['ok',' ']
				else:
					dato = ['error', 'No se encontro un elemento en ARB_LOGICO con ese ID']
			else:
				dato = ['error', str(version[1])]
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]				
			dato = ['error',str(e)+' - '+str(exc_type)+' - '+str(fname)+' - '+str(exc_tb.tb_lineno)]
		finally:
			return dato
	
	#valida antes de crear
	@staticmethod
	def validations_crear(log_id_padre):
		try:
			if (log_id_padre == ""):
				dato = [True,'ok']
			else:
				datos=(log_id_padre,)
				query='SELECT * FROM "ARB_LOGICO" WHERE log_id = %s'
				clase_MyDB = MyDB()
				version = clase_MyDB.conectar(query,datos,True)
				if (version[0]=='ok'):
					if (version[1]!=False): #ya existe 
						dato = [True,'ok']
					else:
						dato = [False,'No existe un arb_logico con ese log_id_padre']
				else:
					dato = ['error', 'Error con la base de datos']         
		except Exception as e:
			dato = [False,str(e)]
		finally:
			return dato

	#consulta la lista de la tabla arb logico
	@staticmethod
	def consultar_lista():
		try:
			query='SELECT * FROM "ARB_LOGICO"'
			datos=()
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)
			if (version[0]=='ok'):
				if (version[1]!=False):
					lista = []
					for arb in version[1]:
						data = {}
						arb_logico = ARB_LOGICO.from_list(arb)
						data.update(arb_logico.get_diccionario())
						lista.append(data)
				else:
					lista = {}
					lista["result"] = "failed"
					lista["error"] = "Sucedio un error"
					lista["error_cod"] = 412
					lista["val_errors"] = "Lista vacia"
			else:
				lista = {}
				lista["result"] = "failed"
				lista["error"] = "Sucedio un error en la base de datos"
				lista["error_cod"] = 412
				lista['val_errors']=str(version[1])
					
		except Exception as e:
			lista = {}
			lista["result"] = "failed"
			lista["error"] = "Sucedio un error"
			lista["error_cod"] = 412
			lista['val_errors'] =str(e)
		finally:
			return lista

	#validacion antes de borrar
	@staticmethod
	def validations_borrar(log_id):
		try:
			query='SELECT * FROM "ARB_LOGICO" WHERE log_id_padre =%s'
			datos= (log_id,)
			clase_MyDB = MyDB()
			version = clase_MyDB.conectar(query,datos,True)
			if (version[0] == 'ok'):
				if (version[1]!=False): #si existe 
					dato = [False,'No se puede eliminar un log_id_padre']
				else:
					dato = [True,'ok']
		except Exception as e:
			dato = [False,str(e)]
		finally:
			return dato

	#modifica el dato seleccionado en arb logico
	def modificar(self):
		try:
			if self.log_id_padre != "NULL":
				pass_flag = True
				arb_aux = ARB_LOGICO(log_id=self.log_id_padre)
				dict_padres = arb_aux.buscar_padres()
				if dict_padres['result'] == 'failed':
					lista = ['error',dict_padres['val_errors']]
					return lista
				lista_padres = dict_padres['listas']
				for objeto in lista_padres:
					try:
						id_padre = objeto['padre']
						if id_padre == self.log_id:
							pass_flag = False
							break
					except Exception:
						pass
				if pass_flag is False:
					lista = ['error','Referencia circular encontrada ingrese otro id de padre']
					return lista
			if ((self.log_id_padre)!="NULL"):
				query = ('UPDATE "ARB_LOGICO" SET log_id_padre= COALESCE(%s,log_id_padre) ,'
					' log_desc=COALESCE(%s,log_desc), log_orden=COALESCE(%s,log_orden) WHERE log_id = %s') 
				datos= (self.log_id_padre,self.log_desc,self.log_orden,self.log_id,)
			else:
				query= 'UPDATE "ARB_LOGICO" SET log_id_padre= NULL ,log_desc= COALESCE(%s,log_desc), log_orden= COALESCE(%s,log_orden) WHERE log_id = %s'
				datos= (self.log_desc,self.log_orden,self.log_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)
			if (respu[0]=='ok'):
				lista = ['ok',' ']
			else:
				lista = ['error','Error en la base de datos']	
		except Exception as e:
			lista = ['error',str(e)]
		finally:
			return lista

	#borra el dato de arbol logico seleccionado
	def borrar(self):
		try:
			query = 'DELETE FROM "ARB_LOGICO" WHERE log_id= %s'
			datos=(self.log_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)	
			if (respu[0] == 'ok'):
				lista = {}
				lista['result']='ok'#+str(respu)
			else:
				lista = {}
				lista['result']='failed'
				lista['error']='Sucedio un error'
				lista['error_cod']=505
				lista['val_errors']=str(respu[1])	
		except Exception as e:
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)
		finally:
			return lista

	#borra la rama seleccionado de arbol logico
	def borrar_rama(self):
		try:
			function = 'call borrar_rama_arbol_logico(%s,%s)'
			params = (self.log_id,[],)
			resultado = self.clase_MyDB.conectar(function,params,True)
			respuesta = {}
			if resultado[0] == 'ok':
				if resultado[1] is not False:
					respuesta['result'] = 'ok'
					respuesta['listas'] = resultado[1][0][0]
				else:
					respuesta['result'] = 'failed'
					respuesta['error'] = 'Sucedio un error'
					respuesta['error_cod'] = 501
					respuesta['val_errors'] = 'No se encontro elementos'
			else:
				respuesta['result'] = 'failed'
				respuesta['error'] = 'Sucedio un error'
				respuesta['error_cod'] = 502
				respuesta['val_errors'] = str(resultado[1])
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			respuesta = {}
			respuesta['result']='failed'
			respuesta['error']='Sucedio un error'
			respuesta['error_cod']=505
			respuesta['val_errors']=str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)
		finally:
			return respuesta

	#busca los padres del arbol seleccionado
	def buscar_padres(self):
		resultado = self.__execute_buscar('buscar_padres_arbol_logico')
		return resultado

	#busca los hijos del arbol seleccionado
	def buscar_hijos(self):
		resultado = self.__execute_buscar('buscar_hijos_arbol_logico')
		return resultado

	#funcion para ejecutar un procedure
	def __execute_buscar(self, function):
		try:
			funct = function
			datos = [self.log_id]
			resultado = self.clase_MyDB.execute_procedure(funct, datos)
			result_lista = []
			if resultado[0] == 'ok':
				if resultado[1] is not False:
					for nodos in resultado[1]:
						data = {}
						data['padre'] = nodos[1]
						data['hijo'] = nodos[0]
						if nodos[1] != None :
							result_lista.append(data)
					respuesta = {}
					respuesta['result'] = 'ok'
					respuesta['listas'] = result_lista
				else:
					respuesta = {}
					respuesta['listas'] = ''
					respuesta['result'] = 'failed'
					respuesta['error'] = 'Sucedio un error'
					respuesta['val_errors'] = 'No se obtuvo resultados'
			else:
				respuesta = {}
				respuesta['result'] = 'failed'
				respuesta['error'] = 'Sucedio un error'
				respuesta['cod'] = 502
				respuesta['val_errors'] = 'Error en la base de datos ' + str(resultado)
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			respuesta = {}
			respuesta['result']='failed'
			respuesta['error']='Sucedio un error'
			respuesta['error_cod']=503
			respuesta['val_errors']=str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)
		finally:
			return respuesta

	#busca a los hermanos del dato selccionado en arbol logico
	def buscar_hermanos(self):
		try:
			flag = False
			listas = []
			cad = {}
			cad["hijo"] = self.log_id
			#listas.append("el hijo es "+str(self.id_obj_hijo))
			listas.append(cad)
			temp = self.log_id
			query = 'SELECT (log_id_padre) FROM "ARB_LOGICO" WHERE log_id = %s'
			datos = (temp,)
			respu3 = self.clase_MyDB.conectar(query,datos,True)
			if (respu3[0]=='ok' and respu3[1] != False ):
				cad = {}
				cad["padre"] = respu3[1][0][0]
				listas.append(cad)
				temp = respu3[1][0][0]
				query = 'SELECT (log_id) FROM "ARB_LOGICO" WHERE log_id_padre = %s AND log_id != %s'
				datos = (temp,self.log_id)
				respu2 = self.clase_MyDB.conectar(query,datos,True)
				if (respu2[0]=='ok'):
					if (respu2[1]!=False):
						cad = {}
						temporal = []
						for re in respu2[1] :
							temporal.append(re[0])
						cad["hermanos"] = temporal
						listas.append(cad)
						#listas = respu2[1]
						respu = ['ok',' ']
					else:
						listas = "No tiene hermanos el Id seleccionado"
						respu = ['ok','error']

				else:
					listas = "Sucedio un error buscando a los hijos"
					respu = ['ok','error']
			else:
				listas = "No existe un hijo con ese Id"
				respu = ['error','No existe un hijo con ese Id']

			if (respu[0] == 'ok'):
				lista = {}
				lista['result']='ok'#+str(respu)
				if (respu[1] == 'error'):
					lista.pop("result")
					lista['result']='failed'
					lista['error']='Sucedio un error'
					lista['error_cod']=505
					lista['val_errors']= listas
				else:
					lista['listas'] = listas				
			else:
				lista = {}
				lista['result']='failed'
				lista['error']='Sucedio un error'
				lista['error_cod']=505
				lista['val_errors']='Error '+ str(respu[1])
		except Exception as e:
			exc_type, exc_obj, exc_tb = sys.exc_info()
			fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)+ " - "+ str(exc_type)+ " - "+ str(fname)+ " - "+ str(exc_tb.tb_lineno)
		finally:
			return lista

	def borrar_foraneo(self): # elimina el objeto ARB_LOGICO y asigna NULL al atributo id_obj_padre de sus hijos
		try:
			query= 'UPDATE "ARB_LOGICO" SET log_id_padre= NULL WHERE log_id_padre = %s'
			datos=(self.log_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)	

			query = 'DELETE FROM "ARB_LOGICO" WHERE log_id= %s'
			datos=(self.log_id,)
			respu = self.clase_MyDB.conectar(query,datos,False)	
			if (respu[0] == 'ok'):
				lista = {}
				lista['result']='ok'#+str(respu)
			else:
				lista = {}
				lista['result']='failed'
				lista['error']='Sucedio un error'
				lista['error_cod']=505
				lista['val_errors']='Error en la base de datos'	
		except Exception as e:
			lista = {}
			lista['result']='failed'
			lista['error']='Sucedio un error'
			lista['error_cod']=505
			lista['val_errors']=str(e)
		finally:
			return lista

	#crea la clase con un array
	@staticmethod
	def from_list(lista):
		arb_logico = ARB_LOGICO(
			log_id=lista[0],
			log_id_padre =lista[1],
			log_desc=lista[2],
			log_orden=lista[3]
		)
		return arb_logico

	#Crea un objeto de ARB_LOGICO a partir de un diccionario json, los datos del json
	#deben tener los mismos nombres que en la clase arb_logico
	@staticmethod
	def from_json(json):
		arb_logico = ARB_LOGICO()
		diccio_arb_logico = vars(arb_logico)
		for key,value in json.items():
			if type(value) is str:
				if len(value) <= 0:
					value = None
			diccio_arb_logico[key] = value
		return arb_logico




